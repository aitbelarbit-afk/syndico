import { Apartment } from '../types';

export interface PaymentDueAlertConfig {
  isEnabled: boolean;
  dueDayOfMonth: number; // e.g. 5 or 10
  remindDaysBefore: number[]; // e.g. [7, 3, 0]
  preferredChannel: 'both' | 'whatsapp' | 'email' | 'sms';
  
  // Residence & Bank Info for payments
  bankName: string;
  bankAccountName: string;
  bankRib: string;
  contactPhone: string;
  contactEmail: string;

  // Custom Templates (Arabic)
  whatsappTemplateAr: string;
  emailSubjectTemplateAr: string;
  emailBodyTemplateAr: string;
  smsTemplateAr: string;

  // Custom Templates (French)
  whatsappTemplateFr: string;
  emailSubjectTemplateFr: string;
  emailBodyTemplateFr: string;
  smsTemplateFr: string;

  lastBatchDispatchDate?: string;
  logs: PaymentDueNotificationLog[];
}

export interface PaymentDueNotificationLog {
  id: string;
  apartmentId: string;
  apartmentNumber: string;
  buildingCode: string;
  residentName: string;
  phone: string;
  email: string;
  channel: 'whatsapp' | 'email' | 'sms' | 'both';
  periodMonth: string;
  periodLabel: string;
  amount: number;
  dueDate: string;
  daysRemaining: number;
  status: 'sent' | 'scheduled' | 'skipped_no_contact';
  sentAt: string;
  messagePreview: string;
}

export interface UpcomingDueResidentItem {
  apartment: Apartment;
  residentName: string;
  phone: string;
  email: string;
  periodKey: string; // e.g. "2026-08"
  periodLabelAr: string; // e.g. "غشت 2026"
  periodLabelFr: string; // e.g. "Août 2026"
  monthlyFee: number;
  totalDue: number;
  dueDate: string; // YYYY-MM-DD
  dueDateFormatted: string;
  daysRemaining: number;
  urgency: 'passed' | 'today' | 'imminent' | 'upcoming';
  isPaid: boolean;
}
