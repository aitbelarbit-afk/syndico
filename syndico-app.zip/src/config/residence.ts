// ============================================================
// Syndico — marque de l'application + profil de la résidence
// Le profil est saisi par chaque syndic (menu « Profil de la résidence »)
// et stocké sur l'appareil. Aucune donnée d'une résidence n'est codée en dur.
// ============================================================

export const APP_BRAND = {
  nameAr: 'سنديكو',
  nameFr: 'Syndico',
  taglineAr: 'منصة تدبير الإقامات والسانديك',
  taglineFr: 'Plateforme de gestion de copropriété'
};

export interface ResidenceProfile {
  nameAr: string;
  nameFr: string;
  fullNameAr: string;
  fullNameFr: string;
  cityAr: string;
  cityFr: string;
  addressAr: string;
  addressFr: string;
  email: string;
  phone: string;
  bankName: string;
  bankRib: string;
}

export const RESIDENCE_PROFILE_KEY = 'syndico_residence_profile';

const DEFAULT_PROFILE: ResidenceProfile = {
  nameAr: 'إقامتي',
  nameFr: 'Ma Résidence',
  fullNameAr: 'إقامتي',
  fullNameFr: 'Ma Résidence',
  cityAr: '',
  cityFr: '',
  addressAr: '',
  addressFr: '',
  email: '',
  phone: '',
  bankName: '',
  bankRib: ''
};

export function hasResidenceProfile(): boolean {
  try {
    return typeof window !== 'undefined' && !!window.localStorage.getItem(RESIDENCE_PROFILE_KEY);
  } catch {
    return false;
  }
}

export function loadResidenceProfile(): ResidenceProfile {
  try {
    if (typeof window !== 'undefined') {
      const raw = window.localStorage.getItem(RESIDENCE_PROFILE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        return { ...DEFAULT_PROFILE, ...parsed };
      }
    }
  } catch {
    /* ignore */
  }
  return { ...DEFAULT_PROFILE };
}

export function saveResidenceProfile(p: ResidenceProfile) {
  const clean: ResidenceProfile = {
    nameAr: p.nameAr.trim() || DEFAULT_PROFILE.nameAr,
    nameFr: p.nameFr.trim() || DEFAULT_PROFILE.nameFr,
    fullNameAr: (p.fullNameAr || p.nameAr).trim() || DEFAULT_PROFILE.fullNameAr,
    fullNameFr: (p.fullNameFr || p.nameFr).trim() || DEFAULT_PROFILE.fullNameFr,
    cityAr: p.cityAr.trim(),
    cityFr: p.cityFr.trim(),
    addressAr: p.addressAr.trim(),
    addressFr: p.addressFr.trim(),
    email: p.email.trim(),
    phone: p.phone.trim(),
    bankName: (p.bankName || '').trim(),
    bankRib: (p.bankRib || '').trim()
  };
  window.localStorage.setItem(RESIDENCE_PROFILE_KEY, JSON.stringify(clean));
}

// Accès pratique : RES.nameAr, RES.nameFr, RES.cityFr ... (lu à chaque accès)
export const RES = {
  get nameAr() { return loadResidenceProfile().nameAr; },
  get nameFr() { return loadResidenceProfile().nameFr; },
  get fullNameAr() { return loadResidenceProfile().fullNameAr; },
  get fullNameFr() { return loadResidenceProfile().fullNameFr; },
  get cityAr() { return loadResidenceProfile().cityAr; },
  get cityFr() { return loadResidenceProfile().cityFr; },
  get addressAr() { return loadResidenceProfile().addressAr; },
  get addressFr() { return loadResidenceProfile().addressFr; },
  get email() { return loadResidenceProfile().email; },
  get phone() { return loadResidenceProfile().phone; },
  get bankName() { return loadResidenceProfile().bankName; },
  get bankRib() { return loadResidenceProfile().bankRib; }
};

// Clé de récupération du compte syndic (définie par le syndic, jamais codée en dur)
export const RECOVERY_KEY_STORAGE = 'syndico_recovery_key';
export function getRecoveryKey(): string {
  try { return (typeof window !== 'undefined' && window.localStorage.getItem(RECOVERY_KEY_STORAGE)) || ''; } catch { return ''; }
}
export function setRecoveryKey(k: string) {
  window.localStorage.setItem(RECOVERY_KEY_STORAGE, k.trim());
}
