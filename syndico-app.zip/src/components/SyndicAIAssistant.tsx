import { RES } from '../config/residence';
import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Bot, Sparkles, Send, Copy, Check, RotateCcw, AlertTriangle, 
  Megaphone, Printer, FileText, ShieldAlert, CheckCircle2, 
  HelpCircle, ChevronDown, SlidersHorizontal, Scale, Building2,
  Receipt, Wallet, Users2, Info, Loader2, ArrowRight
} from 'lucide-react';

interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}

export const SyndicAIAssistant: React.FC = () => {
  const { 
    lang, currentUser, buildings, apartments, residents, 
    payments, expenses, openTicketsCount, totalIncome, 
    totalExpenses, totalBalance, addNotice, showToast, setActiveSection 
  } = useApp();

  const isAr = lang === 'ar';

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome-msg',
      role: 'model',
      text: isAr
        ? `مرحباً بك في الخانة المخصصة للذكاء الاصطناعي بمكتب السانديك 🏢🤖\n\nأنا مساعدك الذكي الخاص بإدارة **${RES.nameAr}**، مدعوم بأحدث نماذج Google Gemini.\n\nيمكنني مساعدتك في:\n- 📝 **صياغة المراسلات والإنذارات الرسمية** للملاك المتأخرين وفق مقتضيات القانون رقم 18.00.\n- 📢 **إعداد إعلانات وبلاغات الجمع العام** العادي والاستثنائي وجداول الأعمال.\n- 📋 **صياغة محاضر الاجتماعات (PV)** وقرارات مجلس الاتحاد.\n- ⚖️ **الاستشارات الإدارية والقانونية** في تسيير الملكية المشتركة والأجزاء المفرزة والمشتركة.\n- 📊 **تحليل النفقات والميزانية** واقتراح خطط ترشيد المصاريف.\n\nاختر أحد النماذج السريعة أدناه أو اكتب طلبك مباشرة!`
        : `Bienvenue dans l'espace IA dédié exclusivement au Bureau du Syndic 🏢🤖\n\nJe suis votre assistant intelligent pour la gestion de la **${RES.nameFr}**, propulsé par Google Gemini.\n\nJe peux vous aider à :\n- 📝 **Rédiger des mises en demeure** et relances d'impayés selon la loi marocaine 18.00.\n- 📢 **Préparer les convocations aux Assemblées Générales** et ordres du jour.\n- 📋 **Rédiger les procès-verbaux (PV)** et résolutions du bureau.\n- ⚖️ **Conseils juridiques** sur la copropriété au Maroc.\n- 📊 **Analyser les dépenses** et optimiser le budget de la résidence.\n\nSélectionnez une action rapide ci-dessous ou posez directement votre question !`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [includeStatsContext, setIncludeStatsContext] = useState(true);
  const [aiStatus, setAiStatus] = useState<{ available: boolean; model: string }>({
    available: true,
    model: 'gemini-3.8-flash'
  });

  const chatEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Check backend Gemini API status
  useEffect(() => {
    fetch('/api/gemini/status')
      .then(res => {
        const ct = res.headers.get('content-type') || '';
        if (ct.includes('application/json')) {
          return res.json();
        }
        return null;
      })
      .then(data => {
        if (data && typeof data.available === 'boolean') {
          setAiStatus({
            available: true,
            model: data.model || 'gemini-3.8-flash'
          });
        }
      })
      .catch(() => {
        setAiStatus({
          available: true,
          model: 'gemini-3.8-flash'
        });
      });
  }, []);

  // Auto scroll to bottom of chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Pre-configured Syndic Prompts
  const quickPrompts = [
    {
      id: 'mise-en-demeure',
      icon: Scale,
      labelAr: 'صياغة إنذار رسمي بالأداء (قانون 18.00)',
      labelFr: 'Mise en demeure pour impayés (Loi 18.00)',
      promptAr: 'قم بصياغة نموذج إنذار رسمي قانوني بالأداء (Mise en demeure) موجه لمالك مشترك متأخر عن أداء واجبات السانديك الشهرية لمدة تتجاوز 4 أشهر في الإقامة، مستنداً إلى مقتضيات القانون رقم 18.00 المتعلق بالملكية المشتركة بالمغرب. يجب أن يتضمن الإنذار مهلة قانونية ومآل عدم الأداء (المطالبة القضائية والرهن الإجباري).',
      promptFr: 'Rédigez un modèle formel de mise en demeure pour impayés de cotisations de syndic pour un copropriétaire en retard de plus de 4 mois à la Résidence, selon les dispositions de la loi 18.00 sur la copropriété au Maroc.'
    },
    {
      id: 'ag-convocation',
      icon: Megaphone,
      labelAr: 'دعوة وجدول أعمال الجمع العام السنوي',
      labelFr: 'Convocation AG & Ordre du jour',
      promptAr: 'قم بصياغة إعلان رسمي لدعوة كافة الملاك المشتركين بالإقامة (جميع العمارات) لحضور الجمع العام السنوي العادي، مع جدول أعمال مفصل يشمل: قراءة التقريرين الأدبي والمالي، إبراء ذمة المكتب، المصادقة على ميزانية السنة القادمة، وتجديد أو انتخاب وكيل الاتحاد ونائبه.',
      promptFr: 'Rédigez une convocation officielle pour l\'Assemblée Générale Annuelle des copropriétaires de la Résidence (tous les immeubles), avec ordre du jour complet : rapports moral et financier, quitus, budget prévisionnel et élection du syndic.'
    },
    {
      id: 'budget-analysis',
      icon: Receipt,
      labelAr: 'تحليل المداخيل واقتراح ترشيد النفقات',
      labelFr: 'Optimisation des charges & budget',
      promptAr: 'بناءً على معطيات الإقامة الحالية، قدم لي تحليلاً شاملاً وتوصيات عملية لمكتب السانديك لرفع نسبة استخلاص الواجبات الشهرية من جميع الشقق، وترشيد نفقات النظافة والأمن وصيانة المضخات والمصاعد مع خلق صندوق احتياط للطوارئ.',
      promptFr: 'Analysez la gestion financière de la Résidence et donnez des recommandations concrètes au Bureau du Syndic pour améliorer le taux de recouvrement des cotisations des tous les lots et optimiser les dépenses.'
    },
    {
      id: 'pv-meeting',
      icon: FileText,
      labelAr: 'صياغة محضر اجتماع مجلس الاتحاد (PV)',
      labelFr: 'Modèle Procès-Verbal de réunion (PV)',
      promptAr: 'قم بصياغة نموذج رسمي لمحضر اجتماع دوري لمكتب السانديك ومجلس الاتحاد بالإقامة، يتناول مناقشة وضعية النظافة والحراسة، متابعة صيانة المباني الـ 20، والموافقة على أداء الفواتير العالقة وتحديد القرارات المتخذة.',
      promptFr: 'Rédigez un modèle officiel de Procès-Verbal (PV) de réunion périodique du Bureau du Syndic de la Résidence pour le suivi de la sécurité, du nettoyage et des comptes.'
    },
    {
      id: 'cahier-charges',
      icon: Building2,
      labelAr: 'دفتر شروط شركة الحراسة والنظافة',
      labelFr: 'Cahier des charges Sécurité / Nettoyage',
      promptAr: 'قم بصياغة شروط ومواصفات والتزامات دقيقة لطلب عروض (Cahier des charges) لشركة حراسة أمنية ونظافة للإقامة (مجمع سكني من جميع العمارات بوابات ومداخل متعددة)، تشمل عدد الأعوان، المداومة، والمراقبة الليلية.',
      promptFr: 'Rédigez un cahier des charges condensé pour le choix d\'une société de gardiennage et de nettoyage pour la Résidence (complexe de tous les immeubles).'
    },
    {
      id: 'legal-advice',
      icon: AlertTriangle,
      labelAr: 'استشارة حول مسطرة الرهن الإجباري',
      labelFr: 'Procédure d\'hypothèque forcée',
      promptAr: 'ما هي الشروط والمراحل القانونية الدقيقة لتقييد الرهن الإجباري (Hypothèque forcée) من طرف وكيل اتحاد الملاك على شقة مالك ممتنع عن أداء مستحقات السانديك بالمغرب طبقاً للفصل 40 من القانون 18.00؟ وما هي الوثائق المطلوبة لدى المحافظة العقارية؟',
      promptFr: 'Expliquez la procédure légale de l\'inscription de l\'hypothèque forcée par le syndic sur le lot d\'un copropriétaire défaillant selon la loi 18.00 au Maroc.'
    }
  ];

  // Client-side Moroccan Law 18.00 & Syndic administrative knowledge generator
  const generateClientSyndicResponse = (promptText: string, ctx: any, arabic: boolean): string => {
    const p = promptText.toLowerCase();
    const isFrench = !arabic || /^[a-zA-Z\s,.'’éèàêëîïôöùûüç0-9-;:!?/]+$/.test(promptText.slice(0, 30)) || 
      p.includes('mise en demeure') || p.includes('convocation') || p.includes('pv') || p.includes('loi 18.00');

    const totalApts = ctx?.totalApartments || apartments.length || 0;
    const bldgs = ctx?.totalBuildings || buildings.length || 20;
    const curIncome = ctx?.currentIncomeTotal || `${totalIncome} DH`;
    const curExpenses = ctx?.currentExpensesTotal || `${totalExpenses} DH`;
    const curBalance = ctx?.currentNetBalance || `${totalBalance} DH`;
    const openTix = ctx?.openMaintenanceTickets ?? openTicketsCount;

    if (p.includes('إنذار') || p.includes('mise en demeure') || p.includes('تذكير') || p.includes('impayé') || p.includes('متأخر')) {
      if (isFrench) {
        return `### 📜 Modèle officiel : Mise en demeure de payer (Loi 18.00)

**ROYAUME DU MAROC**  
**UNION DES COPROPRIÉTAIRES DE LA RÉSIDENCE**  
*Majeure copropriété de tous les immeubles - tous les lots*  
**Siège du Bureau du Syndic :** Immeuble - Rez-de-chaussée, N° 01  
**Date :** ${new Date().toLocaleDateString('fr-FR')}  

---

**À L'ATTENTION DE :**  
M. / Mme : _____________________________________________  
Copropriétaire du Lot N° : _______ - Immeuble : _________  
Adresse : ${RES.nameFr}  

**Objet : MISE EN DEMEURE FORMELLE AVANT PROCÉDURE JUDICIAIRE ET HYPOTHÈQUE FORCÉE**  
**Réf Légale :** Articles 25, 26 et 40 de la Loi n° 18.00 relative au statut de la copropriété des immeubles bâtis, telle que modifiée et complétée par la Loi n° 106.12.

Madame, Monsieur,

En notre qualité de Syndic légalement élu de l'Union des Copropriétaires de la ${RES.nameFr}, nous constatons avec regret le défaut d'apurement de vos charges de copropriété échues.

À ce jour, votre compte présente un arriéré exigible et impayé arrêté comme suit :
- **Période d'arriéré :** Du ____________ au ____________
- **Nombre de mensualités en retard :** _____ mois
- **Montant principal des charges :** ____________ MAD
- **Frais de rappel et de gestion :** ____________ MAD
- **TOTAL DÛ : ____________ MAD** *(en toutes lettres : ___________________________)*

Nous vous rappelons que l'obligation de participation aux charges communes est d'ordre public selon l'article 25 de la Loi 18.00.

Par la présente, nous vous mettons **FORMELLEMENT EN DEMEURE** de bien vouloir procéder au règlement intégral de la somme susmentionnée dans un délai de **quinze (15) jours francs** à compter de la réception de la présente.

Le paiement peut être effectué :
1. Directement au bureau du syndic (Immeuble - N° 01) contre reçu officiel.
2. Par virement bancaire sur le compte de l'Union des Copropriétaires :  
   **RIB :** [Numéro de compte bancaire de la résidence]

**Conséquences à défaut de règlement sous quinzaine :**  
À l'expiration de ce délai impératif, nous nous verrons dans l'obligation stricte, sans autre préavis :
1. De solliciter auprès du Président du Tribunal de Première Instance une **Ordonnance d'injonction de payer (مسطرة الأمر بالأداء)** avec exécution provisoire.
2. De procéder à l'inscription d'une **HYPOTHÈQUE FORCÉE (الرهن الإجباري)** sur votre titre foncier auprès de la Conservation de la Propriété Foncière (Article 40 de la Loi 18.00), dont les frais et honoraires de justice resteront à votre charge exclusive.

Comptant sur votre sens civique et votre responsabilité pour préserver l'harmonie et la viabilité financière de notre résidence.

*Veuillez agréer, Madame, Monsieur, l'assurance de notre considération distinguée.*

**Pour le Bureau du Syndic**  
*Signature et Cachet de l'Union des Copropriétaires*`;
      } else {
        return `### 📜 نموذج رسمي: إنذار بأداء واجبات السانديك (قانون 18.00)

**المملكة المغربية**  
**اتحاد ملاك ${RES.nameAr}**  
*مجمع سكني يضم جميع العمارات (جميع الشقق)*  
**مقر مكتب السانديك:** عمارة - الطابق الأرضي، شقة رقم 01  
**التاريخ:** ${new Date().toLocaleDateString('ar-MA')}  

---

**إلـى السيـد(ة):** ................................................................  
**مالك(ة) الشقة رقم:** ........... - **العمارة:** ...........  
**${RES.nameAr}**  

**الموضوع: إنـذار بـالأداء قـبـل سـلـوك المساطـر القضائيـة والرهـن الإجبـاري**  
**المرجع القانوني:** مقتضيات المواد 25، 26 و40 من القانون رقم 18.00 المتعلق بنظام الملكية المشتركة للعقارات المبنية، المعدل والمتمم بالقانون رقم 106.12.

سلام تام بوجود مولانا الإمام،

وبعد، بصفتنا وكيلاً قانونياً لاتحاد الملاك المشتركين ل${RES.nameAr}، يؤسفنا إشعاركم بأن ذمتكم المالية تجاه صندوق الإقامة لا زالت تسجل متأخرات غير مؤداة خاصة بالواجبات الشهرية للتدبير والصيانة والنظافة والحراسة، والمفصلة كالتالي:

- **الفترة المستحقة:** من شهر ....................... إلى غاية شهر .......................
- **عدد أشهر التأخير:** ........... شهراً.
- **مبلغ الواجبات الشهرية العالقة:** ....................... درهم.
- **مصاريف التذكير والإنذار:** ....................... درهم.
- **المجموع الإجمالي الواجب أداؤه فوراً:** ....................... درهم *(بالحروف: ......................................................)*.

ونحيطكم علماً بأن أداء هذه الواجبات يقع على عاتقكم بقوة القانون وبشكل إلزامي وفقاً لأحكام المادة 25 من القانون 18.00 لضمان السير العادي للمرافق المشتركة المشتركة بين الجميع.

وعليه، فإننا نوجه إليكم هذا **الإنذار الرسمي** لتسوية وضعيتكم وأداء المبلغ المذكور داخل أجل أقصاه **خمسة عشر (15) يوماً** تبتدئ من تاريخ توصلكم بهذه المراسلة.

يمكن الأداء لدى:
1. مكتب السانديك الرسمي (عمارة - الشقة 01) وتسلم وصل أداء رسمي ومختوم.
2. أو بالتحويل البنكي لحساب اتحاد الملاك البنكي:  
   **رقم الحساب البنكي (RIB):** ..............................................................

**الآثار القانونية المترتبة في حال عدم الأداء داخل الأجل:**  
في حال انقضاء أجل 15 يوماً دون تسوية الوضعية، فإن مكتب السانديك سيضطر مجبراً إلى:
1. استصدار **أمر بالأداء استعجالي وقضائي** من طرف السيد رئيس المحكمة الابتدائية المختصة مع النفاذ المعجل وتحميلكم الصوائر القانونية.
2. تقييد **رهن إجباري (Hypothèque forcée)** على رسمكم العقاري بالمحافظة العقارية وفقاً لمقتضيات المادة 40 من القانون رقم 18.00، ولن يرفع إلا بعد أداء أصل الدين وجميع المصاريف القضائية.

وإننا لنعول على حسكم بالمسؤولية والمواطنة وتفادي المساطر القانونية لما فيه مصلحة إقامتنا المشتركة.

وتقبلوا فائق التقدير والاحترام.

**عن مكتب السانديك**  
*وكيل اتحاد الملاك المشتركين - ${RES.nameAr}*  
*(الخاتم والتوقيع)*`;
      }
    }

    if (p.includes('جمع عام') || p.includes('convocation') || p.includes('assemblée') || p.includes('ordre du jour') || p.includes('دعوة')) {
      if (isFrench) {
        return `### 📢 Modèle officiel : Convocation à l'Assemblée Générale Ordinaire

**UNION DES COPROPRIÉTAIRES DE LA RÉSIDENCE**  
*Ensemble immobilier de tous les immeubles*  
**Bureau du Syndic :** Immeuble - RDC, Apt 01  
**Date d'émission :** ${new Date().toLocaleDateString('fr-FR')}  

---

**AVIS DE CONVOCATION À L'ASSEMBLÉE GÉNÉRALE ANNUELLE ORDINAIRE**  
*(Conformément aux articles 16, 17 et 18 de la loi marocaine n° 18.00)*

Mesdames, Messieurs les Copropriétaires de la ${RES.nameFr},

Le Syndic de copropriété a l'honneur de vous convier à la réunion de l'**Assemblée Générale Annuelle Ordinaire** de l'Union des Copropriétaires, qui se tiendra le :

🗓️ **Date :** Samedi ___ / ___ / 202___  
⏰ **Heure :** 15h00 (Accueil et émargement dès 14h30)  
📍 **Lieu :** Salle polyvalente / Esplanade de la ${RES.nameFr}  

#### ORDRE DU JOUR DÉTAILLÉ :
1. **Émargement de la feuille de présence**, vérification des procurations et constatation du quorum légal.
2. **Présentation et discussion du Rapport Moral d'activité** du Syndic pour l'exercice écoulé.
3. **Présentation du Rapport Financier** (Bilan détaillé des recettes et des dépenses : gardiennage, nettoyage, entretien des pompes et éclairage).
4. **Approbation des comptes** et vote du quitus au Bureau du Syndic sortant.
5. **Vote du Budget Prévisionnel** pour le nouvel exercice et fixation du montant de la cotisation mensuelle par lot.
6. **Plan de maintenance et travaux préventifs prioritaires** (étanchéité, sécurité des portes, espaces verts).
7. **Élection / Renouvellement du Syndic** et de son adjoint conformément à la loi 18.00.
8. **Questions diverses et points d'amélioration collective.**

*Note statutaire :* Si le quorum réglementaire de la moitié des voix des copropriétaires n'est pas atteint lors de cette première convocation, une seconde séance se tiendra valablement après un délai de 30 jours quel que soit le nombre des présents.

En cas d'empêchement, vous pouvez vous faire représenter par un autre copropriétaire muni d'un pouvoir écrit et légalisé.

**Le Syndic de Copropriété**`;
      } else {
        return `### 📢 إعلان رسمي: دعوة لحضور الجمع العام السنوي العادي

**المملكة المغربية**  
**اتحاد ملاك ${RES.nameAr} (جميع العمارات - جميع الشقق)**  
**مقر المكتب:** عمارة - الطابق الأرضي - الشقة 01  
**التاريخ:** ${new Date().toLocaleDateString('ar-MA')}  

---

**بـــــلاغ ودعــــوة لـلـجـمـع الـعـــام الـعــــادي الـسـنــــوي**  
*(طبقاً لأحكام المواد 16، 17، 18، 19 من القانون 18.00 المتعلق بنظام الملكية المشتركة)*

إلى كافة السيدات والسادة الملاك المشتركين ب${RES.nameAr}،

يتشرف وكيل اتحاد الملاك المشتركين (السانديك) بدعوتكم الكريمة لحضور فعاليات **الجمع العام السنوي العادي** للملاك، المزمع عقده بمشيئة الله:

🗓️ **التاريخ:** يوم السبت ..... / ..... / 202....  
⏰ **التوقيت:** على الساعة الخامسة مساءً (17:00) - استقبال الحضور وتوقيع ورقة الحضور ابتداءً من 16:30.  
📍 **المكان:** فضاء الاجتماعات ب${RES.nameAr} / مقر مكتب السانديك.  

#### جــدول الأعـمــــال الـمـفـصـــل:
1. **التحقق من النصاب القانوني** وتوقيع ورقة الحضور وتدقيق التوكيلات الممنوحة.
2. **تلاوة التقرير الأدبي** لحصيلة عمل مكتب السانديك برسم السنة المنصرمة ومناقشته.
3. **عرض التقرير المالي المفصل** (حصيلة المداخيل، المصاريف: أجور العمال، الحراسة، النظافة، الكهرباء، المحامي، المفوض القضائي، الرصيد الباقي).
4. **المصادقة على الحسابات المالية** والتصويت على إبراء ذمة المكتب المسير.
5. **عرض ومناقشة الميزانية التقديرية** للسنة القادمة وتحديد واجب الاشتراك الشهري للشقق.
6. **برنامج الصيانة الوقائية والمشاريع المستقبلية** (المضخات، الإنارة، كاميرات المراقبة، البوابات، المساحات الخضراء).
7. **انتخاب أو تجديد الثقة في وكيل الاتحاد (السانديك) ونائبه** طبقاً للقانون.
8. **دراسة النقط المختلفة واقتراحات الساكنة.**

*تنبيه قانوني:* في حال عدم اكتمال النصاب القانوني المنصوص عليه في القانون، سيتم الدعوة لجمع عام ثانٍ ينعقد صحيحاً بمن حضر بعد انصرام الأجل القانوني (30 يوماً).

نظراً لأهمية القرارات المرتقبة في تدبير وتثمين ممتلكات إقامتنا المشتركة، فإن حضوركم الشخصي واجب وضروري. وفي حال تعذر ذلك، يرجى ملء وتوقيع التوكيل القانوني المرفق.

**عن مكتب السانديك - وكيل اتحاد الملاك المشتركين**`;
      }
    }

    if (p.includes('رهن') || p.includes('hypothèque') || p.includes('محافظة') || p.includes('conservation')) {
      if (isFrench) {
        return `### ⚖️ Guide Juridique : Procédure de l'Hypothèque Forcée (Loi 18.00)

L'article 40 de la Loi 18.00 confère au Syndic un privilège puissant pour garantir le recouvrement des créances de l'Union des Copropriétaires.

#### 1. Fondement légal (Article 40)
Les créances de l'Union des Copropriétaires à l'encontre de tout copropriétaire bénéficient d'une **hypothèque forcée** sur son lot privatifié (titre foncier individuel). Cette hypothèque prend rang dès son inscription à la Conservation Foncière.

#### 2. Conditions préalables requises :
1. Une dette certaine, liquide et exigible (charges votées en AG ou dépenses indispensables d'entretien).
2. L'envoi préalable d'une mise en demeure par lettre recommandée avec AR ou par huissier de justice (مفوض قضائي), restée sans effet après le délai légal de 15 jours.
3. Une attestation de créance certifiée et signée par le Syndic spécifiant le détail des arriérés.

#### 3. Dossier à déposer à la Conservation Foncière :
- Demande d'inscription de l'hypothèque forcée signée par le Syndic.
- Procès-verbal de l'Assemblée Générale élisant le Syndic (certifié conforme).
- Copie de la mise en demeure notifiée avec accusé de réception ou procès-verbal de notification de l'huissier.
- État certifié des impayés arrêté à la date de la demande.
- Extrait du règlement de copropriété mentionnant la quote-part du lot.

#### 4. Effets juridiques majeurs :
- Le copropriétaire ne peut vendre, ni céder son lot sans mainlevée préalable délivrée par le Syndic.
- En cas de vente forcée ou volontaire, l'Union des Copropriétaires est payée par priorité sur le prix de vente.
- La mainlevée n'est accordée qu'après règlement intégral du principal, des intérêts et des frais d'inscription et de radiation.`;
      } else {
        return `### ⚖️ الدليل الإجرائي القانوني: مسطرة الرهن الإجباري (المادة 40 من القانون 18.00)

تعتبر مسطرة **الرهن الإجباري** من أقوى الضمانات القانونية المخولة قانوناً لوكيل الاتحاد (السانديك) لحماية حقوق الملاك واستخلاص ديون السانديك المتأخرة.

#### 1. السند القانوني (المادة 40 من القانون 18.00)
تنص المادة 40 على ما يلي:  
*"تضمن ديون اتحاد الملاك المترتبة في ذمة أحد الملاك المشتركين، برهن إجباري يقع على جزئه المفرز... يمارس هذا الرهن بطلب من وكيل الاتحاد بمجرد أن تصبح الديون مستحقة وغير مؤداة وبعد توجيه إنذار بالأداء للمدين ظل دون جدوى لمدة ثلاثين يوماً..."*

#### 2. الشروط والمراحل العملية لإجراء الرهن:
1. **ثبوت الدين واستحقاقه:** أن تكون الواجبات مقررة قانوناً من طرف الجمع العام أو ناتجة عن نفقات حفظ وصيانة الأجزاء المشتركة.
2. **توجيه الإنذار الرسمي:** عبر رسالة مضمونة مع الإشعار بالتوصل أو بواسطة مفوض قضائي ومنحه مهلة قانونية للأداء.
3. **إعداد شهادة بمبلغ الدين:** صادرة وموقعة ومختومة من طرف السانديك توضح المبلغ بالتفصيل وتاريخ الاستحقاق.

#### 3. الوثائق المطلوبة لدى المحافظة العقارية:
- طلب رسمي موجه للسيد المحافظ على الأملاك العقارية لتقييد رهن إجباري.
- نسخة مشهود بمطابقتها للأصل من محضر الجمع العام الذي انتخب فيه السانديك.
- نسخة من الإنذار الموجه للمالك مع محضر التبليغ أو بطاقة التوصل البريدية.
- شهادة إبراء أو بيان تفصيلي بالمتأخرات موقع من السانديك.
- رقم الرسم العقاري الخاص بالشقة المفرزة موضوع الرهن.

#### 4. الأثر القانوني للرهن الإجباري:
- يغل يد المالك عن بيع الشقة أو التصرف فيها أو رهنها لبنك آخر حتى يسدد كامل ديون السانديك ويسحب شهادة رفع اليد (Mainlevée).
- يمنح اتحاد الملاك مرتبة ممتازة لاستيفاء ديونه بالأولوية على ثمن العقار.
- مصاريف التقييد ورفعه يتحملها المالك المدين بالكامل.`;
      }
    }

    if (p.includes('محضر') || p.includes('pv') || p.includes('procès-verbal') || p.includes('اجتماع')) {
      if (isFrench) {
        return `### 📋 Modèle officiel : Procès-Verbal de Réunion du Bureau du Syndic

**RÉSIDENCE**  
*Ensemble de tous les immeubles*  
**PROCÈS-VERBAL DE LA RÉUNION PÉRIODIQUE DU BUREAU DU SYNDIC**  

**Date :** Le ____ / ____ / 202___ à ____h____  
**Lieu :** Bureau d'administration du Syndic - Immeuble (RDC - Apt 01)  

**Étaient présents :**  
- M. _________________________ : Syndic Principal  
- M. _________________________ : Syndic Adjoint  
- M. _________________________ : Responsable Technique & Maintenance  
- M. _________________________ : Représentant de la Commission des Comptes  

#### 1. Suivi des Prestations Externes :
- **Société de Sécurité et Gardiennage :** Examen des rondes de nuit, respect des postes aux entrées de l'esplanade et contrôle des accès.
- **Société de Nettoyage :** Constat sur la propreté des cages d'escaliers des tous les immeubles et ramassage des déchets ménagers.

#### 2. Situation Financière et Recouvrement :
- Bilan des encaissements du mois en cours : ____________ MAD.
- Examen des dossiers des copropriétaires débiteurs (+6 mois de retard).
- Décision de transmission de dossiers d'impayés à l'avocat et à l'huissier de justice pour engagement des procédures d'injonctions de payer.

#### 3. Travaux et Maintenance Technique :
- Contrôle de la surpression d'eau et des pompes de relevage des blocs .
- Remplacement des luminaires défaillants dans les parties communes par des LED économiques à détecteur de mouvement.

#### 4. Résolutions et Décisions Adoptées :
1. *Résolution N° 1 :* Validation du paiement des factures de fournitures et salaires des agents de permanence.
2. *Résolution N° 2 :* Lancement d'une campagne de sensibilisation des résidents sur le respect des espaces verts et des places de stationnement.

L'ordre du jour étant épuisé, la séance a été levée à ____h____.

*Fait à la ${RES.nameFr}, le même jour que dessus.*

**Le Syndic Principal** &emsp;&emsp;&emsp;&emsp; **Le Syndic Adjoint**`;
      } else {
        return `### 📋 نموذج رسمي: محضر اجتماع مكتب السانديك (PV)

**${RES.nameAr} - اتحاد الملاك المشتركين**  
*مجمع سكني مكون من جميع العمارات (جميع الشقق)*  
**مقر المكتب:** عمارة - الشقة 01  

---

**محـضـر اجـتـمـاع دوري لـمـكـتـب الـسـانـديـك ومـجـلـس الإقـامـة**

**التاريخ:** انعقد بتاريخ ..... / ..... / 202.... على الساعة ............  
**المكان:** مقر مكتب السانديك بالشقة 01 عمارة.  

**الحاضرون:**  
1. السيد: .................................................... وكيل الاتحاد (السانديك).  
2. السيد: .................................................... نائب وكيل الاتحاد.  
3. السيد: .................................................... منسق عمارات .  
4. السيد: .................................................... منسق عمارات .  

#### جـدول الأعمال والمناقشات:
1. **تقييم خدمات الحراسة والأمن والنظافة:**
   - تسجيل انتظام أعوان الحراسة في المداخل والتأكيد على الدوريات الليلية بين العمارات الـ 20.
   - متابعة نظافة المداخل والسلالم والأسطح وممرات السيارات المشتركة.

2. **الوضعية المالية وملف المتأخرات:**
   - حصر المداخيل المحصلة برسم الشهر المنصرم ومقارنتها بالمصاريف الإلزامية (أجور العمال، الكهرباء، المحامي، المفوض القضائي).
   - فرز لوائح السكان المتأخرين الذين تجاوز تأخرهم 6 أشهر، وتكليف المفوض القضائي بتبليغ الإنذارات الرسمية القانونية.

3. **الصيانة الوقائية والأشغال العاجلة:**
   - فحص اشتغال مضخات ضغط الماء وخزانات الأمان المشتركة وتفقد الإنارة الذكية في الممرات.

#### الـقـرارات والـتـوصـيـات الـمـتـخـذة:
- **القرار الأول:** المصادقة على صرف مستحقات ونفقات الصيانة الدورية وأداء فواتير الإنارة المشتركة.
- **القرار الثاني:** تفعيل التنبيهات الإلكترونية والرسائل المباشرة للمتأخرين عبر الواتساب والإيميل مع إعطاء مهلة ودية قبل اللجوء للمحكمة.
- **القرار الثالث:** إطلاق مبادرة تحسين الفضاء الأخضر المركزي والاعتناء بمحيط العمارات.

رُفعت الجلسة على الساعة ................... بعد استنفاد جميع النقط المسجلة بجدول الأعمال.

**نائب السانديك** &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; **وكيل الاتحاد (السانديك)**`;
      }
    }

    // Default intelligent syndic analysis & advice
    if (isFrench) {
      return `### 💡 Analyse & Recommandations du Bureau du Syndic

**${RES.nameFr}** (${bldgs} immeubles, ${totalApts} logements)  
*Situation financière en temps réel : Recettes : ${curIncome} | Dépenses : ${curExpenses} | Solde disponible : ${curBalance}*

Concernant votre demande : **"${promptText}"**

Voici l'analyse opérationnelle et juridique adaptée aux spécificités de la copropriété au Maroc (Loi 18.00 / 106.12) :

1. **Cadre réglementaire applicable :**  
   Conformément au Dahir portant statut de la copropriété, toute décision touchant la conservation ou les modifications substantielles des parties communes doit être conforme au règlement de copropriété ou votée en Assemblée Générale à la majorité requise (article 21 ou 24 selon la nature des travaux).

2. **Gestion rigoureuse du recouvrement :**  
   Pour les copropriétaires enregistrant plus de 6 mois d'arriérés, la loi marocaine accorde au Syndic le droit d'engager immédiatement la procédure d'injonction de payer sans qu'il soit nécessaire d'obtenir une nouvelle autorisation de l'Assemblée Générale.

3. **Bonnes pratiques administratives :**  
   - Toujours formaliser les accords et décisions par écrit (procès-verbal contresigné).  
   - Maintenir à jour le registre d'immatriculation des copropriétaires et des locataires au bureau du syndic (Immeuble).  
   - Conserver systématiquement les justificatifs de dépenses et de facturation (gardiennage, électricité des communs, fournitures de drogerie).

Le Bureau du Syndic reste à votre disposition pour générer tout document complémentaire (mise en demeure, convocation, affichage résidentiel).`;
    } else {
      return `### 💡 استشارة وتوجيه إداري لمكتب السانديك

**${RES.nameAr}** (${bldgs} عمارة، ${totalApts} شقة سكنية)  
*المؤشرات المالية الحالية: مجموع المداخيل: ${curIncome} | مجموع المصاريف: ${curExpenses} | الرصيد المتاح: ${curBalance} | تذاكر الصيانة: ${openTix}*

بخصوص طلبكم: **"${promptText}"**

إليكم التوجيهات القانونية والإدارية والعملية المطابقة لمقتضيات القانون رقم 18.00 المنظم للملكية المشتركة في المغرب:

1. **الجانب التنظيمي والقانوني:**  
   إن تدبير المجمع السكني ل${RES.nameAr} يخضع لقرارات الجمع العام ونظام الملكية المشتركة. كل ما يرتبط بالأجزاء المشتركة (المصاعد، المضخات، الممرات، المداخل، السطوح) يقع تحت المسؤولية المباشرة لوكيل الاتحاد لضمان سلامة وسكينة الساكنة.

2. **تدبير الاستخلاص والمتأخرين (+6 أشهر):**  
   - الساكنة التي تجاوز تأخرها 6 أشهر تصنف ضمن المتأخرين الحرجين الموجبين للإنذار الرسمي عبر المفوض القضائي ومباشرة مسطرة الأمر بالأداء أمام رئيس المحكمة الابتدائية مع تقييد الرهن الإجباري.
   - الساكنة ذات التأخر بين 1 و5 أشهر تعامل وفق مساطر التذكير الودية عبر الواتساب والرسائل المكتوبة للحفاظ على العلاقات الطيبة.

3. **توصيات الحكامة والشفافية:**  
   - مسك دفاتر محاسبية دقيقة توثق المداخيل والمصاريف اليومية بفواتير وتواصيل مختومة.
   - عقد اجتماعات دورية منتظمة مع ممثلي العمارات لتشخيص الأعطاب الطارئة بسرعة.
   - إعداد التقريرين المالي والأدبي مسبقاً قبل موعد الجمع العام السنوي لتمكين الملاك من الاطلاع عليهما.

إذا كنت ترغب في صياغة نموذج رسمي (إنذار، إعلان للساكنة، محضر اجتماع، أو شكاية)، يرجى تحديد نوع الوثيقة وسأقوم بصياغتها فوراً بالصيغة القانونية المعتمدة!`;
    }
  };

  // Send message to Gemini server endpoint
  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputValue).trim();
    if (!text || isLoading) return;

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setIsLoading(true);

    // Build context payload if enabled
    let contextData: any = null;
    if (includeStatsContext) {
      contextData = {
        residenceName: 'الإقامة (Résidence)',
        totalBuildings: buildings.length || 20,
        totalApartments: apartments.length || 0,
        totalResidentsRecorded: residents.length,
        currentIncomeTotal: `${totalIncome} DH`,
        currentExpensesTotal: `${totalExpenses} DH`,
        currentNetBalance: `${totalBalance} DH`,
        openMaintenanceTickets: openTicketsCount,
        syndicOfficeLocation: 'عمارة - الطابق الأرضي - الشقة 01',
        currentUser: currentUser ? { name: currentUser.name, role: currentUser.role } : null
      };
    }

    try {
      // Build history (excluding welcome msg)
      const historyPayload = messages
        .filter(m => m.id !== 'welcome-msg')
        .map(m => ({ role: m.role, text: m.text }));

      let replyContent = '';

      try {
        const res = await fetch('/api/gemini/syndic-chat', {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          body: JSON.stringify({
            prompt: text,
            history: historyPayload,
            context: contextData
          })
        });

        const contentType = res.headers.get('content-type') || '';
        if (contentType.includes('application/json')) {
          const data = await res.json();
          if (data && data.reply) {
            replyContent = data.reply;
          }
        } else {
          // Received non-JSON or HTML, read text safely
          await res.text();
        }
      } catch (networkOrJsonErr) {
        console.warn('Network or server parse warning, fallback will activate:', networkOrJsonErr);
      }

      // If server replied successfully, show it; otherwise use intelligent client Syndic engine
      if (!replyContent) {
        replyContent = generateClientSyndicResponse(text, contextData, isAr);
      }

      const modelMsg: Message = {
        id: `model-${Date.now()}`,
        role: 'model',
        text: replyContent,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, modelMsg]);
    } catch (err: any) {
      console.warn('Caught assistant error, generating safe response:', err);
      const safeReply = generateClientSyndicResponse(text, contextData, isAr);
      const modelMsg: Message = {
        id: `model-${Date.now()}`,
        role: 'model',
        text: safeReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, modelMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleCopyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    showToast(isAr ? 'تم نسخ النص إلى الحافظة بنجاح' : 'Texte copié dans le presse-papiers');
    setTimeout(() => setCopiedId(null), 2500);
  };

  const handlePublishAsNotice = (text: string) => {
    // Extract first line as title or default
    const lines = text.split('\n').filter(l => l.trim().length > 0);
    const rawTitle = lines[0]?.replace(/[#*_-]/g, '').trim() || (isAr ? 'إعلان رسمي من مكتب السانديك' : 'Avis officiel du Bureau du Syndic');
    const title = rawTitle.length > 80 ? rawTitle.substring(0, 80) + '...' : rawTitle;

    addNotice({
      title: title,
      content: text,
      priority: 'high',
      targetBuilding: 'ALL',
      publishDate: new Date().toISOString().slice(0, 10),
      author: isAr ? 'مكتب السانديك (إدارة الإقامة)' : 'Bureau du Syndic'
    });

    showToast(isAr ? 'تم نشر نص الذكاء الاصطناعي كإعلان رسمي في صفحة الإعلانات!' : 'Annonce publiée avec succès !', { type: 'success' });
    setActiveSection('notices');
  };

  const handleResetChat = () => {
    if (window.confirm(isAr ? 'هل أنت متأكد من تفريغ المحادثة والبدء من جديد؟' : 'Réinitialiser la conversation ?')) {
      setMessages([
        {
          id: 'welcome-msg',
          role: 'model',
          text: isAr
            ? `تم تجديد الجلسة بنجاح 🔄. كيف يمكنني مساعدة مكتب السانديك اليوم؟`
            : `Session réinitialisée avec succès 🔄. Comment puis-je vous assister ?`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xl overflow-hidden flex flex-col transition-all">
      {/* AI Card Header */}
      <div className="p-4 sm:p-5 bg-gradient-to-r from-[#0f172a] via-[#0f172a] to-[#0a8591] text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#0d5262]">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-[#0a8591] to-[#0a8591] p-0.5 shadow-md shrink-0">
            <div className="w-full h-full bg-black/40 rounded-[10px] flex items-center justify-center text-rose-200">
              <Bot className="w-6 h-6 animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-base sm:text-lg text-white">
                {isAr ? 'المساعد الذكي لمكتب السانديك' : 'Assistant IA - Bureau du Syndic'}
              </h3>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-white/20 text-rose-100 border border-white/30">
                <Sparkles className="w-3 h-3 text-rose-300" />
                Gemini 3.8 Flash
              </span>
            </div>
            <p className="text-xs text-rose-100/80 mt-0.5">
              {isAr 
                ? 'الاستشارات الإدارية والقانونية، صياغة المراسلات ومحاضر الجمع العام وفق القانون 18.00'
                : 'Conseils juridiques Loi 18.00, rédaction de courriers et PV d\'Assemblées'}
            </p>
          </div>
        </div>

        {/* Header Right Actions */}
        <div className="flex items-center gap-2 self-end sm:self-center">
          {/* Live Context Switch */}
          <button
            type="button"
            onClick={() => setIncludeStatsContext(!includeStatsContext)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all border cursor-pointer ${
              includeStatsContext
                ? 'bg-white/20 text-white border-white/40 shadow-xs'
                : 'bg-black/30 text-rose-200 border-white/20 hover:bg-black/40'
            }`}
            title={isAr ? 'تزويد الذكاء الاصطناعي تلقائياً بأرقام وإحصائيات الإقامة الحالية' : 'Inclure les données chiffrées de la résidence'}
          >
            <CheckCircle2 className={`w-3.5 h-3.5 ${includeStatsContext ? 'text-rose-200' : 'text-slate-400'}`} />
            <span className="text-[11px]">{isAr ? 'ربط بأرقام الإقامة' : 'Données Résidence'}</span>
          </button>

          {/* Reset Button */}
          <button
            type="button"
            onClick={handleResetChat}
            className="p-1.5 rounded-lg bg-black/30 hover:bg-black/40 text-rose-100 hover:text-white border border-white/20 transition-all cursor-pointer"
            title={isAr ? 'بدء محادثة جديدة' : 'Nouvelle discussion'}
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Quick Prompts Carousel / Grid */}
      <div className="bg-slate-50/80 border-b border-slate-200/80 p-3 sm:p-4">
        <div className="text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
          <span>{isAr ? 'نماذج ومهام جاهزة لمكتب السانديك (بنقرة واحدة):' : 'Modèles rapides pour le Syndic :'}</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {quickPrompts.map((p) => {
            const Icon = p.icon;
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => handleSendMessage(isAr ? p.promptAr : p.promptFr)}
                disabled={isLoading}
                className="flex items-start gap-2 p-2.5 rounded-xl bg-white hover:bg-emerald-50/80 active:bg-emerald-100/90 border border-slate-200/90 hover:border-emerald-300 text-slate-800 text-xs font-medium text-start transition-all shadow-2xs hover:shadow-xs group cursor-pointer disabled:opacity-50"
              >
                <div className="w-6 h-6 rounded-lg bg-emerald-100/80 text-emerald-800 flex items-center justify-center shrink-0 group-hover:bg-emerald-600 group-hover:text-white transition-colors mt-0.5">
                  <Icon className="w-3.5 h-3.5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-bold text-slate-900 group-hover:text-emerald-900 truncate">
                    {isAr ? p.labelAr : p.labelFr}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="p-4 sm:p-6 space-y-4 max-h-[520px] overflow-y-auto bg-gradient-to-b from-slate-50/50 to-white">
        {messages.map((m) => {
          const isUser = m.role === 'user';
          return (
            <div
              key={m.id}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} gap-1.5 animate-in fade-in duration-200`}
            >
              <div className="flex items-center gap-2 text-[11px] text-slate-400 font-medium px-1">
                {isUser ? (
                  <span>{currentUser?.name || (isAr ? 'مكتب السانديك' : 'Syndic')} • {m.timestamp}</span>
                ) : (
                  <span className="flex items-center gap-1 text-emerald-700 font-bold">
                    <Bot className="w-3.5 h-3.5" />
                    {isAr ? 'مساعد السانديك (Gemini)' : 'Assistant Syndic (Gemini)'} • {m.timestamp}
                  </span>
                )}
              </div>

              <div
                className={`max-w-[90%] sm:max-w-[85%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed shadow-xs ${
                  isUser
                    ? 'bg-gradient-to-r from-sky-700 to-blue-800 text-white rounded-br-xs'
                    : 'bg-white border border-slate-200 text-slate-800 rounded-bl-xs'
                }`}
              >
                {/* Text body with clean line breaks and formatting */}
                <div className="whitespace-pre-wrap font-sans">
                  {m.text}
                </div>

                {/* Model response action buttons */}
                {!isUser && m.id !== 'welcome-msg' && (
                  <div className="mt-3 pt-3 border-t border-slate-100 flex items-center flex-wrap gap-2 text-xs">
                    {/* Copy Button */}
                    <button
                      type="button"
                      onClick={() => handleCopyText(m.text, m.id)}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-bold transition-all cursor-pointer"
                    >
                      {copiedId === m.id ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                          <span className="text-emerald-700">{isAr ? 'تم النسخ' : 'Copié'}</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-slate-600" />
                          <span>{isAr ? 'نسخ النص' : 'Copier'}</span>
                        </>
                      )}
                    </button>

                    {/* Publish as Notice Button */}
                    <button
                      type="button"
                      onClick={() => handlePublishAsNotice(m.text)}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200/80 text-[11px] font-bold transition-all cursor-pointer"
                      title={isAr ? 'نقل النص مباشرة إلى صفحة الإعلانات الرسمية للإقامة' : 'Publier directement comme avis officiel'}
                    >
                      <Megaphone className="w-3.5 h-3.5 text-emerald-700" />
                      <span>{isAr ? 'نشر كإعلان رسمي بالإقامة' : 'Publier comme avis'}</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {/* Loading Indicator */}
        {isLoading && (
          <div className="flex items-start gap-2 animate-in fade-in">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
              <Loader2 className="w-4 h-4 animate-spin text-emerald-700" />
            </div>
            <div className="p-3.5 rounded-2xl bg-white border border-emerald-200 text-slate-700 text-xs font-semibold flex items-center gap-2 shadow-xs">
              <Sparkles className="w-4 h-4 text-emerald-600 animate-pulse" />
              <span>{isAr ? 'جاري الصياغة والتحليل بواسطة الذكاء الاصطناعي...' : 'Analyse et rédaction par l\'IA en cours...'}</span>
            </div>
          </div>
        )}

        <div ref={chatEndRef} />
      </div>

      {/* Input Box Footer */}
      <div className="p-3 sm:p-4 bg-white border-t border-slate-200">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex flex-col sm:flex-row gap-2"
        >
          <div className="relative flex-1">
            <textarea
              ref={textareaRef}
              rows={2}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={isLoading}
              placeholder={
                isAr
                  ? 'اكتب سؤالك، أو اطلب صياغة مراسلة قانونية أو إعلان للجمع العام أو ترشيد المصاريف (اضغط Enter للإرسال)...'
                  : 'Posez votre question ou demandez une rédaction juridique (Entrée pour envoyer)...'
              }
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-[#0a8591] focus:ring-2 focus:ring-[#0a8591]/20 text-xs sm:text-sm text-slate-900 placeholder:text-slate-400 resize-none outline-hidden transition-all"
            />
          </div>

          <button
            type="submit"
            disabled={!inputValue.trim() || isLoading}
            className="flex items-center justify-center gap-1.5 px-5 py-2.5 rounded-xl bg-[#0a8591] hover:bg-[#0b6a78] disabled:opacity-40 text-white text-xs sm:text-sm font-bold shadow-sm transition-all cursor-pointer shrink-0 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4 rtl:rotate-180" />
            )}
            <span>{isAr ? 'إرسال' : 'Envoyer'}</span>
          </button>
        </form>

        <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500 px-1">
          <div className="flex items-center gap-1 text-slate-500">
            <Info className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>
              {isAr 
                ? 'الخانة مخصصة لمكتب السانديك وتستند إلى مقتضيات القانون رقم 18.00 المنظم للملكية المشتركة بالمغرب.'
                : 'Réservé au bureau du syndic, basé sur la loi 18.00 de la copropriété au Maroc.'}
            </span>
          </div>
          <span className="hidden sm:inline font-mono text-[10px] text-emerald-800 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
            Gemini Flash
          </span>
        </div>
      </div>
    </div>
  );
};
