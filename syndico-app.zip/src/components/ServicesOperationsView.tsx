import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { MaintenanceView } from './MaintenanceView';
import { NoticesView } from './NoticesView';
import { EmployeesView } from './EmployeesView';
import { ArchiveView } from './ArchiveView';
import { 
  Wrench, Megaphone, UserCheck, Archive, ShieldCheck, 
  Layers, ChevronRight, Sparkles 
} from 'lucide-react';
import { ConciergeBell as HeaderIcon } from 'lucide-react';

interface ServicesOperationsViewProps {
  initialTab?: 'maintenance' | 'notices' | 'employees' | 'archive';
}

export const ServicesOperationsView: React.FC<ServicesOperationsViewProps> = ({ 
  initialTab = 'maintenance' 
}) => {
  const { lang, currentUser, openTicketsCount, totalArchivedCount, setActiveSection } = useApp();
  const isAr = lang === 'ar';
  const isOwner = currentUser?.role === 'resident';

  const [activeTab, setActiveTab] = useState<'maintenance' | 'notices' | 'employees' | 'archive'>(initialTab);

  const tabs = [
    {
      id: 'maintenance' as const,
      label: isAr ? 'الصيانة والشكايات' : 'Maintenance & Réclamations',
      icon: Wrench,
      count: openTicketsCount > 0 ? openTicketsCount : null,
      countAlert: true,
      description: isAr ? 'متابعة الأعطال والشكايات والتدخلات التقنية' : 'Suivi des pannes et interventions'
    },
    {
      id: 'notices' as const,
      label: isAr ? 'الإعلانات والقرارات' : 'Annonces & Décisions',
      icon: Megaphone,
      description: isAr ? 'نشر وتوثيق البلاغات وقرارات الجمع العام' : 'Diffusions et décisions du Syndic'
    },
    ...(isOwner ? [] : [
      {
        id: 'employees' as const,
        label: isAr ? 'العمال والتنقيط' : 'Personnel & Pointage',
        icon: UserCheck,
        description: isAr ? 'حراس الأمن وعمال النظافة وسجل الرواتب' : 'Agents de sécurité, ménage et salaires'
      },
      {
        id: 'archive' as const,
        label: isAr ? 'الأرشيف والنظام' : 'Archive & Historique',
        icon: Archive,
        count: totalArchivedCount > 0 ? totalArchivedCount : null,
        countAlert: false,
        description: isAr ? 'سجل المحذوفات والنسخ الاحتياطي' : 'Historique des suppressions'
      }
    ])
  ];

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 font-medium mb-1">
            <span 
              onClick={() => setActiveSection('dashboard')}
              className="hover:text-emerald-700 cursor-pointer"
            >
              {isAr ? 'الرئيسية' : 'Accueil'}
            </span>
            <ChevronRight className={`w-3.5 h-3.5 ${isAr ? 'rotate-180' : ''}`} />
            <span className="text-emerald-800 font-bold">
              {isAr ? 'الخدمات والعمليات الميدانية' : 'Services & Opérations'}
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <span className="icon-wiggle anim-bob w-10 h-10 rounded-2xl bg-gradient-to-br from-sky-400 to-sky-600 text-white flex items-center justify-center shadow-md shrink-0"><HeaderIcon className="w-5 h-5" /></span><span>{isAr ? 'إدارة العمليات والخدمات الميدانية' : 'Gestion des Services & Opérations'}</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            {isAr 
              ? 'فضاء موحد وشامل لمتابعة الصيانة، الإعلانات الرسمية، تدبير العمال والأرشيف للإقامة'
              : 'Hub centralisé pour la maintenance, la diffusion d\'annonces et le personnel'}
          </p>
        </div>

        {/* Tab Controls */}
        <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-100 rounded-xl border border-slate-200 shrink-0">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`
                  flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer
                  ${isActive 
                    ? 'bg-white text-emerald-900 shadow-xs border border-slate-200/80' 
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }
                `}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-700' : 'text-slate-500'}`} />
                <span>{tab.label}</span>
                {tab.count !== null && tab.count !== undefined && (
                  <span className={`text-[10px] font-black px-1.5 py-0.2 rounded-full ${tab.countAlert ? 'bg-rose-100 text-rose-700' : 'bg-slate-200 text-slate-700'}`}>
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Dynamic Tab Body */}
      <div className="transition-all">
        {activeTab === 'maintenance' && <MaintenanceView />}
        {activeTab === 'notices' && <NoticesView />}
        {activeTab === 'employees' && !isOwner && <EmployeesView />}
        {activeTab === 'archive' && !isOwner && <ArchiveView />}
      </div>
    </div>
  );
};
