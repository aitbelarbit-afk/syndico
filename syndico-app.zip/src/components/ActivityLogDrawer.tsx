import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Activity, Trash2, RotateCcw, X, 
  PlusCircle, Edit, Trash, FileClock, Lock
} from 'lucide-react';
import { format } from 'date-fns';
import { fr, ar } from 'date-fns/locale';

interface ActivityLogDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ActivityLogDrawer: React.FC<ActivityLogDrawerProps> = ({ isOpen, onClose }) => {
  const { lang, activities, trash, restoreFromTrash } = useApp();
  const [activeTab, setActiveTab] = useState<'activity' | 'trash'>('activity');

  if (!isOpen) return null;

  const dateLocale = lang === 'ar' ? ar : fr;

  const renderIcon = (action: string) => {
    switch (action) {
      case 'CREATE': return <PlusCircle className="w-4 h-4 text-emerald-500" />;
      case 'UPDATE': return <Edit className="w-4 h-4 text-blue-500" />;
      case 'DELETE': return <Trash className="w-4 h-4 text-rose-500" />;
      case 'RESTORE': return <RotateCcw className="w-4 h-4 text-amber-500" />;
      case 'LOGOUT': return <Lock className="w-4 h-4 text-rose-500" />;
      default: return <Activity className="w-4 h-4 text-slate-500" />;
    }
  };

  return (
    <>
      <div 
        className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm z-[9998]"
        onClick={onClose}
      />
      <div 
        className={`fixed top-0 bottom-0 ${lang === 'ar' ? 'left-0' : 'right-0'} w-full sm:w-[400px] bg-white shadow-2xl z-[9999] flex flex-col transform transition-transform duration-300 ${
          isOpen ? 'translate-x-0' : (lang === 'ar' ? '-translate-x-full' : 'translate-x-full')
        }`}
        dir={lang === 'ar' ? 'rtl' : 'ltr'}
      >
        <div className="flex items-center justify-between p-4 border-b border-rose-100 bg-gradient-to-r from-[#0a8591] to-[#8a1f33] text-white">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-white/10 text-amber-300">
              <FileClock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-sm sm:text-base leading-tight">
                {lang === 'ar' ? 'سجل النشاطات والمحذوفات' : 'Activités & Corbeille'}
              </h2>
              <p className="text-[11px] text-rose-200">
                {lang === 'ar' ? 'تتبع العمليات واسترجاع العناصر المحذوفة' : 'Historique et restauration'}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 hover:bg-white/20 rounded-lg transition-colors text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex px-4 pt-2.5 gap-2 border-b border-rose-100/80 bg-rose-50/40">
          <button
            onClick={() => setActiveTab('activity')}
            className={`px-4 py-2 text-xs sm:text-sm font-bold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'activity' 
                ? 'border-[#0a8591] text-[#0a8591]' 
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4" />
              <span>{lang === 'ar' ? 'سجل العمليات' : 'Journal'}</span>
              <span className="bg-slate-200/70 text-slate-700 px-1.5 py-0.5 rounded-full text-[10px]">
                {activities.length}
              </span>
            </div>
          </button>
          <button
            onClick={() => setActiveTab('trash')}
            className={`px-4 py-2 text-xs sm:text-sm font-bold border-b-2 transition-colors cursor-pointer ${
              activeTab === 'trash' 
                ? 'border-[#0a8591] text-[#0a8591]' 
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <div className="flex items-center gap-2">
              <Trash2 className="w-4 h-4 text-rose-600" />
              <span>{lang === 'ar' ? 'سلة المحذوفات' : 'Corbeille'}</span>
              {trash.length > 0 && (
                <span className="bg-rose-500 text-white font-black px-1.5 py-0.5 rounded-full text-[10px] animate-pulse">
                  {trash.length}
                </span>
              )}
            </div>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 bg-slate-50/30">
          {activeTab === 'activity' && (
            <div className="space-y-4">
              {activities.length === 0 ? (
                <div className="text-center py-10 text-slate-400 text-sm">
                  {lang === 'ar' ? 'لا توجد نشاطات مسجلة بعد.' : 'Aucune activité enregistrée.'}
                </div>
              ) : (
                activities.map(act => (
                  <div key={act.id} className="flex gap-3 relative">
                    <div className="flex flex-col items-center">
                      <div className="w-8 h-8 rounded-full bg-white border border-slate-200 shadow-sm flex items-center justify-center shrink-0 z-10">
                        {renderIcon(act.action)}
                      </div>
                      <div className="w-px h-full bg-slate-200 -my-1 absolute top-8 bottom-0" />
                    </div>
                    <div className="pb-4 pt-1 flex-1">
                      <div className="bg-white p-3 rounded-xl border border-slate-100 shadow-sm text-sm">
                        <p className="text-slate-800 mb-1">
                          {lang === 'ar' ? act.detailsAr : act.detailsFr}
                        </p>
                        <div className="flex items-center justify-between text-[11px] text-slate-400">
                          <span>{act.userName}</span>
                          <span>{format(new Date(act.timestamp), 'dd MMM yyyy HH:mm', { locale: dateLocale })}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'trash' && (
            <div className="space-y-3">
              {trash.length === 0 ? (
                <div className="text-center py-10 text-slate-400 text-sm">
                  <Trash2 className="w-10 h-10 mx-auto text-slate-200 mb-2" />
                  {lang === 'ar' ? 'سلة المهملات فارغة.' : 'La corbeille est vide.'}
                </div>
              ) : (
                trash.map(item => (
                  <div key={item.id} className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm flex flex-col gap-2">
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="inline-block px-2 py-0.5 bg-slate-100 text-slate-600 rounded-md text-[10px] font-bold mb-1 uppercase">
                          {item.entityType}
                        </span>
                        <p className="text-sm font-semibold text-slate-800">
                          {item.data?.title || item.data?.fullName || item.data?.number || item.data?.code || item.data?.residentName || (lang === 'ar' ? 'عنصر محذوف' : 'Élément supprimé')}
                        </p>
                      </div>
                      <button
                        onClick={() => restoreFromTrash(item.id)}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg text-xs font-bold transition-colors"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        {lang === 'ar' ? 'تراجع واسترجاع' : 'Restaurer'}
                      </button>
                    </div>
                    <div className="flex items-center justify-between text-[10px] text-slate-400 pt-2 border-t border-slate-50 mt-1">
                      <span>{lang === 'ar' ? 'حُذف بواسطة:' : 'Supprimé par:'} {item.deletedBy}</span>
                      <span>{format(new Date(item.deletedAt), 'dd MMM yyyy HH:mm', { locale: dateLocale })}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </>
  );
};
