import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  CheckCircle2, Share2, Printer, Download, Copy, Check, 
  Building2, ShieldCheck, Calendar, CreditCard, Sparkles, X, UserCheck
} from 'lucide-react';
import { Payment } from '../types';
import { formatPeriodDisplay } from '../utils/debtUtils';
import { downloadReceiptAsPdf, shareReceiptPdf, buildReceiptWhatsAppUrl } from '../utils/pdfReceiptUtils';

interface DigitalPassTicketProps {
  receipt: Payment;
  lang: 'ar' | 'fr';
  onClose?: () => void;
  onPrintA4?: () => void;
  ownerPhone?: string;
}

export const DigitalPassTicket: React.FC<DigitalPassTicketProps> = ({
  receipt,
  lang,
  onClose,
  onPrintA4,
  ownerPhone = ''
}) => {
  const [copied, setCopied] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const isAr = lang === 'ar';

  const formattedPeriod = formatPeriodDisplay(receipt.periodMonth, lang);
  const barcodeNumber = receipt.receiptNumber || `REC-${receipt.id.slice(0, 8).toUpperCase()}`;

  const handleCopy = () => {
    const text = `${isAr ? 'وصل أداء الإقامة' : 'Reçu Cotisation '}\n${isAr ? 'رقم الوصل' : 'N° Reçu'}: ${barcodeNumber}\n${isAr ? 'الساكن' : 'Résident'}: ${receipt.residentName}\n${isAr ? 'الشقة' : 'Appt'}: ${receipt.buildingCode} - ${receipt.apartmentNumber}\n${isAr ? 'الفترة' : 'Période'}: ${formattedPeriod}\n${isAr ? 'المبلغ' : 'Montant'}: ${receipt.amount} MAD\n${isAr ? 'التاريخ' : 'Date'}: ${receipt.paymentDate}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleWhatsApp = () => {
    const url = buildReceiptWhatsAppUrl(receipt, formattedPeriod, ownerPhone);
    window.open(url, '_blank');
  };

  const handleDownload = async () => {
    setIsDownloading(true);
    try {
      await downloadReceiptAsPdf('syndic-receipt-paper', receipt);
    } catch (e) {
      console.error(e);
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="flex flex-col items-center w-full max-w-sm mx-auto">
      {/* ========================================================================= */}
      {/* THE DIGITAL PASS CARD (IN THE EXACT AESTHETIC OF THE VIDEO 00:36)         */}
      {/* ========================================================================= */}
      <motion.div 
        id="digital-pass-card"
        initial={{ opacity: 0, scale: 0.92, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ type: "spring", damping: 22, stiffness: 280 }}
        className="w-full relative rounded-3xl bg-gradient-to-br from-[#0a8591] via-[#0b6a78] to-[#1e3a8a] text-white shadow-2xl overflow-hidden select-none border border-white/20"
      >
        {/* Soft Radial Glow effect */}
        <div className="absolute -top-24 -end-24 w-48 h-48 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-24 -start-24 w-48 h-48 bg-emerald-400/15 rounded-full blur-2xl pointer-events-none" />

        {/* TOP HEADER SECTION */}
        <div className="p-5 pb-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-[11px] font-bold uppercase tracking-wider text-blue-100">
                {isAr ? 'وصل أداء الإقامة الرسمي' : 'Pass Cotisation Résidence'}
              </span>
            </div>
            
            {/* Status Pill Badge */}
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/90 text-white text-[11px] font-black shadow-xs tracking-wide">
              {isAr ? 'خالص • PAYÉ' : 'RÉGLÉ • 100%'}
            </span>
          </div>

          {/* Large Origin & Destination Header */}
          <div className="space-y-1">
            <div className="text-[10px] text-blue-200 font-medium uppercase tracking-wider">
              {isAr ? 'الإقامة • الموقع الرسمي' : 'Résidence & Localisation'}
            </div>
            <div className="text-xl sm:text-2xl font-black tracking-tight leading-snug text-white">
              {isAr ? 'الإقامة' : 'Résidence'}
            </div>
            <div className="text-[11px] text-blue-200">
              {isAr ? ' • عمارات (جميع العمارات / جميع الشقق)' : ' • Immeubles - '}
            </div>
          </div>

          {/* Recipient Box */}
          <div className="mt-4 pt-3 border-t border-white/15">
            <div className="text-[10px] text-blue-200 font-medium">
              {isAr ? 'المالك / المقيم المصرح به' : 'Copropriétaire certifié'}
            </div>
            <div className="text-lg font-black text-white flex items-center gap-1.5 mt-0.5">
              <span className="truncate">{receipt.residentName}</span>
              <ShieldCheck className="w-4 h-4 text-emerald-300 shrink-0" />
            </div>
          </div>
        </div>

        {/* PERFORATED TICKET SEPARATOR WITH CUTOUT NOTCHES */}
        <div className="relative py-2 flex items-center justify-center">
          {/* Left Notch */}
          <div className="absolute -start-3.5 w-7 h-7 rounded-full bg-slate-900 border border-white/10 shadow-inner" />
          
          {/* Dotted Line */}
          <div className="w-full border-t-2 border-dashed border-white/30 mx-6" />
          
          {/* Right Notch */}
          <div className="absolute -end-3.5 w-7 h-7 rounded-full bg-slate-900 border border-white/10 shadow-inner" />
        </div>

        {/* BOTTOM DETAILS & BARCODE SECTION */}
        <div className="p-5 pt-3">
          {/* Key-Value 3-Column Grid */}
          <div className="grid grid-cols-3 gap-2 py-2">
            <div>
              <div className="text-[10px] text-blue-200 font-semibold">{isAr ? 'العمارة والشقة' : 'Appt'}</div>
              <div className="text-xs font-black text-white mt-0.5 font-mono">
                {receipt.buildingCode.replace('GH ', '')}-{receipt.apartmentNumber}
              </div>
            </div>

            <div>
              <div className="text-[10px] text-blue-200 font-semibold">{isAr ? 'شهر الأداء' : 'Période'}</div>
              <div className="text-xs font-black text-white mt-0.5 truncate">
                {formattedPeriod}
              </div>
            </div>

            <div>
              <div className="text-[10px] text-blue-200 font-semibold">{isAr ? 'المبلغ المؤدى' : 'Montant'}</div>
              <div className="text-xs font-black text-emerald-300 mt-0.5 font-mono">
                {receipt.amount} MAD
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-2 pb-3 border-t border-white/15 text-[11px]">
            <div>
              <span className="text-[10px] text-blue-200 block">{isAr ? 'تاريخ السداد' : 'Date de paiement'}</span>
              <span className="font-bold text-white font-mono">{receipt.paymentDate}</span>
            </div>
            <div>
              <span className="text-[10px] text-blue-200 block">{isAr ? 'طريقة الأداء' : 'Mode'}</span>
              <span className="font-bold text-white">
                {receipt.paymentMethod === 'cash' ? (isAr ? 'نقداً (Espèces)' : 'Espèces') : 
                 receipt.paymentMethod === 'bank_transfer' ? (isAr ? 'تحويل بنكي' : 'Virement') : 
                 receipt.paymentMethod === 'check' ? (isAr ? 'شيك' : 'Chèque') : (isAr ? 'دفع إلكتروني' : 'En ligne')}
              </span>
            </div>
          </div>

          {/* OPTICAL REALISTIC BARCODE STRIP (EXACTLY LIKE THE VIDEO 00:36) */}
          <div className="bg-white rounded-xl p-3 text-slate-900 flex flex-col items-center justify-center shadow-lg">
            {/* SVG Barcode Graphic */}
            <div className="w-full flex items-center justify-center gap-[2.5px] h-9 overflow-hidden">
              {[
                3, 1, 2, 4, 1, 3, 2, 1, 4, 2, 1, 3, 1, 4, 2, 1, 3, 2, 1, 4, 
                1, 2, 3, 1, 4, 2, 1, 3, 1, 2, 4, 1, 3, 2, 1, 4, 2, 1, 3, 2
              ].map((w, idx) => (
                <span 
                  key={idx} 
                  className="bg-slate-950 h-full rounded-xs inline-block" 
                  style={{ width: `${w * 1.5}px` }} 
                />
              ))}
            </div>

            {/* Reference & Barcode Label */}
            <div className="w-full flex items-center justify-between mt-2 pt-1.5 border-t border-slate-100 text-[10px] font-mono text-slate-500">
              <span className="font-bold text-slate-900 tracking-wider">{barcodeNumber}</span>
              <span className="text-[9px] text-slate-400 font-sans">{isAr ? 'معتمد رسمياً' : 'Certifié Syndic'}</span>
            </div>
          </div>

          <div className="mt-2.5 text-center text-[10px] text-blue-200/90 font-medium">
            {isAr ? 'أظهر هذه البطاقة الرقمية للسانديك أو قم بحفظها' : 'Présentez ce pass digital au syndic ou téléchargez-le'}
          </div>
        </div>
      </motion.div>

      {/* ========================================================================= */}
      {/* QUICK INTERACTIVE ACTION BUTTONS                                          */}
      {/* ========================================================================= */}
      <div className="w-full mt-4 space-y-2">
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.97 }}
          type="button"
          onClick={handleWhatsApp}
          className="w-full py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs shadow-lg shadow-emerald-700/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          <Share2 className="w-4 h-4" />
          <span>{isAr ? 'مشاركة الوصل في الواتساب (WhatsApp)' : 'Partager sur WhatsApp'}</span>
        </motion.button>

        <div className="grid grid-cols-2 gap-2">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.97 }}
            type="button"
            onClick={handleDownload}
            disabled={isDownloading}
            className="py-2.5 px-3 rounded-2xl bg-white hover:bg-slate-50 text-slate-800 border border-slate-200 font-bold text-xs shadow-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-blue-600" />
            <span>{isDownloading ? (isAr ? 'جار التحميل...' : 'Téléchargement...') : (isAr ? 'تحميل PDF' : 'Télécharger')}</span>
          </motion.button>

          {onPrintA4 && (
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.97 }}
              type="button"
              onClick={onPrintA4}
              className="py-2.5 px-3 rounded-2xl bg-white hover:bg-slate-50 text-slate-800 border border-slate-200 font-bold text-xs shadow-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
              <span>{isAr ? 'طباعة A4 رسمية' : 'Imprimer A4'}</span>
            </motion.button>
          )}
        </div>

        <button
          type="button"
          onClick={handleCopy}
          className="w-full text-center py-1.5 text-[11px] font-semibold text-slate-500 hover:text-slate-800 transition-colors flex items-center justify-center gap-1 cursor-pointer"
        >
          {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
          <span>{copied ? (isAr ? 'تم نسخ بيانات الوصل!' : 'Données copiées !') : (isAr ? 'نسخ ملخص الوصل كنص' : 'Copier le résumé')}</span>
        </button>
      </div>
    </div>
  );
};
