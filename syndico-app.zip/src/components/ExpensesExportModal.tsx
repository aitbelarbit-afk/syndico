import { RES } from '../config/residence';
import React, { useState } from 'react';
import { Expense, Building, ExpenseCategory, PaymentMethod } from '../types';
import { exportExpensesToExcel } from '../utils/exportUtils';
import { exportElementToPdf } from '../utils/monthlyPdfReportUtils';
import { Printer, FileSpreadsheet, X, Receipt, ShieldCheck, Zap, Droplet, Sparkles, Shield, Wrench, Package, FileText, Loader2 } from 'lucide-react';

interface ExpensesExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  expenses: Expense[];
  buildings: Building[];
  lang: string;
  filterCategory: string;
  getCategoryLabel: (cat: ExpenseCategory) => string;
  getMethodLabel: (m: PaymentMethod) => string;
  currentUser?: any;
}

export const ExpensesExportModal: React.FC<ExpensesExportModalProps> = ({
  isOpen,
  onClose,
  expenses,
  buildings,
  lang,
  filterCategory,
  getCategoryLabel,
  getMethodLabel,
  currentUser
}) => {
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  if (!isOpen) return null;

  const isAr = lang === 'ar';
  const currentDate = new Date().toLocaleDateString(isAr ? 'ar-MA' : 'fr-FR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const grandTotal = expenses.reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPdf = async () => {
    setIsGeneratingPdf(true);
    try {
      await exportElementToPdf('syndic-expenses-report-paper', 'Rapport_Depenses');
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const handleExportExcel = () => {
    exportExpensesToExcel(expenses, buildings, lang, getCategoryLabel, getMethodLabel, filterCategory);
  };

  // Group by category to show financial breakdown
  const categoryTotals: Record<string, number> = {};
  expenses.forEach(e => {
    const cat = e.category || 'other';
    categoryTotals[cat] = (categoryTotals[cat] || 0) + (Number(e.amount) || 0);
  });

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white w-full max-w-5xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-200">
        
        {/* Controls Top Bar (Hidden on Print) */}
        <div className="no-print p-4 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-slate-800 text-amber-400 border border-slate-700">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-sm sm:text-base">
                {isAr ? 'معاينة وتصدير تقرير المصاريف والشفافية المالية (PDF / Excel)' : 'Aperçu & Export du Rapport des Dépenses'}
              </h2>
              <p className="text-xs text-slate-300">
                {isAr 
                  ? `مجموع المصاريف: ${grandTotal.toLocaleString()} درهم (${expenses.length} عملية)` 
                  : `Total : ${grandTotal.toLocaleString()} DH (${expenses.length} opérations)`}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              id="btn-print-expenses"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-all cursor-pointer border border-white/10"
              title={isAr ? 'طباعة مباشرة A4' : 'Imprimer'}
            >
              <Printer className="w-4 h-4 text-emerald-300" />
              <span className="hidden sm:inline">{isAr ? 'طباعة' : 'Imprimer'}</span>
            </button>

            <button
              type="button"
              id="btn-export-expenses-pdf"
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
            >
              {isGeneratingPdf ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <FileText className="w-4 h-4" />
              )}
              <span>{isAr ? 'تصدير PDF' : 'Exporter PDF'}</span>
            </button>

            <button
              type="button"
              id="btn-export-expenses-excel"
              onClick={handleExportExcel}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4 text-amber-400" />
              <span>{isAr ? 'تصدير Excel (CSV)' : 'Exporter Excel (CSV)'}</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition-all cursor-pointer"
              title={isAr ? 'إغلاق' : 'Fermer'}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Container */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-8 bg-slate-50">
          <div 
            id="syndic-expenses-report-paper" 
            className="syndic-printable-document bg-white p-6 sm:p-8 rounded-2xl border-2 border-slate-800/40 shadow-xs max-w-4xl mx-auto text-slate-900 space-y-6"
          >
            {/* Document Official Header */}
            <div className="border-b-2 border-slate-900 pb-5">
              <div className="flex items-start justify-between gap-4 text-xs">
                {/* Right Side: Arabic Header */}
                <div className="text-right space-y-1">
                  <p className="font-extrabold text-sm text-slate-950">المملكة المغربية</p>
                  <p className="font-bold text-slate-800">{RES.fullNameAr}</p>
                  <p className="text-slate-600"></p>
                  <p className="text-slate-600">مكتب اتحاد الملاك المشتركين (السانديك)</p>
                </div>

                {/* Center: Official Seal / Emblem Badge */}
                <div className="text-center px-4 py-2 bg-slate-100 rounded-2xl border border-slate-300">
                  <div className="w-10 h-10 mx-auto rounded-full bg-slate-900 text-amber-400 flex items-center justify-center font-bold text-base shadow-xs mb-1">
                    M
                  </div>
                  <span className="text-[10px] font-bold tracking-widest text-slate-900 uppercase">
                    RÉSIDENCE
                  </span>
                  <p className="text-[9px] text-slate-600 font-mono mt-0.5">BILAN FINANCIER</p>
                </div>

                {/* Left Side: French Header */}
                <div className="text-left space-y-1" dir="ltr">
                  <p className="font-extrabold text-sm text-slate-950">ROYAUME DU MAROC</p>
                  <p className="font-bold text-slate-800">{RES.nameFr}</p>
                  <p className="text-slate-600"></p>
                  <p className="text-slate-600">Bureau du Syndic de Copropriété</p>
                </div>
              </div>

              {/* Title Section */}
              <div className="mt-6 text-center">
                <h1 className="text-lg sm:text-xl font-extrabold text-slate-950 tracking-tight">
                  {isAr ? 'بيان وتقرير المصاريف ونفقات التسيير الرسمية' : 'RAPPORT GÉNÉRAL DES DÉPENSES ET CHARGES DE GESTION'}
                </h1>
                <p className="text-xs text-slate-600 mt-1 font-medium">
                  {isAr 
                    ? 'تقرير الشفافية المالية وعرض نفقات الخدمات المشتركة الموجه لعموم الملاك المشتركين' 
                    : 'Rapport de transparence financière et justification des charges communes aux copropriétaires'}
                </p>
              </div>
            </div>

            {/* Report Metadata and Scope */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs">
              <div>
                <span className="text-slate-500 block text-[10px]">{isAr ? 'الفئة المحددة:' : 'Catégorie filtrée :'}</span>
                <span className="font-bold text-slate-900">
                  {filterCategory === 'ALL' 
                    ? (isAr ? 'جميع الفئات والنفقات' : 'Toutes les catégories') 
                    : getCategoryLabel(filterCategory as ExpenseCategory)}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">{isAr ? 'عدد العمليات:' : 'Nombre d\'opérations :'}</span>
                <span className="font-bold text-slate-900 font-mono">{expenses.length} عملية</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">{isAr ? 'تاريخ التقرير:' : 'Date d\'édition :'}</span>
                <span className="font-bold text-slate-900">{currentDate}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">{isAr ? 'الآمر بالصرف:' : 'Ordonnateur :'}</span>
                <span className="font-bold text-slate-800">{currentUser?.name || (isAr ? 'مكتب السانديك' : 'Syndic')}</span>
              </div>
            </div>

            {/* Financial Summary KPIs */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-4 bg-slate-900 text-white rounded-xl text-center sm:col-span-1 shadow-xs">
                <span className="text-xs text-slate-300 font-medium block mb-1">
                  {isAr ? 'المجموع الإجمالي للنفقات' : 'TOTAL GÉNÉRAL DES DÉPENSES'}
                </span>
                <span className="text-2xl font-extrabold text-amber-400 font-mono">
                  {grandTotal.toLocaleString()} <span className="text-xs text-white">DH</span>
                </span>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 sm:col-span-2 flex flex-col justify-center">
                <span className="text-[11px] text-slate-500 font-semibold mb-2 block">
                  {isAr ? 'توزيع المصاريف حسب الأبواب الرئيسية:' : 'Répartition par poste principal :'}
                </span>
                <div className="flex flex-wrap gap-2 text-[10px]">
                  {Object.entries(categoryTotals).map(([catKey, total]) => (
                    <div key={catKey} className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 flex items-center gap-1.5 shadow-2xs">
                      <span className="text-slate-600">{getCategoryLabel(catKey as ExpenseCategory)}:</span>
                      <span className="font-mono font-bold text-slate-900">{total.toLocaleString()} DH</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Expenses Data Table */}
            <div className="overflow-x-auto">
              <table className="w-full whitespace-nowrap text-start border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-900 text-white border border-slate-950">
                    <th className="p-2 text-center w-8">#</th>
                    <th className="p-2 text-start">{isAr ? 'التاريخ' : 'Date'}</th>
                    <th className="p-2 text-start">{isAr ? 'بيان المصروف' : 'Désignation'}</th>
                    <th className="p-2 text-start">{isAr ? 'الفئة' : 'Catégorie'}</th>
                    <th className="p-2 text-center">{isAr ? 'العمارة' : 'Bât.'}</th>
                    <th className="p-2 text-start">{isAr ? 'المورد / الشركة' : 'Fournisseur'}</th>
                    <th className="p-2 text-start">{isAr ? 'رقم الفاتورة' : 'Réf. Facture'}</th>
                    <th className="p-2 text-center">{isAr ? 'طريقة الأداء' : 'Paiement'}</th>
                    <th className="p-2 text-end">{isAr ? 'المبلغ (درهم)' : 'Montant (DH)'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 border border-slate-300">
                  {expenses.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="p-6 text-center text-slate-500 font-medium">
                        {isAr ? 'لا توجد مصاريف مسجلة مطابقة لشروط البحث' : 'Aucune dépense correspondante'}
                      </td>
                    </tr>
                  ) : (
                    expenses.map((e, idx) => (
                      <tr 
                        key={e.id || idx} 
                        className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/70'}
                      >
                        <td className="p-2 text-center font-mono font-semibold text-slate-500">{idx + 1}</td>
                        <td className="p-2 font-mono text-slate-700 whitespace-nowrap">{e.date}</td>
                        <td className="p-2 font-bold text-slate-900">{e.title}</td>
                        <td className="p-2 text-slate-700">{getCategoryLabel(e.category)}</td>
                        <td className="p-2 text-center font-semibold text-slate-800">
                          {e.buildingCode === 'ALL' ? (isAr ? 'الكل' : 'Tous') : e.buildingCode}
                        </td>
                        <td className="p-2 text-slate-700">{e.supplier || '-'}</td>
                        <td className="p-2 font-mono text-slate-600">{e.invoiceRef || '-'}</td>
                        <td className="p-2 text-center text-[10px]">
                          <span className="px-1.5 py-0.5 rounded bg-slate-100 font-semibold text-slate-700">
                            {getMethodLabel(e.paymentMethod)}
                          </span>
                        </td>
                        <td className="p-2 text-end font-mono font-bold text-slate-950 whitespace-nowrap">
                          {Number(e.amount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} DH
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
                {expenses.length > 0 && (
                  <tfoot>
                    <tr className="bg-slate-900 text-white font-bold border-t-2 border-slate-950">
                      <td colSpan={8} className="p-2.5 text-start font-bold">
                        {isAr ? 'المجموع الإجمالي العام للنفقات:' : 'TOTAL GÉNÉRAL :'}
                      </td>
                      <td className="p-2.5 text-end font-mono font-extrabold text-amber-300 text-sm whitespace-nowrap">
                        {grandTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} DH
                      </td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>

            {/* Official Sign-off & Financial Audit Section */}
            <div className="pt-6 border-t-2 border-slate-300 mt-6 grid grid-cols-2 gap-6 text-xs">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <p className="font-bold text-slate-900 mb-1">{isAr ? 'بيان الشفافية والمطابقة:' : 'Déclaration de conformité :'}</p>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  {isAr 
                    ? 'يشهد مكتب السانديك بأن جميع المصاريف المبينة أعلاه مؤيدة بفواتير وأذون صرف أصلية ومطابقة لقرارات الجمع العام للاتحاد.' 
                    : 'Le bureau du syndic certifie la conformité de ces dépenses avec les pièces justificatives et les décisions d\'Assemblée Générale.'}
                </p>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-center flex flex-col justify-between min-h-[110px]">
                <p className="font-bold text-slate-900">{isAr ? 'خاتم وتوقيع وكيل الاتحاد وأمين المال' : 'Cachet & Signature du Bureau du Syndic'}</p>
                <div className="text-[10px] text-slate-400 font-mono">
                  {isAr ? 'حرر في: ' : 'Fait à , le : '} {currentDate}
                </div>
              </div>
            </div>

            {/* Legal Footnote */}
            <div className="text-center pt-3 border-t border-slate-200 text-[10px] text-slate-500">
              {isAr 
                ? 'الإقامة -  | التقرير المالي للتدبير المشترك' 
                : 'Résidence -  | Rapport Financier de Copropriété'}
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
