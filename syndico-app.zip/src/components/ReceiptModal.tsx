import { RES } from '../config/residence';
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Printer, X, MessageSquare, Building2, CheckCircle2, ShieldCheck, 
  Send, Share2, Copy, Check, FileDown, FileText, Loader2, Sparkles, Mail, Phone, Clock 
} from 'lucide-react';
import { 
  downloadReceiptAsPdf, 
  shareReceiptPdf, 
  buildReceiptWhatsAppUrl, 
  buildReceiptEmailUrl 
} from '../utils/pdfReceiptUtils';
import { formatPeriodDisplay } from '../utils/debtUtils';
import { isGenericPlaceholderName, isOldMockResidentName, getMoroccanApartmentData } from '../data/moroccanResidentsData';
import { DigitalPassTicket } from './DigitalPassTicket';

export const ReceiptModal: React.FC = () => {
  const { selectedReceipt, setSelectedReceipt, apartments, residents, t, lang } = useApp();
  const [copied, setCopied] = useState(false);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [isSharingPdf, setIsSharingPdf] = useState(false);
  const [pdfSuccess, setPdfSuccess] = useState(false);
  const [viewMode, setViewMode] = useState<'pass' | 'paper'>('pass');

  if (!selectedReceipt) return null;

  const cleanB = (selectedReceipt.buildingCode || '').replace(/\s+/g, ' ').trim().toUpperCase();
  const cleanA = String(selectedReceipt.apartmentNumber || '01').trim().padStart(2, '0');

  // Find owner contact information from Residents page
  const res = residents.find(
    r => r.buildingCode.replace(/\s+/g, ' ').trim().toUpperCase() === cleanB && 
         String(r.apartmentNumber).trim().padStart(2, '0') === cleanA
  );
  const apt = apartments.find(
    a => a.buildingCode.replace(/\s+/g, ' ').trim().toUpperCase() === cleanB && 
         String(a.number).trim().padStart(2, '0') === cleanA
  );

  const fallbackMoroccan = getMoroccanApartmentData(cleanB, cleanA);

  // Auto-resolve authentic owner name from Residents page
  const realResidentName = (res?.fullName && !isGenericPlaceholderName(res.fullName) && !isOldMockResidentName(res.fullName))
    ? res.fullName.trim()
    : (false)
      ? 'مكتب إدارة وسانديك الإقامة'
      : (false)
        ? 'السيد محمد أيت بلعربي'
        : (apt?.ownerName && !isGenericPlaceholderName(apt.ownerName) && !isOldMockResidentName(apt.ownerName))
          ? apt.ownerName.trim()
          : (apt?.residentName && !isGenericPlaceholderName(apt.residentName) && !isOldMockResidentName(apt.residentName))
            ? apt.residentName.trim()
            : (!isGenericPlaceholderName(selectedReceipt.residentName) && !isOldMockResidentName(selectedReceipt.residentName))
              ? selectedReceipt.residentName
              : (fallbackMoroccan?.fullName && !isGenericPlaceholderName(fallbackMoroccan.fullName))
                ? fallbackMoroccan.fullName
                : `شقة ${cleanA}`;

  const receiptForDisplay = {
    ...selectedReceipt,
    residentName: realResidentName
  };

  const ownerPhone = res?.phone || apt?.ownerPhone || apt?.residentPhone || fallbackMoroccan?.phone || '';
  const ownerEmail = res?.email || apt?.ownerEmail || apt?.residentEmail || fallbackMoroccan?.email || '';

  const formattedPeriod = formatPeriodDisplay(receiptForDisplay.periodMonth, lang);

  const whatsappUrl = buildReceiptWhatsAppUrl(receiptForDisplay, formattedPeriod, ownerPhone);
  const emailUrl = buildReceiptEmailUrl(receiptForDisplay, formattedPeriod, ownerEmail);

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPdf = async () => {
    if (isGeneratingPdf) return;
    setIsGeneratingPdf(true);
    setPdfSuccess(false);
    try {
      const success = await downloadReceiptAsPdf('syndic-receipt-paper', receiptForDisplay);
      if (success) {
        setPdfSuccess(true);
        setTimeout(() => setPdfSuccess(false), 3500);
      }
    } catch (err) {
      console.error('Failed to generate PDF:', err);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const handleSharePdf = async () => {
    if (isSharingPdf) return;
    setIsSharingPdf(true);
    try {
      await shareReceiptPdf('syndic-receipt-paper', receiptForDisplay, formattedPeriod);
    } catch (err) {
      console.error('Failed to share PDF:', err);
    } finally {
      setIsSharingPdf(false);
    }
  };

  const executionTimeDisplay = selectedReceipt.executedAtTime || 
    (selectedReceipt.createdAt ? new Date(selectedReceipt.createdAt).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '');

  const whatsappMessage = `*وصل أداء واجبات التسيير المشترك (السانديك) - ${RES.nameAr}   *\n\n` +
    `📄 رقم الوصل: ${selectedReceipt.receiptNumber}\n` +
    `👤 الساكن / المالك: ${selectedReceipt.residentName}\n` +
    `🏢 الشقة: ${selectedReceipt.buildingCode} - شقة ${selectedReceipt.apartmentNumber}\n` +
    `📅 الفترة / الشهر: ${formattedPeriod} (${selectedReceipt.periodMonth})\n` +
    `💰 المبلغ المؤدى: ${selectedReceipt.amount} درهم مغربي\n` +
    `🗓️ تاريخ الأداء: ${selectedReceipt.paymentDate}${executionTimeDisplay ? ` (ساعة الإنجاز: ${executionTimeDisplay})` : ''}\n` +
    `✍️ المستلم: ${selectedReceipt.receivedBy || 'مكتب السانديك'}\n\n` +
    `نشكركم على مساهمتكم في حسن تسيير وصيانة الإقامة.`;

  const handleCopyText = async () => {
    try {
      await navigator.clipboard.writeText(whatsappMessage);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch (err) {
      console.error('Failed to copy', err);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/75 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto print:p-0 print:bg-white print:static print:overflow-visible">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 print:shadow-none print:border-none print:w-full print:max-w-none flex flex-col my-auto">
        
        {/* Top Header Bar - Hidden during print */}
        <div className="p-3.5 sm:p-4 bg-slate-900 text-white flex items-center justify-between no-print modal-controls print:hidden shrink-0">
          <div className="flex items-center gap-2 font-bold text-xs sm:text-sm">
            <span className="px-2 py-0.5 rounded bg-blue-600 text-[10px] font-mono font-black text-white uppercase tracking-wider">
              PASS & PDF
            </span>
            <FileText className="w-4 h-4 text-emerald-400" />
            <span>{lang === 'ar' ? 'معاينة وإرسال وصل الأداء' : 'Reçu & Pass Digital'}</span>
          </div>

          <div className="flex items-center gap-2">
            {/* Quick Top PDF Download Button */}
            <button
              id="btn-download-pdf-top"
              type="button"
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 active:bg-blue-800 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
              title={lang === 'ar' ? 'تحميل الوصل كملف PDF' : 'Télécharger en PDF'}
            >
              {isGeneratingPdf ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : pdfSuccess ? (
                <Check className="w-3.5 h-3.5 text-emerald-300" />
              ) : (
                <FileDown className="w-3.5 h-3.5" />
              )}
              <span className="hidden sm:inline">
                {isGeneratingPdf 
                  ? (lang === 'ar' ? 'جاري استخراج PDF...' : 'Création PDF...') 
                  : pdfSuccess 
                  ? (lang === 'ar' ? 'تم تنزيل PDF' : 'PDF Téléchargé') 
                  : (lang === 'ar' ? 'تحميل PDF' : 'Télécharger PDF')}
              </span>
            </button>

            <button
              id="btn-close-receipt-top"
              onClick={() => setSelectedReceipt(null)}
              className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-white cursor-pointer transition-colors"
              title={lang === 'ar' ? 'إغلاق' : 'Fermer'}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Dynamic Mode Switcher: Digital Pass vs Official A4 */}
        <div className="bg-slate-100 p-2 border-b border-slate-200 flex items-center justify-center gap-2 no-print shrink-0">
          <button
            type="button"
            id="btn-receipt-view-pass"
            onClick={() => setViewMode('pass')}
            className={`px-3.5 sm:px-4 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
              viewMode === 'pass'
                ? 'bg-[#0a8591] text-white shadow-sm'
                : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
            }`}
          >
            <span>🎫 {lang === 'ar' ? 'التذكرة الرقمية الذكية (Digital Pass)' : 'Pass Digital'}</span>
          </button>

          <button
            type="button"
            id="btn-receipt-view-paper"
            onClick={() => setViewMode('paper')}
            className={`px-3.5 sm:px-4 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
              viewMode === 'paper'
                ? 'bg-slate-900 text-white shadow-sm'
                : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
            }`}
          >
            <span>📄 {lang === 'ar' ? 'الوثيقة الرسمية (Format A4)' : 'Document A4'}</span>
          </button>
        </div>

        {/* Digital Pass View */}
        {viewMode === 'pass' && (
          <div className="p-4 sm:p-6 bg-slate-900/95 overflow-y-auto max-h-[75vh] flex justify-center no-print">
            <DigitalPassTicket 
              receipt={receiptForDisplay} 
              lang={lang} 
              ownerPhone={ownerPhone} 
              onPrintA4={() => {
                setViewMode('paper');
                setTimeout(() => window.print(), 200);
              }} 
            />
          </div>
        )}

        {/* Printable Receipt Paper Container */}
        <div 
          className={`p-6 sm:p-10 bg-white print:p-6 text-slate-900 syndic-printable-document relative overflow-hidden ${
            viewMode === 'pass' ? 'hidden print:block' : 'block'
          }`} 
          id="syndic-receipt-paper"
        >
          {/* Subtle Watermark for Authenticity */}
          <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none select-none print:opacity-[0.04]">
            <Building2 className="w-96 h-96 text-emerald-950" />
          </div>

          {/* Header */}
          <div className="border-b-2 border-emerald-800 pb-4 mb-5 flex items-start justify-between relative z-10">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-800 text-white flex items-center justify-center font-black text-xl shadow-xs print:bg-emerald-800 print:text-white">
                MA
              </div>
              <div>
                <h2 className="text-xl font-black text-emerald-950">الإقامة  </h2>
                <div className="text-xs font-bold text-slate-600"> • SYNDICAT DES COPROPRIÉTAIRES</div>
                <div className="text-[11px] text-slate-500 mt-0.5">
                   | عمارات (جميع العمارات / جميع الشقق)
                </div>
              </div>
            </div>

            <div className="text-end">
              <div className="inline-block px-3 py-1 bg-emerald-100 text-emerald-900 font-mono font-black text-sm rounded-lg border border-emerald-200 print:bg-emerald-50">
                وصل N° {selectedReceipt.receiptNumber}
              </div>
              <div className="text-[11px] text-slate-500 mt-1 font-mono">
                تاريخ الأداء: <span className="font-bold text-slate-700">{selectedReceipt.paymentDate}</span>
              </div>
              {executionTimeDisplay && (
                <div className="text-[10px] text-emerald-800 font-mono flex items-center justify-end gap-1 mt-0.5">
                  <Clock className="w-3 h-3 text-emerald-600 print:hidden" />
                  <span>ساعة الإنجاز: <span className="font-bold">{executionTimeDisplay}</span></span>
                </div>
              )}
            </div>
          </div>

          {/* Receipt Title */}
          <div className="text-center my-4 relative z-10">
            <h1 className="text-lg font-black text-slate-900 tracking-wide">
              وصل أداء واجبات التسيير المشترك (السانديك)
            </h1>
            <p className="text-xs text-slate-500 font-semibold uppercase tracking-wider">
              REÇU DE COTISATION SYNDICALE — LOI 18-00
            </p>
          </div>

          {/* Details Table */}
          <div className="border border-slate-300 rounded-xl overflow-x-auto overflow-hidden mb-5 text-xs relative z-10 print:border-emerald-800">
            <table className="w-full whitespace-nowrap border-collapse">
              <tbody>
                <tr className="border-b border-slate-200 bg-slate-50/80 print:bg-slate-100">
                  <td className="p-3 font-bold text-slate-600 w-1/3">الساكن / المالك (Résident/Propriétaire):</td>
                  <td className="p-3 font-bold text-slate-900 text-sm">{receiptForDisplay.residentName}</td>
                </tr>
                <tr className="border-b border-slate-200">
                  <td className="p-3 font-bold text-slate-600">العمارة والشقة (Immeuble & Appartement):</td>
                  <td className="p-3 font-bold text-emerald-900 text-sm">
                    {selectedReceipt.buildingCode} — شقة رقم {selectedReceipt.apartmentNumber}
                  </td>
                </tr>
                <tr className="border-b border-slate-200 bg-slate-50/80 print:bg-slate-100">
                  <td className="p-3 font-bold text-slate-600">الفترة المؤداة (Période / Mois):</td>
                  <td className="p-3 font-bold text-slate-900 text-sm">
                    <span className="text-emerald-950 font-bold">{formattedPeriod}</span>
                    <span className="text-slate-500 font-mono text-xs ms-2">({selectedReceipt.periodMonth})</span>
                  </td>
                </tr>
                <tr className="border-b border-slate-200">
                  <td className="p-3 font-bold text-slate-600">طريقة الأداء (Mode de Règlement):</td>
                  <td className="p-3 font-bold text-slate-800">
                    {selectedReceipt.paymentMethod === 'cash' ? 'نقداً (Espèces)' :
                     selectedReceipt.paymentMethod === 'bank_transfer' ? 'تحويل بنكي (Virement bancaire)' :
                     selectedReceipt.paymentMethod === 'check' ? 'شيك بنكي (Chèque)' : 'أداء إلكتروني'}
                  </td>
                </tr>
                {selectedReceipt.notes && (
                  <tr className="border-b border-slate-200 bg-slate-50/80 print:bg-slate-100">
                    <td className="p-3 font-bold text-slate-600">ملاحظات وبيان الأداء (Notes):</td>
                    <td className="p-3 text-slate-700 font-medium">{selectedReceipt.notes}</td>
                  </tr>
                )}
                <tr className="bg-emerald-50 text-emerald-950 font-black print:bg-emerald-100/70">
                  <td className="p-4 text-sm font-bold text-emerald-950">المبلغ المؤدى (Montant Payé):</td>
                  <td className="p-4 text-lg font-mono font-black text-emerald-900">
                    {selectedReceipt.amount} درهم مغربي (MAD / DH)
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Signatures & Stamp area */}
          <div className="grid grid-cols-2 gap-6 pt-3 pb-2 text-xs relative z-10 print-avoid-break">
            <div className="border border-dashed border-slate-300 rounded-xl p-4 min-h-[110px] flex flex-col justify-between print:border-slate-400">
              <span className="font-bold text-slate-600">توقيع الساكن / المؤدي:</span>
              <span className="text-[10px] text-slate-400">Signature du Résident</span>
            </div>

            <div className="border border-dashed border-emerald-400 bg-emerald-50/40 rounded-xl p-4 min-h-[110px] flex flex-col justify-between text-end print:border-emerald-600 print:bg-emerald-50/30">
              <div>
                <span className="font-bold text-emerald-950 block">طابع وتوقيع وكيل الاتحاد (السانديك)</span>
                <span className="text-[10px] text-slate-500">Cachet & Signature du Syndic</span>
              </div>
              <div className="text-[11px] font-bold text-emerald-900">
                {selectedReceipt.receivedBy || 'مكتب السانديك'}
              </div>
            </div>
          </div>

          {/* Legal Notice & Footer note */}
          <div className="text-center text-[10px] text-slate-400 mt-5 pt-3 border-t border-slate-200 relative z-10">
            <div>طبقا لمقتضيات القانون رقم 18.00 المتعلق بنظام الملكية المشتركة للعقارات المبنية</div>
            <div className="text-[9px] text-slate-400 mt-0.5">
              تم استخراج هذا الوصل إلكترونياً بصيغة PDF بواسطة منظومة Syndico لتدبير الإقامات السكنية
            </div>
          </div>

        </div>

        {/* Bottom Actions Bar - In the bottom of the page (في أخر الصفحة) */}
        <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-200 no-print modal-controls print:hidden shrink-0 space-y-3">
          
          {/* Owner Recipient Banner if available */}
          {(ownerPhone || ownerEmail) && (
            <div className="flex items-center justify-between p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 flex-wrap gap-2">
              <div className="flex items-center gap-1.5 font-bold">
                <span>👤 بيانات التواصل مع المالك:</span>
              </div>
              <div className="flex items-center gap-3 font-mono text-[11px]">
                {ownerPhone && (
                  <span className="flex items-center gap-1">
                    <Phone className="w-3 h-3 text-emerald-700" />
                    <span>{ownerPhone}</span>
                  </span>
                )}
                {ownerEmail && (
                  <span className="flex items-center gap-1">
                    <Mail className="w-3 h-3 text-blue-700" />
                    <span>{ownerEmail}</span>
                  </span>
                )}
              </div>
            </div>
          )}

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
            
            {/* Left/Secondary Actions: Close button */}
            <button
              id="btn-close-receipt-bottom"
              type="button"
              onClick={() => setSelectedReceipt(null)}
              className="px-4 py-2.5 rounded-xl bg-white hover:bg-slate-100 text-slate-700 hover:text-slate-900 border border-slate-300 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer transition-all shadow-2xs hover:shadow-xs order-3 sm:order-1"
            >
              <X className="w-4 h-4 text-slate-500" />
              <span>{lang === 'ar' ? 'إغلاق' : 'Fermer'}</span>
            </button>

            {/* Right/Primary Actions: PDF Download, Direct WhatsApp, Email, Share & Print */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 order-1 sm:order-2 flex-wrap justify-end">
              
              {/* 1. Download PDF */}
              <button
                id="btn-download-pdf-bottom"
                type="button"
                onClick={handleDownloadPdf}
                disabled={isGeneratingPdf}
                className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 active:bg-rose-800 disabled:opacity-50 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer transition-all shadow-md"
              >
                {isGeneratingPdf ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : pdfSuccess ? (
                  <Check className="w-4 h-4 text-emerald-300" />
                ) : (
                  <FileDown className="w-4 h-4" />
                )}
                <span>
                  {isGeneratingPdf 
                    ? (lang === 'ar' ? 'جاري الاستخراج...' : 'Génération...') 
                    : pdfSuccess 
                    ? (lang === 'ar' ? 'تم تنزيل PDF' : 'PDF Téléchargé !') 
                    : (lang === 'ar' ? 'تحميل الوصل (PDF)' : 'Télécharger (PDF)')}
                </span>
              </button>

              {/* 2. Direct Share PDF (Mobile File Share) */}
              <button
                id="btn-share-pdf-bottom"
                type="button"
                onClick={handleSharePdf}
                disabled={isSharingPdf}
                className="px-3.5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 disabled:opacity-50 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 cursor-pointer transition-all shadow-md"
                title={lang === 'ar' ? 'مشاركة ملف PDF مباشرة عبر التطبيقات' : 'Partager le fichier PDF'}
              >
                {isSharingPdf ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Share2 className="w-4 h-4" />
                )}
                <span>{lang === 'ar' ? 'مشاركة PDF' : 'Partager PDF'}</span>
              </button>

              {/* 3. Send WhatsApp */}
              <a
                id="btn-send-receipt-whatsapp"
                href={whatsappUrl}
                target="_blank"
                rel="noreferrer"
                className="px-3.5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-1.5 cursor-pointer transition-all shadow-md"
              >
                <MessageSquare className="w-4 h-4" />
                <span>{lang === 'ar' ? 'واتساب' : 'WhatsApp'}</span>
              </a>

              {/* 4. Send Email */}
              <a
                id="btn-send-receipt-email"
                href={emailUrl}
                className="px-3.5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 cursor-pointer transition-all shadow-md"
              >
                <Mail className="w-4 h-4" />
                <span>{lang === 'ar' ? 'إيميل' : 'Email'}</span>
              </a>

              {/* 5. Print Button / Save to PDF */}
              <button
                id="btn-print-receipt-bottom"
                type="button"
                onClick={handlePrint}
                className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-900 active:bg-black text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-1.5 cursor-pointer transition-all shadow-md"
              >
                <Printer className="w-4 h-4 text-emerald-400" />
                <span>{lang === 'ar' ? 'طباعة' : 'Imprimer'}</span>
              </button>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};



