import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Search, LayoutDashboard, Building2, Receipt, Users, 
  Settings, Home, BarChart3, Wrench, Shield, Wallet,
  Calendar, FileText, ArrowRight, Activity, FileSpreadsheet
} from 'lucide-react';

type CommandItem = {
  id: string;
  titleAr: string;
  titleFr: string;
  icon: React.ReactNode;
  action: () => void;
  keywords: string[];
};

export const CommandPalette: React.FC = () => {
  const { lang, currentUser, setActiveSection, buildings, showToast } = useApp();
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  // Toggle palette with Ctrl+K or Cmd+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setIsOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Handle keyboard navigation inside the modal
  useEffect(() => {
    if (!isOpen) {
      setQuery('');
      setSelectedIndex(0);
      return;
    }
    
    // Focus input when opened
    setTimeout(() => {
      inputRef.current?.focus();
    }, 100);

    const handleModalKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };
    window.addEventListener('keydown', handleModalKeyDown);
    return () => window.removeEventListener('keydown', handleModalKeyDown);
  }, [isOpen]);

  const items: CommandItem[] = useMemo(() => {
    const baseItems: CommandItem[] = [
      {
        id: 'dashboard',
        titleAr: 'لوحة القيادة (الرئيسية)',
        titleFr: 'Tableau de bord (Accueil)',
        icon: <LayoutDashboard className="w-5 h-5" />,
        action: () => setActiveSection('dashboard'),
        keywords: ['home', 'dashboard', 'accueil', 'رئيسية', 'لوحة'],
      },
      {
        id: 'financial',
        titleAr: 'المتابعة المالية الدقيقة',
        titleFr: 'Contrôle Financier',
        icon: <BarChart3 className="w-5 h-5 text-emerald-600" />,
        action: () => setActiveSection('control'),
        keywords: ['finance', 'argent', 'مالية', 'متابعة', 'فلوس', 'control'],
      },
      {
        id: 'apartments',
        titleAr: 'إدارة الشقق',
        titleFr: 'Gestion des Appartements',
        icon: <Home className="w-5 h-5 text-blue-600" />,
        action: () => setActiveSection('apartments'),
        keywords: ['apartments', 'شقق', 'شقة', 'appartement', 'immobilier'],
      },
      {
        id: 'residents',
        titleAr: 'إدارة السكان والملاك',
        titleFr: 'Résidents & Propriétaires',
        icon: <Users className="w-5 h-5 text-indigo-600" />,
        action: () => setActiveSection('residents'),
        keywords: ['residents', 'proprietaires', 'سكان', 'ملاك', 'سانديك'],
      },
      {
        id: 'payments',
        titleAr: 'الأداءات والمداخيل',
        titleFr: 'Paiements & Recettes',
        icon: <Receipt className="w-5 h-5 text-teal-600" />,
        action: () => setActiveSection('payments'),
        keywords: ['payments', 'paiement', 'recettes', 'مداخيل', 'أداء', 'دفع'],
      },
      {
        id: 'expenses',
        titleAr: 'مصاريف و أجور العمال',
        titleFr: 'Dépenses & Charges',
        icon: <Wallet className="w-5 h-5 text-rose-600" />,
        action: () => setActiveSection('expenses'),
        keywords: ['expenses', 'depenses', 'charges', 'مصاريف', 'نفقات', 'مصاريف و أجور العمال', 'أجور العمال', 'رواتب'],
      },
      {
        id: 'maintenance',
        titleAr: 'الصيانة والأشغال',
        titleFr: 'Maintenance & Travaux',
        icon: <Wrench className="w-5 h-5 text-amber-600" />,
        action: () => setActiveSection('maintenance'),
        keywords: ['maintenance', 'travaux', 'صيانة', 'أشغال', 'إصلاح'],
      },
      {
        id: 'archive',
        titleAr: 'الأرشيف المالي',
        titleFr: 'Archive Financière',
        icon: <FileText className="w-5 h-5 text-slate-600" />,
        action: () => setActiveSection('archive'),
        keywords: ['archive', 'historique', 'أرشيف', 'تاريخ'],
      },
      {
        id: 'manual-financial',
        titleAr: 'السجل والتقرير المالي للأشهر (الخانات الثلاث)',
        titleFr: 'Registre & Rapport Financier Mensuel',
        icon: <FileSpreadsheet className="w-5 h-5 text-amber-500" />,
        action: () => setActiveSection('manual-financial'),
        keywords: ['سجل', 'تقرير مالي', 'الخانات الثلاث', 'رصيد منقول', 'مقبوضات', 'مصاريف', 'registre', 'rapport', 'solde reporté'],
      },
      ...(currentUser?.role !== 'resident' ? [{
        id: 'import-residents-excel',
        titleAr: 'استيراد قائمة السكان من ملف Excel (إدخال أولي)',
        titleFr: 'Importer la liste des résidents via Excel (Initialisation)',
        icon: <FileSpreadsheet className="w-5 h-5 text-emerald-600" />,
        action: () => {
          setActiveSection('residents');
          showToast(lang === 'ar' ? 'تم الانتقال لسجل السكان - انقر على زر استيراد السكان (Excel)' : 'Navigation vers le registre des résidents', { type: 'info' });
        },
        keywords: ['سكان', 'استيراد', 'اكسل', 'إدخال أولي', 'قائمة السكان', 'excel', 'import', 'residents'],
      }] : []),
      ...(currentUser?.role !== 'resident' ? [{
        id: 'syndic-office',
        titleAr: 'مكتب السانديك والذكاء الاصطناعي',
        titleFr: 'Bureau Syndic & IA',
        icon: <Shield className="w-5 h-5 text-purple-600" />,
        action: () => setActiveSection('syndic-office'),
        keywords: ['ai', 'ia', 'syndic', 'مكتب', 'ذكاء', 'اصطناعي'],
      }] : []),
    ];

    // Add building shortcuts
    const buildingItems = buildings.map(b => ({
      id: `building-${b.id}`,
      titleAr: `عمارة ${b.code}`,
      titleFr: `Immeuble ${b.code}`,
      icon: <Building2 className="w-5 h-5 text-slate-400" />,
      action: () => {
        setActiveSection('apartments');
        showToast(lang === 'ar' ? `تم الانتقال لإدارة الشقق - عمارة ${b.code}` : `Navigation vers Appartements - Imm. ${b.code}`, { type: 'info' });
      },
      keywords: ['building', 'عمارة', 'immeuble', 'batiment', b.code.toLowerCase(), b.code.replace(/\s+/g, '').toLowerCase()],
    }));

    return [...baseItems, ...buildingItems];
  }, [buildings, setActiveSection, showToast, lang, currentUser]);

  const filteredItems = useMemo(() => {
    if (!query.trim()) return items.slice(0, 8); // show only top 8 if no query
    
    const lowerQuery = query.toLowerCase().trim();
    return items.filter(item => {
      const matchTitle = item.titleAr.toLowerCase().includes(lowerQuery) || item.titleFr.toLowerCase().includes(lowerQuery);
      const matchKeywords = item.keywords.some(k => k.includes(lowerQuery));
      return matchTitle || matchKeywords;
    }).slice(0, 10);
  }, [query, items]);

  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => (prev + 1) % filteredItems.length);
      scrollToItem((selectedIndex + 1) % filteredItems.length);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => (prev - 1 + filteredItems.length) % filteredItems.length);
      scrollToItem((selectedIndex - 1 + filteredItems.length) % filteredItems.length);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filteredItems[selectedIndex]) {
        filteredItems[selectedIndex].action();
        setIsOpen(false);
      }
    }
  };

  const scrollToItem = (index: number) => {
    if (listRef.current) {
      const itemEl = listRef.current.children[index] as HTMLElement;
      if (itemEl) {
        itemEl.scrollIntoView({ block: 'nearest' });
      }
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[10000] flex items-start justify-center pt-20 px-4 sm:px-0">
      <div 
        className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm transition-opacity" 
        onClick={() => setIsOpen(false)}
      />
      
      <div 
        className="bg-white w-full max-w-xl rounded-2xl shadow-2xl overflow-hidden relative z-10 animate-in fade-in zoom-in-95 duration-200 border border-slate-200"
        dir={lang === 'ar' ? 'rtl' : 'ltr'}
      >
        <div className="flex items-center px-4 py-3 border-b border-slate-100">
          <Search className="w-5 h-5 text-slate-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            className="flex-1 bg-transparent border-none focus:ring-0 text-slate-900 text-lg px-3 placeholder:text-slate-400"
            placeholder={lang === 'ar' ? 'ابحث عن قسم، عمارة، أو وظيفة...' : 'Rechercher une section, immeuble...'}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
          />
          <div className="flex items-center gap-1 shrink-0 bg-slate-100 px-2 py-1 rounded-md">
            <span className="text-[10px] font-bold text-slate-500">ESC</span>
          </div>
        </div>

        <div className="max-h-[60vh] overflow-y-auto p-2" ref={listRef}>
          {filteredItems.length === 0 ? (
            <div className="px-4 py-12 text-center text-slate-500">
              <Activity className="w-10 h-10 mx-auto text-slate-300 mb-3" />
              <p>{lang === 'ar' ? 'لم يتم العثور على نتائج' : 'Aucun résultat trouvé'}</p>
            </div>
          ) : (
            filteredItems.map((item, index) => {
              const isSelected = index === selectedIndex;
              return (
                <div
                  key={item.id}
                  onClick={() => {
                    item.action();
                    setIsOpen(false);
                  }}
                  onMouseEnter={() => setSelectedIndex(index)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl cursor-pointer transition-colors ${
                    isSelected ? 'bg-emerald-50 text-emerald-900' : 'text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className={`p-2 rounded-lg ${isSelected ? 'bg-white shadow-xs' : 'bg-slate-100'}`}>
                    {item.icon}
                  </div>
                  <div className="flex-1 font-semibold text-sm">
                    {lang === 'ar' ? item.titleAr : item.titleFr}
                  </div>
                  {isSelected && (
                    <ArrowRight className={`w-4 h-4 text-emerald-600 ${lang === 'ar' ? 'rotate-180' : ''}`} />
                  )}
                </div>
              );
            })
          )}
        </div>
        
        <div className="px-4 py-3 bg-slate-50 border-t border-slate-100 text-xs text-slate-500 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <kbd className="font-mono bg-white border border-slate-200 rounded px-1.5 py-0.5">↑</kbd>
              <kbd className="font-mono bg-white border border-slate-200 rounded px-1.5 py-0.5">↓</kbd>
              <span className="ms-1">{lang === 'ar' ? 'للتنقل' : 'Naviguer'}</span>
            </span>
            <span className="flex items-center gap-1">
              <kbd className="font-mono bg-white border border-slate-200 rounded px-1.5 py-0.5">Enter</kbd>
              <span className="ms-1">{lang === 'ar' ? 'للاختيار' : 'Sélectionner'}</span>
            </span>
          </div>
          <div>
            <span className="font-semibold text-slate-400">Ctrl + K</span>
          </div>
        </div>
      </div>
    </div>
  );
};
