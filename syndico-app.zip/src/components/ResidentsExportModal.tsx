import { RES } from '../config/residence';
import React, { useState } from 'react';
import { Resident, Building } from '../types';
import { exportResidentsToExcel } from '../utils/exportUtils';
import { exportElementToPdf } from '../utils/monthlyPdfReportUtils';
import { Printer, FileSpreadsheet, X, Users2, ShieldCheck, Building2, Car, Phone, Loader2, FileText } from 'lucide-react';

interface ResidentsExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  residents: Resident[];
  buildings: Building[];
  lang: string;
  filterBuilding: string;
  filterType: string;
  currentUser?: any;
}

export const ResidentsExportModal: React.FC<ResidentsExportModalProps> = ({
  isOpen,
  onClose,
  residents,
  buildings,
  lang,
  filterBuilding,
  filterType,
  currentUser
}) => {
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  if (!isOpen) return null;

  const isAr = lang === 'ar';
  const currentDate = new Date().toLocaleDateString(isAr ? 'ar-MA' : 'fr-FR', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPdf = async () => {
    setIsGeneratingPdf(true);
    try {
      await exportElementToPdf('syndic-residents-report-paper', 'Registre_Residents');
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const handleExportExcel = () => {
    exportResidentsToExcel(residents, buildings, lang, filterBuilding, filterType);
  };

  const ownersCount = residents.filter(r => r.type === 'owner').length;
  const tenantsCount = residents.filter(r => r.type === 'tenant').length;
  const vehiclesCount = residents.filter(r => !!r.vehiclePlate).length;
  const totalFamilyMembers = residents.reduce((sum, r) => sum + (Number(r.familyMembersCount) || 1), 0);

  const getBuildingLabel = (code: string) => {
    if (code === 'ALL') return isAr ? 'جميع العمارات (جميع العمارات)' : 'Tous les bâtiments (tous les immeubles)';
    const b = buildings.find(item => item.code === code);
    return b ? `${b.code} (${b.name})` : code;
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white w-full max-w-5xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-200">
        
        {/* Controls Top Bar (Hidden on Print) */}
        <div className="no-print p-4 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-700/80 text-white">
              <Users2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-sm sm:text-base">
                {isAr ? 'معاينة وتصدير تقرير السكان الرسمي (PDF / Excel)' : 'Aperçu & Export du Registre des Résidents'}
              </h2>
              <p className="text-xs text-slate-300">
                {isAr ? `إجمالي السجلات المعروضة: ${residents.length} ساكن` : `Total des enregistrements : ${residents.length}`}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              id="btn-print-residents"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-all cursor-pointer border border-white/10"
              title={isAr ? 'طباعة مباشرة A4' : 'Imprimer'}
            >
              <Printer className="w-4 h-4 text-emerald-300" />
              <span className="hidden sm:inline">{isAr ? 'طباعة' : 'Imprimer'}</span>
            </button>

            <button
              type="button"
              id="btn-export-residents-pdf"
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
            >
              {isGeneratingPdf ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <FileText className="w-4 h-4" />
              )}
              <span>{isAr ? 'تصدير PDF' : 'Exporter PDF'}</span>
            </button>

            <button
              type="button"
              id="btn-export-residents-excel"
              onClick={handleExportExcel}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              <span>{isAr ? 'تصدير Excel (CSV)' : 'Exporter Excel (CSV)'}</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition-all cursor-pointer"
              title={isAr ? 'إغلاق' : 'Fermer'}
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Container */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-8 bg-slate-50">
          <div 
            id="syndic-residents-report-paper" 
            className="syndic-printable-document bg-white p-6 sm:p-8 rounded-2xl border-2 border-emerald-900/40 shadow-xs max-w-4xl mx-auto text-slate-900 space-y-6"
          >
            {/* Document Official Header */}
            <div className="border-b-2 border-emerald-800 pb-5">
              <div className="flex items-start justify-between gap-4 text-xs">
                {/* Right Side: Arabic Header */}
                <div className="text-right space-y-1">
                  <p className="font-extrabold text-sm text-emerald-950">المملكة المغربية</p>
                  <p className="font-bold text-slate-800">{RES.fullNameAr}</p>
                  <p className="text-slate-600"></p>
                  <p className="text-slate-600">مكتب اتحاد الملاك المشتركين (السانديك)</p>
                </div>

                {/* Center: Official Seal / Emblem Badge */}
                <div className="text-center px-4 py-2 bg-emerald-50 rounded-2xl border border-emerald-200">
                  <div className="w-10 h-10 mx-auto rounded-full bg-emerald-800 text-white flex items-center justify-center font-bold text-base shadow-xs mb-1">
                    M
                  </div>
                  <span className="text-[10px] font-bold tracking-widest text-emerald-900 uppercase">
                    RÉSIDENCE
                  </span>
                  <p className="text-[9px] text-emerald-700 font-mono mt-0.5">SYNDIC OFFICIEL</p>
                </div>

                {/* Left Side: French Header */}
                <div className="text-left space-y-1" dir="ltr">
                  <p className="font-extrabold text-sm text-emerald-950">ROYAUME DU MAROC</p>
                  <p className="font-bold text-slate-800">{RES.nameFr}</p>
                  <p className="text-slate-600"></p>
                  <p className="text-slate-600">Bureau du Syndic de Copropriété</p>
                </div>
              </div>

              {/* Title Section */}
              <div className="mt-6 text-center">
                <h1 className="text-lg sm:text-xl font-extrabold text-emerald-950 tracking-tight">
                  {isAr ? 'سجل الملاك المشتركين وقاطني الإقامة الرسمي' : 'REGISTRE OFFICIEL DES COPROPRIÉTAIRES ET RÉSIDENTS'}
                </h1>
                <p className="text-xs text-slate-600 mt-1 font-medium">
                  {isAr 
                    ? 'وثيقة تنظيمية رسمية معتمدة لدى مكتب السانديك وفق أحكام القانون 18.00 المنظم للملكية المشتركة' 
                    : 'Document officiel conforme aux dispositions de la loi 18.00 régissant la copropriété au Maroc'}
                </p>
              </div>
            </div>

            {/* Report Metadata and Scope */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs">
              <div>
                <span className="text-slate-500 block text-[10px]">{isAr ? 'نطاق العمارة:' : 'Bâtiment cible :'}</span>
                <span className="font-bold text-slate-900">{getBuildingLabel(filterBuilding)}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">{isAr ? 'فئة القاطنين:' : 'Statut filtré :'}</span>
                <span className="font-bold text-slate-900">
                  {filterType === 'ALL' 
                    ? (isAr ? 'الجميع (ملاك ومكترون)' : 'Tous (Propriétaires & Locataires)')
                    : filterType === 'owner' 
                      ? (isAr ? 'الملاك فقط' : 'Propriétaires uniquement')
                      : (isAr ? 'المكترون فقط' : 'Locataires uniquement')}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">{isAr ? 'تاريخ التحرير:' : 'Date d\'édition :'}</span>
                <span className="font-bold text-slate-900">{currentDate}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">{isAr ? 'المحرر والمشرف:' : 'Édité par :'}</span>
                <span className="font-bold text-emerald-800">{currentUser?.name || (isAr ? 'مكتب السانديك' : 'Syndic')}</span>
              </div>
            </div>

            {/* Quick KPI Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-200 text-center">
                <span className="text-[11px] text-emerald-800 font-medium block">{isAr ? 'إجمالي السكان' : 'Total Résidents'}</span>
                <span className="text-xl font-bold text-emerald-950 font-mono">{residents.length}</span>
              </div>
              <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-200 text-center">
                <span className="text-[11px] text-blue-800 font-medium block">{isAr ? 'الملاك المشتركون' : 'Copropriétaires'}</span>
                <span className="text-xl font-bold text-blue-950 font-mono">{ownersCount}</span>
              </div>
              <div className="p-3 bg-amber-50/60 rounded-xl border border-amber-200 text-center">
                <span className="text-[11px] text-amber-800 font-medium block">{isAr ? 'المكترون' : 'Locataires'}</span>
                <span className="text-xl font-bold text-amber-950 font-mono">{tenantsCount}</span>
              </div>
              <div className="p-3 bg-slate-100 rounded-xl border border-slate-300 text-center">
                <span className="text-[11px] text-slate-700 font-medium block">{isAr ? 'السيارات المسجلة' : 'Véhicules'}</span>
                <span className="text-xl font-bold text-slate-900 font-mono">{vehiclesCount}</span>
              </div>
            </div>

            {/* Data Table */}
            <div className="overflow-x-auto">
              <table className="w-full whitespace-nowrap text-start border-collapse text-xs">
                <thead>
                  <tr className="bg-emerald-900 text-white border border-emerald-950">
                    <th className="p-2 text-center w-8">#</th>
                    <th className="p-2 text-start">{isAr ? 'الاسم الكامل' : 'Nom Complet'}</th>
                    <th className="p-2 text-center">{isAr ? 'الصفة' : 'Statut'}</th>
                    <th className="p-2 text-center">{isAr ? 'العمارة' : 'Bâtiment'}</th>
                    <th className="p-2 text-center">{isAr ? 'الشقة' : 'Appt'}</th>
                    <th className="p-2 text-start">{isAr ? 'الهاتف' : 'Téléphone'}</th>
                    <th className="p-2 text-start">{isAr ? 'رقم CIN' : 'N° CIN'}</th>
                    <th className="p-2 text-start">{isAr ? 'لوحة السيارة' : 'Matricule'}</th>
                    <th className="p-2 text-center">{isAr ? 'الأفراد' : 'Membres'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 border border-slate-300">
                  {residents.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="p-6 text-center text-slate-500 font-medium">
                        {isAr ? 'لا توجد سجلات سكان مطابقة لشروط البحث' : 'Aucun résident correspondant'}
                      </td>
                    </tr>
                  ) : (
                    residents.map((r, idx) => (
                      <tr 
                        key={r.id || idx} 
                        className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/70'}
                      >
                        <td className="p-2 text-center font-mono font-semibold text-slate-600">{idx + 1}</td>
                        <td className="p-2 font-bold text-slate-900">{r.fullName}</td>
                        <td className="p-2 text-center">
                          <span className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-bold ${
                            r.type === 'owner' 
                              ? 'bg-emerald-100 text-emerald-800' 
                              : 'bg-blue-100 text-blue-800'
                          }`}>
                            {r.type === 'owner' ? (isAr ? 'مالك' : 'Propriétaire') : (isAr ? 'مكتري' : 'Locataire')}
                          </span>
                        </td>
                        <td className="p-2 text-center font-bold text-slate-800">{r.buildingCode}</td>
                        <td className="p-2 text-center font-mono font-bold text-slate-800">{r.apartmentNumber}</td>
                        <td className="p-2 font-mono text-slate-700">{r.phone}</td>
                        <td className="p-2 font-mono text-slate-600">{r.cin || '-'}</td>
                        <td className="p-2 font-mono text-slate-600">{r.vehiclePlate || '-'}</td>
                        <td className="p-2 text-center font-mono font-semibold text-slate-700">{r.familyMembersCount || 1}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Official Sign-off & Stamp Section */}
            <div className="pt-6 border-t-2 border-slate-300 mt-6 grid grid-cols-2 gap-6 text-xs">
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                <p className="font-bold text-slate-900 mb-1">{isAr ? 'ملاحظات إدارة الإقامة:' : 'Observations :'}</p>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  {isAr 
                    ? 'يُرجى من كافة القاطنين إشعار مكتب السانديك بأي تغيير في أرقام الهواتف أو لوحات السيارات لتسهيل الولوج عبر بوابات الأمن وحسن التنسيق.' 
                    : 'Prière de signaler au bureau du syndic tout changement de coordonnées ou d\'immatriculation pour faciliter les accès et la sécurité.'}
                </p>
              </div>

              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-center flex flex-col justify-between min-h-[110px]">
                <p className="font-bold text-slate-900">{isAr ? 'خاتم وتوقيع وكيل الاتحاد (السانديك)' : 'Cachet & Signature du Syndic'}</p>
                <div className="text-[10px] text-slate-400 font-mono">
                  {isAr ? 'حرر في: ' : 'Fait à , le : '} {currentDate}
                </div>
              </div>
            </div>

            {/* Legal Footnote */}
            <div className="text-center pt-3 border-t border-slate-200 text-[10px] text-slate-500">
              {isAr 
                ? 'الإقامة -  | نظام التسيير الرقمي لسانديك الملكية المشتركة' 
                : 'Résidence -  | Système de Gestion Numérique du Syndic'}
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
