import { RES } from '../config/residence';
import React, { useState, useId } from 'react';
import { useApp } from '../context/AppContext';
import { 
  KeyRound, ShieldCheck, Home, CheckCircle2, AlertCircle, 
  Eye, EyeOff, X, Lock, Check, UserCheck, Shield, Sparkles, Building2
} from 'lucide-react';

interface ChangePasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialRole?: 'syndic' | 'owner';
  defaultBuilding?: string;
  defaultApartment?: string;
  onSuccess?: (message: string) => void;
}

export const ChangePasswordModal: React.FC<ChangePasswordModalProps> = ({
  isOpen,
  onClose,
  initialRole = 'syndic',
  defaultBuilding = '',
  defaultApartment = '02',
  onSuccess,
}) => {
  const { 
    lang, 
    users, 
    buildings, 
    apartments, 
    residents, 
    updateUserPassword, 
    verifyUserCredentials,
    updateApartment,
    updateResident
  } = useApp();

  const [activeTab, setActiveTab] = useState<'syndic' | 'owner'>(initialRole);

  // --- Syndic Form State ---
  const [syndicUsername, setSyndicUsername] = useState('syndic');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);

  // --- Owner Form State ---
  const [selectedBuilding, setSelectedBuilding] = useState(defaultBuilding);
  const [selectedApartment, setSelectedApartment] = useState(defaultApartment);
  const [ownerCinVerification, setOwnerCinVerification] = useState('');
  const [showOwnerVerification, setShowOwnerVerification] = useState(false);
  const [newOwnerPassword, setNewOwnerPassword] = useState('');
  const [confirmOwnerPassword, setConfirmOwnerPassword] = useState('');
  const [showOwnerPassword, setShowOwnerPassword] = useState(false);

  // Feedback State
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const modalHeadingId = useId();

  if (!isOpen) return null;

  // Selected apartment info
  const currentApt = apartments.find(
    a => a.buildingCode === selectedBuilding && a.number === selectedApartment
  );
  const currentRes = residents.find(
    r => r.buildingCode === selectedBuilding && r.apartmentNumber === selectedApartment
  );
  const registeredCin = (currentApt?.ownerCin || currentRes?.cin || '').trim().toUpperCase();

  const resetMessages = () => {
    setErrorMessage('');
    setSuccessMessage('');
  };

  // Syndic Password Change Submit Handler
  const handleSyndicChange = (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    const cleanUser = syndicUsername.trim();
    if (!cleanUser) {
      setErrorMessage(lang === 'ar' ? 'يرجى إدخال اسم المستخدم' : 'Veuillez saisir l\'identifiant');
      return;
    }

    if (!currentPassword) {
      setErrorMessage(lang === 'ar' ? 'يرجى إدخال كلمة المرور الحالية' : 'Veuillez saisir le mot de passe actuel');
      return;
    }

    // Verify current password
    const isOldPassValid = verifyUserCredentials(cleanUser, currentPassword);
    if (!isOldPassValid) {
      setErrorMessage(lang === 'ar' ? 'كلمة المرور الحالية غير صحيحة' : 'Mot de passe actuel incorrect');
      return;
    }

    if (!newPassword || newPassword.length < 4) {
      setErrorMessage(lang === 'ar' ? 'يجب أن تتكون كلمة المرور الجديدة من 4 أحرف أو أرقام على الأقل' : 'Le nouveau mot de passe doit comporter au moins 4 caractères');
      return;
    }

    if (newPassword !== confirmPassword) {
      setErrorMessage(lang === 'ar' ? 'كلمتا المرور الجديدتان غير متطابقتين' : 'Les deux mots de passe ne correspondent pas');
      return;
    }

    // Apply change
    const updated = updateUserPassword(cleanUser, newPassword);
    if (updated) {
      const msg = lang === 'ar' 
        ? `تم بنجاح تغيير كلمة سر حساب (${cleanUser}). يمكنك الآن تسجيل الدخول بكلمة السر الجديدة.` 
        : `Le mot de passe du compte (${cleanUser}) a été mis à jour avec succès.`;
      setSuccessMessage(msg);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      if (onSuccess) onSuccess(msg);
    } else {
      setErrorMessage(lang === 'ar' ? 'تعذر العثور على الحساب المطلوب' : 'Compte introuvable');
    }
  };

  // Owner Password / CIN PIN Change Submit Handler
  const handleOwnerChange = (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    const cleanInputCin = ownerCinVerification.trim().toUpperCase();

    // Verification check
    if (registeredCin && cleanInputCin !== registeredCin) {
      setErrorMessage(
        lang === 'ar' 
          ? `رقم البطاقة الوطنية (CIN) المدخل غير مطابق للرقم المسجل لدى السانديك للشقة ${selectedApartment} (${selectedBuilding}).` 
          : `Le N° CIN saisi ne correspond pas à celui enregistré pour l'appartement ${selectedApartment}.`
      );
      return;
    }

    if (!newOwnerPassword || newOwnerPassword.length < 3) {
      setErrorMessage(
        lang === 'ar' 
          ? 'يرجى إدخال رمز سري أو كلمة مرور من 3 خانات على الأقل (مثال: رقم بطاقة CIN جديدة أو رمز سري).' 
          : 'Veuillez saisir au moins 3 caractères pour le nouveau code/mot de passe.'
      );
      return;
    }

    if (newOwnerPassword !== confirmOwnerPassword) {
      setErrorMessage(
        lang === 'ar' ? 'الرمز الجديد وتأكيد الرمز غير متطابقين' : 'Les codes saisis ne correspondent pas'
      );
      return;
    }

    // Update apartment and resident records with new CIN/Password
    const newCinOrCode = newOwnerPassword.trim().toUpperCase();
    if (currentApt) {
      updateApartment(currentApt.id, { ownerCin: newCinOrCode });
    }
    if (currentRes) {
      updateResident(currentRes.id, { cin: newCinOrCode });
    }

    const msg = lang === 'ar'
      ? `تم بنجاح تحديث رمز الدخول والبطاقة الوطنية للشقة رقم ${selectedApartment} (${selectedBuilding}). الرمز الجديد هو: ${newCinOrCode}`
      : `Le code d'accès de l'appartement ${selectedApartment} (${selectedBuilding}) a été mis à jour avec succès : ${newCinOrCode}`;
    
    setSuccessMessage(msg);
    setOwnerCinVerification('');
    setNewOwnerPassword('');
    setConfirmOwnerPassword('');
    if (onSuccess) onSuccess(msg);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        role="dialog"
        aria-modal="true"
        aria-labelledby={modalHeadingId}
        className="w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200"
      >
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 p-5 text-white flex items-center justify-between border-b border-emerald-800/40">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-800/60 border border-emerald-500/30 text-amber-300">
              <KeyRound className="w-6 h-6" />
            </div>
            <div>
              <h2 id={modalHeadingId} className="text-lg font-black tracking-tight text-white flex items-center gap-2">
                <span>{lang === 'ar' ? 'تغيير كلمة السر ورمز الدخول' : 'Changer le mot de passe'}</span>
                <span className="text-[10px] bg-amber-400 text-slate-950 font-bold px-2 py-0.5 rounded-full">
                  {lang === 'ar' ? RES.nameAr : ''}
                </span>
              </h2>
              <p className="text-xs text-emerald-200/80">
                {lang === 'ar' ? 'تحديث بيانات المرور الخاصة بالسانديك أو الملاك المشتركين' : 'Mise à jour sécurisée des accès'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            aria-label={lang === 'ar' ? 'إغلاق' : 'Fermer'}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher: Syndic vs Owner */}
        <div className="p-4 bg-slate-50 border-b border-slate-200/80">
          <div className="grid grid-cols-2 gap-2 p-1 bg-slate-200/80 rounded-2xl">
            <button
              type="button"
              id="tab-change-syndic"
              onClick={() => { setActiveTab('syndic'); resetMessages(); }}
              className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'syndic'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              <ShieldCheck className={`w-4 h-4 ${activeTab === 'syndic' ? 'text-amber-400' : 'text-slate-500'}`} />
              <span>{lang === 'ar' ? 'كلمة سر السانديك' : 'Mot de passe Syndic'}</span>
            </button>

            <button
              type="button"
              id="tab-change-owner"
              onClick={() => { setActiveTab('owner'); resetMessages(); }}
              className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'owner'
                  ? 'bg-emerald-800 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              <Home className={`w-4 h-4 ${activeTab === 'owner' ? 'text-amber-300' : 'text-slate-500'}`} />
              <span>{lang === 'ar' ? 'رمز / بطاقة المالك' : 'Code / CIN Copropriétaire'}</span>
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-4">

          {/* Success Banner */}
          {successMessage && (
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-start gap-3 animate-in fade-in duration-200">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <span className="font-bold block text-sm">{lang === 'ar' ? 'تم التحديث بنجاح!' : 'Modifié avec succès !'}</span>
                <p className="leading-relaxed">{successMessage}</p>
              </div>
            </div>
          )}

          {/* Error Banner */}
          {errorMessage && (
            <div className="p-3.5 rounded-2xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-start gap-2.5 animate-in fade-in duration-200">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
              <div className="leading-relaxed font-medium">{errorMessage}</div>
            </div>
          )}

          {/* SYNDIC PASSWORD FORM */}
          {activeTab === 'syndic' && (
            <form onSubmit={handleSyndicChange} className="space-y-4">
              
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1.5">
                  {lang === 'ar' ? 'حساب السانديك / اسم المستخدم *' : 'Compte Syndic / Identifiant *'}
                </label>
                <select
                  value={syndicUsername}
                  onChange={(e) => { setSyndicUsername(e.target.value); resetMessages(); }}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-bold focus:ring-2 focus:ring-emerald-600 bg-white text-slate-800"
                >
                  <option value="syndic">👤 syndic (وكيل السانديك الرئيسي)</option>
                  <option value="admin">🛡️ admin (المدير الإداري العام)</option>
                  {users.filter(u => u.username !== 'syndic' && u.username !== 'admin').map(u => (
                    <option key={u.id} value={u.username}>
                      👤 {u.username} ({u.name || u.role})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-800">
                    {lang === 'ar' ? 'كلمة المرور الحالية *' : 'Mot de passe actuel *'}
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                    className="text-[11px] text-emerald-700 hover:text-emerald-800 font-bold flex items-center gap-1 cursor-pointer"
                  >
                    {showCurrentPassword ? (
                      <>
                        <EyeOff className="w-3.5 h-3.5" />
                        <span>{lang === 'ar' ? 'إخفاء' : 'Masquer'}</span>
                      </>
                    ) : (
                      <>
                        <Eye className="w-3.5 h-3.5" />
                        <span>{lang === 'ar' ? 'إظهار' : 'Afficher'}</span>
                      </>
                    )}
                  </button>
                </div>
                <div className="relative">
                  <input
                    type={showCurrentPassword ? 'text' : 'password'}
                    required
                    value={currentPassword}
                    onChange={(e) => { setCurrentPassword(e.target.value); resetMessages(); }}
                    placeholder={lang === 'ar' ? 'أدخل كلمة المرور الحالية للتحقق' : 'Mot de passe actuel'}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-mono font-bold focus:ring-2 focus:ring-emerald-600 bg-white text-slate-900"
                  />
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                  {lang === 'ar' ? '💡 كلمة السر الافتراضية لحساب syndic هي 123456' : '💡 Mot de passe initial : 123456'}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-bold text-slate-800">
                      {lang === 'ar' ? 'كلمة المرور الجديدة *' : 'Nouveau mot de passe *'}
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                      className="text-[10px] text-slate-500 hover:text-slate-800"
                    >
                      {showNewPassword ? '👁️' : '🔒'}
                    </button>
                  </div>
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    required
                    value={newPassword}
                    onChange={(e) => { setNewPassword(e.target.value); resetMessages(); }}
                    placeholder={lang === 'ar' ? 'كلمة السر الجديدة' : 'Nouveau mot de passe'}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-mono font-bold focus:ring-2 focus:ring-emerald-600 bg-white text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1.5">
                    {lang === 'ar' ? 'تأكيد كلمة المرور الجديدة *' : 'Confirmer le mot de passe *'}
                  </label>
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    required
                    value={confirmPassword}
                    onChange={(e) => { setConfirmPassword(e.target.value); resetMessages(); }}
                    placeholder={lang === 'ar' ? 'أعد إدخال كلمة السر' : 'Confirmer mot de passe'}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-mono font-bold focus:ring-2 focus:ring-emerald-600 bg-white text-slate-900"
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl text-slate-600 hover:bg-slate-100 text-xs font-bold transition-all cursor-pointer"
                >
                  {lang === 'ar' ? 'إلغاء' : 'Annuler'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-black transition-all shadow-md flex items-center gap-2 cursor-pointer"
                >
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>{lang === 'ar' ? 'حفظ كلمة السر الجديدة للسانديك' : 'Enregistrer'}</span>
                </button>
              </div>
            </form>
          )}

          {/* OWNER PASSWORD / PIN FORM */}
          {activeTab === 'owner' && (
            <form onSubmit={handleOwnerChange} className="space-y-4">
              
              <div className="p-3 rounded-2xl bg-emerald-50/90 border border-emerald-200 text-emerald-950 text-xs flex items-start gap-2.5">
                <Home className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                <div className="leading-relaxed">
                  <span className="font-bold block">
                    {lang === 'ar' ? 'تخصيص رمز الدخول الخاص بالمالك:' : 'Personnaliser le code d\'accès copropriétaire :'}
                  </span>
                  <span>
                    {lang === 'ar' 
                      ? 'يمكنك تحديث رقم البطاقة الوطنية (CIN) أو الرمز السري المخصص لشقتك لتسجيل الدخول به مستقبلاً.' 
                      : 'Mettez à jour le N° CIN ou code d\'accès associé à votre lot.'}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Building Select */}
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1.5">
                    {lang === 'ar' ? 'العمارة *' : 'Immeuble *'}
                  </label>
                  <select
                    value={selectedBuilding}
                    onChange={(e) => { setSelectedBuilding(e.target.value); resetMessages(); }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold focus:ring-2 focus:ring-emerald-600 bg-white text-slate-800"
                  >
                    {buildings.map(b => (
                      <option key={b.id} value={b.code}>🏢 {b.name}</option>
                    ))}
                  </select>
                </div>

                {/* Apartment Select */}
                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1.5">
                    {lang === 'ar' ? 'رقم الشقة *' : 'N° Appartement *'}
                  </label>
                  <select
                    value={selectedApartment}
                    onChange={(e) => { setSelectedApartment(e.target.value); resetMessages(); }}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-bold focus:ring-2 focus:ring-emerald-600 bg-white text-slate-800"
                  >
                    {Array.from({ length: 16 }, (_, i) => String(i + 1).padStart(2, '0')).map(num => (
                      <option key={num} value={num}>🏠 {lang === 'ar' ? `شقة ${num}` : `Appt ${num}`}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Current CIN Verification (if already set) */}
              {registeredCin && (
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-bold text-slate-800">
                      {lang === 'ar' ? 'كلمة السر / رقم البطاقة الوطنية (CIN) الحالي للتحقق *' : 'N° CIN / Mot de passe actuel pour vérification *'}
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowOwnerVerification(!showOwnerVerification)}
                      className="text-[11px] text-emerald-700 hover:text-emerald-800 font-bold flex items-center gap-1 cursor-pointer"
                    >
                      {showOwnerVerification ? (
                        <>
                          <EyeOff className="w-3.5 h-3.5" />
                          <span>{lang === 'ar' ? 'إخفاء' : 'Masquer'}</span>
                        </>
                      ) : (
                        <>
                          <Eye className="w-3.5 h-3.5" />
                          <span>{lang === 'ar' ? 'إظهار' : 'Afficher'}</span>
                        </>
                      )}
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      type={showOwnerVerification ? 'text' : 'password'}
                      required
                      value={ownerCinVerification}
                      onChange={(e) => { setOwnerCinVerification(e.target.value.toUpperCase()); resetMessages(); }}
                      placeholder={lang === 'ar' ? 'أدخل كلمة السر أو CIN الحالي' : 'Saisir le mot de passe / CIN actuel'}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-mono font-bold tracking-wider uppercase focus:ring-2 focus:ring-emerald-600 bg-white text-slate-800"
                    />
                  </div>
                  <p className="text-[10px] text-slate-500 mt-1">
                    {lang === 'ar' ? '🔒 للتحقق من هوية صاحب الشقة قبل التعديل.' : '🔒 Pour vérifier votre identité de propriétaire.'}
                  </p>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-bold text-slate-800">
                      {lang === 'ar' ? 'الرمز أو CIN الجديد *' : 'Nouveau Code / CIN *'}
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowOwnerPassword(!showOwnerPassword)}
                      className="text-[10px] text-slate-500 hover:text-slate-800"
                    >
                      {showOwnerPassword ? '👁️' : '🔒'}
                    </button>
                  </div>
                  <input
                    type={showOwnerPassword ? 'text' : 'password'}
                    required
                    value={newOwnerPassword}
                    onChange={(e) => { setNewOwnerPassword(e.target.value); resetMessages(); }}
                    placeholder={lang === 'ar' ? 'مثال: BE123456 أو 9876' : 'Ex: BE123456'}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-mono font-bold uppercase focus:ring-2 focus:ring-emerald-600 bg-white text-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-800 mb-1.5">
                    {lang === 'ar' ? 'تأكيد الرمز الجديد *' : 'Confirmer le nouveau code *'}
                  </label>
                  <input
                    type={showOwnerPassword ? 'text' : 'password'}
                    required
                    value={confirmOwnerPassword}
                    onChange={(e) => { setConfirmOwnerPassword(e.target.value); resetMessages(); }}
                    placeholder={lang === 'ar' ? 'أعد إدخال الرمز الجديد' : 'Confirmer'}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-mono font-bold uppercase focus:ring-2 focus:ring-emerald-600 bg-white text-slate-800"
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2.5 rounded-xl text-slate-600 hover:bg-slate-100 text-xs font-bold transition-all cursor-pointer"
                >
                  {lang === 'ar' ? 'إلغاء' : 'Annuler'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-black transition-all shadow-md flex items-center gap-2 cursor-pointer"
                >
                  <Check className="w-4 h-4 text-amber-300" />
                  <span>{lang === 'ar' ? 'حفظ رمز الشقة الجديد' : 'Enregistrer pour l\'appartement'}</span>
                </button>
              </div>
            </form>
          )}

        </div>
      </div>
    </div>
  );
};
