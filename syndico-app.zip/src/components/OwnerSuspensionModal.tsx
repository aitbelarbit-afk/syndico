import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Apartment } from '../types';
import { DebtStatus } from '../utils/debtUtils';
import { 
  ShieldAlert, Lock, Phone, MessageSquare, Building2, Copy, Check,
  X, Info, AlertTriangle, MapPin, Banknote
} from 'lucide-react';

interface OwnerSuspensionModalProps {
  isOpen: boolean;
  onClose: () => void;
  apartment: Apartment | null;
  debtStatus: DebtStatus;
}

export const OwnerSuspensionModal: React.FC<OwnerSuspensionModalProps> = ({
  isOpen,
  onClose,
  apartment,
  debtStatus
}) => {
  const { lang } = useApp();
  const [copiedRib, setCopiedRib] = useState(false);

  if (!isOpen || !apartment) return null;

  const handleCopyRib = () => {
    navigator.clipboard.writeText('011 780 0000 123456789012 34');
    setCopiedRib(true);
    setTimeout(() => setCopiedRib(false), 2500);
  };

  const syndicWhatsappUrl = `https://wa.me/212661000000?text=${encodeURIComponent(
    lang === 'ar'
      ? `السلام عليكم مكتب سانديك الإقامة، أنا مالك شقة ${apartment.number} عمارة ${apartment.buildingCode}، أود أداء وتسوية ما بذمتي من مستحقات السانديك (${debtStatus.totalBalanceDue} درهم - متأخر ${debtStatus.unpaidMonths} أشهر) لتتمكن الشقة من الدخول إلى التطبيق.`
      : `Bonjour Syndic Résidence, je suis le copropriétaire de l'Appt ${apartment.number} Immeuble ${apartment.buildingCode}, je souhaite régler mes arriérés de cotisations (${debtStatus.totalBalanceDue} DH - ${debtStatus.unpaidMonths} mois) pour pouvoir accéder à l'application.`
  )}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      
      <div className="bg-white rounded-3xl shadow-2xl border-2 border-red-300 w-full max-w-2xl overflow-hidden my-auto animate-in zoom-in-95 duration-200">
        
        {/* Header Alert Banner */}
        <div className="bg-gradient-to-r from-red-950 via-red-900 to-rose-950 px-6 py-6 text-white relative">
          
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 start-4 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white/80 hover:text-white transition-all cursor-pointer"
            title={lang === 'ar' ? 'إغلاق' : 'Fermer'}
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mt-2 sm:mt-0">
            <div className="w-14 h-14 rounded-2xl bg-red-500/20 border border-red-300/30 flex items-center justify-center shrink-0 shadow-lg">
              <ShieldAlert className="w-8 h-8 text-rose-300 animate-bounce" />
            </div>
            
            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-red-950 border border-red-400/40 text-[11px] font-black text-rose-300">
                <Lock className="w-3.5 h-3.5 text-rose-400" />
                <span>{lang === 'ar' ? 'حساب محظور مؤقتاً (تجاوز 4 أشهر تأخير)' : 'Accès Bloqué (Retard > 4 mois)'}</span>
              </div>
              <h2 className="text-lg sm:text-xl font-black text-white leading-snug">
                {lang === 'ar' 
                  ? 'يجب أداء ما بذمتكم مستحقات السنديك لتتمكنوا من الدخول الى التطبيق' 
                  : 'Règlement des arriérés obligatoire pour accéder à l\'application'}
              </h2>
              <p className="text-rose-200 text-xs sm:text-sm font-medium">
                {lang === 'ar' 
                  ? 'يُسمح فقط للملاك المتأخرين بأربعة أشهر عن أداء واجبات السانديك بالدخول إلى التطبيق، وأكثر من ذلك يُمنعون من الدخول حتى أداء ما بذمتهم.' 
                  : 'Seuls les copropriétaires ayant jusqu\'à 4 mois d\'arriérés sont autorisés à accéder à l\'application. Au-delà, l\'accès est strictement suspendu.'}
              </p>
            </div>
          </div>

        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          
          {/* Main Alert Box with the exact phrase */}
          <div className="p-4 rounded-2xl bg-red-50 border-2 border-red-300 text-red-950 space-y-2">
            <div className="flex items-center gap-2 font-black text-sm text-red-800">
              <AlertTriangle className="w-5 h-5 text-red-600 shrink-0" />
              <span>{lang === 'ar' ? 'تنبيه إلزامي للمالك:' : 'Avertissement obligatoire :'}</span>
            </div>
            <p className="text-sm font-black text-red-900 bg-white p-3 rounded-xl border border-red-200 leading-relaxed shadow-2xs">
              {lang === 'ar' 
                ? '« يجب أداء ما بذمتكم مستحقات السنديك لتتمكنوا من الدخول الى التطبيق »' 
                : '« Vous devez régler vos arriérés de cotisations de syndic pour pouvoir accéder à l\'application »'}
            </p>
          </div>

          {/* Apartment & Debt Status Card */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-200 text-slate-800">
            
            {/* Apartment Details */}
            <div className="sm:col-span-1 border-b sm:border-b-0 sm:border-e border-slate-200 pb-3 sm:pb-0 sm:pe-3 space-y-1">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                {lang === 'ar' ? 'بيانات الشقة والمالك' : 'Lot & Propriétaire'}
              </span>
              <div className="font-mono font-black text-base text-slate-900 flex items-center gap-1.5">
                <Building2 className="w-4 h-4 text-emerald-800" />
                <span>{apartment.buildingCode}</span>
                <span className="text-red-700 font-bold">• شقة {apartment.number}</span>
              </div>
              <div className="text-xs font-bold text-slate-800 truncate">
                {apartment.ownerName || (lang === 'ar' ? 'مالك الشقة' : 'Propriétaire')}
              </div>
              <div className="text-[11px] text-slate-600 font-medium">
                {lang === 'ar' ? `الواجب الشهري: ${debtStatus.monthlyFee} درهم` : `Cotisation : ${debtStatus.monthlyFee} DH`}
              </div>
            </div>

            {/* Overdue Months */}
            <div className="border-b sm:border-b-0 sm:border-e border-slate-200 pb-3 sm:pb-0 sm:pe-3 space-y-1 text-center sm:text-start">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                {lang === 'ar' ? 'مدة التأخر المسجلة' : 'Retard Cumulé'}
              </span>
              <div className="text-2xl font-black text-red-700 font-mono">
                {debtStatus.unpaidMonths} {lang === 'ar' ? 'أشهر متأخرة' : 'mois impayés'}
              </div>
              <div className="text-[10px] font-black text-red-950 bg-red-100 px-2 py-0.5 rounded-md inline-block">
                {lang === 'ar' ? '⛔ أكثر من 4 أشهر (دخول ممنوع)' : '⛔ > 4 mois (accès bloqué)'}
              </div>
            </div>

            {/* Total Balance Due */}
            <div className="space-y-1 text-center sm:text-start">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                {lang === 'ar' ? 'مجموع المبالغ المستحقة' : 'Total Impayé Dû'}
              </span>
              <div className="text-2xl font-black text-red-700 font-mono">
                {debtStatus.totalBalanceDue.toLocaleString()} <span className="text-xs font-bold text-red-950">DH</span>
              </div>
              <div className="text-[11px] text-slate-600 font-medium">
                {lang === 'ar' ? 'واجبة الأداء لصندوق الإقامة' : 'À verser au syndic'}
              </div>
            </div>

          </div>

          {/* Strict Block Information */}
          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-300 text-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-amber-950 font-black text-xs sm:text-sm">
              <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
              <span>{lang === 'ar' ? 'ضوابط الدخول للتطبيق (الإقامة):' : 'Conditions d\'accès à l\'application :'}</span>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed font-medium">
              {lang === 'ar'
                ? 'يسمح فقط للملاك المتأخرين بأربعة أشهر عن أداء واجبات السانديك (من 0 إلى 4 أشهر كحد أقصى) الدخول إلى التطبيق. أكثر من ذلك (5 أشهر فما فوق) يمنعون من الدخول حتى أداء ما بذمتهم من مستحقات السانديك.'
                : 'Seuls les copropriétaires ayant jusqu\'à 4 mois d\'arriérés (de 0 à 4 mois maximum) sont autorisés à accéder à l\'application. Tout retard supérieur à 4 mois (5 mois et plus) entraîne la suspension de l\'accès jusqu\'au règlement complet des cotisations dues.'}
            </p>
          </div>

          {/* Payment / Regularization Instructions */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
            <h4 className="text-xs font-black text-slate-900 flex items-center gap-2">
              <Banknote className="w-4 h-4 text-emerald-700" />
              <span>{lang === 'ar' ? 'طرق تسوية المستحقات المعتمدة:' : 'Moyens de règlement autorisés :'}</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              
              {/* Option 1: Office Visit */}
              <div className="p-3 rounded-xl bg-white border border-slate-200 space-y-1">
                <div className="font-bold text-slate-900 flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-emerald-700" />
                  <span>{lang === 'ar' ? '1. مكتب السانديك مباشرة' : '1. Bureau du Syndic'}</span>
                </div>
                <p className="text-[11px] text-slate-600">
                  {lang === 'ar' ? 'العمارة - الشقة رقم 01 (مكتب الإدارة).' : 'Immeuble - Appt 01.'}
                </p>
                <span className="text-[10px] text-emerald-800 font-bold block">
                  {lang === 'ar' ? 'نقداً أو شيك بنكي مع استلام وصل فوري' : 'Espèces ou chèque avec reçu'}
                </span>
              </div>

              {/* Option 2: Bank Transfer */}
              <div className="p-3 rounded-xl bg-white border border-slate-200 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900">
                    {lang === 'ar' ? '2. تحويل بنكي رسمي' : '2. Virement bancaire'}
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyRib}
                    className="flex items-center gap-1 text-[10px] font-bold text-emerald-800 hover:text-emerald-950 cursor-pointer"
                  >
                    {copiedRib ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedRib ? (lang === 'ar' ? 'تم النسخ' : 'نسخ') : (lang === 'ar' ? 'نسخ الـ RIB' : 'Copier')}</span>
                  </button>
                </div>
                <div className="font-mono text-[11px] font-black bg-slate-100 p-1.5 rounded text-center tracking-wider text-slate-900">
                  011 780 0000 123456789012 34
                </div>
                <span className="text-[10px] text-slate-500 block">
                  {lang === 'ar' ? 'اتحاد ملاك الإقامة' : 'Syndicat des copropriétaires'}
                </span>
              </div>

            </div>
          </div>

          {/* Direct Action Buttons to Contact Syndic */}
          <div className="space-y-2 pt-2">
            <a
              href={syndicWhatsappUrl}
              target="_blank"
              rel="noreferrer"
              className="w-full py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-black text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2"
            >
              <MessageSquare className="w-4 h-4 text-emerald-200" />
              <span>{lang === 'ar' ? 'مراسلة السانديك عبر واتساب لطلب التسوية' : 'Contacter le syndic par WhatsApp'}</span>
            </a>

            <div className="flex items-center gap-2">
              <a
                href="tel:"
                className="flex-1 py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold border border-slate-200 flex items-center justify-center gap-1.5 transition-colors"
              >
                <Phone className="w-3.5 h-3.5 text-slate-600" />
                <span>{lang === 'ar' ? 'الاتصال هاتفياً بوكيل السانديك' : 'Appeler le syndic'}</span>
              </a>

              <button
                type="button"
                onClick={onClose}
                className="py-2.5 px-5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold cursor-pointer transition-colors"
              >
                {lang === 'ar' ? 'إغلاق والعودة' : 'Fermer'}
              </button>
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="bg-slate-100 px-6 py-2.5 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>{lang === 'ar' ? 'ميثاق التدبير المشترك • الإقامة - ' : 'Règlement de copropriété • Résidence'}</span>
          <span className="font-mono text-[11px] font-bold text-red-700">{lang === 'ar' ? 'حالة الحساب: معلق ⛔' : 'Statut : Bloqué ⛔'}</span>
        </div>

      </div>

    </div>
  );
};
