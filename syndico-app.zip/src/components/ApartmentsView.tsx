import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Apartment, ApartmentStatus } from '../types';
import { 
  Home, Plus, Search, Trash2, Edit2, Check, X, CreditCard, Lock, Eye, 
  ShieldCheck, FileText, CheckCircle2, AlertCircle, Printer, Wrench, Building2, User, Phone, Calendar,
  Coins, Sparkles, ShieldAlert, RotateCcw, Eraser, FileSpreadsheet, Clock
} from 'lucide-react';
import { ExcelImportModal } from './ExcelImportModal';
import { OwnersDuesExcelModal } from './OwnersDuesExcelModal';
import { OverduePayersModal } from './OverduePayersModal';
import { 
  getApartmentDebtStatus, 
  getLastPaidMonthDisplay, 
  getEarliestUnpaidMonthKey, 
  getUnpaidMonthsList, 
  formatPeriodDisplay, 
  CURRENT_REFERENCE_YEAR 
} from '../utils/debtUtils';
import { getMoroccanApartmentData } from '../data/moroccanResidentsData';
import { Building2 as HeaderIcon } from 'lucide-react';

export const ApartmentsView: React.FC = () => {
  const { 
    t, lang, currentUser, apartments, buildings, addApartment, updateApartment, 
    deleteApartment, updateAllMonthlyFees, resetAllApartmentDebts, setApartmentDebt,
    addPayment, payments, setSelectedReceipt, setActiveSection
  } = useApp();

  const isOwner = currentUser?.role === 'resident';

  // Find owner's own apartment
  const myApartment = isOwner 
    ? (apartments.find(a => 
        (a.buildingCode.replace(/\s+/g, '').toUpperCase() === (currentUser?.building || '').replace(/\s+/g, '').toUpperCase()) && 
        (a.number.replace(/\D/g, '') === (currentUser?.apartment || '').replace(/\D/g, ''))
      ) || apartments.find(a => a.buildingCode.includes(currentUser?.building || '')) || apartments[0])
    : null;

  // Payments for owner's apartment only
  const myPayments = isOwner && myApartment
    ? payments.filter(p => 
        p.buildingCode.replace(/\s+/g, '').toUpperCase() === myApartment.buildingCode.replace(/\s+/g, '').toUpperCase() &&
        p.apartmentNumber.replace(/\D/g, '') === myApartment.number.replace(/\D/g, '')
      )
    : [];

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBuilding, setSelectedBuilding] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');
  const [selectedDebt, setSelectedDebt] = useState('ALL');
  const [sortByDebt, setSortByDebt] = useState<'debt_asc' | 'debt_desc' | 'building'>('debt_asc');

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Bulk General Assembly Fee Modal
  const [isBulkFeeModalOpen, setIsBulkFeeModalOpen] = useState(false);
  const [bulkFeeAmount, setBulkFeeAmount] = useState<number>(150);
  const [bulkTargetBuilding, setBulkTargetBuilding] = useState<string>('ALL');
  const [bulkSuccessMsg, setBulkSuccessMsg] = useState<string | null>(null);

  // Excel Bulk Import Modal
  const [isExcelImportModalOpen, setIsExcelImportModalOpen] = useState(false);

  // Owners Dues Excel Modal (Export & Import)
  const [isOwnersDuesModalOpen, setIsOwnersDuesModalOpen] = useState(false);
  const [ownersDuesTab, setOwnersDuesTab] = useState<'export' | 'import'>('import');
  const [apartmentToDelete, setApartmentToDelete] = useState<Apartment | null>(null);

  // Dedicated Overdue Payers Ranking Modal
  const [isOverdueModalOpen, setIsOverdueModalOpen] = useState(false);

  // Clear/Reset Debts Modal
  const [isClearDebtsModalOpen, setIsClearDebtsModalOpen] = useState(false);
  const [clearDebtsTargetBuilding, setClearDebtsTargetBuilding] = useState<string>('ALL');
  const [clearDebtsSuccessMsg, setClearDebtsSuccessMsg] = useState<string | null>(null);

  // Quick Pay Modal (Syndic only)
  const [quickPayApt, setQuickPayApt] = useState<Apartment | null>(null);
  const [payAmount, setPayAmount] = useState<number>(0);
  const [payMonth, setPayMonth] = useState('2026-05');
  const [payDate, setPayDate] = useState<string>(() => new Date().toISOString().slice(0, 10));
  const [payMonthsCount, setPayMonthsCount] = useState<number>(1);
  const [payMethod, setPayMethod] = useState<'cash' | 'bank_transfer' | 'check'>('cash');

  // Form State
  const [number, setNumber] = useState('');
  const [buildingCode, setBuildingCode] = useState(buildings[0]?.code || '');
  const [floor, setFloor] = useState(0);
  const [ownerName, setOwnerName] = useState('');
  const [ownerPhone, setOwnerPhone] = useState('');
  const [ownerCin, setOwnerCin] = useState('');
  const [residentName, setResidentName] = useState('');
  const [residentPhone, setResidentPhone] = useState('');
  const [status, setStatus] = useState<ApartmentStatus>('occupied');
  const [monthlyFee, setMonthlyFee] = useState<number>(150);
  const [balanceDue, setBalanceDue] = useState<number>(0);
  const [unpaidMonthsCount, setUnpaidMonthsCount] = useState<number>(0);
  const [debtType, setDebtType] = useState<'clean' | 'in_debt'>('clean');

  const getFloorLabel = (floorNum: number, currentLang: string = 'ar') => {
    if (floorNum === 0) return currentLang === 'ar' ? 'الطابق السفلي (RDC)' : 'Rez-de-chaussée (RDC)';
    if (floorNum === 1) return currentLang === 'ar' ? 'الطابق الأول' : '1er étage';
    if (floorNum === 2) return currentLang === 'ar' ? 'الطابق الثاني' : '2ème étage';
    if (floorNum === 3) return currentLang === 'ar' ? 'الطابق الثالث' : '3ème étage';
    return currentLang === 'ar' ? `الطابق ${floorNum}` : `Étage ${floorNum}`;
  };

  const handleOpenNew = () => {
    if (isOwner) return;
    setEditingId(null);
    setNumber(String(apartments.length + 1).padStart(2, '0'));
    setBuildingCode(buildings[0]?.code || '');
    setFloor(0);
    setOwnerName('');
    setOwnerPhone('');
    setOwnerCin('');
    setResidentName('');
    setResidentPhone('');
    setStatus('occupied');
    setMonthlyFee(150);
    setBalanceDue(0);
    setUnpaidMonthsCount(0);
    setDebtType('clean');
    setIsFormOpen(true);
  };

  const handleOpenEdit = (apt: Apartment) => {
    if (isOwner) return;
    setEditingId(apt.id);
    setNumber(apt.number);
    setBuildingCode(apt.buildingCode);
    setFloor(apt.floor ?? 0);
    setOwnerName(apt.ownerName || '');
    setOwnerPhone(apt.ownerPhone || '');
    setOwnerCin(apt.ownerCin || '');
    setResidentName(apt.residentName || '');
    setResidentPhone(apt.residentPhone || '');
    setStatus(apt.status || 'occupied');
    const fee = apt.monthlyFee ?? 150;
    setMonthlyFee(fee);
    const bal = apt.balanceDue ?? 0;
    setBalanceDue(bal);
    const calculatedMonths = apt.unpaidMonthsCount ?? (bal > 0 ? Math.round(bal / (fee || 150)) : 0);
    setUnpaidMonthsCount(calculatedMonths);
    setDebtType(bal > 0 || calculatedMonths > 0 ? 'in_debt' : 'clean');
    setIsFormOpen(true);
  };

  const handleApplyBulkFee = (e: React.FormEvent) => {
    e.preventDefault();
    if (isOwner) return;
    const amount = Number(bulkFeeAmount);
    updateAllMonthlyFees(amount, bulkTargetBuilding);
    setBulkSuccessMsg(
      lang === 'ar'
        ? `تم بنجاح تحديث واجب السانديك الشهري إلى ${amount} درهم ${bulkTargetBuilding === 'ALL' ? 'لكافة شقق الإقامة (جميع الشقق)' : `لعمارة ${bulkTargetBuilding}`}`
        : `Cotisation mise à jour avec succès (${amount} DH) ${bulkTargetBuilding === 'ALL' ? 'pour tous les lots' : `pour l\'immeuble ${bulkTargetBuilding}`}`
    );
    setTimeout(() => {
      setBulkSuccessMsg(null);
      setIsBulkFeeModalOpen(false);
    }, 1800);
  };

  const handleApplyClearDebts = (e: React.FormEvent) => {
    e.preventDefault();
    if (isOwner) return;
    resetAllApartmentDebts(clearDebtsTargetBuilding);
    setClearDebtsSuccessMsg(
      lang === 'ar'
        ? `تم بنجاح تصفير ومسح المديونيات ${clearDebtsTargetBuilding === 'ALL' ? 'لكافة شقق الإقامة (جميع الشقق)' : `لعمارة ${clearDebtsTargetBuilding}`}. أصبحت الوضعية عادية (0 درهم ديون) حتى يقوم السانديك بإدخال المديونيات المستحقة بدقة.`
        : `Toutes les dettes ont été remises à zéro avec succès (${clearDebtsTargetBuilding === 'ALL' ? 'tous les logements' : `immeuble ${clearDebtsTargetBuilding}`}).`
    );
    setTimeout(() => {
      setClearDebtsSuccessMsg(null);
      setIsClearDebtsModalOpen(false);
    }, 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isOwner) return;
    if (!number.trim() || !buildingCode) return;

    const finalMonths = debtType === 'clean' ? 0 : Number(unpaidMonthsCount);
    const finalBalance = debtType === 'clean' ? 0 : Number(balanceDue);

    if (editingId) {
      updateApartment(editingId, {
        number,
        buildingCode,
        floor: Number(floor),
        ownerName,
        ownerPhone,
        ownerCin,
        residentName: residentName || ownerName,
        residentPhone: residentPhone || ownerPhone,
        isRented: status === 'occupied' && residentName !== ownerName,
        status,
        monthlyFee: Number(monthlyFee),
        balanceDue: finalBalance,
        unpaidMonthsCount: finalMonths,
      });
    } else {
      addApartment({
        number,
        buildingCode,
        floor: Number(floor),
        ownerName,
        ownerPhone,
        ownerCin,
        residentName: residentName || ownerName,
        residentPhone: residentPhone || ownerPhone,
        isRented: status === 'occupied' && residentName !== ownerName,
        status,
        monthlyFee: Number(monthlyFee),
        balanceDue: finalBalance,
        unpaidMonthsCount: finalMonths,
      });
    }
    setIsFormOpen(false);
  };

  const handleQuickPaySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isOwner || !quickPayApt) return;

    const mData = getMoroccanApartmentData(quickPayApt.buildingCode, quickPayApt.number);
    const fallbackResidentName = (quickPayApt.residentName && !quickPayApt.residentName.includes('مالك شقة')) 
      ? quickPayApt.residentName 
      : (quickPayApt.ownerName && !quickPayApt.ownerName.includes('مالك شقة')) 
        ? quickPayApt.ownerName 
        : mData.residentName || mData.fullName;

    const receipt = addPayment({
      residentName: fallbackResidentName,
      buildingCode: quickPayApt.buildingCode,
      apartmentNumber: quickPayApt.number,
      periodMonth: payMonth,
      amount: Number(payAmount),
      paymentDate: payDate || new Date().toISOString().slice(0, 10),
      paymentMethod: payMethod,
      notes: payMonthsCount > 1 
        ? `أداء واجب السانديك عن ${payMonthsCount} أشهر (${payMonth})`
        : `أداء واجب السانديك لشهر ${payMonth}`,
      receivedBy: 'مكتب السانديك',
    });

    setQuickPayApt(null);
    setSelectedReceipt(receipt);
  };

  const filteredApartments = useMemo(() => {
    const list = apartments.filter(a => {
      const matchesSearch = 
        (a.number || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (a.buildingCode || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (a.ownerName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (a.residentName || '').toLowerCase().includes(searchTerm.toLowerCase());

      const matchesBuilding = 
        selectedBuilding === 'ALL' ||
        (selectedBuilding === 'GROUP_A' && (a.buildingCode.endsWith('A') || a.buildingCode.includes(' A'))) ||
        (selectedBuilding === 'GROUP_B' && (a.buildingCode.endsWith('B') || a.buildingCode.includes(' B'))) ||
        a.buildingCode === selectedBuilding;
      const matchesStatus = selectedStatus === 'ALL' || a.status === selectedStatus;
      const debtStatus = getApartmentDebtStatus(a, payments);
      const matchesDebt = 
        selectedDebt === 'ALL' 
          ? true 
          : selectedDebt === 'clean' 
          ? debtStatus.isPaid 
          : selectedDebt === 'debt' 
          ? (!debtStatus.isPaid && !a.isSyndicOffice) 
          : true;

      return matchesSearch && matchesBuilding && matchesStatus && matchesDebt;
    });

    return [...list].sort((a, b) => {
      if (sortByDebt === 'debt_asc') {
        const debtA = getApartmentDebtStatus(a, payments);
        const debtB = getApartmentDebtStatus(b, payments);
        if (debtA.unpaidMonths !== debtB.unpaidMonths) {
          return debtA.unpaidMonths - debtB.unpaidMonths;
        }
        if (debtA.totalBalanceDue !== debtB.totalBalanceDue) {
          return debtA.totalBalanceDue - debtB.totalBalanceDue;
        }
        return a.buildingCode.localeCompare(b.buildingCode) || (parseInt(a.number, 10) - parseInt(b.number, 10));
      }

      if (sortByDebt === 'debt_desc') {
        const debtA = getApartmentDebtStatus(a, payments);
        const debtB = getApartmentDebtStatus(b, payments);
        if (debtB.unpaidMonths !== debtA.unpaidMonths) {
          return debtB.unpaidMonths - debtA.unpaidMonths;
        }
        if (debtB.totalBalanceDue !== debtA.totalBalanceDue) {
          return debtB.totalBalanceDue - debtA.totalBalanceDue;
        }
        return a.buildingCode.localeCompare(b.buildingCode) || (parseInt(a.number, 10) - parseInt(b.number, 10));
      }

      // Default: building order
      return a.buildingCode.localeCompare(b.buildingCode) || (parseInt(a.number, 10) - parseInt(b.number, 10));
    });
  }, [apartments, payments, searchTerm, selectedBuilding, selectedStatus, selectedDebt, sortByDebt]);

  // ==========================================
  // RENDER OWNER PRIVATE VIEW (PRIVACY-COMPLIANT)
  // ==========================================
  if (isOwner && myApartment) {
    return (
      <div className="space-y-6">
        {/* Owner Header */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-lg bg-[#e9fbf8] text-[#0a8591] border border-[#92e8dd] text-xs font-extrabold font-mono">
                {myApartment.buildingCode} - شقة {myApartment.number}
              </span>
              <span className="flex items-center gap-1 text-[11px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                <ShieldCheck className="w-3.5 h-3.5 text-[#0a8591]" />
                {lang === 'ar' ? 'فضاء المالك المحمي' : 'Espace Propriétaire Sécurisé'}
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-2">
              {lang === 'ar' ? 'بطاقة شقتي والوضعية المالية' : 'Mon Appartement & Situation Financière'}
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">
              {lang === 'ar' 
                ? 'الإقامة - الاطلاع الحصري على بيانات شقتك والوصولات الشخصية' 
                : 'Résidence - Consultation exclusive de votre appartement'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveSection('maintenance')}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
            >
              <Wrench className="w-4 h-4" />
              <span>{lang === 'ar' ? 'طلب صيانة أو شكاية' : 'Réclamation'}</span>
            </button>
          </div>
        </div>

        {/* Confidentiality notice */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-slate-700 flex items-start gap-3 text-xs">
          <ShieldCheck className="w-5 h-5 text-[#0a8591] mt-0.5 shrink-0" />
          <div className="leading-relaxed">
            <span className="font-bold text-slate-900">
              {lang === 'ar' ? 'حماية الخصوصية والمعطيات الشخصية: ' : 'Protection des données privées : '}
            </span>
            {lang === 'ar' 
              ? 'طبقاً لميثاق اتحاد الملاك المشتركين وقوانين حماية المعطيات الشخصية، يُسمح لكل مالك بالاطلاع الحصري على بيانات شقته ومستحقاته المالية، بينما تظل بيانات الملاك الآخرين محمية ومحجوبة لمنع التطفل.'
              : 'Conformément aux règles de copropriété, vous avez accès uniquement aux données de votre appartement.'}
          </div>
        </div>

        {/* Main Details & Financial Card */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Apartment Info Card */}
          <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2.5 text-[#0a8591] font-bold text-base">
                <Home className="w-5 h-5 text-[#0a8591]" />
                <span>{lang === 'ar' ? 'البيانات العقارية والساكن' : 'Détails de l\'appartement'}</span>
              </div>
              <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                myApartment.status === 'occupied' ? 'bg-[#e9fbf8] text-[#0a8591] border border-[#92e8dd]' : 'bg-slate-100 text-slate-700'
              }`}>
                {myApartment.status === 'occupied' ? (lang === 'ar' ? 'شقة مسكونة' : 'Occupé') : (lang === 'ar' ? 'شقة شاغرة' : 'Vacant')}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                <div className="text-slate-400 font-medium mb-1">{lang === 'ar' ? 'العمارة' : 'Immeuble'}</div>
                <div className="text-sm font-bold text-[#0a8591]">{myApartment.buildingCode}</div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                <div className="text-slate-400 font-medium mb-1">{lang === 'ar' ? 'رقم الشقة' : 'N° Appartement'}</div>
                <div className="text-sm font-bold text-slate-900 font-mono">شقة {myApartment.number}</div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                <div className="text-slate-400 font-medium mb-1">{lang === 'ar' ? 'الطابق' : 'Étage'}</div>
                <div className="text-sm font-bold text-slate-900">{getFloorLabel(myApartment.floor, lang)}</div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100">
                <div className="text-slate-400 font-medium mb-1">{lang === 'ar' ? 'الاسم الكامل للمالك' : 'Propriétaire'}</div>
                <div className="text-sm font-bold text-slate-900">{myApartment.ownerName || currentUser?.name}</div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 col-span-2 sm:col-span-1">
                <div className="text-slate-400 font-medium mb-1">{lang === 'ar' ? 'الساكن الفعلي' : 'Résident'}</div>
                <div className="text-sm font-bold text-slate-900">{myApartment.residentName || myApartment.ownerName}</div>
              </div>
            </div>

            {myApartment.ownerPhone && (
              <div className="flex items-center gap-2 p-3 rounded-xl bg-[#e9fbf8] border border-[#92e8dd] text-xs text-[#0a8591]">
                <Phone className="w-4 h-4 text-[#0a8591]" />
                <span className="font-medium">{lang === 'ar' ? 'رقم الهاتف المسجل لدى السانديك:' : 'Téléphone enregistré :'}</span>
                <span className="font-bold font-mono">{myApartment.ownerPhone}</span>
              </div>
            )}
          </div>

          {/* Financial Status Summary */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center gap-2 text-[#0a8591] font-bold text-base pb-3 border-b border-slate-100 mb-4">
                <CreditCard className="w-5 h-5 text-[#0a8591]" />
                <span>{lang === 'ar' ? 'الاشتراك والوضعية المالية' : 'Cotisations & Solde'}</span>
              </div>

              <div className="space-y-3">
                <div className="p-4 rounded-xl bg-[#e9fbf8] border border-[#92e8dd] text-[#0a8591]">
                  <div className="text-xs font-semibold text-[#0a8591] mb-1">
                    {lang === 'ar' ? 'الواجب الشهري للسانديك' : 'Cotisation Mensuelle'}
                  </div>
                  <div className="text-2xl font-black text-[#0a8591] font-mono">
                    {myApartment.monthlyFee} <span className="text-xs font-bold text-[#0a8591]/80">DH / شهر</span>
                  </div>
                </div>

                {(() => {
                  const myAptDebt = getApartmentDebtStatus(myApartment, payments);
                  return (
                    <div className={`p-4 rounded-xl border ${
                      myAptDebt.isPaid 
                        ? 'bg-emerald-50/60 border-emerald-200 text-emerald-900' 
                        : 'bg-rose-50 border-rose-300 text-rose-950 shadow-2xs'
                    }`}>
                      <div className="text-xs font-semibold mb-1 flex items-center justify-between">
                        <span>{lang === 'ar' ? 'الوضعية المالية الحالية' : 'Situation Financière Actuelle'}</span>
                        {myAptDebt.isPaid ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        ) : (
                          <AlertCircle className="w-4 h-4 text-rose-600" />
                        )}
                      </div>
                      
                      {myAptDebt.isPaid ? (
                        <div>
                          <div className="text-sm font-extrabold text-emerald-800">
                            {lang === 'ar' ? '✅ حسابك خالص ومسوى (غير مدين لسانديك 🟢)' : '✅ À jour - Aucun retard (0 DH)'}
                          </div>
                          <div className="text-[11px] text-emerald-700 mt-1">
                            {lang === 'ar' ? 'جميع واجبات السانديك مسواة حتى الشهر الجاري.' : 'Toutes les cotisations sont réglées à jour.'}
                          </div>
                        </div>
                      ) : (
                        <div>
                          <div className="flex items-center justify-between">
                            <div className="text-xl font-black text-rose-700 font-mono">
                              🔴 {myAptDebt.totalBalanceDue.toLocaleString()} DH
                            </div>
                            <span className="px-2 py-0.5 rounded bg-rose-200 text-rose-900 text-[10px] font-black border border-rose-300">
                              {lang === 'ar' ? `غير خالص (${myAptDebt.unpaidMonths} شهر)` : `Non réglé (${myAptDebt.unpaidMonths} mois)`}
                            </span>
                          </div>
                          <div className="text-[11px] text-rose-700 mt-1 font-bold">
                            {lang === 'ar' 
                              ? (myAptDebt.unpaidMonths > 1
                                  ? `🔴 متأخرات مستحقة عن ${myAptDebt.unpaidMonths} أشهر، المرجو تسويتها لدى مكتب السانديك`
                                  : '🔴 واجب شهر ماي 2026 مستحق، المرجو الأداء لدى مكتب السانديك')
                              : '🔴 Cotisation due à régulariser auprès du bureau du syndic'}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })()}
              </div>
            </div>

            <div className="text-[11px] text-slate-500 text-center pt-3 border-t border-slate-100">
              {lang === 'ar' ? 'مكتب سانديك الإقامة' : 'Syndic Résidence'}
            </div>
          </div>
        </div>

        {/* My Receipts & Payment History */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2.5 text-slate-900 font-bold text-base">
              <FileText className="w-5 h-5 text-emerald-700" />
              <span>{lang === 'ar' ? 'سجل وصولات الأداء الخاصة بشقتي' : 'Mes Reçus de Paiement'}</span>
            </div>
            <span className="text-xs font-bold text-slate-500">
              {myPayments.length} {lang === 'ar' ? 'وصل مؤكد' : 'reçus'}
            </span>
          </div>

          {myPayments.length === 0 ? (
            <div className="text-center py-10 text-slate-400 text-xs">
              <FileText className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <div>{lang === 'ar' ? 'لا توجد وصولات أداء مسجلة بعد لهذه الشقة' : 'Aucun reçu de paiement enregistré'}</div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full whitespace-nowrap text-xs text-start border-collapse">
                <thead>
                  <tr className="bg-emerald-900 text-white font-bold">
                    <th className="p-3 text-start">{lang === 'ar' ? 'رقم الوصل' : 'N° Reçu'}</th>
                    <th className="p-3 text-start">{lang === 'ar' ? 'الشهر المؤدى عنه' : 'Période'}</th>
                    <th className="p-3 text-start">{lang === 'ar' ? 'المبلغ' : 'Montant'}</th>
                    <th className="p-3 text-start">{lang === 'ar' ? 'تاريخ الأداء' : 'Date'}</th>
                    <th className="p-3 text-start">{lang === 'ar' ? 'طريقة الدفع' : 'Mode'}</th>
                    <th className="p-3 text-center">{lang === 'ar' ? 'الوصل' : 'Reçu'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {myPayments.map(p => (
                    <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3 font-mono font-bold text-slate-900">
                        <span className="px-2 py-1 rounded bg-slate-100 border border-slate-200">
                          {p.receiptNumber}
                        </span>
                      </td>
                      <td className="p-3 font-semibold text-emerald-900">
                        {p.periodMonth}
                      </td>
                      <td className="p-3 font-black text-emerald-700 font-mono">
                        {p.amount} DH
                      </td>
                      <td className="p-3 text-slate-600">
                        {p.paymentDate}
                      </td>
                      <td className="p-3">
                        <span className="px-2 py-0.5 rounded-full text-[11px] bg-slate-100 text-slate-700 font-medium">
                          {p.paymentMethod === 'cash' ? 'نقداً (Espèces)' : p.paymentMethod === 'bank_transfer' ? 'تحويل بنكي (Virement)' : 'شيك (Chèque)'}
                        </span>
                      </td>
                      <td className="p-3 text-center">
                        <button
                          onClick={() => setSelectedReceipt(p)}
                          className="px-3 py-1.5 rounded-lg bg-[#e9fbf8] hover:bg-[#92e8dd] text-[#0a8591] font-bold inline-flex items-center gap-1.5 transition-colors cursor-pointer text-xs border border-[#92e8dd]"
                        >
                          <Printer className="w-3.5 h-3.5 text-[#0a8591]" />
                          <span>{lang === 'ar' ? 'عرض الوصل' : 'Voir reçu'}</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    );
  }

  // ==========================================
  // RENDER SYNDIC / ADMIN FULL MANAGEMENT VIEW
  // ==========================================
  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 relative overflow-hidden bg-white p-5 rounded-2xl border border-slate-200 border-t-4 border-t-indigo-500 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="icon-wiggle anim-bob w-10 h-10 rounded-2xl bg-gradient-to-br from-indigo-400 to-indigo-600 text-white flex items-center justify-center shadow-md shrink-0"><HeaderIcon className="w-5 h-5" /></span>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">{t.apartments.title}</h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 font-medium mt-1">{t.apartments.subtitle}</p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* ترتيب الملاك المتأخرين عن أداء واجبات السانديك */}
          <button
            type="button"
            id="btn-apartments-overdue-ranking"
            onClick={() => setIsOverdueModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-rose-700 to-amber-700 hover:from-rose-800 hover:to-amber-800 text-white text-xs font-bold transition-all shadow-xs border border-rose-400/30 cursor-pointer"
            title={lang === 'ar' ? 'ترتيب الملاك المتأخرين عن أداء واجبات السانديك من الملتزم شهرياً إلى أكثر متأخر مع الديون' : 'Classement des copropriétaires (du plus assidu au plus débiteur)'}
          >
            <Clock className="w-4 h-4 text-amber-200" />
            <span>{lang === 'ar' ? 'ترتيب المتأخرين والديون 📊' : 'Classement Débiteurs'}</span>
          </button>

          {/* خانة استيراد وتصدير مستحقات الملاك Excel */}
          <button
            type="button"
            id="btn-apartments-owners-dues-excel"
            onClick={() => {
              setOwnersDuesTab('import');
              setIsOwnersDuesModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white text-xs font-bold transition-all shadow-xs border border-emerald-400/30 cursor-pointer"
            title={lang === 'ar' ? 'خانة استيراد وتصدير مستحقات الملاك على صيغة Excel' : 'Importer/Exporter les arriérés des copropriétaires (Excel)'}
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
            <span>{lang === 'ar' ? 'خانة استيراد مستحقات الملاك (Excel) 📗' : 'Arriérés Excel'}</span>
          </button>

          <button
            type="button"
            id="btn-apartments-excel-import"
            onClick={() => setIsExcelImportModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 text-xs font-bold transition-all shadow-2xs cursor-pointer"
            title={lang === 'ar' ? 'استيراد وإدخال بيانات وأسماء وعناوين الملاك جماعياً عبر ملف Excel' : 'Importer les données des propriétaires via Excel'}
          >
            <FileSpreadsheet className="w-4 h-4 text-slate-700" />
            <span>{t.apartments.importExcel}</span>
          </button>

          <button
            onClick={() => setIsClearDebtsModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-rose-700 hover:bg-rose-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
            title={lang === 'ar' ? 'مسح وتصفير مديونيات الشقق لضبطها يدوياً من طرف السانديك' : 'Remise à zéro des dettes'}
          >
            <Eraser className="w-4 h-4" />
            <span>{lang === 'ar' ? 'تصفير المديونيات 🧹' : 'Remise à zéro'}</span>
          </button>

          <button
            onClick={() => setIsBulkFeeModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-[#0f172a] hover:bg-[#0f172a] text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
            title={lang === 'ar' ? 'تحديد واجب السانديك المتفق عليه في الجمع العام لجميع الشقق دفعة واحدة' : 'Définir la cotisation votée en AG pour tous les appartements'}
          >
            <Coins className="w-4 h-4 text-amber-300" />
            <span>{t.apartments.votedFeeBtn}</span>
          </button>

          <button
            onClick={handleOpenNew}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#0a8591] hover:bg-[#0b6a78] text-white text-xs font-bold transition-all shadow-sm shadow-[#0a8591]/20 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{t.apartments.addBtn}</span>
          </button>
        </div>
      </div>

      {/* Clear/Reset Debts Modal (السانديك يمسح المديونيات لضبطها يدوياً) */}
      {isClearDebtsModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2 text-rose-800 font-bold text-base">
                <Eraser className="w-5 h-5" />
                <span>{lang === 'ar' ? 'مسح وتصفير مديونيات الشقق للسانديك' : 'Réinitialisation des dettes'}</span>
              </div>
              <button 
                onClick={() => setIsClearDebtsModalOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {clearDebtsSuccessMsg ? (
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>{clearDebtsSuccessMsg}</span>
              </div>
            ) : (
              <form onSubmit={handleApplyClearDebts} className="space-y-4">
                <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-950 text-xs leading-relaxed">
                  <div className="font-bold mb-1 flex items-center gap-1.5 text-rose-900">
                    <ShieldAlert className="w-4 h-4 text-rose-600" />
                    <span>{lang === 'ar' ? 'تصفير المديونية لضبطها يدوياً من طرف السانديك' : 'Réinitialisation manuelle'}</span>
                  </div>
                  <div>
                    {lang === 'ar'
                      ? 'يقوم هذا الإجراء بمسح وتصفير أي مديونية مسجلة وجعل الشقق في حالة عادية (0 درهم ديون و 0 شهور متأخرة)، حتى يتسنى للسانديك إدخال وتحديد بيانات الملاك والشهور غير المؤداة والمبالغ المستحقة بدقة يدوياً.'
                      : 'Cette action réinitialise les arriérés à 0 DH pour permettre au syndic d\'introduire manuellement les dettes réelles par propriétaire.'}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    {lang === 'ar' ? 'اختر نطاق المسح والتصفير:' : 'Périmètre de réinitialisation :'}
                  </label>
                  <select
                    value={clearDebtsTargetBuilding}
                    onChange={e => setClearDebtsTargetBuilding(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-rose-500 focus:outline-none bg-white font-bold text-slate-800"
                  >
                    <option value="ALL">
                      {lang === 'ar' ? '🧹 تصفير مديونيات كافة شقق الإقامة (جميع الشقق عبر جميع العمارات)' : '🧹 Tous les appartements (tous les lots)'}
                    </option>
                    <optgroup label="المجموعة الأولى (GH A)">
                      {buildings.filter(b => b.code.endsWith('A')).map(b => (
                        <option key={b.id} value={b.code}>عمارة {b.code} (16 شقة)</option>
                      ))}
                    </optgroup>
                    <optgroup label="المجموعة الثانية (GH B)">
                      {buildings.filter(b => b.code.endsWith('B')).map(b => (
                        <option key={b.id} value={b.code}>عمارة {b.code} (16 شقة)</option>
                      ))}
                    </optgroup>
                  </select>
                </div>

                <div className="flex items-center gap-2 pt-2 justify-end">
                  <button
                    type="button"
                    onClick={() => setIsClearDebtsModalOpen(false)}
                    className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 text-xs font-bold cursor-pointer hover:bg-slate-50"
                  >
                    {t.common.cancel}
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-rose-700 hover:bg-rose-800 text-white text-xs font-bold shadow-xs cursor-pointer flex items-center gap-1.5"
                  >
                    <Eraser className="w-4 h-4" />
                    <span>{lang === 'ar' ? 'تأكيد تصفير المديونية' : 'Confirmer la remise à zéro'}</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Bulk General Assembly Fee Modal */}
      {isBulkFeeModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2 text-amber-800 font-bold text-base">
                <Coins className="w-5 h-5" />
                <span>{lang === 'ar' ? 'تحديد واجب السانديك (المقرر بالجمع العام)' : 'Fixer la cotisation votée en Assemblée Générale'}</span>
              </div>
              <button 
                onClick={() => setIsBulkFeeModalOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {bulkSuccessMsg ? (
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>{bulkSuccessMsg}</span>
              </div>
            ) : (
              <form onSubmit={handleApplyBulkFee} className="space-y-4">
                <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-950 text-xs leading-relaxed">
                  <div className="font-bold mb-1 flex items-center gap-1.5 text-amber-900">
                    <Sparkles className="w-4 h-4 text-amber-600" />
                    <span>{lang === 'ar' ? 'تعديل مرن ومباشر لواجب السانديك' : 'Ajustement flexible de la cotisation'}</span>
                  </div>
                  <div>
                    {lang === 'ar'
                      ? 'واجب السانديك الشهري ليس رقماً ثابتاً، بل يتم تحديده وتغييره بناءً على قرارات الجمع العام السنوي أو الاستثنائي. يمكنك تطبيق المبلغ الجديد على جميع الشقق السكنية الـ 319 بنقرة واحدة (مع إبقاء مكتب السانديك معفى)، أو على عمارة محددة، مع إمكانية تعديل كل شقة على حدة في أي وقت.'
                      : 'La cotisation mensuelle est variable selon les décisions prises en Assemblée Générale. Vous pouvez appliquer le nouveau montant à l\'ensemble des tous les lots (bureau du syndic exclu) ou à un immeuble spécifique.'}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    {lang === 'ar' ? 'نطاق التطبيق' : 'Champ d\'application'}
                  </label>
                  <select
                    value={bulkTargetBuilding}
                    onChange={e => setBulkTargetBuilding(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white font-bold text-slate-800"
                  >
                    <option value="ALL">
                      {lang === 'ar' ? '🌟 تطبيق على كافة الشقق السكنية (جميع الشقق عبر جميع العمارات)' : '🌟 tous les lots (tous les immeubles)'}
                    </option>
                    <optgroup label="المجموعة الأولى (GH A)">
                      {buildings.filter(b => b.code.endsWith('A')).map(b => (
                        <option key={b.id} value={b.code}>عمارة {b.code} (16 شقة)</option>
                      ))}
                    </optgroup>
                    <optgroup label="المجموعة الثانية (GH B)">
                      {buildings.filter(b => b.code.endsWith('B')).map(b => (
                        <option key={b.id} value={b.code}>عمارة {b.code} (16 شقة)</option>
                      ))}
                    </optgroup>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    {lang === 'ar' ? 'مبلغ واجب السانديك الشهري المتفق عليه (درهم) *' : 'Montant de la cotisation mensuelle (DH) *'}
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      required
                      min="0"
                      step="1"
                      value={bulkFeeAmount}
                      onChange={e => setBulkFeeAmount(Number(e.target.value))}
                      placeholder="مثال: 150، 200، 250، 300..."
                      className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-none font-bold text-slate-900 bg-white"
                    />
                    <span className="absolute left-3.5 rtl:left-auto rtl:right-3.5 top-2.5 text-xs font-bold text-slate-400 pointer-events-none">
                      DH / {lang === 'ar' ? 'شهر' : 'mois'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 mt-2">
                    <span className="text-[11px] text-slate-500">{lang === 'ar' ? 'اقتراحات سريعة:' : 'Suggestions:'}</span>
                    {[100, 150, 200, 250, 300].map(val => (
                      <button
                        key={val}
                        type="button"
                        onClick={() => setBulkFeeAmount(val)}
                        className={`px-2 py-0.5 rounded-md text-[11px] font-bold border transition-colors cursor-pointer ${
                          bulkFeeAmount === val 
                            ? 'bg-amber-600 text-white border-amber-600' 
                            : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                        }`}
                      >
                        {val} DH
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-3 justify-end border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setIsBulkFeeModalOpen(false)}
                    className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 text-xs font-bold hover:bg-slate-50 cursor-pointer"
                  >
                    {t.common.cancel}
                  </button>
                  <button
                    type="submit"
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-xs cursor-pointer"
                  >
                    <Check className="w-4 h-4" />
                    <span>{lang === 'ar' ? 'تأكيد وتطبيق المبلغ' : 'Appliquer le montant'}</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Quick Pay Modal (Syndic only) */}
      {quickPayApt && (() => {
        const quickPayDebt = getApartmentDebtStatus(quickPayApt, payments);
        const quickPayUnpaidList = getUnpaidMonthsList(quickPayDebt.unpaidMonths);
        const earliestUnpaidKey = getEarliestUnpaidMonthKey(quickPayDebt.unpaidMonths);

        return (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
                <div className="flex items-center gap-2 text-emerald-800 font-bold text-base">
                  <CreditCard className="w-5 h-5" />
                  <span>{t.payments.addBtn} - {quickPayApt.buildingCode} ({lang === 'ar' ? 'شقة' : 'Appt'} {quickPayApt.number})</span>
                </div>
                <button 
                  onClick={() => setQuickPayApt(null)}
                  className="p-1 rounded-lg hover:bg-slate-100 text-slate-400"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleQuickPaySubmit} className="space-y-4">
                {/* Financial Status Banner */}
                <div className={`p-3.5 rounded-xl border ${
                  !quickPayDebt.isPaid
                    ? 'bg-rose-50/90 border-rose-300 text-rose-950'
                    : 'bg-emerald-50/90 border-emerald-300 text-emerald-950'
                }`}>
                  <div className="flex items-center justify-between gap-2 mb-2 font-bold text-xs">
                    <span>الساكن / المالك: {quickPayApt.residentName || quickPayApt.ownerName || getMoroccanApartmentData(quickPayApt.buildingCode, quickPayApt.number).fullName}</span>
                    <span className={`px-2.5 py-1 rounded font-mono text-[11px] font-black ${
                      quickPayDebt.isPaid
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : 'bg-rose-100 text-rose-900 border border-rose-300'
                    }`}>
                      {quickPayDebt.isPaid
                        ? 'خالص (0 أشهر تأخير 🟢)'
                        : `🔴 غير خالص: متأخر ${quickPayDebt.unpaidMonths} أشهر (${quickPayDebt.totalBalanceDue} DH)`}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1.5 border-t border-amber-200/60 text-slate-700">
                    <div>
                      <span className="font-semibold">{lang === 'ar' ? 'آخر شهر مؤدى:' : 'Dernier mois payé:'}</span>{' '}
                      <span className="font-bold text-slate-900">{getLastPaidMonthDisplay(quickPayDebt.unpaidMonths, lang)}</span>
                    </div>
                    <div>
                      <span className="font-semibold">{lang === 'ar' ? 'الشهر المستحق أولاً:' : 'Mois dû prioritaire:'}</span>{' '}
                      <span className="font-bold text-emerald-800 font-mono">
                        {formatPeriodDisplay(earliestUnpaidKey, lang)}
                      </span>
                    </div>
                  </div>

                  {/* 1-Click Quick Period Selection */}
                  <div className="mt-2 pt-2 border-t border-slate-200/60 flex flex-wrap items-center gap-1.5">
                    <span className="text-[11px] font-bold text-slate-600">
                      {lang === 'ar' ? 'اختر الفترة بنقرة واحدة:' : 'Période rapide:'}
                    </span>

                    {quickPayDebt.unpaidMonths > 0 ? (
                      <>
                        {quickPayUnpaidList.map((m, idx) => (
                          <button
                            key={m.key}
                            type="button"
                            onClick={() => {
                              setPayMonth(m.key);
                              setPayAmount(quickPayApt.monthlyFee);
                            }}
                            className={`px-2 py-1 rounded-lg text-xs font-bold transition-all border cursor-pointer ${
                              payMonth === m.key
                                ? 'bg-emerald-800 text-white border-emerald-800 shadow-2xs'
                                : 'bg-white hover:bg-emerald-50 text-emerald-900 border-emerald-300'
                            }`}
                          >
                            {lang === 'ar' ? `أداء ${m.labelAr}` : `Mois ${m.labelFr}`}
                            {idx === 0 && <span className="ms-1 text-[10px] text-amber-300">⭐</span>}
                          </button>
                        ))}

                        {quickPayDebt.unpaidMonths > 1 && (
                          <button
                            type="button"
                            onClick={() => {
                              const first = quickPayUnpaidList[0];
                              const last = quickPayUnpaidList[quickPayUnpaidList.length - 1];
                              setPayMonth(`${first.key} إلى ${last.key}`);
                              setPayAmount(quickPayDebt.totalBalanceDue);
                            }}
                            className={`px-2.5 py-1 rounded-lg text-xs font-black transition-all border cursor-pointer ${
                              payMonth.includes('إلى') || payAmount === quickPayDebt.totalBalanceDue
                                ? 'bg-amber-700 text-white border-amber-700 shadow-2xs'
                                : 'bg-amber-100 hover:bg-amber-200 text-amber-900 border-amber-300'
                            }`}
                          >
                            🌟 تسوية شاملة ({quickPayDebt.totalBalanceDue} DH)
                          </button>
                        )}
                      </>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setPayMonth(`${CURRENT_REFERENCE_YEAR}-08`);
                          setPayAmount(quickPayApt.monthlyFee);
                        }}
                        className="px-2 py-1 rounded-lg text-xs font-bold bg-white hover:bg-emerald-50 text-emerald-900 border border-emerald-300 cursor-pointer"
                      >
                        شهر غشت {CURRENT_REFERENCE_YEAR} ({quickPayApt.monthlyFee} DH)
                      </button>
                    )}
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700">{t.payments.period} *</label>
                    {payMonth && (
                      <span className="text-[11px] text-emerald-800 font-bold bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200">
                        {formatPeriodDisplay(payMonth, lang)}
                      </span>
                    )}
                  </div>
                  <input
                    type="text"
                    required
                    value={payMonth}
                    onChange={e => setPayMonth(e.target.value)}
                    placeholder="2026-07 أو 2026-07 إلى 2026-08"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none font-mono font-bold text-slate-900"
                  />
                </div>

                {/* عدد الأشهر الخالص بالأرقام */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700">
                      {t.payments.paidMonthsCount} *
                    </label>
                    <span className="text-[11px] text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                      {payMonthsCount > 1 
                        ? (lang === 'ar' ? `${payMonthsCount} أشهر` : `${payMonthsCount} mois`) 
                        : (lang === 'ar' ? 'شهر واحد' : '1 mois')}
                    </span>
                  </div>
                  <input
                    type="number"
                    min="1"
                    max="60"
                    step="1"
                    required
                    value={payMonthsCount || ''}
                    onChange={e => {
                      const val = parseInt(e.target.value, 10);
                      const count = isNaN(val) ? 1 : Math.max(1, val);
                      setPayMonthsCount(count);
                      const fee = quickPayApt.monthlyFee || 150;
                      setPayAmount(count * fee);
                    }}
                    placeholder="1"
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none font-mono font-bold text-slate-900 bg-white"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">{t.payments.amount} (DH)</label>
                    <input
                      type="number"
                      min="1"
                      required
                      value={payAmount}
                      onChange={e => setPayAmount(Number(e.target.value))}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none font-mono font-bold text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {lang === 'ar' ? 'تاريخ الأداء (احتساب المداخيل)' : 'Date d\'encaissement'}
                    </label>
                    <input
                      type="date"
                      required
                      value={payDate}
                      onChange={e => setPayDate(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none font-medium text-slate-800"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{t.payments.method}</label>
                  <select
                    value={payMethod}
                    onChange={e => setPayMethod(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none bg-white font-bold"
                  >
                    <option value="cash">{t.payments.methodCash}</option>
                    <option value="bank_transfer">{t.payments.methodTransfer}</option>
                    <option value="check">{t.payments.methodCheck}</option>
                  </select>
                </div>

                <div className="flex items-center gap-2 pt-2 justify-end">
                  <button
                    type="button"
                    onClick={() => setQuickPayApt(null)}
                    className="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 text-xs font-bold"
                  >
                    {t.common.cancel}
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-lg bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs cursor-pointer"
                  >
                    تأكيد الأداء وتوليد الوصل
                  </button>
                </div>
              </form>
            </div>
          </div>
        );
      })()}

      {/* Add / Edit Form Box (Syndic only) */}
      {isFormOpen && (
        <div className="bg-white p-6 rounded-2xl border-2 border-emerald-600 shadow-lg animate-in fade-in zoom-in-98 duration-200">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
            <h2 className="text-base font-bold text-emerald-900 flex items-center gap-2">
              <Home className="w-5 h-5 text-emerald-700" />
              <span>{editingId ? t.common.edit : t.apartments.addBtn}</span>
            </h2>
            <button 
              onClick={() => setIsFormOpen(false)}
              className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.apartments.building} *</label>
                <select
                  required
                  value={buildingCode}
                  onChange={e => setBuildingCode(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none bg-white font-bold"
                >
                  <optgroup label="المجموعة الأولى: عمارات GH A">
                    {buildings
                      .filter(b => b.code.endsWith('A'))
                      .sort((a, b) => parseInt((a.code.match(/\d+/) || ['999'])[0], 10) - parseInt((b.code.match(/\d+/) || ['999'])[0], 10))
                      .map(b => (
                        <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                      ))}
                  </optgroup>
                  <optgroup label="المجموعة الثانية: عمارات GH B">
                    {buildings
                      .filter(b => b.code.endsWith('B'))
                      .sort((a, b) => parseInt((a.code.match(/\d+/) || ['999'])[0], 10) - parseInt((b.code.match(/\d+/) || ['999'])[0], 10))
                      .map(b => (
                        <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                      ))}
                  </optgroup>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.apartments.number} *</label>
                <input
                  type="text"
                  required
                  value={number}
                  onChange={e => {
                    const val = e.target.value;
                    setNumber(val);
                    const n = parseInt(val.replace(/\D/g, ''), 10);
                    if (!isNaN(n) && n >= 1 && n <= 16) {
                      setFloor(Math.floor((n - 1) / 4));
                    }
                  }}
                  placeholder="01"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.apartments.floor} *</label>
                <select
                  value={floor}
                  onChange={e => setFloor(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none bg-white font-bold"
                >
                  <option value={0}>{lang === 'ar' ? 'الطابق السفلي (RDC) - شقق 01 إلى 04' : 'Rez-de-chaussée (RDC) - Apparts 01 à 04'}</option>
                  <option value={1}>{lang === 'ar' ? 'الطابق الأول (1er) - شقق 05 إلى 08' : '1er étage - Apparts 05 à 08'}</option>
                  <option value={2}>{lang === 'ar' ? 'الطابق الثاني (2ème) - شقق 09 إلى 12' : '2ème étage - Apparts 09 à 12'}</option>
                  <option value={3}>{lang === 'ar' ? 'الطابق الثالث (3ème) - شقق 13 إلى 16' : '3ème étage - Apparts 13 à 16'}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.apartments.owner}</label>
                <input
                  type="text"
                  value={ownerName}
                  onChange={e => setOwnerName(e.target.value)}
                  placeholder={lang === 'ar' ? 'اسم مالك الشقة' : 'Nom du propriétaire'}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">هاتف المالك</label>
                <input
                  type="tel"
                  value={ownerPhone}
                  onChange={e => setOwnerPhone(e.target.value)}
                  placeholder="+212 661-000000"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'ar' ? 'رقم البطاقة الوطنية (CIN) للمالك' : 'N° CIN du propriétaire'}
                </label>
                <input
                  type="text"
                  value={ownerCin}
                  onChange={e => setOwnerCin(e.target.value.toUpperCase())}
                  placeholder="BE123456"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none uppercase font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.apartments.resident}</label>
                <input
                  type="text"
                  value={residentName}
                  onChange={e => setResidentName(e.target.value)}
                  placeholder="نفس المالك أو المكتري"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.apartments.status}</label>
                <select
                  value={status}
                  onChange={e => setStatus(e.target.value as ApartmentStatus)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none bg-white"
                >
                  <option value="occupied">{t.apartments.occupied}</option>
                  <option value="vacant">{t.apartments.vacant}</option>
                  <option value="for_rent">{t.apartments.forRent}</option>
                  <option value="for_sale">{t.apartments.forSale}</option>
                </select>
              </div>

              <div className="sm:col-span-2 p-3 rounded-xl bg-amber-50/70 border border-amber-200">
                <label className="block text-xs font-bold text-amber-950 mb-1">
                  {lang === 'ar' ? 'واجب السانديك الشهري (المبلغ المحدد في الجمع العام)' : 'Cotisation Syndic (décision de l\'AG)'} *
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={monthlyFee}
                    onChange={e => setMonthlyFee(Number(e.target.value))}
                    placeholder={lang === 'ar' ? "اكتب المبلغ المتفق عليه بالدرهم..." : "Montant en DH..."}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white font-bold text-slate-900"
                  />
                  <span className="absolute left-3 rtl:left-auto rtl:right-3 top-2 text-xs font-bold text-slate-400 pointer-events-none">
                    DH / {lang === 'ar' ? 'شهر' : 'mois'}
                  </span>
                </div>
                <div className="text-[11px] text-amber-800 font-medium mt-1">
                  {lang === 'ar' 
                    ? '💡 هذا المبلغ متغير بحسب قرارات الجمع العام لكل شقة (يمكنك كتابة أي رقم مباشرة).' 
                    : '💡 Montant variable modifiable selon les décisions de l\'AG.'}
                </div>
              </div>

              {/* ضبط وتحديد وضعية المديونية من طرف السانديك */}
              <div className="sm:col-span-2 p-4 rounded-xl bg-slate-50 border-2 border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 text-emerald-700" />
                    <span>{lang === 'ar' ? 'وضعية المديونية للسانديك (يحددها السانديك يدوياً)' : 'Statut de la dette (défini par le Syndic)'} *</span>
                  </label>
                  <span className="text-[11px] font-bold text-slate-500">
                    {debtType === 'clean' ? '🟢 وضعية سليمة' : `🔴 مديونية: ${unpaidMonthsCount} أشهر (${balanceDue} DH)`}
                  </span>
                </div>

                {/* Debt Type Selector */}
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setDebtType('clean');
                      setUnpaidMonthsCount(0);
                      setBalanceDue(0);
                    }}
                    className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer border ${
                      debtType === 'clean'
                        ? 'bg-emerald-700 text-white border-emerald-700 shadow-xs'
                        : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{lang === 'ar' ? 'عادي (ليس عليه مديونية 0 DH)' : 'À jour (Aucune dette 0 DH)'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setDebtType('in_debt');
                      const initialMonths = unpaidMonthsCount > 0 ? unpaidMonthsCount : 1;
                      setUnpaidMonthsCount(initialMonths);
                      if (balanceDue === 0) {
                        setBalanceDue(initialMonths * (monthlyFee || 150));
                      }
                    }}
                    className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer border ${
                      debtType === 'in_debt'
                        ? 'bg-rose-700 text-white border-rose-700 shadow-xs'
                        : 'bg-white hover:bg-rose-50 text-rose-800 border-rose-300'
                    }`}
                  >
                    <AlertCircle className="w-4 h-4" />
                    <span>{lang === 'ar' ? 'بذمته مديونية للسانديك' : 'En situation d\'impayé'}</span>
                  </button>
                </div>

                {/* In Debt Sub-fields */}
                {debtType === 'in_debt' && (
                  <div className="p-3 bg-rose-50/70 rounded-xl border border-rose-200 space-y-3 animate-in fade-in">
                    <div>
                      <label className="block text-xs font-bold text-rose-950 mb-1">
                        {lang === 'ar' ? 'عدد الشهور التي لم تُؤدَّ من طرف المالك:' : 'Nombre de mois impayés par le propriétaire :'} *
                      </label>
                      <div className="flex items-center gap-2">
                        <input
                          type="number"
                          min="1"
                          max="120"
                          required
                          value={unpaidMonthsCount}
                          onChange={e => {
                            const val = Math.max(1, parseInt(e.target.value, 10) || 1);
                            setUnpaidMonthsCount(val);
                            setBalanceDue(val * (monthlyFee || 150));
                          }}
                          className="w-24 px-3 py-2 text-xs rounded-lg border border-rose-300 focus:ring-2 focus:ring-rose-500 focus:outline-none bg-white font-mono font-bold text-rose-950"
                        />
                        <span className="text-xs font-bold text-rose-900">{lang === 'ar' ? 'شهور غير مؤداة' : 'mois impayés'}</span>
                      </div>

                      {/* Quick preset pills */}
                      <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                        <span className="text-[11px] text-rose-800 font-bold">{lang === 'ar' ? 'اختيار سريع:' : 'Sélection rapide :'}</span>
                        {[1, 2, 3, 4, 6, 12].map(m => (
                          <button
                            key={m}
                            type="button"
                            onClick={() => {
                              setUnpaidMonthsCount(m);
                              setBalanceDue(m * (monthlyFee || 150));
                            }}
                            className={`px-2 py-0.5 rounded-md text-[11px] font-bold border transition-colors cursor-pointer ${
                              unpaidMonthsCount === m
                                ? 'bg-rose-700 text-white border-rose-700'
                                : 'bg-white hover:bg-rose-100 text-rose-900 border-rose-300'
                            }`}
                          >
                            {m === 1 ? (lang === 'ar' ? 'شهر واحد' : '1 mois') :
                             m === 2 ? (lang === 'ar' ? 'شهران' : '2 mois') :
                             m === 12 ? (lang === 'ar' ? 'سنة (12)' : '1 an') :
                             `${m} ${lang === 'ar' ? 'أشهر' : 'mois'}`}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-rose-950 mb-1">
                        {lang === 'ar' ? 'إجمالي المال المستحق عليه للسانديك (درهم):' : 'Montant total dû au Syndic (DH) :'} *
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          min="0"
                          required
                          value={balanceDue}
                          onChange={e => setBalanceDue(Number(e.target.value))}
                          className="w-full px-3 py-2 text-xs rounded-lg border border-rose-300 focus:ring-2 focus:ring-rose-500 focus:outline-none bg-white font-mono font-bold text-rose-950"
                        />
                        <span className="absolute left-3 rtl:left-auto rtl:right-3 top-2 text-xs font-bold text-rose-400 pointer-events-none">
                          DH
                        </span>
                      </div>
                      <div className="text-[11px] text-rose-800 mt-1">
                        {lang === 'ar' 
                          ? `💡 محسوب تلقائياً: ${unpaidMonthsCount} أشهر × ${monthlyFee || 150} DH = ${unpaidMonthsCount * (monthlyFee || 150)} DH (يمكنك تعديل المبلغ يدوياً إن وجد اتفاق خاص).`
                          : `💡 Calculé : ${unpaidMonthsCount} mois × ${monthlyFee || 150} DH = ${unpaidMonthsCount * (monthlyFee || 150)} DH.`}
                      </div>
                    </div>
                  </div>
                )}

                <div className="text-[11px] text-slate-500">
                  {lang === 'ar' 
                    ? '📌 يقوم السانديك بإدخال وتحديث هذه البيانات لكل مالك لمعرفة وضعيته المالية بدقة في لوحة التحكم وقوائم المتأخرين.' 
                    : '📌 Ces données saisies par le syndic définissent avec exactitude la situation d\'impayé.'}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-3 justify-end border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsFormOpen(false)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-bold transition-all cursor-pointer"
              >
                {t.common.cancel}
              </button>
              <button
                type="submit"
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>{t.common.save}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Filter and Search Bar (Syndic only) */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        <div className="relative lg:col-span-1">
          <Search className="w-4 h-4 text-slate-400 absolute start-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder={t.apartments.searchPlaceholder}
            className="w-full ps-9 pe-3 py-2 text-xs bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-600"
          />
        </div>

        <div>
          <select
            value={selectedBuilding}
            onChange={e => setSelectedBuilding(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-600 font-bold"
          >
            <option value="ALL">{t.apartments.filterBuilding}</option>
            <option value="GROUP_A">🅰️ عمارات حرف A وحدها</option>
            <option value="GROUP_B">🅱️ عمارات حرف B وحدها</option>
            <optgroup label="المجموعة الأولى: عمارات GH A">
              {buildings
                .filter(b => b.code.endsWith('A'))
                .sort((a, b) => parseInt((a.code.match(/\d+/) || ['999'])[0], 10) - parseInt((b.code.match(/\d+/) || ['999'])[0], 10))
                .map(b => (
                  <option key={b.id} value={b.code}>{b.name} (16 شقة)</option>
                ))}
            </optgroup>
            <optgroup label="المجموعة الثانية: عمارات GH B">
              {buildings
                .filter(b => b.code.endsWith('B'))
                .sort((a, b) => parseInt((a.code.match(/\d+/) || ['999'])[0], 10) - parseInt((b.code.match(/\d+/) || ['999'])[0], 10))
                .map(b => (
                  <option key={b.id} value={b.code}>{b.name} (16 شقة)</option>
                ))}
            </optgroup>
          </select>
        </div>

        <div>
          <select
            value={selectedStatus}
            onChange={e => setSelectedStatus(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-600"
          >
            <option value="ALL">{t.apartments.filterStatus}</option>
            <option value="occupied">{t.apartments.occupied}</option>
            <option value="vacant">{t.apartments.vacant}</option>
            <option value="for_rent">{t.apartments.forRent}</option>
            <option value="for_sale">{t.apartments.forSale}</option>
          </select>
        </div>

        <div>
          <select
            value={selectedDebt}
            onChange={e => setSelectedDebt(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-600 font-bold"
          >
            <option value="ALL">{t.apartments.filterAllDebt || "جميع وضعيات الأداء"}</option>
            <option value="clean">{t.apartments.filterClean || "خالص ومسوى 🟢 (À jour)"}</option>
            <option value="debt">{t.apartments.filterDebt || "عليه متأخرات 🔴 (En retard)"}</option>
          </select>
        </div>

        <div>
          <select
            value={sortByDebt}
            onChange={e => setSortByDebt(e.target.value as any)}
            className="w-full px-3 py-2 text-xs rounded-xl border-2 border-amber-400 bg-amber-50/70 text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-extrabold shadow-2xs"
            title={lang === 'ar' ? 'ترتيب الملاك حسب الأداء والديون' : 'Tri par situation de cotisation'}
          >
            <option value="debt_asc">
              {lang === 'ar' ? '🟢 من الملتزم شهرياً إلى الأكثر تأخراً' : '🟢 Du plus assidu au plus débiteur'}
            </option>
            <option value="debt_desc">
              {lang === 'ar' ? '🔴 من الأكثر تأخراً إلى الملتزم شهرياً' : '🔴 Du plus débiteur au plus assidu'}
            </option>
            <option value="building">
              {lang === 'ar' ? '🏢 حسب تسلسل العمارات والشقق' : '🏢 Par ordre des immeubles'}
            </option>
          </select>
        </div>
      </div>

      {/* Table (Syndic only) */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full whitespace-nowrap text-xs text-start border-collapse">
            <thead>
              <tr className="bg-[#0a8591] text-white font-bold">
                <th className="p-3.5 text-start">{t.apartments.building}</th>
                <th className="p-3.5 text-start">{t.apartments.number}</th>
                <th className="p-3.5 text-start">{t.apartments.floor}</th>
                <th className="p-3.5 text-start">{t.apartments.owner}</th>
                <th className="p-3.5 text-start">{t.apartments.resident}</th>
                <th className="p-3.5 text-start">{t.apartments.status}</th>
                <th className="p-3.5 text-start">{t.apartments.monthlyFee}</th>
                <th className="p-3.5 text-start">{t.apartments.balance}</th>
                <th className="p-3.5 text-center">{t.apartments.actions}</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100">
              {filteredApartments.length === 0 ? (
                <tr>
                  <td colSpan={9} className="text-center py-8 text-slate-400">
                    لا توجد شقق مطابقة للبحث
                  </td>
                </tr>
              ) : (
                filteredApartments.map((apt) => {
                  const aptDebt = getApartmentDebtStatus(apt, payments);
                  return (
                    <tr key={apt.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3 font-bold text-[#0a8591]">
                        <span className="px-2 py-1 rounded-md bg-[#e9fbf8] border border-[#92e8dd]">
                          {apt.buildingCode}
                        </span>
                      </td>
                      <td className="p-3 font-mono font-bold text-slate-900">
                        شقة {apt.number}
                      </td>
                      <td className="p-3 font-semibold text-slate-700">
                        {getFloorLabel(apt.floor, lang)}
                      </td>
                      <td className="p-3 font-medium text-slate-900">
                        {apt.isSyndicOffice ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-purple-100 text-purple-900 font-bold border border-purple-200">
                            🏢 {lang === 'ar' ? 'مكتب سانديك الإقامة' : 'Bureau du Syndic'}
                          </span>
                        ) : (
                          <div>
                            <div className="font-bold text-slate-900">{apt.ownerName || '-'}</div>
                            <div className="mt-1 flex items-center gap-1">
                              <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black border ${
                                aptDebt.isPaid
                                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                  : 'bg-rose-100 text-rose-900 border-rose-300'
                              }`}>
                                {aptDebt.isPaid
                                  ? (lang === 'ar' ? 'خالص ومسوى 🟢' : 'À jour 🟢')
                                  : (lang === 'ar' ? `غير خالص (متأخر ${aptDebt.unpaidMonths} شهر) 🔴` : `Non réglé (${aptDebt.unpaidMonths} mois) 🔴`)}
                              </span>
                            </div>
                          </div>
                        )}
                      </td>
                      <td className="p-3 text-slate-700">
                        {apt.isSyndicOffice ? (
                          <span className="text-slate-500 italic text-[11px]">{lang === 'ar' ? 'مقر الإدارة والمكتب' : 'Local administratif'}</span>
                        ) : (
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-semibold text-xs">{apt.residentName || '-'}</span>
                            {!aptDebt.isPaid && aptDebt.unpaidMonths > 0 && (
                              <span className={`px-2 py-0.5 rounded-full text-[10px] font-black border shadow-2xs ${
                                aptDebt.unpaidMonths > 4
                                  ? 'bg-rose-700 text-white border-rose-800'
                                  : 'bg-amber-600 text-white border-amber-700'
                              }`}>
                                {aptDebt.unpaidMonths > 4
                                  ? (lang === 'ar' ? `⛔ ممنوع من الدخول (${aptDebt.unpaidMonths} أشهر)` : `⛔ Accès Bloqué (${aptDebt.unpaidMonths} mois)`)
                                  : (lang === 'ar' ? `✅ مسموح بالدخول (${aptDebt.unpaidMonths} أشهر)` : `✅ Accès Autorisé (${aptDebt.unpaidMonths} mois)`)}
                              </span>
                            )}
                          </div>
                        )}
                      </td>
                      <td className="p-3">
                        {apt.isSyndicOffice ? (
                          <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-purple-100 text-purple-800">
                            {lang === 'ar' ? 'مكتب إداري' : 'Bureau'}
                          </span>
                        ) : (
                          <span className={`px-2 py-0.5 rounded-full text-[11px] font-semibold ${
                            apt.status === 'occupied' ? 'bg-emerald-100 text-emerald-800' :
                            apt.status === 'vacant' ? 'bg-slate-100 text-slate-700' :
                            apt.status === 'for_rent' ? 'bg-blue-100 text-blue-800' : 'bg-amber-100 text-amber-800'
                          }`}>
                            {apt.status === 'occupied' ? t.apartments.occupied :
                             apt.status === 'vacant' ? t.apartments.vacant :
                             apt.status === 'for_rent' ? t.apartments.forRent : t.apartments.forSale}
                          </span>
                        )}
                      </td>
                      <td className="p-3 font-bold text-slate-800">
                        {apt.isSyndicOffice ? (
                          <span className="text-purple-700 font-bold text-[11px]">{lang === 'ar' ? '0 DH (معفى)' : '0 DH (Exonéré)'}</span>
                        ) : (
                          `${apt.monthlyFee} DH`
                        )}
                      </td>
                      <td className="p-3">
                        {apt.isSyndicOffice ? (
                          <span className="px-2 py-0.5 rounded-md bg-purple-50 text-purple-700 font-bold border border-purple-200 text-xs">
                            0 DH (مكتب سانديك)
                          </span>
                        ) : !aptDebt.isPaid ? (
                          <div className="flex flex-col gap-1">
                            <span className="px-2.5 py-1 rounded bg-red-100 text-red-900 font-black border border-red-300 inline-block w-max font-mono text-xs shadow-2xs">
                              🔴 {aptDebt.totalBalanceDue.toLocaleString()} DH
                            </span>
                            <div className="text-[11px] font-bold text-red-800">
                              {lang === 'ar' ? `غير خالص: واجب ${aptDebt.unpaidMonths} أشهر` : `Non réglé: ${aptDebt.unpaidMonths} mois`}
                            </div>
                            <div className="text-[10px] text-slate-600 font-medium">
                              <div>{lang === 'ar' ? `المستحق: ${formatPeriodDisplay(getEarliestUnpaidMonthKey(aptDebt.unpaidMonths), lang)}` : `Dû: ${formatPeriodDisplay(getEarliestUnpaidMonthKey(aptDebt.unpaidMonths), lang)}`}</div>
                            </div>
                            <span 
                              className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-rose-100 text-rose-900 text-[10px] font-black border border-rose-300 w-max"
                            >
                              <span>{lang === 'ar' ? 'بذمته واجب مستحق 🔴' : 'Cotisation due 🔴'}</span>
                            </span>
                          </div>
                        ) : (
                          <div className="flex flex-col gap-1">
                            <span className="px-2.5 py-1 rounded bg-emerald-50 text-emerald-700 font-bold border border-emerald-200 font-mono inline-block w-max">
                              0 DH
                            </span>
                            <span className="text-[10px] text-emerald-700 font-bold">
                              {lang === 'ar' ? `خالص ومسوى 🟢` : `À jour 🟢`}
                            </span>
                          </div>
                        )}
                      </td>
                    <td className="p-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => {
                            const debt = getApartmentDebtStatus(apt, payments);
                            const dueKey = getEarliestUnpaidMonthKey(debt.unpaidMonths);
                            setQuickPayApt(apt);
                            setPayAmount(apt.monthlyFee);
                            setPayMonth(dueKey);
                          }}
                          className={`px-2.5 py-1.5 rounded-lg font-bold flex items-center gap-1 transition-all cursor-pointer text-xs ${
                            !aptDebt.isPaid && !apt.isSyndicOffice
                              ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-2xs'
                              : 'bg-emerald-100 hover:bg-emerald-200 text-emerald-900'
                          }`}
                          title={t.apartments.payNow}
                        >
                          <CreditCard className="w-3.5 h-3.5" />
                          <span>{!aptDebt.isPaid && !apt.isSyndicOffice ? (lang === 'ar' ? 'استلام الأداء 💳' : 'Encaisser') : t.apartments.payNow}</span>
                        </button>
                        <button
                          onClick={() => handleOpenEdit(apt)}
                          className="p-1 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-emerald-800 cursor-pointer"
                          title={lang === 'ar' ? 'تعديل بيانات الشقة والمديونية' : 'Modifier'}
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        {!aptDebt.isPaid && !apt.isSyndicOffice && (
                          <button
                            onClick={() => {
                              if (confirm(lang === 'ar' ? `هل أنت متأكد من تصفير مديونية الشقة ${apt.buildingCode} - شقة ${apt.number} وجعلها خالصة بدون ديون (0 DH)؟` : `Remettre à 0 la dette de cet appt ?`)) {
                                setApartmentDebt(apt.id, 0, 0);
                              }
                            }}
                            className="p-1 rounded-lg hover:bg-emerald-50 text-slate-400 hover:text-emerald-700 cursor-pointer"
                            title={lang === 'ar' ? 'تصفير مديونية هذه الشقة وجعلها عادية (0 DH)' : 'Remettre la dette à 0'}
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          onClick={() => setApartmentToDelete(apt)}
                          className="p-1 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-600 cursor-pointer"
                          title={lang === 'ar' ? 'حذف الشقة' : 'Supprimer'}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Excel Bulk Import Modal */}
      <ExcelImportModal
        isOpen={isExcelImportModalOpen}
        onClose={() => setIsExcelImportModalOpen(false)}
      />

      {/* Owners Dues Excel Modal (Export & Import) */}
      <OwnersDuesExcelModal
        isOpen={isOwnersDuesModalOpen}
        onClose={() => setIsOwnersDuesModalOpen(false)}
        defaultTab={ownersDuesTab}
      />

      {/* In-App Delete Confirmation Modal */}
      {apartmentToDelete && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mb-4 mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            
            <h3 className="text-base font-bold text-slate-900 text-center mb-2">
              {lang === 'ar' ? 'تأكيد حذف الشقة' : 'Confirmation de suppression'}
            </h3>
            
            <p className="text-xs text-slate-600 text-center mb-6 leading-relaxed">
              {lang === 'ar' 
                ? `هل أنت متأكد من حذف الشقة رقم (${apartmentToDelete.number}) في (${apartmentToDelete.buildingCode})؟`
                : `Êtes-vous sûr de vouloir supprimer l'appartement N° ${apartmentToDelete.number} (${apartmentToDelete.buildingCode}) ?`}
            </p>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setApartmentToDelete(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-bold transition-all cursor-pointer"
              >
                {lang === 'ar' ? 'تراجع' : t.common.cancel}
              </button>
              <button
                type="button"
                onClick={() => {
                  deleteApartment(apartmentToDelete.id);
                  setApartmentToDelete(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold shadow-md transition-all cursor-pointer"
              >
                {lang === 'ar' ? 'تأكيد الحذف' : 'Supprimer'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Dedicated Overdue Payers Ranking Modal */}
      <OverduePayersModal
        isOpen={isOverdueModalOpen}
        onClose={() => setIsOverdueModalOpen(false)}
      />
    </div>
  );
};

