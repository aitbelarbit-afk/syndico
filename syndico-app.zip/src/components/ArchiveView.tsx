import React, { useState, useMemo, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { Payment, Expense, ExpenseCategory, PaymentMethod } from '../types';
import { 
  Archive, Database, Calendar, ShieldCheck, ArrowRightLeft, 
  RotateCcw, Trash2, Printer, Search, Download, Upload, 
  CheckCircle2, AlertCircle, Sparkles, Filter, ChevronDown, 
  FileSpreadsheet, Zap, Droplet, Sparkles as SparklesIcon, 
  Shield, Wrench, Package, ArrowDownToLine, RefreshCw, AlertTriangle,
  Users, Briefcase, Hammer, Droplets, FileText, Scale, Gavel
} from 'lucide-react';

export const ArchiveView: React.FC = () => {
  const { 
    t, lang, currentUser,
    archivedPayments, archivedExpenses, archiveBatches,
    archivedPaymentsTotal, archivedExpensesTotal, totalArchivedCount,
    archiveOldRecords, restorePaymentFromArchive, restoreExpenseFromArchive,
    restoreBatchFromArchive, restoreAllArchivedRecords,
    deleteArchivedPayment, deleteArchivedExpense, clearAllArchive,
    exportArchiveJSON, importArchiveFromJSON, getEligibleArchiveCount,
    setSelectedReceipt, setActiveSection
  } = useApp();

  const isRtl = lang === 'ar';
  const isOwner = currentUser?.role === 'resident';

  // Navigation Tab
  const [activeTab, setActiveTab] = useState<'payments' | 'expenses' | 'batches' | 'wizard' | 'tools'>('wizard');

  // Archive Wizard Settings
  const [presetCutoff, setPresetCutoff] = useState<'1year' | '2years' | '6months' | 'custom'>('1year');
  
  // Compute default 1 year ago date: e.g. 2025-08-24
  const getInitialCutoffDate = (preset: '1year' | '2years' | '6months' | 'custom') => {
    const now = new Date();
    if (preset === '1year') {
      now.setFullYear(now.getFullYear() - 1);
    } else if (preset === '2years') {
      now.setFullYear(now.getFullYear() - 2);
    } else if (preset === '6months') {
      now.setMonth(now.getMonth() - 6);
    }
    return now.toISOString().slice(0, 10);
  };

  const [customCutoffDate, setCustomCutoffDate] = useState<string>(() => getInitialCutoffDate('1year'));
  const [includePayments, setIncludePayments] = useState(true);
  const [includeExpenses, setIncludeExpenses] = useState(true);
  const [archiveNotes, setArchiveNotes] = useState('');

  // Confirmation Modal for Archiving
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showClearConfirmModal, setShowClearConfirmModal] = useState(false);
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  // Search & Filters
  const [searchPayments, setSearchPayments] = useState('');
  const [filterPaymentBuilding, setFilterPaymentBuilding] = useState('ALL');
  const [searchExpenses, setSearchExpenses] = useState('');
  const [filterExpenseCategory, setFilterExpenseCategory] = useState('ALL');

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Handle Preset Changes
  const handlePresetChange = (preset: '1year' | '2years' | '6months' | 'custom') => {
    setPresetCutoff(preset);
    if (preset !== 'custom') {
      setCustomCutoffDate(getInitialCutoffDate(preset));
    }
  };

  // Preview Eligible records count in real-time
  const eligiblePreview = useMemo(() => {
    return getEligibleArchiveCount(customCutoffDate);
  }, [customCutoffDate, getEligibleArchiveCount]);

  const showToast = (text: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 4500);
  };

  // Execute Archiving
  const handleExecuteArchive = () => {
    if (!includePayments && !includeExpenses) {
      showToast(lang === 'ar' ? 'يرجى اختيار الأداءات أو المصاريف للأرشفة' : 'Veuillez cocher au moins les cotisations ou les dépenses', 'error');
      return;
    }

    const months = presetCutoff === '1year' ? 12 : presetCutoff === '2years' ? 24 : presetCutoff === '6months' ? 6 : 0;
    const result = archiveOldRecords({
      cutoffDate: customCutoffDate,
      cutoffMonths: months,
      includePayments,
      includeExpenses,
      notes: archiveNotes || (lang === 'ar' ? `أرشفة السجلات السابقة لتاريخ ${customCutoffDate}` : `Archivage des opérations antérieures au ${customCutoffDate}`)
    });

    setShowConfirmModal(false);

    if (result.paymentsMoved === 0 && result.expensesMoved === 0) {
      showToast(lang === 'ar' ? 'لم يتم العثور على أي سجلات مطابقة للشروط قبل هذا التاريخ' : 'Aucun enregistrement trouvé antérieur à cette date', 'info');
    } else {
      showToast(
        lang === 'ar' 
          ? `تم ترحيل ${result.paymentsMoved} أداء (${result.paymentsAmount.toLocaleString()} درهم) و ${result.expensesMoved} مصروف (${result.expensesAmount.toLocaleString()} درهم) إلى الأرشيف بنجاح!` 
          : `${result.paymentsMoved} cotisations et ${result.expensesMoved} dépenses transférées avec succès vers l'archive !`,
        'success'
      );
      setActiveTab('payments');
    }
  };

  // Filtered Archived Payments
  const filteredArchivedPayments = useMemo(() => {
    return archivedPayments.filter(p => {
      const matchSearch = 
        p.receiptNumber.toLowerCase().includes(searchPayments.toLowerCase()) ||
        p.residentName.toLowerCase().includes(searchPayments.toLowerCase()) ||
        p.buildingCode.toLowerCase().includes(searchPayments.toLowerCase()) ||
        p.apartmentNumber.toLowerCase().includes(searchPayments.toLowerCase()) ||
        (p.notes && p.notes.toLowerCase().includes(searchPayments.toLowerCase()));

      const matchBuilding = filterPaymentBuilding === 'ALL' || p.buildingCode === filterPaymentBuilding;
      return matchSearch && matchBuilding;
    });
  }, [archivedPayments, searchPayments, filterPaymentBuilding]);

  // Filtered Archived Expenses
  const filteredArchivedExpenses = useMemo(() => {
    return archivedExpenses.filter(e => {
      const matchSearch = 
        e.title.toLowerCase().includes(searchExpenses.toLowerCase()) ||
        e.supplier.toLowerCase().includes(searchExpenses.toLowerCase()) ||
        (e.invoiceRef && e.invoiceRef.toLowerCase().includes(searchExpenses.toLowerCase())) ||
        (e.buildingCode && e.buildingCode.toLowerCase().includes(searchExpenses.toLowerCase()));

      const matchCategory = filterExpenseCategory === 'ALL' || e.category === filterExpenseCategory;
      return matchSearch && matchCategory;
    });
  }, [archivedExpenses, searchExpenses, filterExpenseCategory]);

  // Export to CSV
  const handleExportCSV = () => {
    const rows = [
      ['نوع السجل', 'الرقم المرجعي', 'الطرف / العمارة', 'التاريخ', 'الفترة', 'طريقة الأداء', 'المبلغ (درهم)', 'ملاحظات'],
      ...archivedPayments.map(p => ['أداء / اشتراك', p.receiptNumber, `${p.residentName} (${p.buildingCode} - شقة ${p.apartmentNumber})`, p.paymentDate, p.periodMonth, p.paymentMethod, p.amount, p.notes || '']),
      ...archivedExpenses.map(e => ['مصروف / فاتورة', e.invoiceRef || e.id, `${e.title} (${e.supplier} - ${e.buildingCode || 'ALL'})`, e.date, '', e.paymentMethod, e.amount, e.category])
    ];

    const csvContent = '\uFEFF' + rows.map(e => e.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `SYNDICO_Archive_Data_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    showToast(lang === 'ar' ? 'تم تصدير ملف CSV للأرشيف بنجاح' : 'Fichier CSV exporté avec succès');
  };

  // Import Archive File
  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const success = importArchiveFromJSON(content);
      if (success) {
        showToast(lang === 'ar' ? 'تم استيراد ودمج سجلات الأرشيف بنجاح' : 'Archive importée et intégrée avec succès', 'success');
      } else {
        showToast(lang === 'ar' ? 'تعذر قراءة ملف الأرشيف، تأكد من صحة التنسيق' : 'Format de fichier archive invalide', 'error');
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const getCategoryLabel = (cat: ExpenseCategory) => {
    switch (cat) {
      case 'worker_salaries': return t.expenses.catWorkerSalaries;
      case 'syndic_fees': return t.expenses.catSyndicAgent;
      case 'cleaning_supplies': return t.expenses.catCleaningSupplies;
      case 'electrical_supplies': return t.expenses.catElectricalSupplies;
      case 'hardware_droguerie': return t.expenses.catHardwareDroguerie;
      case 'building_materials': return t.expenses.catBuildingMaterials;
      case 'irrigation_tools': return t.expenses.catIrrigationTools;
      case 'office_stationery': return t.expenses.catOfficeStationery;
      case 'lawyer_fees': return t.expenses.catLawyerFees;
      case 'bailiff_fees': return t.expenses.catBailiffFees;
      case 'electricity': return t.expenses.catElectricity;
      case 'water': return t.expenses.catWater;
      case 'cleaning_company': return t.expenses.catCleaning;
      case 'security_company': return t.expenses.catSecurity;
      case 'emergency_repairs': return t.expenses.catEmergency;
      case 'supplies': return t.expenses.catSupplies;
      default: return t.expenses.catOther;
    }
  };

  const getCategoryIcon = (cat: ExpenseCategory) => {
    switch (cat) {
      case 'worker_salaries': return <Users className="w-4 h-4 text-sky-600" />;
      case 'syndic_fees': return <Briefcase className="w-4 h-4 text-amber-600" />;
      case 'cleaning_supplies': return <SparklesIcon className="w-4 h-4 text-emerald-500" />;
      case 'electrical_supplies': return <Zap className="w-4 h-4 text-amber-500" />;
      case 'hardware_droguerie': return <Wrench className="w-4 h-4 text-orange-600" />;
      case 'building_materials': return <Hammer className="w-4 h-4 text-stone-600" />;
      case 'irrigation_tools': return <Droplets className="w-4 h-4 text-teal-600" />;
      case 'office_stationery': return <FileText className="w-4 h-4 text-blue-600" />;
      case 'lawyer_fees': return <Scale className="w-4 h-4 text-purple-600" />;
      case 'bailiff_fees': return <Gavel className="w-4 h-4 text-rose-600" />;
      case 'electricity': return <Zap className="w-4 h-4 text-amber-500" />;
      case 'water': return <Droplet className="w-4 h-4 text-blue-500" />;
      case 'cleaning_company': return <SparklesIcon className="w-4 h-4 text-emerald-500" />;
      case 'security_company': return <Shield className="w-4 h-4 text-indigo-500" />;
      case 'emergency_repairs': return <Wrench className="w-4 h-4 text-red-500" />;
      default: return <Package className="w-4 h-4 text-slate-500" />;
    }
  };

  const getPaymentMethodLabel = (m: PaymentMethod) => {
    switch (m) {
      case 'cash': return lang === 'ar' ? 'نقداً (Espèces)' : 'Espèces';
      case 'bank_transfer': return lang === 'ar' ? 'تحويل بنكي (Virement)' : 'Virement';
      case 'check': return lang === 'ar' ? 'شيك (Chèque)' : 'Chèque';
      case 'online': return lang === 'ar' ? 'أداء إلكتروني (En ligne)' : 'En ligne';
      default: return m;
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Toast Notification */}
      {toastMessage && (
        <div className={`fixed bottom-6 ${isRtl ? 'left-6' : 'right-6'} z-50 flex items-center gap-3 px-5 py-3.5 rounded-2xl shadow-xl border text-sm font-bold text-white transition-all transform animate-in slide-in-from-bottom-5 ${
          toastMessage.type === 'success' ? 'bg-emerald-900 border-emerald-700' :
          toastMessage.type === 'error' ? 'bg-rose-900 border-rose-700' : 'bg-slate-900 border-slate-700'
        }`}>
          {toastMessage.type === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />}
          {toastMessage.type === 'error' && <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />}
          {toastMessage.type === 'info' && <Database className="w-5 h-5 text-sky-400 shrink-0" />}
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Main Header */}
      <div className="bg-gradient-to-r from-[#0f172a] via-[#0f172a] to-[#0a8591] text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-[#0d5262] relative overflow-hidden">
        <div className="absolute top-0 end-0 -mt-8 -me-8 w-64 h-64 bg-white/5 rounded-full blur-3xl pointer-events-none aurora-blob aurora-a" />
        <Database className="absolute top-6 end-10 w-20 h-20 text-white/10 anim-float pointer-events-none hidden sm:block" />
        <Database className="absolute bottom-4 end-1/3 w-8 h-8 text-amber-300/30 anim-float-2 pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/20 text-amber-200 text-xs font-bold tracking-wide">
              <Database className="w-3.5 h-3.5" />
              <span>{lang === 'ar' ? 'نظام تسريع التطبيق وقاعدة البيانات التاريخية' : 'Optimisation de Vitesse & Base Historique'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              {t.archive.title}
            </h1>
            <p className="text-emerald-100/90 text-xs sm:text-sm max-w-3xl leading-relaxed">
              {t.archive.subtitle}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setActiveTab('wizard')}
              id="btn-quick-archive-tab"
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition-all shadow-md cursor-pointer ${
                activeTab === 'wizard' 
                  ? 'bg-white text-[#0a8591] ring-2 ring-white/40' 
                  : 'bg-white/10 hover:bg-white/20 text-white border border-white/20'
              }`}
            >
              <ArrowRightLeft className="w-4 h-4" />
              <span>{lang === 'ar' ? 'ترحيل جديد للأرشيف' : 'Archiver Maintenant'}</span>
            </button>

            <button
              onClick={handleExportCSV}
              id="btn-export-archive-csv"
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs bg-black/20 hover:bg-black/30 text-white border border-white/20 transition-all cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4 text-amber-200" />
              <span>{lang === 'ar' ? 'تصدير Excel / CSV' : 'Export Excel / CSV'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Stats Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-500">{t.archive.statArchivedPayments}</span>
            <div className="text-2xl font-black text-slate-900 mt-1">{archivedPayments.length}</div>
            <div className="text-xs font-semibold text-[#0a8591] mt-0.5">
              {archivedPaymentsTotal.toLocaleString()} {t.common.currencyShort}
            </div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-[#e9fbf8] border border-[#92e8dd] flex items-center justify-center text-[#0a8591]">
            <Archive className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-500">{t.archive.statArchivedExpenses}</span>
            <div className="text-2xl font-black text-slate-900 mt-1">{archivedExpenses.length}</div>
            <div className="text-xs font-semibold text-rose-700 mt-0.5">
              {archivedExpensesTotal.toLocaleString()} {t.common.currencyShort}
            </div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-700">
            <Database className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-500">{t.archive.statBatches}</span>
            <div className="text-2xl font-black text-slate-900 mt-1">{archiveBatches.length}</div>
            <div className="text-xs font-semibold text-slate-500 mt-0.5">
              {lang === 'ar' ? 'عمليات ترحيل منفذة' : 'Lots traités'}
            </div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-700">
            <RotateCcw className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-[#0a8591] to-[#0f172a] text-white rounded-2xl p-5 shadow-xs flex items-center justify-between border border-[#0d5262]">
          <div>
            <span className="text-xs font-bold text-amber-200">{t.archive.statEfficiency}</span>
            <div className="text-xl font-extrabold mt-1">100%</div>
            <div className="text-[11px] text-emerald-100/90 mt-0.5 font-medium">
              {lang === 'ar' ? 'سرعة استجابة فائقة' : 'Vitesse optimale'}
            </div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center text-amber-200 border border-white/10">
            <Sparkles className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Navigation Tabs Bar */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 bg-slate-200/70 rounded-2xl border border-slate-200">
        <button
          onClick={() => setActiveTab('wizard')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'wizard' 
              ? 'bg-white text-[#0a8591] shadow-sm' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
          }`}
        >
          <ArrowRightLeft className="w-4 h-4 text-[#0a8591]" />
          <span>{lang === 'ar' ? 'لوحة ترحيل السجلات' : 'Assistant d\'Archivage'}</span>
          {(eligiblePreview.paymentsCount > 0 || eligiblePreview.expensesCount > 0) && (
            <span className="w-2 h-2 rounded-full bg-[#0a8591] animate-pulse" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('payments')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'payments' 
              ? 'bg-white text-[#0a8591] shadow-sm' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
          }`}
        >
          <Archive className="w-4 h-4 text-[#0a8591]" />
          <span>{t.archive.tabPayments}</span>
          <span className="px-2 py-0.5 text-[10px] rounded-full bg-[#e9fbf8] text-[#0a8591] font-bold border border-[#92e8dd]">
            {archivedPayments.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('expenses')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'expenses' 
              ? 'bg-white text-[#0a8591] shadow-sm' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
          }`}
        >
          <Database className="w-4 h-4 text-rose-700" />
          <span>{t.archive.tabExpenses}</span>
          <span className="px-2 py-0.5 text-[10px] rounded-full bg-rose-100 text-rose-800 font-bold">
            {archivedExpenses.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('batches')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'batches' 
              ? 'bg-white text-[#0a8591] shadow-sm' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
          }`}
        >
          <RotateCcw className="w-4 h-4 text-indigo-700" />
          <span>{t.archive.tabBatches}</span>
          <span className="px-2 py-0.5 text-[10px] rounded-full bg-indigo-100 text-indigo-800 font-bold">
            {archiveBatches.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('tools')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'tools' 
              ? 'bg-white text-[#0a8591] shadow-sm' 
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
          }`}
        >
          <Download className="w-4 h-4 text-slate-700" />
          <span>{t.archive.tabSettings}</span>
        </button>
      </div>

      {/* TAB CONTENT: 1. ARCHIVE WIZARD */}
      {activeTab === 'wizard' && (
        <div className="space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
            <div className="flex items-start justify-between gap-4 border-b border-slate-100 pb-5">
              <div>
                <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2.5">
                  <ArrowRightLeft className="w-5 h-5 text-emerald-700" />
                  <span>{t.archive.archiveWizardTitle}</span>
                </h2>
                <p className="text-slate-500 text-xs sm:text-sm mt-1">
                  {t.archive.archiveWizardDesc}
                </p>
              </div>

              <span className="px-3 py-1 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-xl border border-emerald-200 shrink-0">
                {lang === 'ar' ? 'توصية: أقدم من 1 سنة' : 'Recommandé : > 1 an'}
              </span>
            </div>

            {/* Presets Selector */}
            <div className="space-y-3">
              <label className="text-xs font-bold text-slate-700">
                {lang === 'ar' ? 'اختر الفترة الزمنية للترحيل :' : 'Sélectionnez la période d\'archivage :'}
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <button
                  type="button"
                  onClick={() => handlePresetChange('1year')}
                  className={`p-4 rounded-2xl border-2 text-start transition-all cursor-pointer flex flex-col justify-between h-28 ${
                    presetCutoff === '1year' 
                      ? 'border-emerald-600 bg-emerald-50/70 shadow-xs' 
                      : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100/70'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-extrabold text-slate-900">{t.archive.olderThan1Year}</span>
                    {presetCutoff === '1year' && <CheckCircle2 className="w-4 h-4 text-emerald-700" />}
                  </div>
                  <div className="text-[11px] text-slate-500 font-medium">
                    {lang === 'ar' ? 'كل ما قبل 12 شهراً مضت' : 'Antérieur à 12 mois'}
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => handlePresetChange('2years')}
                  className={`p-4 rounded-2xl border-2 text-start transition-all cursor-pointer flex flex-col justify-between h-28 ${
                    presetCutoff === '2years' 
                      ? 'border-emerald-600 bg-emerald-50/70 shadow-xs' 
                      : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100/70'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-extrabold text-slate-900">{t.archive.olderThan2Years}</span>
                    {presetCutoff === '2years' && <CheckCircle2 className="w-4 h-4 text-emerald-700" />}
                  </div>
                  <div className="text-[11px] text-slate-500 font-medium">
                    {lang === 'ar' ? 'السنوات المالية السابقة' : 'Antérieur à 24 mois'}
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => handlePresetChange('6months')}
                  className={`p-4 rounded-2xl border-2 text-start transition-all cursor-pointer flex flex-col justify-between h-28 ${
                    presetCutoff === '6months' 
                      ? 'border-emerald-600 bg-emerald-50/70 shadow-xs' 
                      : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100/70'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-extrabold text-slate-900">{t.archive.olderThan6Months}</span>
                    {presetCutoff === '6months' && <CheckCircle2 className="w-4 h-4 text-emerald-700" />}
                  </div>
                  <div className="text-[11px] text-slate-500 font-medium">
                    {lang === 'ar' ? 'تخفيف نصف سنوي' : 'Antérieur à 6 mois'}
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => handlePresetChange('custom')}
                  className={`p-4 rounded-2xl border-2 text-start transition-all cursor-pointer flex flex-col justify-between h-28 ${
                    presetCutoff === 'custom' 
                      ? 'border-emerald-600 bg-emerald-50/70 shadow-xs' 
                      : 'border-slate-200 bg-slate-50/50 hover:bg-slate-100/70'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-extrabold text-slate-900">{t.archive.customDate}</span>
                    {presetCutoff === 'custom' && <CheckCircle2 className="w-4 h-4 text-emerald-700" />}
                  </div>
                  <div className="text-[11px] text-slate-500 font-medium">
                    {lang === 'ar' ? 'تحديد تاريخ مخصص' : 'Date personnalisée'}
                  </div>
                </button>
              </div>
            </div>

            {/* Cutoff Date Input */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-200">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  {t.archive.cutoffDateLabel}
                </label>
                <input
                  type="date"
                  value={customCutoffDate}
                  onChange={(e) => {
                    setCustomCutoffDate(e.target.value);
                    setPresetCutoff('custom');
                  }}
                  className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-700"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  {lang === 'ar' ? 'ملاحظة توضيحية لدفعة الأرشفة (اختياري) :' : 'Note pour ce lot (Optionnel) :'}
                </label>
                <input
                  type="text"
                  placeholder={lang === 'ar' ? 'مثال: أرشفة السنة المالية المنتهية 2025' : 'Ex: Clôture exercice précédent'}
                  value={archiveNotes}
                  onChange={(e) => setArchiveNotes(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-medium text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-emerald-700"
                />
              </div>
            </div>

            {/* Selection Checkboxes */}
            <div className="space-y-3">
              <label className="text-xs font-bold text-slate-700">
                {lang === 'ar' ? 'البيانات المشمولة بالترحيل :' : 'Données concernées :'}
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label className="flex items-center gap-3 p-3.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={includePayments}
                    onChange={(e) => setIncludePayments(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded-md focus:ring-emerald-500"
                  />
                  <div className="text-xs">
                    <span className="font-bold text-slate-900 block">{t.archive.includePayments}</span>
                    <span className="text-slate-500 text-[11px]">
                      {lang === 'ar' ? 'وصولات الاشتراكات وأداءات الشقق القديمة' : 'Reçus de cotisations mensuelles'}
                    </span>
                  </div>
                </label>

                <label className="flex items-center gap-3 p-3.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={includeExpenses}
                    onChange={(e) => setIncludeExpenses(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded-md focus:ring-emerald-500"
                  />
                  <div className="text-xs">
                    <span className="font-bold text-slate-900 block">{t.archive.includeExpenses}</span>
                    <span className="text-slate-500 text-[11px]">
                      {lang === 'ar' ? 'فواتير الصيانة والكهرباء والماء والشركات' : 'Factures d\'électricité, eau et prestataires'}
                    </span>
                  </div>
                </label>
              </div>
            </div>

            {/* Live Counter Box */}
            <div className="p-5 rounded-2xl bg-emerald-50/80 border border-emerald-200/90 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-700 text-white flex items-center justify-center shrink-0">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-bold text-xs text-emerald-950">
                    {lang === 'ar' ? 'نتيجة الفحص والمعاينة الحية قبل الترحيل :' : 'Résultat de l\'analyse préliminaire :'}
                  </div>
                  <div className="text-xs text-emerald-800 mt-0.5">
                    <span>{t.archive.eligiblePaymentsFound} : <strong>{includePayments ? eligiblePreview.paymentsCount : 0}</strong> ({includePayments ? eligiblePreview.paymentsAmount.toLocaleString() : 0} {t.common.currencyShort})</span>
                    <span className="mx-2">•</span>
                    <span>{t.archive.eligibleExpensesFound} : <strong>{includeExpenses ? eligiblePreview.expensesCount : 0}</strong> ({includeExpenses ? eligiblePreview.expensesAmount.toLocaleString() : 0} {t.common.currencyShort})</span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                id="btn-open-confirm-archive"
                disabled={isOwner || (eligiblePreview.paymentsCount === 0 && eligiblePreview.expensesCount === 0)}
                onClick={() => setShowConfirmModal(true)}
                className={`px-5 py-3 rounded-xl font-bold text-xs flex items-center gap-2 transition-all shrink-0 cursor-pointer shadow-md ${
                  (eligiblePreview.paymentsCount > 0 || eligiblePreview.expensesCount > 0) && !isOwner
                    ? 'bg-emerald-800 hover:bg-emerald-700 text-white shadow-emerald-900/20'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed border border-slate-300'
                }`}
              >
                <ArrowRightLeft className="w-4 h-4" />
                <span>{t.archive.archiveNowBtn}</span>
              </button>
            </div>

            {/* Performance Advice Note */}
            <div className="flex items-start gap-2.5 p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600">
              <Sparkles className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <p className="leading-relaxed">
                {t.archive.performanceNote}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT: 2. ARCHIVED PAYMENTS */}
      {activeTab === 'payments' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Archive className="w-5 h-5 text-emerald-700" />
                <span>{t.archive.tabPayments} ({filteredArchivedPayments.length})</span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                {lang === 'ar' ? 'مجموع المبالغ المؤرشفة :' : 'Total archivé :'} <strong className="text-emerald-700">{archivedPaymentsTotal.toLocaleString()} {t.common.currencyShort}</strong>
              </p>
            </div>

            {/* Search and filters */}
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative min-w-[220px]">
                <Search className={`w-4 h-4 absolute ${isRtl ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 text-slate-400`} />
                <input
                  type="text"
                  placeholder={lang === 'ar' ? 'بحث برقم الوصل، الاسم، الشقة...' : 'Recherche reçu, nom, lot...'}
                  value={searchPayments}
                  onChange={(e) => setSearchPayments(e.target.value)}
                  className={`w-full bg-slate-50 border border-slate-200 rounded-xl py-2 ${isRtl ? 'pr-9 pl-3' : 'pl-9 pr-3'} text-xs font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-700`}
                />
              </div>

              {archivedPayments.length > 0 && (
                <button
                  type="button"
                  onClick={handleExportCSV}
                  className="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Excel / CSV</span>
                </button>
              )}
            </div>
          </div>

          {/* Payments Table */}
          {filteredArchivedPayments.length === 0 ? (
            <div className="py-16 text-center text-slate-400 space-y-3">
              <Archive className="w-12 h-12 mx-auto text-slate-300 stroke-1" />
              <div className="text-sm font-bold text-slate-600">{t.archive.noArchivedPayments}</div>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                {lang === 'ar' ? 'يمكنك استخدام معالج الترحيل لنقل الأداءات القديمة التي تجاوزت سنة إلى هذا الأرشيف.' : 'Utilisez l\'assistant d\'archivage pour déplacer les anciennes cotisations.'}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-2xl border border-slate-200">
              <table className="w-full whitespace-nowrap text-xs text-start">
                <thead className="bg-slate-50/90 text-slate-600 font-bold border-b border-slate-200">
                  <tr>
                    <th className="p-3.5 text-start">{lang === 'ar' ? 'رقم الوصل' : 'N° Reçu'}</th>
                    <th className="p-3.5 text-start">{lang === 'ar' ? 'الساكن / المالك' : 'Résident'}</th>
                    <th className="p-3.5 text-start">{lang === 'ar' ? 'العمارة والشقة' : 'Bâtiment / Lot'}</th>
                    <th className="p-3.5 text-start">{lang === 'ar' ? 'تاريخ الأداء' : 'Date Paiement'}</th>
                    <th className="p-3.5 text-start">{lang === 'ar' ? 'الفترة' : 'Période'}</th>
                    <th className="p-3.5 text-start">{lang === 'ar' ? 'طريقة الأداء' : 'Mode'}</th>
                    <th className="p-3.5 text-start">{lang === 'ar' ? 'المبلغ' : 'Montant'}</th>
                    <th className="p-3.5 text-center">{lang === 'ar' ? 'إجراءات الأرشيف' : 'Actions'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                  {filteredArchivedPayments.map((p) => (
                    <tr key={p.id} className="hover:bg-emerald-50/30 transition-colors">
                      <td className="p-3.5 font-mono font-bold text-emerald-800">
                        {p.receiptNumber}
                      </td>
                      <td className="p-3.5 font-bold text-slate-900">
                        {p.residentName}
                      </td>
                      <td className="p-3.5">
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-800 font-semibold">
                          {p.buildingCode} - {lang === 'ar' ? 'شقة' : 'Apt'} {p.apartmentNumber}
                        </span>
                      </td>
                      <td className="p-3.5 text-slate-500 font-mono">
                        {p.paymentDate}
                      </td>
                      <td className="p-3.5 font-semibold text-slate-700">
                        {p.periodMonth}
                      </td>
                      <td className="p-3.5">
                        <span className="text-[11px] text-slate-600">
                          {getPaymentMethodLabel(p.paymentMethod)}
                        </span>
                      </td>
                      <td className="p-3.5 font-extrabold text-emerald-700">
                        {Number(p.amount).toLocaleString()} {t.common.currencyShort}
                      </td>
                      <td className="p-3.5">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => setSelectedReceipt(p)}
                            title={t.archive.viewReceipt}
                            className="p-1.5 rounded-lg bg-emerald-50 text-emerald-800 hover:bg-emerald-100 transition-colors cursor-pointer"
                          >
                            <Printer className="w-4 h-4" />
                          </button>

                          {!isOwner && (
                            <>
                              <button
                                type="button"
                                onClick={() => {
                                  restorePaymentFromArchive(p.id);
                                  showToast(t.archive.restoreSuccess, 'success');
                                }}
                                title={t.archive.restoreBtn}
                                className="p-1.5 rounded-lg bg-blue-50 text-blue-800 hover:bg-blue-100 transition-colors cursor-pointer"
                              >
                                <RotateCcw className="w-4 h-4" />
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  if (confirm(lang === 'ar' ? 'هل أنت متأكد من حذف هذا السجل نهائياً من الأرشيف؟' : 'Supprimer définitivement ce reçu de l\'archive ?')) {
                                    deleteArchivedPayment(p.id);
                                    showToast(lang === 'ar' ? 'تم حذف السجل من الأرشيف' : 'Reçu supprimé de l\'archive', 'info');
                                  }
                                }}
                                title={t.common.delete}
                                className="p-1.5 rounded-lg bg-rose-50 text-rose-700 hover:bg-rose-100 transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT: 3. ARCHIVED EXPENSES */}
      {activeTab === 'expenses' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Database className="w-5 h-5 text-rose-700" />
                <span>{t.archive.tabExpenses} ({filteredArchivedExpenses.length})</span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                {lang === 'ar' ? 'مجموع المصاريف المؤرشفة :' : 'Total dépenses archivées :'} <strong className="text-rose-700">{archivedExpensesTotal.toLocaleString()} {t.common.currencyShort}</strong>
              </p>
            </div>

            {/* Search and filters */}
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative min-w-[220px]">
                <Search className={`w-4 h-4 absolute ${isRtl ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 text-slate-400`} />
                <input
                  type="text"
                  placeholder={lang === 'ar' ? 'بحث في المصاريف المؤرشفة...' : 'Recherche dépenses...'}
                  value={searchExpenses}
                  onChange={(e) => setSearchExpenses(e.target.value)}
                  className={`w-full bg-slate-50 border border-slate-200 rounded-xl py-2 ${isRtl ? 'pr-9 pl-3' : 'pl-9 pr-3'} text-xs font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-700`}
                />
              </div>

              {archivedExpenses.length > 0 && (
                <button
                  type="button"
                  onClick={handleExportCSV}
                  className="px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Excel / CSV</span>
                </button>
              )}
            </div>
          </div>

          {/* Expenses Table */}
          {filteredArchivedExpenses.length === 0 ? (
            <div className="py-16 text-center text-slate-400 space-y-3">
              <Database className="w-12 h-12 mx-auto text-slate-300 stroke-1" />
              <div className="text-sm font-bold text-slate-600">{t.archive.noArchivedExpenses}</div>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                {lang === 'ar' ? 'لا توجد فواتير أو مصاريف مؤرشفة حالياً.' : 'Aucune dépense archivée actuellement.'}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-2xl border border-slate-200">
              <table className="w-full whitespace-nowrap text-xs text-start">
                <thead className="bg-slate-50/90 text-slate-600 font-bold border-b border-slate-200">
                  <tr>
                    <th className="p-3.5 text-start">{lang === 'ar' ? 'الصنف' : 'Catégorie'}</th>
                    <th className="p-3.5 text-start">{lang === 'ar' ? 'عنوان المصروف / البيان' : 'Désignation'}</th>
                    <th className="p-3.5 text-start">{lang === 'ar' ? 'المورد / رقم الفاتورة' : 'Fournisseur / Facture'}</th>
                    <th className="p-3.5 text-start">{lang === 'ar' ? 'العمارة' : 'Bâtiment'}</th>
                    <th className="p-3.5 text-start">{lang === 'ar' ? 'التاريخ' : 'Date'}</th>
                    <th className="p-3.5 text-start">{lang === 'ar' ? 'طريقة الأداء' : 'Mode'}</th>
                    <th className="p-3.5 text-start">{lang === 'ar' ? 'المبلغ' : 'Montant'}</th>
                    <th className="p-3.5 text-center">{lang === 'ar' ? 'إجراءات' : 'Actions'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                  {filteredArchivedExpenses.map((e) => (
                    <tr key={e.id} className="hover:bg-rose-50/30 transition-colors">
                      <td className="p-3.5">
                        <div className="flex items-center gap-2">
                          {getCategoryIcon(e.category)}
                          <span className="font-semibold text-slate-800">{getCategoryLabel(e.category)}</span>
                        </div>
                      </td>
                      <td className="p-3.5 font-bold text-slate-900">
                        {e.title}
                      </td>
                      <td className="p-3.5">
                        <div className="text-slate-900 font-semibold">{e.supplier}</div>
                        {e.invoiceRef && <div className="text-[10px] text-slate-400 font-mono">{e.invoiceRef}</div>}
                      </td>
                      <td className="p-3.5">
                        <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-semibold">
                          {e.buildingCode || 'ALL'}
                        </span>
                      </td>
                      <td className="p-3.5 text-slate-500 font-mono">
                        {e.date}
                      </td>
                      <td className="p-3.5 text-slate-600">
                        {getPaymentMethodLabel(e.paymentMethod)}
                      </td>
                      <td className="p-3.5 font-extrabold text-rose-700">
                        {Number(e.amount).toLocaleString()} {t.common.currencyShort}
                      </td>
                      <td className="p-3.5">
                        <div className="flex items-center justify-center gap-1.5">
                          {!isOwner && (
                            <>
                              <button
                                type="button"
                                onClick={() => {
                                  restoreExpenseFromArchive(e.id);
                                  showToast(t.archive.restoreSuccess, 'success');
                                }}
                                title={t.archive.restoreBtn}
                                className="p-1.5 rounded-lg bg-blue-50 text-blue-800 hover:bg-blue-100 transition-colors cursor-pointer"
                              >
                                <RotateCcw className="w-4 h-4" />
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  if (confirm(lang === 'ar' ? 'هل أنت متأكد من حذف هذا المصروف نهائياً من الأرشيف؟' : 'Supprimer définitivement cette dépense de l\'archive ?')) {
                                    deleteArchivedExpense(e.id);
                                    showToast(lang === 'ar' ? 'تم حذف المصروف من الأرشيف' : 'Dépense supprimée de l\'archive', 'info');
                                  }
                                }}
                                title={t.common.delete}
                                className="p-1.5 rounded-lg bg-rose-50 text-rose-700 hover:bg-rose-100 transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT: 4. BATCHES HISTORY */}
      {activeTab === 'batches' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <RotateCcw className="w-5 h-5 text-indigo-700" />
                <span>{t.archive.tabBatches}</span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                {lang === 'ar' ? 'سجل كافة دفعات الترحيل التي تمت إلى قاعدة بيانات الأرشيف مع إمكانية التراجع عنها في أي وقت' : 'Historique des transferts avec possibilité de restauration complète'}
              </p>
            </div>
          </div>

          {archiveBatches.length === 0 ? (
            <div className="py-16 text-center text-slate-400 space-y-3">
              <RotateCcw className="w-12 h-12 mx-auto text-slate-300 stroke-1" />
              <div className="text-sm font-bold text-slate-600">{t.archive.noBatches}</div>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                {lang === 'ar' ? 'عند تنفيذ أول عملية أرشفة ستظهر تفاصيلها وسجلها هنا.' : 'Les lots d\'archivage apparaîtront ici dès leur exécution.'}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {archiveBatches.map((batch) => (
                <div key={batch.id} className="p-4 rounded-2xl border border-slate-200 bg-slate-50/60 hover:bg-slate-50 transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs text-slate-900">
                        {batch.notes || (lang === 'ar' ? 'دفعة ترحيل أرشيف' : 'Lot d\'archivage')}
                      </span>
                      <span className="text-[10px] font-mono px-2 py-0.5 bg-slate-200 rounded-md text-slate-700">
                        {batch.archiveDate}
                      </span>
                    </div>

                    <div className="text-xs text-slate-600 flex flex-wrap items-center gap-2">
                      <span>{lang === 'ar' ? 'الحد الأقصى للتاريخ :' : 'Date limite :'} <strong>{batch.cutoffDate}</strong></span>
                      <span>•</span>
                      <span>{lang === 'ar' ? 'الأداءات المرحّلة :' : 'Cotisations :'} <strong className="text-emerald-700">{batch.paymentsCount} ({batch.paymentsTotalAmount.toLocaleString()} {t.common.currencyShort})</strong></span>
                      <span>•</span>
                      <span>{lang === 'ar' ? 'المصاريف المرحّلة :' : 'Dépenses :'} <strong className="text-rose-700">{batch.expensesCount} ({batch.expensesTotalAmount.toLocaleString()} {t.common.currencyShort})</strong></span>
                      <span>•</span>
                      <span className="text-slate-400">بواسطة: {batch.archivedBy}</span>
                    </div>
                  </div>

                  {!isOwner && (
                    <button
                      type="button"
                      onClick={() => {
                        if (confirm(lang === 'ar' ? 'هل تريد استرجاع كافة سجلات هذه الدفعة وإعادتها للقوائم النشطة؟' : 'Restaurer tout ce lot vers les listes actives ?')) {
                          restoreBatchFromArchive(batch.id);
                          showToast(t.archive.restoreSuccess, 'success');
                        }
                      }}
                      className="px-3.5 py-2 rounded-xl text-xs font-bold bg-white hover:bg-blue-50 text-blue-800 border border-slate-200 shadow-xs flex items-center gap-1.5 shrink-0 cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>{t.archive.restoreAllBatch}</span>
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT: 5. TOOLS & EXPORT */}
      {activeTab === 'tools' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Export / Download Card */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
                <Download className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">{lang === 'ar' ? 'تصدير وحفظ قاعدة بيانات الأرشيف' : 'Export de la Base d\'Archives'}</h3>
                <p className="text-xs text-slate-500">{lang === 'ar' ? 'تحميل السجلات المؤرشفة كملف مستقل' : 'Télécharger une copie externe de l\'archive'}</p>
              </div>
            </div>

            <div className="space-y-2.5">
              <button
                type="button"
                onClick={exportArchiveJSON}
                className="w-full flex items-center justify-between p-3.5 rounded-xl border border-slate-200 hover:bg-emerald-50 hover:border-emerald-300 text-xs font-bold text-slate-800 transition-all cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <Database className="w-4 h-4 text-emerald-700" />
                  <span>{t.archive.downloadArchiveJson}</span>
                </div>
                <ArrowDownToLine className="w-4 h-4 text-emerald-700" />
              </button>

              <button
                type="button"
                onClick={handleExportCSV}
                className="w-full flex items-center justify-between p-3.5 rounded-xl border border-slate-200 hover:bg-emerald-50 hover:border-emerald-300 text-xs font-bold text-slate-800 transition-all cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
                  <span>{t.archive.downloadArchiveCsv}</span>
                </div>
                <ArrowDownToLine className="w-4 h-4 text-emerald-700" />
              </button>
            </div>
          </div>

          {/* Import / Restore Card */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
              <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center">
                <Upload className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">{lang === 'ar' ? 'استيراد واسترجاع الأرشيف' : 'Importation & Restauration'}</h3>
                <p className="text-xs text-slate-500">{lang === 'ar' ? 'دمج أرشيف محفوظ أو استرجاع العمليات' : 'Intégrer une archive sauvegardée'}</p>
              </div>
            </div>

            <div className="space-y-2.5">
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleImportFile} 
                accept=".json" 
                className="hidden" 
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full flex items-center justify-between p-3.5 rounded-xl border border-slate-200 hover:bg-blue-50 hover:border-blue-300 text-xs font-bold text-slate-800 transition-all cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <Upload className="w-4 h-4 text-blue-700" />
                  <span>{t.archive.importArchive}</span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">.JSON</span>
              </button>

              {!isOwner && totalArchivedCount > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    if (confirm(lang === 'ar' ? 'هل تريد استرجاع كافة السجلات المؤرشفة وإعادتها دفعة واحدة إلى الجداول النشطة؟' : 'Tout restaurer vers les listes actives ?')) {
                      restoreAllArchivedRecords();
                      showToast(t.archive.restoreSuccess, 'success');
                    }
                  }}
                  className="w-full flex items-center justify-between p-3.5 rounded-xl border border-blue-200 bg-blue-50/50 hover:bg-blue-100 text-xs font-bold text-blue-900 transition-all cursor-pointer"
                >
                  <div className="flex items-center gap-2.5">
                    <RotateCcw className="w-4 h-4 text-blue-700" />
                    <span>{lang === 'ar' ? 'استرجاع كافة سجلات الأرشيف إلى النشط' : 'Tout restaurer vers les listes actives'}</span>
                  </div>
                  <span className="text-[11px] font-bold text-blue-800">({totalArchivedCount})</span>
                </button>
              )}
            </div>
          </div>

          {/* Danger Zone: Purge Archive */}
          {!isOwner && (
            <div className="md:col-span-2 bg-rose-50/70 rounded-3xl p-6 border border-rose-200 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-rose-900 font-bold text-sm">
                  <AlertTriangle className="w-5 h-5 text-rose-600" />
                  <span>{lang === 'ar' ? 'منطقة العمليات الحساسة : تفريغ الأرشيف نهائياً' : 'Zone Critique : Purge de l\'archive'}</span>
                </div>

                <button
                  type="button"
                  id="btn-purge-archive"
                  disabled={totalArchivedCount === 0}
                  onClick={() => setShowClearConfirmModal(true)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
                    totalArchivedCount > 0 
                      ? 'bg-rose-700 hover:bg-rose-800 text-white shadow-xs cursor-pointer' 
                      : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>{t.archive.clearArchive}</span>
                </button>
              </div>
              <p className="text-xs text-rose-700 leading-relaxed">
                {lang === 'ar' 
                  ? 'يُنصح دائماً بتنزيل نسخة احتياطية من ملف الأرشيف قبل إجراء أي عملية تفريغ نهائية لقاعدة البيانات التاريخية.'
                  : 'Assurez-vous de télécharger une copie de sauvegarde avant de purger définitivement la base d\'archives.'}
              </p>
            </div>
          )}
        </div>
      )}

      {/* CONFIRMATION ARCHIVE MODAL */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-5 animate-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 text-emerald-900">
              <div className="w-11 h-11 rounded-2xl bg-emerald-100 flex items-center justify-center text-emerald-800 shrink-0">
                <Archive className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-extrabold text-base">{t.archive.confirmArchiveTitle}</h3>
                <span className="text-xs text-slate-500">{lang === 'ar' ? 'تأكيد عملية الترحيل' : 'Confirmation du transfert'}</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 text-xs text-slate-700">
              <div className="flex justify-between">
                <span>{lang === 'ar' ? 'تاريخ الحد الأقصى :' : 'Date limite :'}</span>
                <strong className="text-slate-900 font-mono">{customCutoffDate}</strong>
              </div>
              <div className="flex justify-between">
                <span>{lang === 'ar' ? 'الأداءات المرشحة :' : 'Cotisations :'}</span>
                <strong className="text-emerald-700">{includePayments ? eligiblePreview.paymentsCount : 0} ({includePayments ? eligiblePreview.paymentsAmount.toLocaleString() : 0} {t.common.currencyShort})</strong>
              </div>
              <div className="flex justify-between">
                <span>{lang === 'ar' ? 'المصاريف المرشحة :' : 'Dépenses :'}</span>
                <strong className="text-rose-700">{includeExpenses ? eligiblePreview.expensesCount : 0} ({includeExpenses ? eligiblePreview.expensesAmount.toLocaleString() : 0} {t.common.currencyShort})</strong>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              {t.archive.confirmArchiveDesc}
            </p>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-100 cursor-pointer"
              >
                {t.common.cancel}
              </button>
              <button
                type="button"
                id="btn-confirm-archive-execute"
                onClick={handleExecuteArchive}
                className="flex-1 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-900/20 cursor-pointer"
              >
                {t.archive.archiveNowBtn}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CONFIRMATION CLEAR ARCHIVE MODAL */}
      {showClearConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-5 animate-in zoom-in-95 duration-150">
            <div className="flex items-center gap-3 text-rose-900">
              <div className="w-11 h-11 rounded-2xl bg-rose-100 flex items-center justify-center text-rose-700 shrink-0">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-extrabold text-base">{t.archive.clearArchive}</h3>
                <span className="text-xs text-rose-600 font-bold">{lang === 'ar' ? 'إجراء لا يمكن التراجع عنه' : 'Action irréversible'}</span>
              </div>
            </div>

            <p className="text-xs text-slate-700 leading-relaxed">
              {t.archive.clearArchiveConfirm}
            </p>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowClearConfirmModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-100 cursor-pointer"
              >
                {t.common.cancel}
              </button>
              <button
                type="button"
                onClick={() => {
                  clearAllArchive();
                  setShowClearConfirmModal(false);
                  showToast(lang === 'ar' ? 'تم تفريغ الأرشيف بالكامل' : 'Archive vidée avec succès', 'info');
                }}
                className="flex-1 py-2.5 rounded-xl bg-rose-700 hover:bg-rose-800 text-white font-bold text-xs shadow-md shadow-rose-900/20 cursor-pointer"
              >
                {t.common.confirm}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
