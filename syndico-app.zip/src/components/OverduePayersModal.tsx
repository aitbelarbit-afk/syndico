import { RES } from '../config/residence';
import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Apartment } from '../types';
import { getApartmentDebtStatus, getUnpaidMonthsList } from '../utils/debtUtils';
import { 
  X, Search, Filter, MessageSquare, Mail, Edit2, CreditCard, 
  AlertCircle, CheckCircle2, Check, Clock, Building2, Home, 
  User, Phone, AlertTriangle, Users, Download, Printer,
  Send, Bot, BellRing, Sparkles, RefreshCw, Copy, CheckCheck, 
  ShieldAlert, FileText, ChevronRight, Play, CheckSquare, Square,
  CheckCircle, History, ExternalLink
} from 'lucide-react';

interface OverduePayersModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenDebtEditor?: (apt: Apartment, prefillName?: string) => void;
}

export const OverduePayersModal: React.FC<OverduePayersModalProps> = ({
  isOpen,
  onClose,
  onOpenDebtEditor
}) => {
  const { 
    lang, 
    t, 
    apartments, 
    residents, 
    payments, 
    updateApartment, 
    setActiveSection,
    buildings
  } = useApp();

  const isAr = lang === 'ar';

  // Navigation Tab between Standard Table View & Automated Alerts Center
  const [activeModalTab, setActiveModalTab] = useState<'list' | 'auto_alerts'>('list');

  // Filters and Sorting State
  const [overdueBuilding, setOverdueBuilding] = useState<string>('ALL');
  const [overdueApartmentNum, setOverdueApartmentNum] = useState<string>('ALL');
  const [overdueSearch, setOverdueSearch] = useState<string>('');
  const [overdueMonthsFilter, setOverdueMonthsFilter] = useState<'ALL' | 'OVERDUE_ONLY' | 'RELATIVELY_COMPLIANT' | 'COMPLIANT_ONLY' | '1_3' | '4_5' | '6_PLUS'>('ALL');
  const [sortOrder, setSortOrder] = useState<'compliant_to_overdue' | 'overdue_to_compliant' | 'building'>('compliant_to_overdue');

  // Multi-Selection of Apartments for Alerts
  const [selectedApartmentIds, setSelectedApartmentIds] = useState<string[]>([]);

  // Alert Target Classification Tier:
  // 'overdue_6plus': فقط المتأخرون الذين تجاوز تأخرهم 6 أشهر (القانون 18.00)
  // 'relatively_compliant': الملتزمون نسبياً (1 إلى 5 أشهر)
  // 'all_unpaid': الجميع (متأخرون + ملتزمون نسبياً)
  const [alertTargetTier, setAlertTargetTier] = useState<'overdue_6plus' | 'relatively_compliant' | 'all_unpaid'>('overdue_6plus');

  // Channel filter in alerts center: 'all' | 'whatsapp' | 'email' | 'missing'
  const [alertChannelFilter, setAlertChannelFilter] = useState<'all' | 'whatsapp' | 'email' | 'missing'>('all');

  // Template Preview Mode: 'whatsapp' | 'email'
  const [alertTemplateType, setAlertTemplateType] = useState<'whatsapp' | 'email'>('whatsapp');
  const [showTemplateEditor, setShowTemplateEditor] = useState<boolean>(false);
  const [showHistoryDrawer, setShowHistoryDrawer] = useState<boolean>(false);

  // History & Toast notifications
  const [alertHistory, setAlertHistory] = useState<{
    id: string;
    aptId: string;
    aptCode: string;
    ownerName: string;
    channel: 'whatsapp' | 'email';
    sentAt: string;
    monthsCount: number;
    amount: number;
  }[]>(() => {
    try {
      const saved = localStorage.getItem('ma_overdue_alerts_history_v1');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sequential batch sender helper state
  const [sequentialSendIndex, setSequentialSendIndex] = useState<number | null>(null);

  // Quick Debt & Owner Edit Modal State (Direct inside modal)
  const [isDebtEditModalOpen, setIsDebtEditModalOpen] = useState(false);
  const [debtEditApt, setDebtEditApt] = useState<Apartment | null>(null);
  const [editOwnerName, setEditOwnerName] = useState('');
  const [editOwnerPhone, setEditOwnerPhone] = useState('');
  const [editOwnerCin, setEditOwnerCin] = useState('');
  const [editDebtType, setEditDebtType] = useState<'clean' | 'in_debt'>('in_debt');
  const [editUnpaidMonths, setEditUnpaidMonths] = useState<number>(7);
  const [editMonthlyFee, setEditMonthlyFee] = useState<number>(150);
  const [editBalanceDue, setEditBalanceDue] = useState<number>(1050);
  const [debtEditSuccessMsg, setDebtEditSuccessMsg] = useState<string | null>(null);

  // Master list of all apartments with their debt and compliance status
  // Rule:
  // - Fully compliant: 0 months unpaid (debt.isPaid || unpaidMonths === 0)
  // - Relatively compliant: less than 6 months delay (1 to 5 months)
  // - Overdue debtor: starts from 6 months of arrears (unpaidMonths >= 6)
  const allApartmentsDebtList = useMemo(() => {
    return apartments
      .filter(apt => !apt.isSyndicOffice && !(false))
      .map(apt => {
        const debt = getApartmentDebtStatus(apt, payments);
        const unpaidList = getUnpaidMonthsList(debt.unpaidMonths);
        const res = residents.find(r => 
          r.buildingCode.trim().toLowerCase() === apt.buildingCode.trim().toLowerCase() && 
          r.apartmentNumber.trim() === apt.number.trim()
        );
        const ownerName = apt.ownerName || res?.fullName || 'مالك الشقة';
        const phone = apt.ownerPhone || apt.residentPhone || res?.phone || '';
        const email = apt.ownerEmail || apt.residentEmail || res?.email || '';
        
        const isFullyCompliant = debt.isPaid || debt.unpaidMonths === 0;
        // أقل من 6 أشهر (1 إلى 5 أشهر) يعتبر صاحبه نسبياً أنه ملتزم
        const isRelativelyCompliant = !debt.isPaid && debt.unpaidMonths >= 1 && debt.unpaidMonths < 6;
        // يحتسب التأخر ابتداءً من 6 أشهر من تأخير
        const isOverdue = !debt.isPaid && debt.unpaidMonths >= 6;
        const isCompliant = isFullyCompliant || isRelativelyCompliant;

        return {
          apt,
          debt,
          unpaidList,
          res,
          ownerName,
          phone,
          email,
          isFullyCompliant,
          isRelativelyCompliant,
          isOverdue,
          isCompliant,
        };
      });
  }, [apartments, payments, residents]);

  // Filtered and Sorted list
  const filteredOverdueApartments = useMemo(() => {
    let list = allApartmentsDebtList;

    if (overdueBuilding !== 'ALL') {
      list = list.filter(item => item.apt.buildingCode === overdueBuilding);
    }

    if (overdueApartmentNum !== 'ALL') {
      list = list.filter(item => item.apt.number === overdueApartmentNum);
    }

    if (overdueMonthsFilter === 'OVERDUE_ONLY') {
      list = list.filter(item => item.isOverdue);
    } else if (overdueMonthsFilter === 'RELATIVELY_COMPLIANT') {
      list = list.filter(item => item.isRelativelyCompliant);
    } else if (overdueMonthsFilter === 'COMPLIANT_ONLY') {
      list = list.filter(item => item.isFullyCompliant);
    } else if (overdueMonthsFilter === '1_3') {
      list = list.filter(item => item.debt.unpaidMonths >= 1 && item.debt.unpaidMonths <= 3);
    } else if (overdueMonthsFilter === '4_5') {
      list = list.filter(item => item.debt.unpaidMonths >= 4 && item.debt.unpaidMonths <= 5);
    } else if (overdueMonthsFilter === '6_PLUS') {
      list = list.filter(item => item.debt.unpaidMonths >= 6);
    }

    if (overdueSearch.trim()) {
      const q = overdueSearch.toLowerCase().trim();
      list = list.filter(item => 
        item.apt.buildingCode.toLowerCase().includes(q) ||
        item.apt.number.includes(q) ||
        item.ownerName.toLowerCase().includes(q) ||
        (item.apt.residentName && item.apt.residentName.toLowerCase().includes(q)) ||
        item.phone.includes(q) ||
        item.email.toLowerCase().includes(q)
      );
    }

    // Apply sorting
    return [...list].sort((a, b) => {
      if (sortOrder === 'compliant_to_overdue') {
        // From monthly compliant (0 months / 0 debt) to the most overdue (highest debt)
        if (a.debt.unpaidMonths !== b.debt.unpaidMonths) {
          return a.debt.unpaidMonths - b.debt.unpaidMonths;
        }
        if (a.debt.totalBalanceDue !== b.debt.totalBalanceDue) {
          return a.debt.totalBalanceDue - b.debt.totalBalanceDue;
        }
        return a.apt.buildingCode.localeCompare(b.apt.buildingCode) || (parseInt(a.apt.number, 10) - parseInt(b.apt.number, 10));
      }

      if (sortOrder === 'overdue_to_compliant') {
        // From most overdue down to monthly compliant
        if (b.debt.unpaidMonths !== a.debt.unpaidMonths) {
          return b.debt.unpaidMonths - a.debt.unpaidMonths;
        }
        if (b.debt.totalBalanceDue !== a.debt.totalBalanceDue) {
          return b.debt.totalBalanceDue - a.debt.totalBalanceDue;
        }
        return a.apt.buildingCode.localeCompare(b.apt.buildingCode) || (parseInt(a.apt.number, 10) - parseInt(b.apt.number, 10));
      }

      // Building sequence
      return a.apt.buildingCode.localeCompare(b.apt.buildingCode) || (parseInt(a.apt.number, 10) - parseInt(b.apt.number, 10));
    });
  }, [allApartmentsDebtList, overdueBuilding, overdueApartmentNum, overdueMonthsFilter, overdueSearch, sortOrder]);

  // Overall Statistics according to user rule:
  // - Overdue starts from 6 months delay (>= 6)
  // - Less than 6 months (< 6) is considered relatively compliant
  const fullyCompliantCount = useMemo(() => allApartmentsDebtList.filter(i => i.isFullyCompliant).length, [allApartmentsDebtList]);
  const relativelyCompliantCount = useMemo(() => allApartmentsDebtList.filter(i => i.isRelativelyCompliant).length, [allApartmentsDebtList]);
  const overdueCount = useMemo(() => allApartmentsDebtList.filter(i => i.isOverdue).length, [allApartmentsDebtList]);
  const compliantCount = fullyCompliantCount; // compatibility

  const totalOverdueAmount = useMemo(() => {
    return filteredOverdueApartments.reduce((sum, item) => sum + item.debt.totalBalanceDue, 0);
  }, [filteredOverdueApartments]);

  const overdueOnlyAmount = useMemo(() => {
    return allApartmentsDebtList
      .filter(i => i.isOverdue)
      .reduce((sum, item) => sum + item.debt.totalBalanceDue, 0);
  }, [allApartmentsDebtList]);

  // WhatsApp Reminder message generator
  const getWhatsappUrl = (item: (typeof allApartmentsDebtList)[0]) => {
    const rawPhone = (item.phone || '').replace(/[^0-9]/g, '');
    let cleanPhone = rawPhone;
    if (cleanPhone.startsWith('0')) {
      cleanPhone = '212' + cleanPhone.slice(1);
    }
    const monthsText = item.unpaidList.map(m => m.labelAr).join('، ');

    let msg = '';
    if (item.isOverdue) {
      msg = 
        `السلام عليكم ورحمة الله وبركاته،\n` +
        `السيد(ة) ${item.ownerName} المحترم(ة)،\n` +
        `بصفتكم مالك(ة) الشقة رقم ${item.apt.number} بالعمارة ${item.apt.buildingCode} ب${RES.nameAr}.\n\n` +
        `نحيطكم علماً بوجود متأخرات مستحقة بذمتكم لفائدة صندوق اتحاد الملاك (السنديك) بلغت أو تجاوزت 6 أشهر:\n` +
        `• الشهور غير المؤداة: ${monthsText}\n` +
        `• عدد الشهور: ${item.debt.unpaidMonths} أشهر (تأخر 6 أشهر فما فوق)\n` +
        `• المبلغ الإجمالي المستحق: ${item.debt.totalBalanceDue.toLocaleString()} درهم\n\n` +
        `نلتمس منكم التكرم بالتسوية العاجلة لتفادي أي مساطر إدارية أو قانونية ولضمان استمرارية خدمات ومرافق الإقامة.\n` +
        `شاكرين لكم حسن تعاونكم.\n` +
        `إدارة اتحاد الملاك - ${RES.nameAr}`;
    } else {
      msg = 
        `السلام عليكم ورحمة الله وبركاته،\n` +
        `السيد(ة) ${item.ownerName} المحترم(ة)،\n` +
        `بصفتكم مالك(ة) الشقة رقم ${item.apt.number} بالعمارة ${item.apt.buildingCode} ب${RES.nameAr}.\n\n` +
        `نود تذكيركم ودياً بمستحقات واجب السنديك الشهري الجارية (${item.debt.unpaidMonths} أشهر دون 6 أشهر):\n` +
        `• الشهور: ${monthsText}\n` +
        `• المبلغ الإجمالي المستحق: ${item.debt.totalBalanceDue.toLocaleString()} درهم\n\n` +
        `نشكر لكم حرصكم وتفضلكم بالتسوية في أقرب فرصة.\n` +
        `مع أطيب التحيات، إدارة اتحاد الملاك - ${RES.nameAr}`;
    }
    return cleanPhone ? `https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}` : `https://wa.me/?text=${encodeURIComponent(msg)}`;
  };

  const getEmailReminderUrl = (item: (typeof allApartmentsDebtList)[0]) => {
    const isOverdue = item.isOverdue;
    const subject = isOverdue
      ? `إشعار قانوني بتأخر مستحقات السنديك (تجاوزت 6 أشهر) - ${RES.nameAr} (${item.apt.buildingCode} - شقة ${item.apt.number})`
      : `تذكير ودي بواجبات السنديك - ${RES.nameAr} (${item.apt.buildingCode} - شقة ${item.apt.number})`;
    const monthsText = item.unpaidList.map(m => m.labelAr).join('، ');
    const bodyText = isOverdue
      ? `تحية طيبة وبعد،\n\n` +
        `السيد(ة) ${item.ownerName}، مالك(ة) الشقة رقم ${item.apt.number} بالعمارة ${item.apt.buildingCode}.\n\n` +
        `نحيطكم علماً بوجود متأخرات مستحقة بذمتكم بلغت أو تجاوزت 6 أشهر لفائدة صندوق اتحاد الملاك (السنديك):\n` +
        `• الشهور غير المؤداة: ${monthsText}\n` +
        `• عدد الشهور: ${item.debt.unpaidMonths} أشهر (متأخر رسمي)\n` +
        `• المبلغ الإجمالي المستحق: ${item.debt.totalBalanceDue.toLocaleString()} درهم\n\n` +
        `نلتمس منكم التكرم بالتسوية العاجلة لتفادي أي مساطر قانونية ولضمان استمرارية مرافق الإقامة.\n\n` +
        `مع خالص الشكر والتقدير.\n` +
        `إدارة اتحاد الملاك - ${RES.nameAr}`
      : `تحية طيبة وبعد،\n\n` +
        `السيد(ة) ${item.ownerName}، مالك(ة) الشقة رقم ${item.apt.number} بالعمارة ${item.apt.buildingCode}.\n\n` +
        `نود تذكيركم ودياً بمستحقات واجب السنديك (${item.debt.unpaidMonths} أشهر دون 6 أشهر):\n` +
        `• الشهور: ${monthsText}\n` +
        `• المبلغ: ${item.debt.totalBalanceDue.toLocaleString()} درهم\n\n` +
        `شاكرين لكم حسن تعاونكم الدائم.\n` +
        `إدارة اتحاد الملاك - ${RES.nameAr}`;
    return `mailto:${item.email || ''}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(bodyText)}`;
  };

  // Automated Alert Eligible List based on Selected Target Tier & Channels
  const alertEligibleApartments = useMemo(() => {
    let list = allApartmentsDebtList;

    if (alertTargetTier === 'overdue_6plus') {
      // فقط من تجاوز تأخرهم 6 أشهر (تأخر 6 أشهر فما فوق)
      list = list.filter(i => i.isOverdue);
    } else if (alertTargetTier === 'relatively_compliant') {
      // الملتزمون نسبياً (1 إلى 5 أشهر)
      list = list.filter(i => i.isRelativelyCompliant);
    } else {
      // جميع غير المؤدين
      list = list.filter(i => !i.isFullyCompliant);
    }

    // Filter by channel availability
    if (alertChannelFilter === 'whatsapp') {
      list = list.filter(i => !!i.phone && i.phone.replace(/\D/g, '').length >= 9);
    } else if (alertChannelFilter === 'email') {
      list = list.filter(i => !!i.email && i.email.includes('@'));
    } else if (alertChannelFilter === 'missing') {
      list = list.filter(i => (!i.phone || i.phone.replace(/\D/g, '').length < 9) && (!i.email || !i.email.includes('@')));
    }

    return list;
  }, [allApartmentsDebtList, alertTargetTier, alertChannelFilter]);

  // Record an alert in history log
  const recordAlertSent = (item: (typeof allApartmentsDebtList)[0], channel: 'whatsapp' | 'email') => {
    const entry = {
      id: `${Date.now()}_${item.apt.id}`,
      aptId: item.apt.id,
      aptCode: `${item.apt.buildingCode} - شقة ${item.apt.number}`,
      ownerName: item.ownerName,
      channel,
      sentAt: new Date().toLocaleString(isAr ? 'ar-MA' : 'fr-FR', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }),
      monthsCount: item.debt.unpaidMonths,
      amount: item.debt.totalBalanceDue
    };

    setAlertHistory(prev => {
      const updated = [entry, ...prev.slice(0, 99)];
      try {
        localStorage.setItem('ma_overdue_alerts_history_v1', JSON.stringify(updated));
      } catch {}
      return updated;
    });

    setToastMessage(
      isAr 
        ? `✅ تم تسجيل إرسال التنبيه للشقة (${item.apt.buildingCode} - شقة ${item.apt.number}) بنجاح!` 
        : `✅ Alerte enregistrée pour ${item.apt.buildingCode} - Appt ${item.apt.number} !`
    );
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Toggle selection
  const handleToggleSelectApartment = (id: string) => {
    setSelectedApartmentIds(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const handleSelectAllInView = () => {
    if (selectedApartmentIds.length === alertEligibleApartments.length && alertEligibleApartments.length > 0) {
      setSelectedApartmentIds([]);
    } else {
      setSelectedApartmentIds(alertEligibleApartments.map(i => i.apt.id));
    }
  };

  // Copy text helper
  const handleCopyText = (text: string) => {
    navigator.clipboard.writeText(text);
    setToastMessage(isAr ? '📋 تم نسخ نص الإشعار بنجاح!' : '📋 Texte copié avec succès !');
    setTimeout(() => setToastMessage(null), 2500);
  };

  // Launch Individual WhatsApp
  const handleLaunchWhatsApp = (item: (typeof allApartmentsDebtList)[0]) => {
    recordAlertSent(item, 'whatsapp');
    const url = getWhatsappUrl(item);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  // Launch Individual Email
  const handleLaunchEmail = (item: (typeof allApartmentsDebtList)[0]) => {
    recordAlertSent(item, 'email');
    const url = getEmailReminderUrl(item);
    window.location.href = url;
  };

  // Launch Batch Email
  const handleBatchEmail = () => {
    const selectedList = alertEligibleApartments.filter(i => selectedApartmentIds.includes(i.apt.id));
    const emails = selectedList.map(i => i.email).filter(e => e && e.includes('@'));
    if (emails.length === 0) {
      setToastMessage(isAr ? '⚠️ لا يتوفر أي بريد إلكتروني للملاك المحددين!' : '⚠️ Aucun email pour la sélection !');
      setTimeout(() => setToastMessage(null), 3000);
      return;
    }
    const subject = encodeURIComponent(
      isAr 
        ? 'إشعار قانوني رسمي بتسوية متأخرات السانديك (تجاوزت 6 أشهر) - الإقامة' 
        : 'Mise en demeure légale - Arriérés de cotisations (+6 mois) - Résidence El '
    );
    const body = encodeURIComponent(
      isAr 
        ? `السادة الملاك المحترمون ب${RES.nameAr}،\n\nنحيطكم علماً بوجوب تسوية متأخرات واجبات السانديك العالقة بذمتكم والتي بلغت أو تجاوزت 6 أشهر، وذلك بمقتضى القانون رقم 18.00 المتعلق بنظام الملكية المشتركة.\n\nيرجى التواصل مع إدارة السنديك أو التحويل للحساب البنكي الرسمي ل${RES.nameAr}.\n\nمع الشكر والتقدير،\nإدارة اتحاد الملاك - ${RES.nameAr}`
        : `Madame, Monsieur,\n\nNous vous prions de bien vouloir régulariser vos arriérés de cotisations de copropriété excédant 6 mois conformément à la loi 18.00.\n\nSyndic Résidence El `
    );
    selectedList.forEach(item => {
      if (item.email) recordAlertSent(item, 'email');
    });
    window.location.href = `mailto:?bcc=${emails.join(',')}&subject=${subject}&body=${body}`;
  };

  // Open Debt Editor internal handler
  const openDebtEditor = (apt: Apartment, prefillName?: string) => {
    if (onOpenDebtEditor) {
      onOpenDebtEditor(apt, prefillName);
      return;
    }
    setDebtEditApt(apt);
    const existingRes = residents.find(r => 
      r.buildingCode.trim().toLowerCase() === apt.buildingCode.trim().toLowerCase() && 
      r.apartmentNumber.trim() === apt.number.trim()
    );
    const resolvedName = apt.ownerName || existingRes?.fullName || prefillName || '';
    const resolvedPhone = apt.ownerPhone || existingRes?.phone || '';
    const resolvedCin = apt.ownerCin || existingRes?.cin || '';
    const fee = apt.monthlyFee > 0 ? apt.monthlyFee : 150;
    const months = (apt.unpaidMonthsCount && apt.unpaidMonthsCount > 0)
      ? apt.unpaidMonthsCount 
      : (apt.balanceDue > 0 ? Math.round(apt.balanceDue / fee) : 7);
    const balance = apt.balanceDue > 0 ? apt.balanceDue : (months * fee);

    setEditOwnerName(resolvedName);
    setEditOwnerPhone(resolvedPhone);
    setEditOwnerCin(resolvedCin);
    setEditMonthlyFee(fee);
    setEditDebtType('in_debt');
    setEditUnpaidMonths(months);
    setEditBalanceDue(balance);
    setDebtEditSuccessMsg(null);
    setIsDebtEditModalOpen(true);
  };

  const handleSaveDebtEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!debtEditApt) return;

    const finalMonths = editDebtType === 'clean' ? 0 : Number(editUnpaidMonths);
    const finalBalance = editDebtType === 'clean' ? 0 : Number(editBalanceDue);

    updateApartment(debtEditApt.id, {
      ownerName: editOwnerName.trim(),
      ownerPhone: editOwnerPhone.trim(),
      ownerCin: editOwnerCin.trim() ? editOwnerCin.trim().toUpperCase() : undefined,
      monthlyFee: Number(editMonthlyFee) || 150,
      balanceDue: finalBalance,
      unpaidMonthsCount: finalMonths,
      residentName: editOwnerName.trim() || debtEditApt.residentName,
      residentPhone: editOwnerPhone.trim() || debtEditApt.residentPhone,
      status: 'occupied'
    });

    setDebtEditSuccessMsg(
      isAr
        ? `تم بنجاح تحديث بيانات الشقة (${debtEditApt.buildingCode} - شقة ${debtEditApt.number}) والمالك "${editOwnerName || 'المحدد'}" وتثبيت المديونية.`
        : `Dette et informations enregistrées avec succès.`
    );

    setTimeout(() => {
      setDebtEditSuccessMsg(null);
      setIsDebtEditModalOpen(false);
    }, 1500);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-6xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-rose-300 overflow-hidden text-slate-900">
        
        {/* ========================================================================= */}
        {/* MODAL HEADER                                                              */}
        {/* ========================================================================= */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-rose-950 to-red-950 text-white flex items-center justify-between shrink-0 shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center text-white shadow-inner">
              <Clock className="w-5 h-5 text-rose-200" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base sm:text-lg font-black tracking-wide text-white">
                  {isAr ? 'ترتيب الملاك ومتابعة أداء واجبات السنديك' : 'Suivi & Classement des Propriétaires'}
                </h2>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/30 text-emerald-200 border border-emerald-300/30 text-xs font-mono font-bold" title={isAr ? 'ملتزم كلياً (0 أشهر تأخر)' : 'À jour (0 mois)'}>
                  🟢 {fullyCompliantCount} {isAr ? 'ملتزم كلياً (0 ش)' : 'à jour (0m)'}
                </span>
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500/30 text-amber-200 border border-amber-300/30 text-xs font-mono font-bold" title={isAr ? 'ملتزم نسبياً (1 إلى 5 أشهر تأخر - دون 6 أشهر)' : 'Relativement assidu (1-5 mois)'}>
                  🟡 {relativelyCompliantCount} {isAr ? 'ملتزم نسبياً (1-5 ش)' : 'relat. assidu (1-5m)'}
                </span>
                <span className="px-2.5 py-0.5 rounded-full bg-rose-500/40 text-rose-200 border border-rose-300/40 text-xs font-mono font-bold" title={isAr ? 'متأخر عن الأداء (6 أشهر فما فوق - متابعة الديون)' : 'Débiteur en retard (6+ mois)'}>
                  🔴 {overdueCount} {isAr ? 'متأخر (≥6 أشهر)' : 'en retard (≥6m)'}
                </span>
              </div>
              <p className="text-xs text-rose-200/90 font-medium mt-0.5">
                {isAr 
                  ? 'يحتسب التأخر ابتداءً من 6 أشهر فما فوق، أما أقل من 6 أشهر فيعتبر المالك ملتزماً نسبياً.' 
                  : 'Le retard est comptabilisé à partir de 6 mois d\'arriérés. Moins de 6 mois est considéré relativement assidu.'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-white/10 hover:bg-white/25 active:bg-white/30 text-white flex items-center justify-center transition-colors cursor-pointer border border-white/15"
            title={t.common.close}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs between Standard Table View & Automated Alerts Center */}
        <div className="bg-slate-900 px-4 pt-2.5 pb-0 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              type="button"
              onClick={() => setActiveModalTab('list')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-t-2xl text-xs font-black transition-all cursor-pointer ${
                activeModalTab === 'list'
                  ? 'bg-white text-slate-900 shadow-md border-t-2 border-rose-500'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <Users className="w-4 h-4 text-rose-600" />
              <span>{isAr ? 'جدول الملاك ومتابعة الأداء' : 'Tableau des Copropriétaires'}</span>
              <span className="px-1.5 py-0.2 rounded-full bg-slate-200 text-slate-800 text-[10px] font-mono font-bold">
                {allApartmentsDebtList.length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveModalTab('auto_alerts');
                if (selectedApartmentIds.length === 0) {
                  setSelectedApartmentIds(allApartmentsDebtList.filter(i => i.isOverdue).map(i => i.apt.id));
                }
              }}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-t-2xl text-xs font-black transition-all cursor-pointer ${
                activeModalTab === 'auto_alerts'
                  ? 'bg-white text-rose-950 shadow-md border-t-2 border-red-600'
                  : 'text-amber-300 hover:text-white hover:bg-white/10'
              }`}
            >
              <Send className="w-4 h-4 text-red-500 animate-pulse" />
              <span>{isAr ? 'مركز التنبيهات الآلية (+6 أشهر)' : 'Alertes Automatiques (+6 mois)'}</span>
              <span className="px-2 py-0.5 rounded-full bg-red-600 text-white text-[10px] font-mono font-black animate-pulse">
                {overdueCount} {isAr ? 'متأخر' : 'débiteurs'}
              </span>
            </button>
          </div>

          <div className="hidden sm:flex items-center gap-2 text-[11px] font-bold text-rose-200/90 pb-2">
            <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
            <span>{isAr ? 'تنبيهات مستندة للقانون 18.00' : 'Mise en demeure légale (Loi 18.00)'}</span>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* TAB 1: STANDARD TABLE & CLASSIFICATION LIST                              */}
        {/* ========================================================================= */}
        {activeModalTab === 'list' && (
          <>
            {/* FILTERS & SEARCH TOOLBAR */}
            <div className="p-4 bg-slate-50 border-b border-slate-200/90 space-y-3 shrink-0">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
            {/* 1. Sort Order Selector (CRITICAL USER REQUIREMENT) */}
            <div>
              <label className="block text-[11px] font-black text-rose-950 mb-1 flex items-center gap-1">
                <span>🔄</span>
                <span>{isAr ? 'ترتيب الملاك حسب الأداء:' : 'Ordre de classement :'}</span>
              </label>
              <select
                value={sortOrder}
                onChange={e => setSortOrder(e.target.value as any)}
                className="w-full text-xs font-extrabold px-3 py-2 rounded-xl border-2 border-rose-300 bg-white text-rose-950 focus:outline-none focus:ring-2 focus:ring-rose-500 shadow-2xs"
              >
                <option value="compliant_to_overdue">
                  {isAr ? '🟢 من الملتزم شهرياً إلى الأكثر تأخراً' : '🟢 Du plus assidu au plus débiteur'}
                </option>
                <option value="overdue_to_compliant">
                  {isAr ? '🔴 من الأكثر تأخراً إلى الملتزم شهرياً' : '🔴 Du plus débiteur au plus assidu'}
                </option>
                <option value="building">
                  {isAr ? '🏢 حسب تسلسل العمارات والشقق' : '🏢 Par ordre des immeubles & lots'}
                </option>
              </select>
            </div>

            {/* 2. Debt Depth & Compliance Tier Filter */}
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                {isAr ? 'تصفية حسب الالتزام والديون:' : 'Filtre de situation :'}
              </label>
              <select
                value={overdueMonthsFilter}
                onChange={e => setOverdueMonthsFilter(e.target.value as any)}
                className="w-full text-xs font-bold px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500"
              >
                <option value="ALL">{isAr ? `كافة الملاك [${allApartmentsDebtList.length}]` : `Tous les copropriétaires (${allApartmentsDebtList.length})`}</option>
                <option value="OVERDUE_ONLY">{isAr ? `🔴 المتأخرون فقط (6 أشهر فما فوق) [${overdueCount}]` : `🔴 Débiteurs (6 mois et +) [${overdueCount}]`}</option>
                <option value="RELATIVELY_COMPLIANT">{isAr ? `🟡 ملتزمون نسبياً (1 إلى 5 أشهر) [${relativelyCompliantCount}]` : `🟡 Relativement assidus (1-5 mois) [${relativelyCompliantCount}]`}</option>
                <option value="COMPLIANT_ONLY">{isAr ? `🟢 ملتزمون كلياً (0 أشهر / خالص) [${fullyCompliantCount}]` : `🟢 À jour complet (0 retard) [${fullyCompliantCount}]`}</option>
                <option value="1_3">{isAr ? '🟡 تأخر خفيف (1 إلى 3 أشهر)' : '🟡 1 à 3 mois'}</option>
                <option value="4_5">{isAr ? '🟠 تأخر معتدل (4 إلى 5 أشهر)' : '🟠 4 à 5 mois'}</option>
                <option value="6_PLUS">{isAr ? '🚨 متأخرون (6 أشهر فما فوق)' : '🚨 6 mois et plus'}</option>
              </select>
            </div>

            {/* 3. Building Selector */}
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                {isAr ? 'العمارة (جميع العمارات):' : 'Immeuble :'}
              </label>
              <select
                value={overdueBuilding}
                onChange={e => {
                  setOverdueBuilding(e.target.value);
                  setOverdueApartmentNum('ALL');
                }}
                className="w-full text-xs font-bold px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500"
              >
                <option value="ALL">{isAr ? '🏢 كافة العمارات (جميع العمارات)' : '🏢 Tous les immeubles'}</option>
                <optgroup label={isAr ? 'المجموعة A' : 'Groupe A'}>
                  {buildings.filter(b => b.code.includes('A')).map(b => (
                    <option key={b.id} value={b.code}>{b.code} - {b.name}</option>
                  ))}
                </optgroup>
                <optgroup label={isAr ? 'المجموعة B' : 'Groupe B'}>
                  {buildings.filter(b => b.code.includes('B')).map(b => (
                    <option key={b.id} value={b.code}>{b.code} - {b.name}</option>
                  ))}
                </optgroup>
              </select>
            </div>

            {/* 4. Apartment Number */}
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                {isAr ? 'رقم الشقة:' : 'Appartement :'}
              </label>
              <select
                value={overdueApartmentNum}
                onChange={e => setOverdueApartmentNum(e.target.value)}
                className="w-full text-xs font-bold px-3 py-2 rounded-xl border border-slate-300 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500"
              >
                <option value="ALL">{isAr ? '🚪 كافة الشقق' : '🚪 Tous les appartements'}</option>
                {Array.from({ length: 16 }, (_, i) => String(i + 1).padStart(2, '0')).map(num => (
                  <option key={num} value={num}>{isAr ? `شقة ${num}` : `Appt ${num}`}</option>
                ))}
              </select>
            </div>

            {/* 5. Search Input */}
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                {isAr ? 'بحث بالاسم / الهاتف:' : 'Recherche :'}
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={overdueSearch}
                  onChange={e => setOverdueSearch(e.target.value)}
                  placeholder={isAr ? 'اسم المالك أو الهاتف...' : 'Nom, téléphone...'}
                  className="w-full text-xs px-3 py-2 ps-8 rounded-xl border border-slate-300 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
                <Search className="w-3.5 h-3.5 text-slate-400 absolute start-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Metrics Ribbon Inside Modal */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-200 text-xs">
            <div className="flex items-center gap-3 sm:gap-4 flex-wrap">
              <span className="text-slate-600 font-semibold">
                {isAr ? 'المعروض:' : 'Affichés :'} <strong className="text-slate-900 font-black">{filteredOverdueApartments.length}</strong>
              </span>
              <span className="text-emerald-700 font-bold flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                {isAr ? 'ملتزم كلياً:' : 'À jour :'} <strong className="font-mono">{filteredOverdueApartments.filter(i => i.isFullyCompliant).length}</strong>
              </span>
              <span className="text-amber-700 font-bold flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-amber-500" />
                {isAr ? 'ملتزم نسبياً (<6 أشهر):' : 'Relat. assidu :'} <strong className="font-mono">{filteredOverdueApartments.filter(i => i.isRelativelyCompliant).length}</strong>
              </span>
              <span className="text-rose-700 font-bold flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-rose-600" />
                {isAr ? 'متأخر (≥6 أشهر):' : 'En retard (≥6m) :'} <strong className="font-mono">{filteredOverdueApartments.filter(i => i.isOverdue).length}</strong>
              </span>
              <span className="text-slate-700 font-semibold">
                {isAr ? 'مجموع الديون المعروضة:' : 'Total dettes :'} <strong className="text-rose-700 font-black font-mono">{totalOverdueAmount.toLocaleString()} DH</strong>
              </span>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={() => {
                  setActiveModalTab('auto_alerts');
                  setSelectedApartmentIds(allApartmentsDebtList.filter(i => i.isOverdue).map(i => i.apt.id));
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white font-black shadow-xs transition-all active:scale-95 cursor-pointer text-xs"
                title={isAr ? 'إرسال تنبيهات تلقائية للمتأخرين 6 أشهر فما فوق' : 'Alertes automatiques (+6m)'}
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isAr ? 'إرسال تنبيهات (+6 أشهر)' : 'Alertes (+6m)'}</span>
                <span className="px-1.5 py-0.2 rounded-full bg-white text-rose-700 font-mono text-[10px] font-black">
                  {overdueCount}
                </span>
              </button>

              {(overdueBuilding !== 'ALL' || overdueApartmentNum !== 'ALL' || overdueMonthsFilter !== 'ALL' || overdueSearch.trim() || sortOrder !== 'compliant_to_overdue') && (
                <button
                  type="button"
                  onClick={() => {
                    setOverdueBuilding('ALL');
                    setOverdueApartmentNum('ALL');
                    setOverdueMonthsFilter('ALL');
                    setOverdueSearch('');
                    setSortOrder('compliant_to_overdue');
                  }}
                  className="text-[11px] text-rose-700 hover:text-rose-900 font-bold underline cursor-pointer"
                >
                  {isAr ? 'إعادة ضبط' : 'Réinitialiser'}
                </button>
              )}
            </div>
          </div>

        </div>

        {/* ========================================================================= */}
        {/* TABLE OF OWNERS AND DEBTORS                                               */}
        {/* ========================================================================= */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 custom-scrollbar space-y-3">
          
          {filteredOverdueApartments.length === 0 ? (
            <div className="text-center py-16 px-4 bg-slate-50/50 rounded-2xl border border-dashed border-slate-200 space-y-2">
              <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
              <div className="text-base font-bold text-slate-800">
                {isAr ? 'لا توجد أي شقة تطابق معايير البحث الحالية' : 'Aucun appartement pour cette sélection'}
              </div>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                {isAr 
                  ? 'يرجى مراجعة عوامل التصفية للوصول إلى النتيجة المطلوبة.' 
                  : 'Veuillez réinitialiser les filtres pour afficher la liste.'}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-2xl border border-slate-200 shadow-2xs bg-white">
              <table className="w-full whitespace-nowrap text-start text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-100 text-slate-700 font-black">
                    <th className="p-3 text-center w-10">
                      <input 
                        type="checkbox" 
                        checked={selectedApartmentIds.length > 0 && selectedApartmentIds.length === filteredOverdueApartments.length}
                        onChange={() => {
                          if (selectedApartmentIds.length === filteredOverdueApartments.length && filteredOverdueApartments.length > 0) {
                            setSelectedApartmentIds([]);
                          } else {
                            setSelectedApartmentIds(filteredOverdueApartments.map(i => i.apt.id));
                          }
                        }}
                        className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500 cursor-pointer"
                        title={isAr ? 'تحديد الكل' : 'Tout sélectionner'}
                      />
                    </th>
                    <th className="p-3 text-start">{isAr ? 'العمارة والشقة' : 'Immeuble & Appt'}</th>
                    <th className="p-3 text-start">{isAr ? 'اسم مالك الشقة / الساكن' : 'Nom du Propriétaire'}</th>
                    <th className="p-3 text-start">{isAr ? 'وضعية الالتزام والشهور' : 'Situation & Mois'}</th>
                    <th className="p-3 text-start">{isAr ? 'الديون المترتبة عليه' : 'Dettes Cumulées'}</th>
                    <th className="p-3 text-center min-w-[200px]">{isAr ? 'إجراءات فورية' : 'Actions'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredOverdueApartments.map((item) => {
                    const isFullyCompliant = item.isFullyCompliant;
                    const isRelativelyCompliant = item.isRelativelyCompliant;
                    const isOverdue = item.isOverdue;
                    const whatsappUrl = getWhatsappUrl(item);

                    return (
                      <tr 
                        key={item.apt.id} 
                        className={`transition-colors hover:bg-slate-50/80 ${
                          isFullyCompliant 
                            ? 'bg-emerald-50/15' 
                            : isRelativelyCompliant 
                            ? 'bg-amber-50/25' 
                            : 'bg-rose-50/30'
                        }`}
                      >
                        {/* Checkbox column */}
                        <td className="p-3 text-center">
                          <input 
                            type="checkbox" 
                            checked={selectedApartmentIds.includes(item.apt.id)}
                            onChange={() => handleToggleSelectApartment(item.apt.id)}
                            className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500 cursor-pointer"
                          />
                        </td>
                        {/* 1. Building & Apartment */}
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                              isFullyCompliant ? 'bg-emerald-500' : isRelativelyCompliant ? 'bg-amber-500 ring-2 ring-amber-200' : 'bg-rose-600 ring-2 ring-rose-200 animate-pulse'
                            }`} />
                            <div>
                              <div className="font-black text-slate-900 text-xs">
                                {item.apt.buildingCode} - {isAr ? `شقة ${item.apt.number}` : `Appt ${item.apt.number}`}
                              </div>
                              <span className="text-[10px] text-slate-500 font-medium">
                                {item.apt.buildingCode.includes('A') ? (isAr ? 'مجموعة A' : 'Groupe A') : (isAr ? 'مجموعة B' : 'Groupe B')}
                              </span>
                            </div>
                          </div>
                        </td>

                        {/* 2. Owner & Resident info */}
                        <td className="p-3">
                          <div className="space-y-1">
                            <div className="font-extrabold text-slate-900 text-xs flex items-center gap-1.5">
                              <User className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                              <span>{item.ownerName}</span>
                            </div>
                            <div className="flex items-center gap-2 text-[11px] text-slate-600">
                              {item.phone && (
                                <a 
                                  href={`tel:${item.phone}`}
                                  className="hover:text-emerald-700 flex items-center gap-1 font-mono font-bold"
                                >
                                  <Phone className="w-3 h-3 text-slate-400" />
                                  <span>{item.phone}</span>
                                </a>
                              )}
                              {item.email && (
                                <>
                                  <span className="text-slate-300">•</span>
                                  <a 
                                    href={`mailto:${item.email}`}
                                    className="hover:text-blue-700 flex items-center gap-1 font-medium"
                                  >
                                    <Mail className="w-3 h-3 text-slate-400" />
                                    <span>{item.email}</span>
                                  </a>
                                </>
                              )}
                            </div>
                          </div>
                        </td>

                        {/* 3. Months & Compliance Status */}
                        <td className="p-3">
                          <div className="space-y-1 max-w-sm">
                            <div className="flex items-center gap-1.5">
                              {isFullyCompliant ? (
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-black text-xs font-mono bg-emerald-100 text-emerald-800 border border-emerald-300">
                                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                                  <span>{isAr ? 'ملتزم شهرياً (خالص كلياً 🟢)' : 'À jour (0 retard)'}</span>
                                </span>
                              ) : isRelativelyCompliant ? (
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md font-bold text-xs bg-amber-100 text-amber-900 border border-amber-300" title={isAr ? 'أقل من 6 أشهر تأخر - يعتبر نسبياً ملتزم' : 'Moins de 6 mois d\'arriérés'}>
                                  <Clock className="w-3.5 h-3.5 text-amber-600" />
                                  <span>{isAr ? `ملتزم نسبياً (${item.debt.unpaidMonths} أشهر - دون 6 أشهر 🟡)` : `Relat. assidu (${item.debt.unpaidMonths} mois)`}</span>
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md font-black text-xs font-mono bg-rose-100 text-rose-950 border border-rose-300 shadow-2xs" title={isAr ? 'تأخر 6 أشهر فما فوق - مسطرة الاستخلاص' : 'Retard officiel 6 mois et plus'}>
                                  <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                                  <span>{isAr ? `متأخر عن الأداء (${item.debt.unpaidMonths} أشهر - 6 فما فوق 🔴)` : `Débiteur (${item.debt.unpaidMonths} mois - 6m+)`}</span>
                                </span>
                              )}
                            </div>

                            {/* Unpaid Month tags */}
                            {!isFullyCompliant && item.unpaidList.length > 0 && (
                              <div className="flex items-center gap-1 flex-wrap max-h-14 overflow-y-auto">
                                {item.unpaidList.map((monthItem) => (
                                  <span
                                    key={monthItem.key}
                                    className={`px-1.5 py-0.2 rounded text-[10px] font-bold border ${
                                      isOverdue
                                        ? 'bg-rose-50 text-rose-800 border-rose-200'
                                        : 'bg-amber-50 text-amber-800 border-amber-200'
                                    }`}
                                  >
                                    {isAr ? monthItem.labelAr : monthItem.labelFr}
                                  </span>
                                ))}
                              </div>
                            )}

                            {isFullyCompliant && (
                              <div className="text-[10px] text-emerald-700 font-semibold">
                                {isAr ? 'جميع اشتراكات السانديك مسواة حتى الشهر الحالي' : 'Toutes les cotisations sont à jour'}
                              </div>
                            )}
                          </div>
                        </td>

                        {/* 4. Total Amount Owed (الديون المترتبة) */}
                        <td className="p-3">
                          {isFullyCompliant ? (
                            <div>
                              <div className="text-sm font-black font-mono text-emerald-700">
                                0 {t.common.currencyShort}
                              </div>
                              <div className="text-[10px] text-emerald-600 font-semibold">
                                {isAr ? 'لا ديون مترتبة' : 'Aucune dette'}
                              </div>
                            </div>
                          ) : isRelativelyCompliant ? (
                            <div>
                              <div className="text-sm font-black font-mono text-amber-800">
                                {item.debt.totalBalanceDue.toLocaleString()} {t.common.currencyShort}
                              </div>
                              <div className="text-[10px] text-amber-700 font-semibold">
                                {isAr ? `مستحقات جارية (${item.debt.monthlyFee} د/ش)` : `Courant (${item.debt.monthlyFee} DH/m)`}
                              </div>
                            </div>
                          ) : (
                            <div>
                              <div className="text-sm font-black font-mono text-rose-700">
                                {item.debt.totalBalanceDue.toLocaleString()} {t.common.currencyShort}
                              </div>
                              <div className="text-[10px] text-rose-600 font-bold">
                                {isAr ? `ديون واجبة الاستخلاص (${item.debt.monthlyFee} د/ش)` : `Impayés 6m+ (${item.debt.monthlyFee} DH/m)`}
                              </div>
                            </div>
                          )}
                        </td>

                        {/* 5. Quick Actions */}
                        <td className="p-3 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            {!isFullyCompliant && (
                              <>
                                {/* WhatsApp Reminder */}
                                <a
                                  href={whatsappUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-white text-xs font-bold transition-all shadow-2xs cursor-pointer ${
                                    isOverdue 
                                      ? 'bg-rose-700 hover:bg-rose-800 active:bg-rose-900' 
                                      : 'bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800'
                                  }`}
                                  title={isAr 
                                    ? (isOverdue ? 'إرسال إشعار متأخرات 6+ أشهر عبر واتساب' : 'إرسال تذكير ودي عبر واتساب') 
                                    : (isOverdue ? 'Mise en demeure WhatsApp (6m+)' : 'Rappel WhatsApp')}
                                >
                                  <MessageSquare className="w-3.5 h-3.5" />
                                  <span>{isAr ? (isOverdue ? 'إشعار واتساب' : 'واتساب') : 'WhatsApp'}</span>
                                </a>

                                {/* Email Reminder */}
                                <a
                                  href={getEmailReminderUrl(item)}
                                  className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all shadow-2xs cursor-pointer ${
                                    item.email 
                                      ? (isOverdue ? 'bg-rose-900 hover:bg-rose-950 text-white' : 'bg-blue-600 hover:bg-blue-700 text-white') 
                                      : 'bg-slate-100 hover:bg-blue-50 text-blue-700 border border-blue-200'
                                  }`}
                                  title={isAr 
                                    ? (isOverdue ? 'إرسال إشعار رسمي عبر البريد الإلكتروني' : 'إرسال تذكير ودي عبر البريد الإلكتروني') 
                                    : (isOverdue ? 'Mise en demeure Email' : 'Rappel Email')}
                                >
                                  <Mail className="w-3.5 h-3.5" />
                                  <span className="hidden sm:inline">{isAr ? (isOverdue ? 'إشعار إيميل' : 'إيميل') : 'Email'}</span>
                                </a>
                              </>
                            )}

                            {/* Edit Debt / Owner */}
                            <button
                              type="button"
                              onClick={() => openDebtEditor(item.apt)}
                              className="p-1.5 rounded-xl bg-slate-100 hover:bg-rose-100 text-slate-700 hover:text-rose-900 transition-all cursor-pointer border border-slate-200"
                              title={isAr ? 'تعديل بيانات المالك والمديونية' : 'Modifier la dette'}
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>

                            {/* Collect Payment */}
                            <button
                              type="button"
                              onClick={() => {
                                onClose();
                                setActiveSection('payments');
                              }}
                              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold transition-all border border-emerald-200 cursor-pointer"
                              title={isAr ? 'استخلاص وتسجيل وصل أداء' : 'Encaisser'}
                            >
                              <CreditCard className="w-3.5 h-3.5 text-emerald-700" />
                              <span className="hidden sm:inline">{isAr ? 'استخلاص' : 'Encaisser'}</span>
                            </button>
                          </div>
                        </td>

                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

        </div>

          {/* Floating Selection Bar for Batch Actions in List View */}
          {selectedApartmentIds.length > 0 && (
            <div className="p-3 px-5 bg-gradient-to-r from-slate-900 via-rose-950 to-red-950 text-white flex items-center justify-between gap-3 text-xs border-t border-rose-500/40 shadow-xl shrink-0 animate-in slide-in-from-bottom-2">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-rose-600 text-white font-black font-mono">
                  {selectedApartmentIds.length} {isAr ? 'شقة محددة' : 'sélectionnés'}
                </span>
                <span className="text-rose-200 text-xs hidden sm:inline">
                  {isAr ? 'إجراءات جماعية فورية للملاك المحددين:' : 'Actions groupées :'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveModalTab('auto_alerts')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold transition-all shadow-xs cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isAr ? 'فتح مركز الإرسال الآلي' : 'Centre d\'envoi'}</span>
                </button>
                <button
                  type="button"
                  onClick={handleBatchEmail}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold transition-all shadow-xs cursor-pointer"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>{isAr ? 'إيميل جماعي (BCC)' : 'Email groupé'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedApartmentIds([])}
                  className="px-2 py-1 text-slate-300 hover:text-white text-xs underline cursor-pointer"
                >
                  {isAr ? 'إلغاء التحديد' : 'Désélectionner'}
                </button>
              </div>
            </div>
          )}
          </>
        )}

        {/* ========================================================================= */}
        {/* TAB 2: AUTOMATED ALERTS CENTER (+6 MONTHS & COMPLIANCE CLASSIFICATION)    */}
        {/* ========================================================================= */}
        {activeModalTab === 'auto_alerts' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 custom-scrollbar space-y-4 bg-slate-50/50">
            
            {/* Toast Notification Alert */}
            {toastMessage && (
              <div className="p-3 rounded-2xl bg-emerald-600 text-white font-bold text-xs flex items-center justify-between shadow-lg animate-in fade-in duration-200">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{toastMessage}</span>
                </div>
                <button onClick={() => setToastMessage(null)} className="p-1 hover:bg-white/20 rounded-lg cursor-pointer">
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* 1. COMPLIANCE CLASSIFICATION CARDS (THE 3 TIERS) */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              
              {/* Tier 1: 🔴 Overdue (>= 6 months) */}
              <div 
                onClick={() => {
                  setAlertTargetTier('overdue_6plus');
                  setSelectedApartmentIds(allApartmentsDebtList.filter(i => i.isOverdue).map(i => i.apt.id));
                }}
                className={`p-4 rounded-2xl border-2 transition-all cursor-pointer relative ${
                  alertTargetTier === 'overdue_6plus' 
                    ? 'bg-rose-50/80 border-rose-500 shadow-md ring-2 ring-rose-400/20' 
                    : 'bg-white border-slate-200 hover:border-rose-300'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-black tracking-wide">
                    🔴 {isAr ? 'المتأخرون عن الأداء' : 'Débiteurs Officiels'}
                  </span>
                  <span className="text-xs font-mono font-black text-rose-700">
                    ≥ 6 {isAr ? 'أشهر تأخر' : 'mois'}
                  </span>
                </div>
                <div className="flex items-baseline justify-between mt-1">
                  <div className="text-2xl font-black text-slate-900 font-mono">
                    {overdueCount} <span className="text-xs font-normal text-slate-500">{isAr ? 'شقة' : 'lots'}</span>
                  </div>
                  <div className="text-xs font-mono font-bold text-rose-700">
                    {overdueOnlyAmount.toLocaleString()} {t.common.currencyShort}
                  </div>
                </div>
                <p className="text-[11px] text-slate-600 font-medium mt-2 line-clamp-2">
                  {isAr 
                    ? 'تجاوزوا 6 أشهر من تأخر الأداء - توجيه إشعار قانوني رسمي ومطالبة بالأداء الفوري وفق القانون 18.00.' 
                    : 'Arriérés >= 6 mois - Mise en demeure officielle et recouvrement immédiat.'}
                </p>
                {alertTargetTier === 'overdue_6plus' && (
                  <div className="mt-2 text-[10px] font-black text-rose-700 flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>{isAr ? 'محدد ومستهدف تلقائياً للإرسال' : 'Cible active'}</span>
                  </div>
                )}
              </div>

              {/* Tier 2: 🟡 Relatively Compliant (1 to 5 months) */}
              <div 
                onClick={() => {
                  setAlertTargetTier('relatively_compliant');
                  setSelectedApartmentIds(allApartmentsDebtList.filter(i => i.isRelativelyCompliant).map(i => i.apt.id));
                }}
                className={`p-4 rounded-2xl border-2 transition-all cursor-pointer relative ${
                  alertTargetTier === 'relatively_compliant' 
                    ? 'bg-amber-50/80 border-amber-500 shadow-md ring-2 ring-amber-400/20' 
                    : 'bg-white border-slate-200 hover:border-amber-300'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-500 text-white text-[10px] font-black tracking-wide">
                    🟡 {isAr ? 'ملتزمون نسبياً' : 'Relativement Assidus'}
                  </span>
                  <span className="text-xs font-mono font-black text-amber-700">
                    1-5 {isAr ? 'أشهر' : 'mois'}
                  </span>
                </div>
                <div className="flex items-baseline justify-between mt-1">
                  <div className="text-2xl font-black text-slate-900 font-mono">
                    {relativelyCompliantCount} <span className="text-xs font-normal text-slate-500">{isAr ? 'شقة' : 'lots'}</span>
                  </div>
                  <div className="text-xs font-mono font-bold text-amber-700">
                    {allApartmentsDebtList.filter(i => i.isRelativelyCompliant).reduce((s, x) => s + x.debt.totalBalanceDue, 0).toLocaleString()} {t.common.currencyShort}
                  </div>
                </div>
                <p className="text-[11px] text-slate-600 font-medium mt-2 line-clamp-2">
                  {isAr 
                    ? 'دون الحد القانوني 6 أشهر - يعتبرون ملتزمين نسبياً. يمكن إرسال تذكير ودي اختياري عند الحاجة.' 
                    : 'Moins de 6 mois d\'impayés - Considérés relativement assidus. Rappel courtois.'}
                </p>
                {alertTargetTier === 'relatively_compliant' && (
                  <div className="mt-2 text-[10px] font-black text-amber-700 flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>{isAr ? 'محدد للتذكير الودي' : 'Cible rappel amical'}</span>
                  </div>
                )}
              </div>

              {/* Tier 3: 🟢 Fully Compliant (0 months) */}
              <div className="p-4 rounded-2xl border-2 border-slate-200 bg-emerald-50/30 text-slate-600">
                <div className="flex items-center justify-between mb-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-600 text-white text-[10px] font-black tracking-wide">
                    🟢 {isAr ? 'ملتزمون كلياً' : 'Totalement à jour'}
                  </span>
                  <span className="text-xs font-mono font-black text-emerald-700">
                    0 {isAr ? 'أشهر تأخر' : 'retard'}
                  </span>
                </div>
                <div className="flex items-baseline justify-between mt-1">
                  <div className="text-2xl font-black text-slate-900 font-mono">
                    {fullyCompliantCount} <span className="text-xs font-normal text-slate-500">{isAr ? 'شقة' : 'lots'}</span>
                  </div>
                  <div className="text-xs font-mono font-bold text-emerald-700">
                    0 {t.common.currencyShort}
                  </div>
                </div>
                <p className="text-[11px] text-slate-600 font-medium mt-2 line-clamp-2">
                  {isAr 
                    ? 'جميع اشتراكاتهم الشهرية مسواة بالكامل حتى اليوم - معفيون ومستثنون تلقائياً من أي تنبيهات.' 
                    : 'Toutes les cotisations sont à jour - Exclus systématiquement des relances.'}
                </p>
                <div className="mt-2 text-[10px] font-black text-emerald-700 flex items-center gap-1">
                  <CheckCheck className="w-3.5 h-3.5" />
                  <span>{isAr ? 'محمي ومعفى من التنبيهات' : 'Exclus des alertes'}</span>
                </div>
              </div>

            </div>

            {/* 2. DISPATCH CONTROLS & CHANNELS TOOLBAR */}
            <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-3">
              
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                {/* Target & Filter Selection */}
                <div className="flex items-center gap-2 flex-wrap text-xs">
                  <span className="font-bold text-slate-700 flex items-center gap-1">
                    <Filter className="w-3.5 h-3.5 text-rose-600" />
                    <span>{isAr ? 'الفئة المستهدفة:' : 'Cible :'}</span>
                  </span>

                  <button
                    type="button"
                    onClick={() => {
                      setAlertTargetTier('overdue_6plus');
                      setSelectedApartmentIds(allApartmentsDebtList.filter(i => i.isOverdue).map(i => i.apt.id));
                    }}
                    className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                      alertTargetTier === 'overdue_6plus'
                        ? 'bg-red-600 text-white shadow-xs'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                  >
                    🔴 {isAr ? `المتأخرون فقط (+6 أشهر) [${overdueCount}]` : `Débiteurs (+6m) [${overdueCount}]`}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setAlertTargetTier('relatively_compliant');
                      setSelectedApartmentIds(allApartmentsDebtList.filter(i => i.isRelativelyCompliant).map(i => i.apt.id));
                    }}
                    className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                      alertTargetTier === 'relatively_compliant'
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                  >
                    🟡 {isAr ? `الملتزمون نسبياً (1-5 أشهر) [${relativelyCompliantCount}]` : `Relat. assidus (1-5m) [${relativelyCompliantCount}]`}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setAlertTargetTier('all_unpaid');
                      setSelectedApartmentIds(allApartmentsDebtList.filter(i => !i.isFullyCompliant).map(i => i.apt.id));
                    }}
                    className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                      alertTargetTier === 'all_unpaid'
                        ? 'bg-slate-800 text-white shadow-xs'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                  >
                    👥 {isAr ? `الجميع [${overdueCount + relativelyCompliantCount}]` : `Tous les impayés`}
                  </button>
                </div>

                {/* Channel Filters */}
                <div className="flex items-center gap-1.5 text-xs flex-wrap">
                  <span className="font-bold text-slate-500 text-[11px]">{isAr ? 'القناة:' : 'Canal :'}</span>
                  
                  <button
                    type="button"
                    onClick={() => setAlertChannelFilter('all')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer ${
                      alertChannelFilter === 'all' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {isAr ? 'كافة القنوات' : 'Tous'}
                  </button>

                  <button
                    type="button"
                    onClick={() => setAlertChannelFilter('whatsapp')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer ${
                      alertChannelFilter === 'whatsapp' ? 'bg-emerald-600 text-white' : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                    }`}
                  >
                    <MessageSquare className="w-3 h-3" />
                    <span>{isAr ? 'واتساب فقط' : 'WhatsApp'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setAlertChannelFilter('email')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer ${
                      alertChannelFilter === 'email' ? 'bg-blue-600 text-white' : 'bg-blue-50 text-blue-800 hover:bg-blue-100'
                    }`}
                  >
                    <Mail className="w-3 h-3" />
                    <span>{isAr ? 'إيميل فقط' : 'Email'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setAlertChannelFilter('missing')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer ${
                      alertChannelFilter === 'missing' ? 'bg-rose-600 text-white' : 'bg-rose-50 text-rose-800 hover:bg-rose-100'
                    }`}
                  >
                    <AlertTriangle className="w-3 h-3" />
                    <span>{isAr ? 'ينقصه هاتف/بريد' : 'Sans contact'}</span>
                  </button>
                </div>
              </div>

              {/* Batch Operations Bar */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 text-xs">
                <div className="flex items-center gap-3">
                  <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-800">
                    <input
                      type="checkbox"
                      checked={selectedApartmentIds.length > 0 && selectedApartmentIds.length === alertEligibleApartments.length}
                      onChange={handleSelectAllInView}
                      className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500 cursor-pointer"
                    />
                    <span>{isAr ? 'تحديد كافة الملاك المعروضين' : 'Tout sélectionner'}</span>
                  </label>
                  <span className="px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 font-mono font-bold text-[11px]">
                    {isAr 
                      ? `تم تحديد ${selectedApartmentIds.length} من أصل ${alertEligibleApartments.length}`
                      : `${selectedApartmentIds.length} sur ${alertEligibleApartments.length} sélectionnés`}
                  </span>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  {/* Launch Sequential WhatsApp Sender */}
                  <button
                    type="button"
                    onClick={() => {
                      const debtorsWithPhone = alertEligibleApartments.filter(i => selectedApartmentIds.includes(i.apt.id) && !!i.phone && i.phone.replace(/\D/g, '').length >= 9);
                      if (debtorsWithPhone.length === 0) {
                        setToastMessage(isAr ? '⚠️ يرجى تحديد مالك واحد على الأقل يتوفر على رقم هاتف!' : '⚠️ Aucun contact avec numéro sélectionné !');
                        setTimeout(() => setToastMessage(null), 3000);
                        return;
                      }
                      setSequentialSendIndex(0);
                    }}
                    disabled={selectedApartmentIds.length === 0}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold transition-all shadow-xs cursor-pointer active:scale-95"
                    title={isAr ? 'إرسال متتابع عبر واتساب للمحددين' : 'Envoi séquentiel WhatsApp'}
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>{isAr ? 'بدء الإرسال المتتابع لواتساب' : 'Envoi Séquentiel WhatsApp'}</span>
                  </button>

                  {/* Batch Email */}
                  <button
                    type="button"
                    onClick={handleBatchEmail}
                    disabled={selectedApartmentIds.length === 0}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold transition-all shadow-xs cursor-pointer active:scale-95"
                    title={isAr ? 'إرسال إيميل رسمي جماعي للمحددين (BCC)' : 'Email groupé (BCC)'}
                  >
                    <Mail className="w-3.5 h-3.5" />
                    <span>{isAr ? 'إيميل جماعي (BCC)' : 'Email groupé'}</span>
                  </button>

                  {/* Template Preview Toggle */}
                  <button
                    type="button"
                    onClick={() => setShowTemplateEditor(!showTemplateEditor)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold transition-all cursor-pointer"
                  >
                    <FileText className="w-3.5 h-3.5 text-slate-600" />
                    <span>{isAr ? 'معاينة نص التنبيه' : 'Modèle de message'}</span>
                  </button>

                  {/* History Log Toggle */}
                  <button
                    type="button"
                    onClick={() => setShowHistoryDrawer(!showHistoryDrawer)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-bold transition-all cursor-pointer"
                  >
                    <History className="w-3.5 h-3.5 text-amber-700" />
                    <span>{isAr ? `سجل التنبيهات (${alertHistory.length})` : `Historique (${alertHistory.length})`}</span>
                  </button>
                </div>
              </div>

            </div>

            {/* 3. SEQUENTIAL WHATSAPP DISPATCH MODAL */}
            {sequentialSendIndex !== null && (() => {
              const debtorsWithPhone = alertEligibleApartments.filter(i => selectedApartmentIds.includes(i.apt.id) && !!i.phone && i.phone.replace(/\D/g, '').length >= 9);
              const currentItem = debtorsWithPhone[sequentialSendIndex];

              if (!currentItem) {
                return (
                  <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-center space-y-2">
                    <CheckCheck className="w-8 h-8 text-emerald-600 mx-auto" />
                    <div className="font-bold text-sm">{isAr ? 'اكتملت دورة الإرسال التلقائي عبر واتساب بنجاح!' : 'Envoi terminé avec succès !'}</div>
                    <button
                      type="button"
                      onClick={() => setSequentialSendIndex(null)}
                      className="px-4 py-1.5 rounded-xl bg-emerald-700 text-white font-bold text-xs cursor-pointer"
                    >
                      {isAr ? 'إغلاق' : 'Fermer'}
                    </button>
                  </div>
                );
              }

              return (
                <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-emerald-900 via-slate-900 to-rose-950 text-white shadow-xl border border-emerald-500/50 space-y-3 animate-in zoom-in-95">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Bot className="w-5 h-5 text-emerald-400 animate-pulse" />
                      <h3 className="font-black text-sm">
                        {isAr 
                          ? `إرسال متتابع لواتساب: المالك (${sequentialSendIndex + 1} من ${debtorsWithPhone.length})` 
                          : `Envoi WhatsApp séquentiel (${sequentialSendIndex + 1}/${debtorsWithPhone.length})`}
                      </h3>
                    </div>
                    <button
                      type="button"
                      onClick={() => setSequentialSendIndex(null)}
                      className="text-white/70 hover:text-white p-1 rounded-lg cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3 rounded-xl bg-white/10 backdrop-blur-xs text-xs">
                    <div>
                      <span className="text-white/70 block text-[10px]">{isAr ? 'الشقة والمالك:' : 'Appt & Copropriétaire:'}</span>
                      <strong className="font-bold text-sm text-amber-300">{currentItem.apt.buildingCode} - {isAr ? `شقة ${currentItem.apt.number}` : `Appt ${currentItem.apt.number}`}</strong>
                      <div className="font-medium text-white">{currentItem.ownerName}</div>
                    </div>

                    <div>
                      <span className="text-white/70 block text-[10px]">{isAr ? 'حالة التأخر والديون:' : 'Situation & Montant:'}</span>
                      <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${
                        currentItem.isOverdue ? 'bg-red-500/50 text-red-100' : 'bg-amber-500/50 text-amber-100'
                      }`}>
                        {currentItem.isOverdue ? `🔴 تأخر تجاوز 6 أشهر (${currentItem.debt.unpaidMonths} ش)` : `🟡 ملتزم نسبياً (${currentItem.debt.unpaidMonths} ش)`}
                      </span>
                      <div className="font-mono font-bold text-sm text-rose-200 mt-1">
                        {currentItem.debt.totalBalanceDue.toLocaleString()} DH
                      </div>
                    </div>

                    <div>
                      <span className="text-white/70 block text-[10px]">{isAr ? 'رقم الهاتف:' : 'Téléphone WhatsApp:'}</span>
                      <strong className="font-mono text-emerald-300 font-bold">{currentItem.phone}</strong>
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-2 border-t border-white/15">
                    <button
                      type="button"
                      onClick={() => setSequentialSendIndex(null)}
                      className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold cursor-pointer"
                    >
                      {isAr ? 'إنهاء دورة الإرسال' : 'Arrêter'}
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        if (sequentialSendIndex + 1 < debtorsWithPhone.length) {
                          setSequentialSendIndex(sequentialSendIndex + 1);
                        } else {
                          setSequentialSendIndex(null);
                        }
                      }}
                      className="px-3.5 py-2 rounded-xl bg-white/20 hover:bg-white/30 text-xs font-bold cursor-pointer"
                    >
                      {isAr ? 'تخطي للمالك التالي ⏭️' : 'Passer au suivant'}
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        handleLaunchWhatsApp(currentItem);
                        if (sequentialSendIndex + 1 < debtorsWithPhone.length) {
                          setSequentialSendIndex(sequentialSendIndex + 1);
                        } else {
                          setSequentialSendIndex(null);
                        }
                      }}
                      className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black text-xs shadow-md transition-all active:scale-95 cursor-pointer"
                    >
                      <Send className="w-4 h-4" />
                      <span>{isAr ? '📲 إرسال عبر واتساب والانتقال للتالي' : 'Envoyer & Suivant'}</span>
                    </button>
                  </div>
                </div>
              );
            })()}

            {/* 4. TEMPLATE PREVIEW ACCORDION */}
            {showTemplateEditor && (
              <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-md space-y-3 animate-in fade-in">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-rose-700" />
                    <h4 className="font-black text-xs text-slate-900">
                      {isAr ? 'معاينة وتخصيص نص التنبيه الموجه للمتأخرين (+6 أشهر)' : 'Modèle de notification pour les débiteurs (+6 mois)'}
                    </h4>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setAlertTemplateType('whatsapp')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold cursor-pointer ${
                        alertTemplateType === 'whatsapp' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      واتساب (WhatsApp)
                    </button>
                    <button
                      type="button"
                      onClick={() => setAlertTemplateType('email')}
                      className={`px-3 py-1 rounded-lg text-xs font-bold cursor-pointer ${
                        alertTemplateType === 'email' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      البريد الإلكتروني (Email)
                    </button>
                  </div>
                </div>

                {alertTemplateType === 'whatsapp' ? (
                  <div className="space-y-2">
                    <div className="p-3 rounded-xl bg-emerald-50/70 border border-emerald-200 text-slate-800 font-sans text-xs whitespace-pre-line leading-relaxed max-h-48 overflow-y-auto">
                      {alertEligibleApartments.length > 0 
                        ? (getWhatsappUrl(alertEligibleApartments[0]).split('?text=')[1] ? decodeURIComponent(getWhatsappUrl(alertEligibleApartments[0]).split('?text=')[1]) : '')
                        : 'نص التنبيه القانوني التلقائي...'}
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-slate-500">
                      <span>{isAr ? '📌 يتم إدراج اسم المالك، رقم الشقة، عدد الشهور، والمبلغ المستحق تلقائياً.' : 'Les variables sont remplacées automatiquement.'}</span>
                      <button
                        type="button"
                        onClick={() => {
                          if (alertEligibleApartments.length > 0) {
                            const sampleText = decodeURIComponent(getWhatsappUrl(alertEligibleApartments[0]).split('?text=')[1] || '');
                            handleCopyText(sampleText);
                          }
                        }}
                        className="flex items-center gap-1 font-bold text-emerald-700 hover:text-emerald-900 cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>{isAr ? 'نسخ نص المعاينة' : 'Copier'}</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-200 text-slate-800 font-sans text-xs whitespace-pre-line leading-relaxed max-h-48 overflow-y-auto">
                      {alertEligibleApartments.length > 0 
                        ? (getEmailReminderUrl(alertEligibleApartments[0]).split('&body=')[1] ? decodeURIComponent(getEmailReminderUrl(alertEligibleApartments[0]).split('&body=')[1]) : '')
                        : 'نص الإشعار الرسمي عبر البريد الإلكتروني...'}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* 5. SENT ALERTS HISTORY LOG */}
            {showHistoryDrawer && (
              <div className="p-4 rounded-2xl bg-white border border-amber-300 shadow-md space-y-3 animate-in fade-in">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                  <div className="flex items-center gap-2">
                    <History className="w-4 h-4 text-amber-700" />
                    <h4 className="font-black text-xs text-slate-900">
                      {isAr ? `سجل التنبيهات المرسلة (${alertHistory.length})` : `Historique des alertes (${alertHistory.length})`}
                    </h4>
                  </div>
                  {alertHistory.length > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        setAlertHistory([]);
                        localStorage.removeItem('ma_overdue_alerts_history_v1');
                      }}
                      className="text-xs text-rose-600 hover:text-rose-800 font-bold underline cursor-pointer"
                    >
                      {isAr ? 'مسح السجل' : 'Effacer l\'historique'}
                    </button>
                  )}
                </div>

                {alertHistory.length === 0 ? (
                  <div className="text-center py-6 text-xs text-slate-400">
                    {isAr ? 'لا توجد تنبيهات مسجلة حتى الآن.' : 'Aucune alerte enregistrée.'}
                  </div>
                ) : (
                  <div className="max-h-56 overflow-y-auto divide-y divide-slate-100 text-xs">
                    {alertHistory.map((hist) => (
                      <div key={hist.id} className="py-2 flex items-center justify-between gap-3">
                        <div>
                          <span className="font-black text-slate-900">{hist.aptCode}</span>
                          <span className="text-slate-600 ms-2 font-medium">({hist.ownerName})</span>
                          <div className="text-[10px] text-slate-400">
                            {hist.monthsCount} {isAr ? 'أشهر متأخرة' : 'mois'} • {hist.amount.toLocaleString()} DH
                          </div>
                        </div>
                        <div className="text-end">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            hist.channel === 'whatsapp' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
                          }`}>
                            {hist.channel === 'whatsapp' ? 'واتساب' : 'إيميل'}
                          </span>
                          <div className="text-[10px] text-slate-500 font-mono mt-0.5">{hist.sentAt}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* 6. DEBTORS CARDS GRID */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between text-xs text-slate-600 px-1">
                <span className="font-bold">
                  {isAr 
                    ? `الملاك المستحقون للتنبيه حسب المعايير المختارة (${alertEligibleApartments.length})` 
                    : `Copropriétaires éligibles (${alertEligibleApartments.length})`}
                </span>
                <span className="text-[11px] text-slate-500">
                  {isAr ? 'يمكنك إرسال تنبيه فردي مباشر أو استخدام الإرسال المتتابع' : 'Envoi direct ou groupé'}
                </span>
              </div>

              {alertEligibleApartments.length === 0 ? (
                <div className="text-center py-12 px-4 bg-white rounded-2xl border border-dashed border-slate-200">
                  <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
                  <div className="font-bold text-sm text-slate-800">
                    {isAr ? 'لا يوجد أي مالك يطابق شروط التنبيه المختارة' : 'Aucun copropriétaire pour cette sélection'}
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {alertEligibleApartments.map((item) => {
                    const isSelected = selectedApartmentIds.includes(item.apt.id);
                    const hasPhone = !!item.phone && item.phone.replace(/\D/g, '').length >= 9;
                    const hasEmail = !!item.email && item.email.includes('@');
                    const lastAlert = alertHistory.find(h => h.aptId === item.apt.id);

                    return (
                      <div
                        key={item.apt.id}
                        className={`p-3.5 rounded-2xl border transition-all ${
                          isSelected 
                            ? 'bg-white border-rose-500 shadow-sm ring-1 ring-rose-300/40' 
                            : 'bg-white border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          {/* Checkbox */}
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => handleToggleSelectApartment(item.apt.id)}
                            className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500 cursor-pointer mt-0.5 shrink-0"
                          />

                          <div className="flex-1 min-w-0 space-y-1.5">
                            {/* Header: Apt & Compliance Badge */}
                            <div className="flex items-center justify-between gap-2 flex-wrap">
                              <div className="font-black text-xs text-slate-900">
                                {item.apt.buildingCode} - {isAr ? `شقة ${item.apt.number}` : `Appt ${item.apt.number}`}
                              </div>
                              <span className={`px-2 py-0.5 rounded-md text-[10px] font-black font-mono ${
                                item.isOverdue 
                                  ? 'bg-rose-100 text-rose-900 border border-rose-300' 
                                  : 'bg-amber-100 text-amber-900 border border-amber-300'
                              }`}>
                                {item.isOverdue 
                                  ? (isAr ? `🔴 متأخر رسمي (${item.debt.unpaidMonths} أشهر)` : `🔴 Débiteur (+6m)`) 
                                  : (isAr ? `🟡 ملتزم نسبياً (${item.debt.unpaidMonths} أشهر)` : `🟡 Relat. assidu`)}
                              </span>
                            </div>

                            {/* Owner info & Total debt */}
                            <div className="flex items-center justify-between text-xs">
                              <div className="font-extrabold text-slate-800 truncate flex items-center gap-1">
                                <User className="w-3 h-3 text-slate-400 shrink-0" />
                                <span>{item.ownerName}</span>
                              </div>
                              <div className="font-mono font-black text-rose-700">
                                {item.debt.totalBalanceDue.toLocaleString()} {t.common.currencyShort}
                              </div>
                            </div>

                            {/* Contacts & Recent alert indicator */}
                            <div className="flex items-center gap-2 text-[11px] text-slate-500 flex-wrap">
                              {item.phone ? (
                                <span className="font-mono font-bold text-slate-700 flex items-center gap-1">
                                  <Phone className="w-3 h-3 text-slate-400" />
                                  <span>{item.phone}</span>
                                </span>
                              ) : (
                                <span className="text-rose-600 font-bold flex items-center gap-0.5">
                                  <AlertTriangle className="w-3 h-3" />
                                  <span>{isAr ? 'بدون هاتف' : 'Sans tél'}</span>
                                </span>
                              )}

                              {item.email && (
                                <span className="truncate max-w-[140px] text-slate-600 flex items-center gap-0.5">
                                  <Mail className="w-3 h-3 text-slate-400" />
                                  <span>{item.email}</span>
                                </span>
                              )}
                            </div>

                            {/* Alert History badge if previously sent */}
                            {lastAlert && (
                  <div className="text-[10px] text-emerald-700 font-bold flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                    <CheckCircle className="w-3 h-3 text-emerald-600 shrink-0" />
                    <span>{isAr ? `أُرسل تنبيه ${lastAlert.channel === 'whatsapp' ? 'واتساب' : 'إيميل'} (${lastAlert.sentAt})` : `Alerte envoyée (${lastAlert.sentAt})`}</span>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex items-center gap-1.5 pt-1.5 border-t border-slate-100 flex-wrap">
                  {/* WhatsApp Direct */}
                  <button
                    type="button"
                    onClick={() => handleLaunchWhatsApp(item)}
                    disabled={!hasPhone}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold transition-all shadow-2xs ${
                      hasPhone 
                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer' 
                        : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                    }`}
                    title={isAr ? 'إرسال تنبيه فوري عبر واتساب' : 'WhatsApp direct'}
                  >
                    <MessageSquare className="w-3 h-3" />
                    <span>{isAr ? 'واتساب' : 'WhatsApp'}</span>
                  </button>

                  {/* Email Direct */}
                  <button
                    type="button"
                    onClick={() => handleLaunchEmail(item)}
                    disabled={!hasEmail}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold transition-all shadow-2xs ${
                      hasEmail 
                        ? 'bg-blue-600 hover:bg-blue-700 text-white cursor-pointer' 
                        : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                    }`}
                    title={isAr ? 'إرسال تنبيه رسمي عبر البريد' : 'Email direct'}
                  >
                    <Mail className="w-3 h-3" />
                    <span>{isAr ? 'إيميل' : 'Email'}</span>
                  </button>

                  {/* Copy Text */}
                  <button
                    type="button"
                    onClick={() => {
                      const msg = decodeURIComponent(getWhatsappUrl(item).split('?text=')[1] || '');
                      handleCopyText(msg);
                    }}
                    className="p-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-all cursor-pointer"
                    title={isAr ? 'نسخ نص التنبيه المخصص لهذا المالك' : 'Copier'}
                  >
                    <Copy className="w-3 h-3" />
                  </button>

                  {/* Edit Debt / Contact */}
                  <button
                    type="button"
                    onClick={() => openDebtEditor(item.apt)}
                    className="p-1 rounded-lg bg-slate-100 hover:bg-rose-100 text-slate-700 hover:text-rose-900 transition-all cursor-pointer ms-auto"
                    title={isAr ? 'تعديل الهاتف أو المديونية' : 'Modifier'}
                  >
                    <Edit2 className="w-3 h-3" />
                  </button>
                </div>

                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

          </div>
        )}

        {/* ========================================================================= */}
        {/* MODAL FOOTER                                                              */}
        {/* ========================================================================= */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-slate-600 font-medium">
            {isAr 
              ? '💡 يمكنك فتح وصل استخلاص جديد مباشرة لأي شقة مديونة بنقرة واحدة على زر استخلاص.' 
              : '💡 Vous pouvez émettre une quittance de règlement immédiatement via le bouton Encaisser.'}
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold transition-all cursor-pointer"
            >
              {t.common.close}
            </button>
          </div>
        </div>

      </div>

      {/* Internal Quick Debt Editor Modal */}
      {isDebtEditModalOpen && debtEditApt && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-60 flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3.5 bg-slate-50 border-b border-slate-200 shrink-0">
              <div className="flex items-center gap-2 text-rose-900 font-bold text-sm">
                <Edit2 className="w-5 h-5 text-rose-700 shrink-0" />
                <span>
                  {isAr 
                    ? `تعديل مديونية: ${debtEditApt.buildingCode} - شقة ${debtEditApt.number}` 
                    : `Définir la dette : ${debtEditApt.buildingCode} - Appt ${debtEditApt.number}`}
                </span>
              </div>
              <button 
                type="button" 
                onClick={() => setIsDebtEditModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveDebtEdit} className="p-5 space-y-4 overflow-y-auto">
              {debtEditSuccessMsg && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{debtEditSuccessMsg}</span>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {isAr ? 'اسم مالك الشقة الحالي:' : 'Nom du propriétaire :'}
                </label>
                <input
                  type="text"
                  value={editOwnerName}
                  onChange={e => setEditOwnerName(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-rose-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isAr ? 'رقم الهاتف:' : 'Téléphone :'}
                  </label>
                  <input
                    type="text"
                    value={editOwnerPhone}
                    onChange={e => setEditOwnerPhone(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-rose-500 focus:outline-none font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {isAr ? 'رقم البطاقة (CIN):' : 'CIN :'}
                  </label>
                  <input
                    type="text"
                    value={editOwnerCin}
                    onChange={e => setEditOwnerCin(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-rose-500 focus:outline-none font-mono uppercase"
                  />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 space-y-2">
                <label className="block text-xs font-bold text-rose-950">
                  {isAr ? 'عدد الشهور غير المؤداة:' : 'Nombre de mois impayés :'}
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="1"
                    max="120"
                    value={editUnpaidMonths}
                    onChange={e => {
                      const val = Math.max(1, parseInt(e.target.value, 10) || 1);
                      setEditUnpaidMonths(val);
                      setEditBalanceDue(val * (editMonthlyFee || 150));
                    }}
                    className="w-24 px-3 py-2 text-xs rounded-lg border border-rose-300 font-mono font-bold"
                  />
                  <span className="text-xs font-bold text-rose-900">{isAr ? 'أشهر مديونية' : 'mois'}</span>
                  <span className="text-xs text-rose-700 font-bold font-mono ms-auto">
                    = {editBalanceDue.toLocaleString()} DH
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsDebtEditModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-100"
                >
                  {isAr ? 'إلغاء' : 'Annuler'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-black"
                >
                  {isAr ? 'حفظ التعديلات' : 'Enregistrer'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
