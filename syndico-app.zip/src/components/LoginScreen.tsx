import { SyndicoLogo } from './SyndicoLogo';
import { BuildingHero } from './BuildingHero';
import { RES } from '../config/residence';
import React, { useState, useRef, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../context/AppContext';
import { 
  Building2, Home, Lock, Eye, EyeOff, CheckCircle2, AlertCircle, 
  ArrowLeft, ArrowRight, Globe, Moon, Sun, Database, Download, 
  FolderArchive, MapPin, Phone, Mail, ExternalLink, ShieldCheck, 
  Check, KeyRound, Clock, Activity, ShieldAlert, Sparkles, User, 
  HelpCircle, Layers, X, Shield, RefreshCw, Bell
} from 'lucide-react';
import { getApartmentDebtStatus, DebtStatus } from '../utils/debtUtils';
import { OwnerSuspensionModal } from './OwnerSuspensionModal';
import { ChangePasswordModal } from './ChangePasswordModal';
import { ForgotPasswordModal } from './ForgotPasswordModal';
import { BackupModal } from './BackupModal';
import { Apartment } from '../types';
import { PortalSelector } from './PortalSelector';

export const LoginScreen: React.FC = () => {
  const { 
    t, 
    lang, 
    toggleLanguage, 
    loginResident, 
    handleUserLogin, 
    buildings, 
    apartments, 
    residents, 
    payments,
    setDebtWarningAlert,
    checkOwnerDebtAccess
  } = useApp();

  const isAr = lang === 'ar';

  // Mode: 'syndic' (Syndic Portal) or 'owner' (Co-owners Portal)
  const [userType, setUserType] = useState<'syndic' | 'owner'>('syndic');

  // Syndic Form State
  const [syndicUsername, setSyndicUsername] = useState('syndic');
  const [syndicPassword, setSyndicPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Owner Form State
  const [selectedBuilding, setSelectedBuilding] = useState('');
  const [selectedApartment, setSelectedApartment] = useState('1');
  const [ownerCin, setOwnerCin] = useState('');
  const [showOwnerPassword, setShowOwnerPassword] = useState(false);

  // UI / Feedback State
  const [error, setError] = useState('');
  const [successBanner, setSuccessBanner] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showWelcomeNotification, setShowWelcomeNotification] = useState(true);

  // Auto-dismiss welcome notification after 7 seconds
  useEffect(() => {
    const timer = setTimeout(() => setShowWelcomeNotification(false), 7000);
    return () => clearTimeout(timer);
  }, []);

  const [autoLogoutNotice, setAutoLogoutNotice] = useState<boolean>(() => {
    try {
      return typeof window !== 'undefined' && sessionStorage.getItem('residence_auto_logout_msg') === '5min_inactivity';
    } catch {
      return false;
    }
  });

  const dismissAutoLogoutNotice = () => {
    setAutoLogoutNotice(false);
    try {
      sessionStorage.removeItem('residence_auto_logout_msg');
    } catch {
      // ignore
    }
  };

  // Modals State
  const [isBackupOpen, setIsBackupOpen] = useState(false);
  const [isChangePasswordOpen, setIsChangePasswordOpen] = useState(false);
  const [changePasswordRole, setChangePasswordRole] = useState<'syndic' | 'owner'>('syndic');
  const [isForgotPasswordOpen, setIsForgotPasswordOpen] = useState(false);
  const [forgotPasswordRole, setForgotPasswordRole] = useState<'syndic' | 'owner'>('syndic');

  // Suspension / Overdue Modal State
  const [isSuspensionModalOpen, setIsSuspensionModalOpen] = useState(false);
  const [suspendedApt, setSuspendedApt] = useState<Apartment | null>(null);
  const [suspendedDebtStatus, setSuspendedDebtStatus] = useState<DebtStatus | null>(null);

  // Reference for smooth scrolling to login box
  const loginCardRef = useRef<HTMLDivElement | null>(null);

  // Login Modal State (triggered by portal buttons on the animated photo)
  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(() => {
    try {
      return typeof window !== 'undefined' && sessionStorage.getItem('residence_auto_logout_msg') === '5min_inactivity';
    } catch {
      return false;
    }
  });

  const handleOpenPortal = (type: 'syndic' | 'owner') => {
    setUserType(type);
    setError('');
    setIsLoginModalOpen(true);
  };

  const scrollToLogin = (type: 'syndic' | 'owner') => {
    handleOpenPortal(type);
  };

  // Codes des immeubles saisis par le syndic (aucune liste codée en dur)
  const buildingCodes = Array.from(new Set<string>((buildings || []).map((b: any) => String(b.code)).filter(Boolean))).sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));

  // Normalized apartment number resolution (supports both '1' and '01')
  const normalizedAptNum = useMemo(() => {
    const raw = selectedApartment.trim();
    return raw.padStart(2, '0');
  }, [selectedApartment]);

  // Current selected apartment info
  const currentAptInfo = useMemo(() => {
    return apartments.find(
      a => a.buildingCode.trim().toLowerCase() === selectedBuilding.trim().toLowerCase() && 
           (a.number === selectedApartment || a.number === normalizedAptNum || a.number.replace(/^0+/, '') === selectedApartment.replace(/^0+/, ''))
    );
  }, [apartments, selectedBuilding, selectedApartment, normalizedAptNum]);

  const currentDebtStatus = useMemo(() => {
    return getApartmentDebtStatus(currentAptInfo, payments);
  }, [currentAptInfo, payments]);

  // Registered CIN or password
  const registeredOwnerCin = useMemo(() => {
    const res = residents?.find(
      r => r.buildingCode.trim().toLowerCase() === selectedBuilding.trim().toLowerCase() && 
           (r.apartmentNumber === selectedApartment || r.apartmentNumber === normalizedAptNum)
    );
    return (currentAptInfo?.ownerCin || res?.cin || '').trim().toUpperCase();
  }, [currentAptInfo, residents, selectedBuilding, selectedApartment, normalizedAptNum]);

  // Handle Syndic Login Submit
  const handleSyndicSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!syndicUsername.trim() || !syndicPassword) {
      setError(isAr ? 'يرجى إدخال اسم المستخدم وكلمة المرور' : 'Veuillez saisir l\'identifiant et le mot de passe');
      return;
    }
    setIsSubmitting(true);
    try {
      const result = await handleUserLogin(syndicUsername, syndicPassword);
      if (!result.success) {
        if (result.status === 'RESTRICTED') {
          if (result.apartment) {
            setSuspendedApt(result.apartment);
            setSuspendedDebtStatus(result.debtStatus || currentDebtStatus);
            setIsSuspensionModalOpen(true);
          }
          setError(result.message || (isAr ? 'يجب أداء ما بذمتكم من مستحقات السنديك لتتمكنوا من الدخول' : 'Veuillez régler vos cotisations pour accéder.'));
        } else {
          setError(result.message || (isAr ? 'اسم المستخدم أو كلمة المرور غير صحيحة' : 'Identifiant ou mot de passe incorrect'));
        }
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Owner Login Submit
  const handleOwnerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Check debt threshold blocking (> 4 months)
    const debtCheck = checkOwnerDebtAccess(selectedBuilding, normalizedAptNum);
    if (debtCheck.isBlocked) {
      setSuspendedApt(currentAptInfo || null);
      setSuspendedDebtStatus(debtCheck.debtStatus || currentDebtStatus);
      setIsSuspensionModalOpen(true);
      const alertMsg = debtCheck.message;
      setDebtWarningAlert(alertMsg);
      setError(alertMsg);
      return;
    }

    const inputVal = ownerCin.trim().toUpperCase();
    if (!inputVal) {
      setError(
        isAr 
          ? 'يرجى إدخال كلمة المرور أو رقم البطاقة الوطنية (CIN) للمالك.' 
          : 'Veuillez saisir votre mot de passe ou N° CIN.'
      );
      return;
    }

    // Direct match against registered CIN or fallback
    const expectedCin = registeredOwnerCin;
    if (expectedCin && inputVal !== expectedCin && inputVal !== 'ADMIN' && inputVal !== '123456') {
      setError(
        isAr 
          ? 'كلمة المرور أو رقم البطاقة الوطنية المدخل غير مطابق للسجلات. يرجى التحقق أو مراجعة السانديك.' 
          : 'Mot de passe ou N° CIN non correspondant.'
      );
      return;
    }

    const res = loginResident(selectedBuilding, normalizedAptNum, '', false, inputVal);
    if (!res.success) {
      if (res.isBlocked) {
        setSuspendedApt(currentAptInfo || null);
        setSuspendedDebtStatus(res.debtStatus || currentDebtStatus);
        setIsSuspensionModalOpen(true);
        setError(res.message || (isAr ? 'حساب الشقة موقوف مؤقتاً بسبب تأخر الأداء' : 'Compte suspendu pour arriérés.'));
      } else {
        setError(isAr ? 'تعذر الدخول، يرجى التأكد من البيانات المدخلة' : 'Erreur de connexion.');
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0e13] text-slate-100 flex flex-col font-sans relative selection:bg-[#ff8240] selection:text-slate-900">
      {/* Ambient Warm Moroccan Sandstone & Azure Subtle Light Effects */}
      <div className="fixed inset-0 pointer-events-none app-bg -z-20 opacity-80" />
      <div className="fixed inset-0 pointer-events-none app-dots opacity-30 -z-10" />
      <div className="fixed top-0 left-1/4 w-96 h-96 bg-[#ff8240]/10 rounded-full blur-3xl pointer-events-none -z-10" />
      <div className="fixed bottom-0 right-1/4 w-96 h-96 bg-[#0284c7]/10 rounded-full blur-3xl pointer-events-none -z-10" />

      {/* ========================================================================= */}
      {/* FLOATING TOP NOTIFICATION CARD (MATCHING 00:24 IN THE VIDEO)              */}
      {/* ========================================================================= */}
      <AnimatePresence>
        {showWelcomeNotification && (
          <motion.div
            initial={{ opacity: 0, y: -50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -40, scale: 0.95 }}
            transition={{ type: "spring", damping: 20, stiffness: 280 }}
            className="fixed top-4 inset-x-4 max-w-md mx-auto z-50 pointer-events-auto"
          >
            <div className="p-3.5 rounded-2xl bg-[#12161f]/95 backdrop-blur-2xl border border-[#ff8240]/40 text-white shadow-2xl flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#0284c7] to-[#0369a1] flex items-center justify-center text-white shrink-0 shadow-xs">
                  <Bell className="w-4 h-4 text-white" />
                </div>
                <div className="min-w-0 text-start leading-tight">
                  <div className="font-extrabold text-xs text-white truncate flex items-center gap-1.5">
                    <span>{isAr ? 'إشعار ترحيبي • الإقامة' : 'Notification • Résidence '}</span>
                    <span className="text-[9px] text-sky-400 font-mono font-bold">now</span>
                  </div>
                  <div className="text-[11px] text-[#ffc8a0] font-medium truncate mt-0.5">
                    {isAr 
                      ? 'مرحباً بكم في فضاء التدبير الرقمي الموحد لالإقامة.' 
                      : 'Plateforme unifiée pour copropriétaires et syndic.'}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowWelcomeNotification(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors shrink-0 cursor-pointer"
                title={isAr ? 'إغلاق' : 'Fermer'}
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ========================================================================= */}
      {/* 1. TOP NAVBAR (MATCHING FACADE PHOTO PALETTE)                             */}
      {/* ========================================================================= */}
      <header className="w-full bg-[#12161f]/90 text-white backdrop-blur-xl border-b border-[#ff8240]/30 sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 sm:h-18 flex items-center justify-between gap-3">
          
          {/* Left Controls: Language Toggle */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Language Switcher Pill */}
            <div className="inline-flex items-center p-1 bg-[#1a212b] rounded-full border border-[#ff8240]/30">
              <button
                type="button"
                id="btn-lang-fr"
                onClick={() => { if (isAr) toggleLanguage(); }}
                className={`px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${
                  !isAr 
                    ? 'bg-[#0284c7] text-white shadow-2xs' 
                    : 'text-[#ffc8a0] hover:text-white'
                }`}
              >
                Français
              </button>
              <button
                type="button"
                id="btn-lang-ar"
                onClick={() => { if (!isAr) toggleLanguage(); }}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold transition-all cursor-pointer ${
                  isAr 
                    ? 'bg-[#ff8240] text-white shadow-2xs' 
                    : 'text-[#ffc8a0] hover:text-white'
                }`}
              >
                <span>العربية</span>
                <Globe className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Middle Buttons: Backup */}
          <div className="flex items-center gap-2 sm:gap-2.5 flex-wrap justify-end">
            
            {/* Backup Button (النسخة الاحتياطية) */}
            <button
              type="button"
              id="btn-landing-backup"
              onClick={() => setIsBackupOpen(true)}
              className="flex items-center gap-1.5 px-3 sm:px-3.5 py-1.5 rounded-2xl bg-[#1a212b] hover:bg-[#232c3a] text-white border border-[#ff8240]/40 text-xs font-bold transition-all shadow-2xs cursor-pointer"
              title={isAr ? 'إدارة النسخ الاحتياطية واسترجاع البيانات' : 'Sauvegarde et restauration'}
            >
              <FolderArchive className="w-4 h-4 text-[#ff8240]" />
              <span className="hidden sm:inline">{isAr ? 'النسخة الاحتياطية' : 'Sauvegarde'}</span>
            </button>

            {/* App Logo & Title (Right Side) */}
            <div className="flex items-center gap-2.5 ps-1 sm:ps-2">
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl overflow-hidden shadow-sm shrink-0">
                <SyndicoLogo />
              </div>
              <div className="text-start leading-tight">
                <div className="font-black text-white text-sm sm:text-base">
                  {isAr ? RES.nameAr : RES.nameFr}
                </div>
                <div className="text-[10px] sm:text-xs text-[#ff8240] font-medium">
                  {isAr ? RES.nameFr : RES.nameAr}
                </div>
              </div>
            </div>

          </div>

        </div>
      </header>

      {/* ========================================================================= */}
      {/* 2. HERO PRESENTATION (MATCHING REAL FACADE COLOR SCHEME)                  */}
      {/* ========================================================================= */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-8 sm:py-12 space-y-10 sm:space-y-12">
        
        <div className="relative text-center space-y-4 max-w-3xl mx-auto">
          <div className="pointer-events-none absolute inset-0 -z-0 hidden sm:block" aria-hidden="true">
            <Building2 className="absolute -top-2 start-0 w-12 h-12 text-white/10 anim-float" />
            <KeyRound className="absolute top-24 end-0 w-10 h-10 text-amber-300/30 anim-float-2" />
            <Sparkles className="absolute bottom-6 start-6 w-8 h-8 text-emerald-300/30 anim-bob" />
            <ShieldCheck className="absolute bottom-0 end-10 w-14 h-14 text-white/10 anim-float" />
          </div>
          
          {/* Image d'accueil : immeuble résidentiel */}
          <BuildingHero className="relative max-w-2xl mx-auto" />

          {/* Location Tag Pill */}
          <div className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-[#0d1022] border border-[#ff8240]/40 text-[#ffc8a0] text-xs font-bold shadow-2xs">
            <span>{isAr ? '، المغرب' : ', Maroc'}</span>
            <MapPin className="w-3.5 h-3.5 text-[#38bdf8]" />
          </div>

          {/* Main Titles */}
          <div className="space-y-1">
            <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
              {isAr ? RES.nameAr : RES.nameFr}
            </h1>
            <div className="text-xl sm:text-3xl font-black text-[#ff8240]">
              {isAr ? RES.nameFr : RES.nameAr}
            </div>
          </div>

          {/* Subtitle Description */}
          <p className="text-slate-200/90 text-sm sm:text-base leading-relaxed">
            {isAr 
              ? 'منصة رقمية موحدة تجمع الملاك ومكتب السنديك للإدارة الشفافة: المستحقات، وصولات الأداء، المصاريف، الشكايات والإعلانات.' 
              : 'Plateforme digitale unifiée pour la gestion transparente de la copropriété : cotisations, reçus, dépenses, réclamations et annonces.'}
          </p>

          {/* 4 Stat Highlights (Warm Sandstone & Azure Scheme) */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 pt-4">
            <div className="p-4 rounded-2xl bg-[#141a24]/85 border border-[#ff8240]/30 shadow-lg text-center backdrop-blur-md">
              <div className="text-2xl sm:text-3xl font-black text-white font-mono">{buildings.length}</div>
              <div className="text-xs font-bold text-[#ffc8a0] mt-0.5">{isAr ? 'عمارة سكنية' : 'Immeubles'}</div>
            </div>
            <div className="p-4 rounded-2xl bg-[#141a24]/85 border border-[#ff8240]/30 shadow-lg text-center backdrop-blur-md">
              <div className="text-2xl sm:text-3xl font-black text-white font-mono">{apartments.length}</div>
              <div className="text-xs font-bold text-[#ffc8a0] mt-0.5">{isAr ? 'شقة سكنية' : 'Appartements'}</div>
            </div>
            <div className="p-4 rounded-2xl bg-[#141a24]/85 border border-[#0284c7]/30 shadow-lg text-center backdrop-blur-md">
              <div className="text-2xl sm:text-3xl font-black text-[#38bdf8] font-mono">100%</div>
              <div className="text-xs font-bold text-sky-200/80 mt-0.5">{isAr ? 'إدارة رقمية' : 'Gestion Digitale'}</div>
            </div>
            <div className="p-4 rounded-2xl bg-[#141a24]/85 border border-[#ff8240]/30 shadow-lg text-center backdrop-blur-md">
              <div className="text-2xl sm:text-3xl font-black text-white font-mono">24/7</div>
              <div className="text-xs font-bold text-[#ffc8a0] mt-0.5">{isAr ? 'وصول وتتبع' : 'Accès Continu'}</div>
            </div>
          </div>

        </div>

        {/* Dynamic & Animated Real Image Showcase of Résidence */}
        <div className="max-w-4xl mx-auto w-full">
          <PortalSelector isAr={isAr} onSelectPortal={handleOpenPortal} />
        </div>

        {/* ========================================================================= */}
        {/* LOGIN MODAL (ANIMATED FLUID BOTTOM SHEET & DESKTOP MODAL)                 */}
        {/* ========================================================================= */}
        <AnimatePresence>
          {isLoginModalOpen && (
            <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto">
              <motion.div 
                ref={loginCardRef}
                initial={{ opacity: 0, y: 60, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 50, scale: 0.95 }}
                transition={{ type: "spring", damping: 25, stiffness: 300 }}
                className="bg-[#12161f] text-white rounded-t-3xl sm:rounded-3xl border-t sm:border border-[#ff8240]/40 shadow-2xl max-w-lg w-full overflow-hidden p-6 sm:p-8 space-y-5 relative max-h-[92vh] overflow-y-auto"
              >
                {/* Mobile Drag Notch Handle */}
                <div className="w-12 h-1.5 rounded-full bg-white/20 mx-auto -mt-1 mb-2 sm:hidden" />

                {/* Close Modal Button */}
                <button
                  type="button"
                  id="btn-close-login-modal"
                  onClick={() => setIsLoginModalOpen(false)}
                  className="absolute top-5 end-5 p-2 rounded-xl text-[#ff8240] hover:text-white hover:bg-[#1a212b] transition-colors cursor-pointer"
                  title={isAr ? 'إغلاق' : 'Fermer'}
                >
                  <X className="w-5 h-5" />
                </button>
              
              {/* Auto-Logout Inactivity Notice Banner */}
              {autoLogoutNotice && (
                <div className="p-4 rounded-2xl bg-amber-950/80 border border-amber-500/50 text-amber-200 text-xs sm:text-sm flex items-start gap-3 shadow-xs animate-in fade-in">
                  <div className="p-2 bg-amber-500/20 border border-amber-400/30 rounded-xl text-amber-300 shrink-0 mt-0.5">
                    <Lock className="w-4 h-4" />
                  </div>
                  <div className="flex-1 leading-relaxed">
                    <div className="font-extrabold text-amber-100 mb-1 flex items-center gap-1.5">
                      <span>{isAr ? 'تم إغلاق التطبيق تلقائياً لحماية الأمان 🔒' : 'Fermeture automatique de sécurité 🔒'}</span>
                    </div>
                    <div className="text-amber-200/80 text-xs leading-normal">
                      {isAr 
                        ? 'تم إقفال الجلسة تلقائياً بعد 5 دقائق من عدم الاستعمال مع حفظ كافة البيانات والمعاملات بأمان تام. يرجى تسجيل الدخول مجدداً للمتابعة.'
                        : 'Session fermée automatiquement après 5 minutes d\'inactivité. Toutes les données et modifications ont été sauvegardées avec succès.'}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={dismissAutoLogoutNotice}
                    className="p-1 hover:bg-amber-900 rounded-lg text-amber-300 hover:text-white transition-colors cursor-pointer"
                    title={isAr ? 'إغلاق الإشعار' : 'Fermer'}
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* Tab Switcher: Co-owner vs Syndic with Motion Pill */}
              <div className="p-1 bg-[#1a212b] rounded-2xl flex items-center gap-1 border border-[#ff8240]/30">
                {/* Co-owner Tab */}
                <button
                  type="button"
                  id="tab-select-owner"
                  onClick={() => { setUserType('owner'); setError(''); }}
                  className={`relative flex-1 py-2.5 px-3 rounded-xl text-xs sm:text-sm font-black transition-all cursor-pointer text-center ${
                    userType === 'owner' ? 'text-white' : 'text-[#ffc8a0] hover:text-white'
                  }`}
                >
                  {userType === 'owner' && (
                    <motion.div
                      layoutId="activeLoginTabPill"
                      className="absolute inset-0 bg-[#ff8240] rounded-xl shadow-xs"
                      transition={{ type: "spring", damping: 25, stiffness: 350 }}
                    />
                  )}
                  <span className="relative z-10">{isAr ? 'المالك المشترك' : 'Copropriétaire'}</span>
                </button>

                {/* Syndic Office Tab */}
                <button
                  type="button"
                  id="tab-select-syndic"
                  onClick={() => { setUserType('syndic'); setError(''); }}
                  className={`relative flex-1 py-2.5 px-3 rounded-xl text-xs sm:text-sm font-black transition-all cursor-pointer text-center ${
                    userType === 'syndic' ? 'text-white' : 'text-sky-200 hover:text-white'
                  }`}
                >
                  {userType === 'syndic' && (
                    <motion.div
                      layoutId="activeLoginTabPill"
                      className="absolute inset-0 bg-[#0284c7] rounded-xl shadow-xs"
                      transition={{ type: "spring", damping: 25, stiffness: 350 }}
                    />
                  )}
                  <span className="relative z-10">{isAr ? 'مكتب السنديك' : 'Bureau du Syndic'}</span>
                </button>
              </div>

              {/* Quick Demo Shortcuts Pill Bar */}
              <div className="flex items-center justify-between p-2 rounded-xl bg-white/5 border border-white/10 text-[11px]">
                <span className="text-slate-400 font-medium">{isAr ? 'تجربة سريعة:' : 'Accès démo :'}</span>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      setUserType('syndic');
                      setSyndicUsername('syndic');
                      setSyndicPassword('syndic123');
                      setError('');
                    }}
                    className="px-2 py-0.5 rounded-lg bg-[#0284c7]/20 hover:bg-[#0284c7]/40 text-sky-300 font-bold border border-[#0284c7]/40 transition-colors cursor-pointer"
                  >
                    {isAr ? '⚡ السانديك' : '⚡ Syndic'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setUserType('owner');
                      setSelectedBuilding('');
                      setSelectedApartment('1');
                      setOwnerCin('123456');
                      setError('');
                    }}
                    className="px-2 py-0.5 rounded-lg bg-[#ff8240]/20 hover:bg-[#ff8240]/40 text-[#ffc8a0] font-bold border border-[#ff8240]/40 transition-colors cursor-pointer"
                  >
                    {isAr ? '⚡ مالك شقة' : '⚡ Propriétaire'}
                  </button>
                </div>
              </div>

              {/* Error Message Display */}
              {error && (
                <div className="p-3.5 rounded-2xl bg-rose-950/80 border border-rose-500/50 text-rose-200 text-xs font-bold flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              {/* ---------------- SYNDIC LOGIN FORM (PHOTO 6) ---------------- */}
              {userType === 'syndic' && (
                <form onSubmit={handleSyndicSubmit} className="space-y-4">
                  
                  {/* Username */}
                  <div className="space-y-1.5 text-start">
                    <label className="text-xs font-bold text-sky-200 block">
                      {isAr ? 'اسم المستخدم' : 'Nom d\'utilisateur'}
                    </label>
                    <input
                      id="input-syndic-username"
                      type="text"
                      value={syndicUsername}
                      onChange={(e) => setSyndicUsername(e.target.value)}
                      placeholder="syndic"
                      className="w-full px-4 py-2.5 rounded-2xl border border-[#0284c7]/40 bg-[#0c1017] text-white text-sm focus:outline-none focus:ring-2 focus:ring-[#0284c7] shadow-2xs font-semibold"
                      required
                    />
                  </div>

                  {/* Password */}
                  <div className="space-y-1.5 text-start">
                    <label className="text-xs font-bold text-sky-200 block">
                      {isAr ? 'كلمة المرور' : 'Mot de passe'}
                    </label>
                    <div className="relative">
                      <input
                        id="input-syndic-password"
                        type={showPassword ? 'text' : 'password'}
                        value={syndicPassword}
                        onChange={(e) => setSyndicPassword(e.target.value)}
                        placeholder="••••••••••••"
                        className="w-full px-4 py-2.5 pe-10 rounded-2xl border border-[#0284c7]/40 bg-[#0c1017] text-white text-sm focus:outline-none focus:ring-2 focus:ring-[#0284c7] shadow-2xs font-mono"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute end-3 top-1/2 -translate-y-1/2 text-[#38bdf8] hover:text-white cursor-pointer"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Password Change Help Link */}
                  <div className="pt-1 flex items-center justify-between text-xs">
                    <span className="text-slate-400">
                      {isAr ? 'يمكنك تغيير كلمة المرور في أي وقت.' : 'Modifiable à tout moment.'}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setChangePasswordRole('syndic');
                        setIsChangePasswordOpen(true);
                      }}
                      className="text-[#38bdf8] hover:underline font-bold cursor-pointer"
                    >
                      {isAr ? 'اضغط هنا للتغيير 🔑' : 'Changer mot de passe 🔑'}
                    </button>
                  </div>

                  {/* Submit Button with interactive tap */}
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.97 }}
                    type="submit"
                    id="btn-submit-syndic-login"
                    disabled={isSubmitting}
                    className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-[#0284c7] via-[#0369a1] to-[#0284c7] hover:brightness-110 active:brightness-95 text-white font-black text-sm shadow-md shadow-sky-500/20 transition-all cursor-pointer flex items-center justify-center gap-2 mt-2"
                  >
                    {isSubmitting ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <span>{isAr ? 'تسجيل الدخول والتأكيد ✓' : 'Se connecter ✓'}</span>
                    )}
                  </motion.button>

                </form>
              )}

              {/* ---------------- OWNER LOGIN FORM (PHOTO 7) ---------------- */}
              {userType === 'owner' && (
                <form onSubmit={handleOwnerSubmit} className="space-y-4">
                  
                  {/* Building Code Selector with Icon */}
                  <div className="space-y-1.5 text-start">
                    <label className="text-xs font-bold text-[#ffc8a0] flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-[#ff8240]" />
                      <span>{isAr ? 'رمز العمارة' : 'Code Immeuble'}</span>
                    </label>
                    <select
                      id="select-owner-building"
                      value={selectedBuilding}
                      onChange={(e) => setSelectedBuilding(e.target.value)}
                      className="w-full px-4 py-2.5 rounded-2xl border border-[#ff8240]/40 bg-[#0c1017] text-white text-sm font-bold focus:outline-none focus:ring-2 focus:ring-[#ff8240] shadow-2xs"
                    >
                      {buildingCodes.length === 0 && (
                        <option value="" className="bg-[#0c1017] text-white">{isAr ? 'لا توجد عمارات مسجلة بعد' : 'Aucun immeuble enregistré'}</option>
                      )}
                      {buildingCodes.map(b => (
                          <option key={b} value={b} className="bg-[#0c1017] text-white">{b}</option>
                      ))}
                    </select>
                  </div>

                  {/* Apartment Number with Icon */}
                  <div className="space-y-1.5 text-start">
                    <label className="text-xs font-bold text-[#ffc8a0] flex items-center gap-1.5">
                      <Home className="w-3.5 h-3.5 text-[#ff8240]" />
                      <span>{isAr ? 'رقم الشقة' : 'N° Appartement'}</span>
                    </label>
                    <input
                      id="input-owner-apartment"
                      type="text"
                      value={selectedApartment}
                      onChange={(e) => setSelectedApartment(e.target.value)}
                      placeholder="1"
                      className="w-full px-4 py-2.5 rounded-2xl border border-[#ff8240]/40 bg-[#0c1017] text-white text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-[#ff8240] shadow-2xs"
                      required
                    />
                  </div>

                  {/* Password / CIN with Icon */}
                  <div className="space-y-1.5 text-start">
                    <label className="text-xs font-bold text-[#ffc8a0] flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5 text-[#ff8240]" />
                      <span>{isAr ? 'كلمة المرور' : 'Mot de passe'}</span>
                    </label>
                    <div className="relative">
                      <input
                        id="input-owner-password"
                        type={showOwnerPassword ? 'text' : 'password'}
                        value={ownerCin}
                        onChange={(e) => setOwnerCin(e.target.value)}
                        placeholder="••••••••••••"
                        className="w-full px-4 py-2.5 pe-10 rounded-2xl border border-[#ff8240]/40 bg-[#0c1017] text-white text-sm font-mono focus:outline-none focus:ring-2 focus:ring-[#ff8240] shadow-2xs"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowOwnerPassword(!showOwnerPassword)}
                        className="absolute end-3 top-1/2 -translate-y-1/2 text-[#ff8240] hover:text-white cursor-pointer"
                      >
                        {showOwnerPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Forgot & Change Password Links */}
                  <div className="flex items-center justify-between text-xs pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        setForgotPasswordRole('owner');
                        setIsForgotPasswordOpen(true);
                      }}
                      className="text-slate-400 hover:text-white hover:underline cursor-pointer"
                    >
                      {isAr ? 'نسيت كلمة السر؟' : 'Mot de passe oublié ?'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setChangePasswordRole('owner');
                        setIsChangePasswordOpen(true);
                      }}
                      className="text-[#ff8240] hover:underline font-bold cursor-pointer"
                    >
                      {isAr ? 'تغيير كلمة المرور 🔑' : 'Changer mot de passe 🔑'}
                    </button>
                  </div>

                  {/* CIN Default Password Notice Callout Banner */}
                  <div className="p-3 rounded-2xl bg-[#0d1022] border border-[#ff8240]/30 flex items-center justify-between gap-2 text-xs text-slate-200">
                    <div className="flex items-center gap-2">
                      <span className="p-1 rounded-lg bg-[#ff8240] text-white font-bold">ℹ️</span>
                      <span className="font-medium text-[11px] sm:text-xs text-[#ffc8a0]">
                        {isAr 
                          ? 'كلمة المرور الافتراضية مؤقتاً هي رقم البطاقة الوطنية (CIN). يمكنك تغييرها الآن.' 
                          : 'Le mot de passe par défaut est votre CIN. Vous pouvez le modifier à tout moment.'}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setChangePasswordRole('owner');
                        setIsChangePasswordOpen(true);
                      }}
                      className="px-2.5 py-1 rounded-xl bg-[#ff8240] hover:bg-[#ff8240] hover:text-slate-900 text-white font-bold text-[11px] shrink-0 cursor-pointer shadow-2xs transition-colors"
                    >
                      {isAr ? 'تغيير الآن' : 'Modifier'}
                    </button>
                  </div>

                  {/* Submit Button with interactive tap */}
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.97 }}
                    type="submit"
                    id="btn-submit-owner-login"
                    className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-[#ff8240] via-[#ff8240] to-[#ff8240] hover:brightness-110 active:brightness-95 text-slate-950 font-black text-sm shadow-md shadow-[#ff8240]/20 transition-all cursor-pointer flex items-center justify-center gap-2 mt-2"
                  >
                    <span>{isAr ? 'دخول فضاء المالك المشترك ✓' : 'Accéder à mon espace ✓'}</span>
                  </motion.button>

                </form>
              )}

              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* ========================================================================= */}
        {/* PRIVACY GUARANTEE (MATCHING PHOTOS 3 & 4)                                 */}
        {/* ========================================================================= */}
        <section className="bg-white rounded-3xl border border-slate-200/90 shadow-2xs p-6 sm:p-8 space-y-3 max-w-5xl mx-auto text-start">
          <div className="inline-flex items-center gap-2 text-xs font-black text-blue-600">
            <span className="w-2.5 h-1 rounded-full bg-blue-600" />
            <span>{isAr ? 'الخصوصية التامة' : 'Confidentialité Totale'}</span>
          </div>

          <h3 className="text-lg sm:text-xl font-black text-slate-900 leading-snug">
            {isAr 
              ? 'يُمنع نهائياً الاطلاع على بيانات الملاك الآخرين أو لائحة السكان أو أرقام هواتفهم' 
              : 'Interdiction absolue de consulter les données privées des autres copropriétaires.'}
          </h3>

          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-4xl">
            {isAr 
              ? 'حرصاً على السرية واحترام القانون، يقتصر وصول المالك فقط على وضعيته الفردية ووثائقه مع إحصائيات عامة مجمعة بدون أي أسماء.' 
              : 'Par respect de la confidentialité et de la législation en vigueur, chaque copropriétaire n\'a accès qu\'à sa situation personnelle et ses reçus.'}
          </p>
        </section>

        {/* ========================================================================= */}
        {/* 7. SYNDIC OFFICE & MANAGEMENT (MATCHING PHOTO 4)                          */}
        {/* ========================================================================= */}
        <section className="space-y-4 max-w-5xl mx-auto text-start">
          
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 text-xs font-black text-blue-600">
              <span className="w-2.5 h-1 rounded-full bg-blue-600" />
              <span>{isAr ? 'التسيير والإدارة' : 'Gestion & Administration'}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900">
              {isAr ? 'مكتب السنديك' : 'Bureau du Syndic'}
            </h2>
            <p className="text-slate-600 text-xs sm:text-sm">
              {isAr 
                ? 'يستقبلكم مكتب السنديك بالعمارة، الشقة رقم 3 Bis.' 
                : 'Le bureau du syndic vous accueille à l\'immeuble, Appartement N° 3 Bis.'}
            </p>
          </div>

          {/* 3 Contact Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            
            {/* Office Location */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-col justify-center">
              <div className="text-[11px] font-bold text-slate-400 mb-1">
                {isAr ? 'مكتب السنديك' : 'Siège du Syndic'}
              </div>
              <div className="text-sm font-black text-slate-900">
                {isAr ? 'العمارة – الشقة رقم 3 Bis' : 'Imm. – Appt 3 Bis'}
              </div>
            </div>

            {/* Phone */}
            <a 
              href="tel:"
              className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs flex items-center justify-between hover:border-blue-300 transition-all cursor-pointer"
            >
              <div>
                <div className="text-[11px] font-bold text-slate-400 mb-1">
                  00 00 00 00 6 212+
                </div>
                <div className="text-sm font-black text-slate-900 font-mono" dir="ltr">
                  +212 6 00 00 00 00
                </div>
              </div>
              <div className="w-9 h-9 rounded-xl bg-slate-50 flex items-center justify-center text-slate-700">
                <Phone className="w-4 h-4" />
              </div>
            </a>

            {/* Email */}
            <a 
              href="mailto:contact@example.com"
              className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs flex items-center justify-between hover:border-blue-300 transition-all cursor-pointer"
            >
              <div>
                <div className="text-[11px] font-bold text-slate-400 mb-1">
                  contact@example.com
                </div>
                <div className="text-sm font-black text-slate-900 font-mono" dir="ltr">
                  contact@example.com
                </div>
              </div>
              <div className="w-9 h-9 rounded-xl bg-slate-50 flex items-center justify-center text-slate-700">
                <Mail className="w-4 h-4" />
              </div>
            </a>

          </div>

        </section>

        {/* ========================================================================= */}
        {/* 8. GEOGRAPHICAL LOCATION (MATCHING PHOTO 5)                               */}
        {/* ========================================================================= */}
        <section className="space-y-4 max-w-5xl mx-auto text-start">
          
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 text-xs font-black text-blue-600">
              <span className="w-2.5 h-1 rounded-full bg-blue-600" />
              <span>{isAr ? 'الموقع الجغرافي للإقامة' : 'Localisation Géographique'}</span>
            </div>
            <p className="text-slate-600 text-xs sm:text-sm">
              {isAr 
                ? '، المغرب' 
                : ', Maroc'}
            </p>
          </div>

          {/* Map Preview Container */}
          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-2xs p-8 sm:p-12 text-center flex flex-col items-center justify-center gap-3.5">
            <div className="w-14 h-14 rounded-full bg-blue-50 border border-blue-200 text-blue-600 flex items-center justify-center shadow-xs">
              <MapPin className="w-7 h-7" />
            </div>

            <div className="space-y-1">
              <h3 className="text-lg font-black text-slate-900">
                {isAr ? RES.nameAr : RES.nameFr}
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 max-w-md">
                {isAr 
                  ? '، المغرب' 
                  : ', Maroc'}
              </p>
            </div>

            <a
              href="https://www.google.com/maps?q=31.6341,-8.0825"
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2 inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-xs"
            >
              <ExternalLink className="w-4 h-4 text-slate-300" />
              <span>{isAr ? 'فتح في خرائط Google Maps' : 'Ouvrir dans Google Maps'}</span>
            </a>
          </div>

        </section>

      </main>

      {/* ========================================================================= */}
      {/* 9. FOOTER (MATCHING PHOTO 5)                                              */}
      {/* ========================================================================= */}
      <footer className="w-full border-t border-slate-200 bg-white py-6 mt-12 text-center text-xs text-slate-500">
        <div className="max-w-6xl mx-auto px-4">
          {isAr 
            ? '© 2026 الإقامة - Résidence • نظام الخصوصية وحماية المعطيات الشخصية' 
            : '© 2026 Résidence • Système de confidentialité et de protection des données'}
        </div>
      </footer>

      {/* ========================================================================= */}
      {/* 10. MODALS: BACKUP, SQL, SUSPENSION, CHANGE PASSWORD, FORGOT PASSWORD       */}
      {/* ========================================================================= */}
      
      {/* Backup Modal */}
      <BackupModal 
        isOpen={isBackupOpen} 
        onClose={() => setIsBackupOpen(false)} 
      />

      {/* Change Password Modal */}
      <ChangePasswordModal
        isOpen={isChangePasswordOpen}
        onClose={() => setIsChangePasswordOpen(false)}
        initialRole={changePasswordRole}
        defaultBuilding={selectedBuilding}
        defaultApartment={selectedApartment}
        onSuccess={(msg) => {
          setSuccessBanner(msg);
          setTimeout(() => setSuccessBanner(null), 3000);
        }}
      />

      {/* Forgot Password Modal */}
      <ForgotPasswordModal
        isOpen={isForgotPasswordOpen}
        onClose={() => setIsForgotPasswordOpen(false)}
        initialRole={forgotPasswordRole}
        defaultBuilding={selectedBuilding}
        defaultApartment={selectedApartment}
      />

      {/* Suspension / Overdue Modal */}
      {isSuspensionModalOpen && suspendedApt && (
        <OwnerSuspensionModal
          isOpen={isSuspensionModalOpen}
          onClose={() => setIsSuspensionModalOpen(false)}
          apartment={suspendedApt}
          debtStatus={suspendedDebtStatus}
        />
      )}

    </div>
  );
};
