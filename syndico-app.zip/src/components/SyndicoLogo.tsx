import React from 'react';

// Logo Syndico : un immeuble stylisé + badge de validation orange.
export const SyndicoLogo: React.FC<{ className?: string; title?: string }> = ({ className = 'w-full h-full', title = 'Syndico' }) => (
  <svg viewBox="0 0 64 64" className={className} role="img" aria-label={title} xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="syndico-logo-bg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor="#0a8591" />
        <stop offset="1" stopColor="#1fbfb8" />
      </linearGradient>
    </defs>
    <rect width="64" height="64" rx="16" fill="url(#syndico-logo-bg)" />
    {/* Immeuble */}
    <rect x="16" y="13" width="28" height="39" rx="3.5" fill="#ffffff" />
    <rect x="13" y="50" width="34" height="4" rx="2" fill="#ffffff" opacity="0.85" />
    {/* Fenêtres */}
    {[0, 1, 2, 3].map(r =>
      [0, 1, 2].map(c => (
        <rect key={`${r}-${c}`} x={20 + c * 8} y={17 + r * 8} width="4.6" height="5" rx="1.2" fill="#0a8591" opacity={r === 1 && c === 1 ? 1 : 0.55} />
      ))
    )}
    {/* Porte */}
    <rect x="26" y="41" width="8" height="11" rx="1.6" fill="#ff8240" />
    {/* Badge validé */}
    <circle cx="47" cy="17" r="9" fill="#ff8240" stroke="#ffffff" strokeWidth="2.5" />
    <path d="M42.8 17.2l3 3 5.2-5.8" fill="none" stroke="#ffffff" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);
