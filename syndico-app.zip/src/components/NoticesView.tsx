import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Notice, NoticePriority } from '../types';
import { Bell, Plus, Search, Printer, MessageSquare, Trash2, Check, X, Megaphone, Users, Lock, Send } from 'lucide-react';
import { PaymentDueAlertModal } from './PaymentDueAlertModal';
import { Megaphone as HeaderIcon } from 'lucide-react';

export const NoticesView: React.FC = () => {
  const { t, lang, currentUser, notices, buildings, addNotice, deleteNotice, setSelectedNotice } = useApp();

  const isOwner = currentUser?.role === 'resident';

  const [searchTerm, setSearchTerm] = useState('');
  const [filterPriority, setFilterPriority] = useState('ALL');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDueAlertModalOpen, setIsDueAlertModalOpen] = useState(false);
  const [noticeToDelete, setNoticeToDelete] = useState<Notice | null>(null);

  // Form
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [targetAudience, setTargetAudience] = useState('all');
  const [buildingCode, setBuildingCode] = useState('ALL');
  const [priority, setPriority] = useState<NoticePriority>('normal');
  const [author, setAuthor] = useState('مكتب السانديك (السيد الرئيس)');

  const handleOpenNew = () => {
    if (isOwner) return;
    setTitle('');
    setContent('');
    setTargetAudience('all');
    setBuildingCode('ALL');
    setPriority('normal');
    setAuthor('مكتب السانديك (السيد الرئيس)');
    setIsFormOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isOwner) return;
    if (!title.trim() || !content.trim()) return;

    const newNotice = addNotice({
      title,
      content,
      targetBuilding: targetAudience === 'specific_building' ? buildingCode : 'ALL',
      publishDate: new Date().toISOString().slice(0, 10),
      targetAudience: targetAudience as any,
      buildingCode: targetAudience === 'specific_building' ? buildingCode : undefined,
      priority,
      author,
    });

    setIsFormOpen(false);
    setSelectedNotice(newNotice);
  };

  const filteredNotices = notices.filter(n => {
    const matchesSearch = 
      n.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.author.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesPriority = filterPriority === 'ALL' || n.priority === filterPriority;
    return matchesSearch && matchesPriority;
  });

  const getTargetLabel = (notice: Notice) => {
    if (notice.targetAudience === 'owners') return t.notices.targetOwners;
    if (notice.targetAudience === 'tenants') return t.notices.targetTenants;
    if (notice.targetAudience === 'specific_building') return `عمارة ${notice.buildingCode || ''}`;
    return t.notices.targetAll;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border-2 border-[#92e8dd] shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="icon-wiggle anim-bob w-10 h-10 rounded-2xl bg-gradient-to-br from-fuchsia-400 to-fuchsia-600 text-white flex items-center justify-center shadow-md shrink-0"><HeaderIcon className="w-5 h-5" /></span>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">{t.notices.title}</h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">{t.notices.subtitle}</p>
        </div>

        {!isOwner ? (
          <div className="flex items-center gap-2 flex-wrap">
            <button
              id="btn-open-payment-due-alerts-notices"
              type="button"
              onClick={() => setIsDueAlertModalOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-[#0a8591] to-[#0f172a] hover:from-[#0b6a78] hover:to-[#0f172a] text-white text-xs font-black transition-all shadow-xs cursor-pointer border border-[#0d5262]"
              title={lang === 'ar' ? 'إرسال تنبيهات اقتراب موعد سداد السانديك' : 'Alertes d\'échéance'}
            >
              <Bell className="w-4 h-4 text-rose-200" />
              <span>{lang === 'ar' ? 'تنبيهات اقتراب موعد السداد ⏰' : 'Alertes Échéance'}</span>
            </button>

            <button
              onClick={handleOpenNew}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#0a8591] hover:bg-[#0b6a78] text-white text-xs font-bold transition-all shadow-xs self-start sm:self-auto cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{t.notices.addBtn}</span>
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-slate-600 text-xs font-semibold">
            <Lock className="w-3.5 h-3.5 text-slate-400" />
            <span>{lang === 'ar' ? 'لوحة الإعلانات الرسمية (اطلاع فقط)' : 'Tableau d\'affichage officiel'}</span>
          </div>
        )}
      </div>

      {/* Form Modal / Box (Syndic only) */}
      {!isOwner && isFormOpen && (
        <div className="bg-white p-6 rounded-2xl border-2 border-[#0a8591] shadow-lg animate-in fade-in zoom-in-98 duration-200">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
            <h2 className="text-base font-bold text-[#0a8591] flex items-center gap-2">
              <Megaphone className="w-5 h-5 text-[#0a8591]" />
              <span>{t.notices.addBtn}</span>
            </h2>
            <button 
              onClick={() => setIsFormOpen(false)}
              className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.notices.noticeTitle} *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="إشعار بانعقاد الجمع العام العادي، أعمال صيانة..."
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.notices.priority} *</label>
                <select
                  value={priority}
                  onChange={e => setPriority(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none bg-white"
                >
                  <option value="normal">{t.notices.prioNormal}</option>
                  <option value="high">{t.notices.prioHigh}</option>
                  <option value="urgent">{t.notices.prioUrgent}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.notices.targetAudience} *</label>
                <select
                  value={targetAudience}
                  onChange={e => setTargetAudience(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none bg-white"
                >
                  <option value="all">{t.notices.targetAll}</option>
                  <option value="owners">{t.notices.targetOwners}</option>
                  <option value="tenants">{t.notices.targetTenants}</option>
                  <option value="specific_building">عمارة محددة</option>
                </select>
              </div>

              {targetAudience === 'specific_building' && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">اختر العمارة *</label>
                  <select
                    value={buildingCode}
                    onChange={e => setBuildingCode(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none bg-white"
                  >
                    {buildings.map(b => (
                      <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.notices.author}</label>
                <input
                  type="text"
                  value={author}
                  onChange={e => setAuthor(e.target.value)}
                  placeholder="مكتب السانديك"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{t.notices.content} *</label>
              <textarea
                required
                rows={4}
                value={content}
                onChange={e => setContent(e.target.value)}
                placeholder="نص الإشعار أو الإعلان الرسمي الموجه للمقيمين..."
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-[#0a8591] focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-2 pt-3 justify-end border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsFormOpen(false)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-bold transition-all cursor-pointer"
              >
                {t.common.cancel}
              </button>
              <button
                type="submit"
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#0a8591] hover:bg-[#0b6a78] text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>نشر وتوليد الملصق الرسمي</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Notices Grid Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredNotices.map((notice) => (
          <div 
            key={notice.id}
            className="bg-white rounded-2xl border border-slate-200 shadow-xs hover:border-[#0a8591] transition-all p-5 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <div className={`p-2 rounded-xl border ${
                    notice.priority === 'urgent' ? 'bg-red-50 border-red-200 text-red-700' :
                    notice.priority === 'high' ? 'bg-amber-50 border-amber-200 text-amber-700' : 'bg-[#e9fbf8] border-[#92e8dd] text-[#0a8591]'
                  }`}>
                    <Megaphone className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-slate-900">{notice.title}</h3>
                    <div className="text-[11px] text-slate-500 font-medium flex items-center gap-2 mt-0.5">
                      <span className="flex items-center gap-1">
                        <Users className="w-3 h-3 text-slate-400" />
                        <span>{getTargetLabel(notice)}</span>
                      </span>
                      <span>•</span>
                      <span>{notice.publishDate}</span>
                    </div>
                  </div>
                </div>

                {!isOwner && (
                  <button
                    onClick={() => setNoticeToDelete(notice)}
                    className="p-1 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-600 cursor-pointer"
                    title={lang === 'ar' ? 'حذف الإعلان' : 'Supprimer'}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 text-xs text-slate-700 leading-relaxed my-2 whitespace-pre-line">
                {notice.content}
              </div>

              <div className="text-[11px] text-slate-400 font-medium">
                بواسطة: {notice.author}
              </div>
            </div>

            {/* Actions */}
            <div className="pt-3 mt-3 border-t border-slate-100 flex items-center justify-between gap-2">
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                notice.priority === 'urgent' ? 'bg-red-100 text-red-800' :
                notice.priority === 'high' ? 'bg-amber-100 text-amber-800' : 'bg-[#e9fbf8] text-[#0a8591] border border-[#92e8dd]'
              }`}>
                {notice.priority === 'urgent' ? t.notices.prioUrgent :
                 notice.priority === 'high' ? t.notices.prioHigh : t.notices.prioNormal}
              </span>

              <div className="flex items-center gap-1.5">
                <a
                  href={`https://wa.me/?text=${encodeURIComponent(`*إعلان رسمي من سانديك الإقامة: ${notice.title}*\n\n${notice.content}\n\n_مكتب السانديك_`)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="p-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 transition-colors cursor-pointer"
                  title="مشاركة عبر واتساب"
                >
                  <MessageSquare className="w-4 h-4" />
                </a>

                <button
                  onClick={() => setSelectedNotice(notice)}
                  className="px-3 py-1 rounded-lg bg-[#0a8591] hover:bg-[#0b6a78] text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>{t.notices.printNotice}</span>
                </button>
              </div>
            </div>

          </div>
        ))}
      </div>

      {/* Payment Due Date Alerts Modal */}
      <PaymentDueAlertModal
        isOpen={isDueAlertModalOpen}
        onClose={() => setIsDueAlertModalOpen(false)}
      />

      {/* In-App Delete Confirmation Modal */}
      {noticeToDelete && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mb-4 mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            
            <h3 className="text-base font-bold text-slate-900 text-center mb-2">
              {lang === 'ar' ? 'تأكيد حذف الإعلان' : 'Confirmation de suppression'}
            </h3>
            
            <p className="text-xs text-slate-600 text-center mb-6 leading-relaxed">
              {lang === 'ar' 
                ? `هل أنت متأكد من حذف الإعلان "${noticeToDelete.title}"؟`
                : `Êtes-vous sûr de vouloir supprimer l'annonce "${noticeToDelete.title}" ?`}
            </p>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setNoticeToDelete(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-bold transition-all cursor-pointer"
              >
                {lang === 'ar' ? 'تراجع' : t.common.cancel}
              </button>
              <button
                type="button"
                onClick={() => {
                  deleteNotice(noticeToDelete.id);
                  setNoticeToDelete(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold shadow-md transition-all cursor-pointer"
              >
                {lang === 'ar' ? 'تأكيد الحذف' : 'Supprimer'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
