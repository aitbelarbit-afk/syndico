import React, { useState } from 'react';
import { X, Building2, Save, KeyRound, Landmark } from 'lucide-react';
import {
  APP_BRAND, loadResidenceProfile, saveResidenceProfile, ResidenceProfile,
  getRecoveryKey, setRecoveryKey
} from '../config/residence';
import { useApp } from '../context/AppContext';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  firstRun?: boolean;
}

export const ResidenceProfileModal: React.FC<Props> = ({ isOpen, onClose, firstRun }) => {
  const { lang, currentUser, updateUser } = useApp();
  const isAr = lang === 'ar';
  const [p, setP] = useState<ResidenceProfile>(() => {
    const cur = loadResidenceProfile();
    // Champs par défaut génériques : on les vide pour que le syndic saisisse les siens
    if (cur.nameAr === 'إقامتي') cur.nameAr = '';
    if (cur.nameFr === 'Ma Résidence') cur.nameFr = '';
    if (cur.fullNameAr === 'إقامتي') cur.fullNameAr = '';
    if (cur.fullNameFr === 'Ma Résidence') cur.fullNameFr = '';
    return cur;
  });
  const [recovery, setRecovery] = useState<string>(getRecoveryKey());

  if (!isOpen) return null;

  const set = (k: keyof ResidenceProfile, v: string) => setP(prev => ({ ...prev, [k]: v }));

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(p.email.trim())) return;
    saveResidenceProfile(p);
    if (currentUser && !(currentUser.email || '').trim()) updateUser(currentUser.id, { email: p.email.trim().toLowerCase() });
    if (recovery.trim().length >= 6) setRecoveryKey(recovery);
    // Rechargement : les en-têtes, reçus et rapports utilisent le nouveau nom
    window.location.reload();
  };

  const field = (label: string, key: keyof ResidenceProfile, placeholder = '', dir: 'rtl' | 'ltr' = 'ltr') => (
    <label className="block">
      <span className="block text-xs font-bold text-slate-700 mb-1">{label}</span>
      <input
        required={key === 'email'}
        type={key === 'email' ? 'email' : 'text'}
        value={p[key]} dir={dir} placeholder={placeholder}
        onChange={e => set(key, e.target.value)}
        className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
      />
    </label>
  );

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-3 bg-slate-950/60 backdrop-blur-sm no-print">
      <form onSubmit={handleSave} className="w-full max-w-2xl max-h-[92vh] overflow-y-auto rounded-3xl bg-white shadow-2xl border border-slate-200">
        <div className="relative overflow-hidden p-5 rounded-t-3xl bg-gradient-to-br from-emerald-800 to-emerald-950 text-white">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <span className="icon-wiggle w-11 h-11 rounded-2xl gradient-flow flex items-center justify-center shadow-md shrink-0">
                <Building2 className="w-6 h-6" />
              </span>
              <div>
                <h2 className="text-lg font-black">
                  {firstRun
                    ? (isAr ? `مرحباً بكم في ${APP_BRAND.nameAr}` : `Bienvenue sur ${APP_BRAND.nameFr}`)
                    : (isAr ? 'ملف الإقامة' : 'Profil de la résidence')}
                </h2>
                <p className="text-xs text-emerald-100 font-medium mt-0.5">
                  {isAr ? 'هذه المعلومات تظهر في الوصولات والتقارير والمراسلات.' : 'Ces informations apparaissent sur les reçus, rapports et messages.'}
                </p>
              </div>
            </div>
            {!firstRun && (
              <button type="button" onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/15 cursor-pointer" aria-label="close">
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        <div className="p-5 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {field(isAr ? 'اسم الإقامة (بالعربية)' : 'Nom de la résidence (arabe)', 'nameAr', 'إقامة ...', 'rtl')}
            {field(isAr ? 'اسم الإقامة (بالفرنسية)' : 'Nom de la résidence (français)', 'nameFr', 'Résidence ...')}
            {field(isAr ? 'المدينة (بالعربية)' : 'Ville (arabe)', 'cityAr', '', 'rtl')}
            {field(isAr ? 'المدينة (بالفرنسية)' : 'Ville (français)', 'cityFr')}
            {field(isAr ? 'العنوان (بالعربية)' : 'Adresse (arabe)', 'addressAr', '', 'rtl')}
            {field(isAr ? 'العنوان (بالفرنسية)' : 'Adresse (français)', 'addressFr')}
            {field(isAr ? 'هاتف المكتب' : 'Téléphone du bureau', 'phone')}
            {field(isAr ? 'البريد الإلكتروني (إجباري) *' : 'E-mail (obligatoire) *', 'email', 'syndic@exemple.com')}
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center gap-2 text-sm font-black text-slate-900"><Landmark className="w-4 h-4 text-emerald-700" />{isAr ? 'معلومات الأداء البنكي (تظهر في التذكيرات)' : 'Coordonnées bancaires (rappels de paiement)'}</div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {field(isAr ? 'اسم البنك' : 'Banque', 'bankName')}
              {field('RIB', 'bankRib')}
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 space-y-2">
            <div className="flex items-center gap-2 text-sm font-black text-amber-900"><KeyRound className="w-4 h-4" />{isAr ? 'مفتاح استرجاع حساب السنديك' : 'Clé de récupération du compte syndic'}</div>
            <input
              type="password" value={recovery} onChange={e => setRecovery(e.target.value)} placeholder="••••••••"
              className="w-full px-3 py-2.5 rounded-xl border border-amber-300 bg-white text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500"
            />
            <p className="text-[11px] font-semibold text-amber-900/80">
              {isAr ? '6 خانات على الأقل. احتفظ به في مكان آمن: يسمح بإعادة تعيين كلمة المرور إذا نسيتها.' : '6 caractères minimum. Conservez-la : elle permet de réinitialiser le mot de passe si vous l\'oubliez.'}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-1">
            <button type="submit"
              className="flex-1 flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-gradient-to-l from-emerald-700 to-emerald-500 text-white font-black text-sm shadow-md cursor-pointer hover:shadow-lg">
              <Save className="w-4 h-4" /> {isAr ? 'حفظ' : 'Enregistrer'}
            </button>
            {firstRun && (
              <button type="button" onClick={() => { saveResidenceProfile(loadResidenceProfile()); onClose(); }}
                className="px-5 py-3.5 rounded-xl bg-slate-100 text-slate-700 font-bold text-sm cursor-pointer hover:bg-slate-200">
                {isAr ? 'لاحقاً' : 'Plus tard'}
              </button>
            )}
          </div>
        </div>
      </form>
    </div>
  );
};
