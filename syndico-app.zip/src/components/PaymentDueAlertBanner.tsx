import React from 'react';

interface PaymentDueAlertBannerProps {
  onOpenModal?: () => void;
}

export const PaymentDueAlertBanner: React.FC<PaymentDueAlertBannerProps> = () => {
  return null;
};
