import { RES } from '../config/residence';
import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Apartment } from '../types';
import { getApartmentDebtStatus, formatPeriodDisplay } from '../utils/debtUtils';
import { OverduePayersModal } from './OverduePayersModal';
import { MonthlyFinancialReportModal } from './MonthlyFinancialReportModal';
import { PaidReceiptsPdfModal } from './PaidReceiptsPdfModal';
import { OwnersDuesExcelModal } from './OwnersDuesExcelModal';
import { ResidentsExcelImportModal } from './ResidentsExcelImportModal';
import { 
  Building2, Home, CreditCard, Receipt, 
  Scale, Wallet, TrendingUp, TrendingDown, 
  AlertTriangle, CheckCircle2, Users, 
  Send, Phone, Search, FileText, ArrowUpRight, 
  Sparkles, Calendar, ChevronRight, ShieldCheck,
  MessageSquare, FileSpreadsheet, Download, Plus,
  Wrench, Activity
} from 'lucide-react';
import { 
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, 
  Legend, Line, CartesianGrid, ComposedChart 
} from 'recharts';
import { 
  computeMonthlyFinanceSummary, 
  ARABIC_MONTH_NAMES, 
  FRENCH_MONTH_NAMES 
} from '../utils/monthlyFinanceUtils';

export const DashboardView: React.FC = () => {
  const { 
    lang, currentUser, setActiveSection, apartments, 
    payments, expenses, totalIncome, totalExpenses, 
    totalBalance, openTicketsCount, manualMonthlyRecords
  } = useApp();

  const isAr = lang === 'ar';
  const isOwner = currentUser?.role === 'resident';

  // Modal States
  const [isOverdueModalOpen, setIsOverdueModalOpen] = useState(false);
  const [isFinancialReportModalOpen, setIsFinancialReportModalOpen] = useState(false);
  const [financialReportMode, setFinancialReportMode] = useState<'monthly' | 'annual' | 'custom_period'>('monthly');
  const [isPaidReceiptsModalOpen, setIsPaidReceiptsModalOpen] = useState(false);
  const [isOwnersDuesExcelOpen, setIsOwnersDuesExcelOpen] = useState(false);
  const [isResidentsExcelImportOpen, setIsResidentsExcelImportOpen] = useState(false);

  // Timeframe for Recharts
  const [evolutionYear, setEvolutionYear] = useState<'2026' | '2025' | 'all'>('2026');

  // Handle opening payment modal directly
  const handleOpenPaymentRegistration = () => {
    sessionStorage.setItem('open_payment_modal_on_load', 'true');
    setActiveSection('payments');
    window.dispatchEvent(new Event('open-payment-modal'));
  };

  // Handle opening expense modal directly
  const handleOpenExpenseRegistration = () => {
    sessionStorage.setItem('open_expense_modal_on_load', 'true');
    setActiveSection('expenses');
    window.dispatchEvent(new Event('open-expense-modal'));
  };

  // Expected revenue calculation
  const totalMonthlyExpected = useMemo(() => {
    return apartments.reduce((sum, a) => sum + (Number(a.monthlyFee) || 150), 0);
  }, [apartments]);

  // Global Collection Rate
  const collectionRate = useMemo(() => {
    if (totalMonthlyExpected === 0) return 0;
    const activeIncome = payments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
    // Estimated against annual expected (12 months)
    const annualExpected = totalMonthlyExpected * 12;
    if (annualExpected === 0) return 0;
    return Math.min(100, Math.round((activeIncome / annualExpected) * 100));
  }, [payments, totalMonthlyExpected]);

  // Delinquent Residents (6+ Months Late Rule)
  const overdueResidents = useMemo(() => {
    const list: Array<{
      apartment: Apartment;
      unpaidMonthsCount: number;
      totalDue: number;
      isCritical: boolean;
      statusLabel: string;
      residentName: string;
      phone: string;
    }> = [];

    apartments.forEach(apt => {
      if (apt.isSyndicOffice) return;
      const status = getApartmentDebtStatus(apt, payments);
      const monthsLate = status.unpaidMonths || 0;
      
      // Starting from 6 months, resident is overdue and subject to alerts
      if (monthsLate >= 6) {
        list.push({
          apartment: apt,
          unpaidMonthsCount: monthsLate,
          totalDue: status.totalBalanceDue || (monthsLate * (apt.monthlyFee || 150)),
          isCritical: monthsLate >= 12,
          statusLabel: monthsLate >= 12 ? (isAr ? 'متأخر حرج (سنة+)' : 'Retard Critique') : (isAr ? 'تأخر يتجاوز 6 أشهر' : 'Retard +6 mois'),
          residentName: apt.residentName || (isAr ? 'مالك الشقة' : 'Copropriétaire'),
          phone: apt.residentPhone || ''
        });
      }
    });

    return list.sort((a, b) => b.unpaidMonthsCount - a.unpaidMonthsCount);
  }, [apartments, payments, isAr]);

  // Recharts Monthly Evolution Data (2025 and 2026)
  const chartData = useMemo(() => {
    const months = evolutionYear === 'all' 
      ? [
          '2025-01', '2025-03', '2025-06', '2025-09', '2025-12',
          '2026-01', '2026-03', '2026-06', '2026-09', '2026-12'
        ]
      : Array.from({ length: 12 }, (_, i) => `${evolutionYear}-${String(i + 1).padStart(2, '0')}`);

    return months.map(mKey => {
      const summary = computeMonthlyFinanceSummary(payments, expenses, apartments, mKey, 'ALL', manualMonthlyRecords);
      const [y, m] = mKey.split('-');
      const label = isAr ? `${ARABIC_MONTH_NAMES[m]?.split(' ')[0] || m} ${y}` : `${FRENCH_MONTH_NAMES[m]?.slice(0, 3) || m} ${y}`;

      return {
        key: mKey,
        label,
        income: Math.round(summary.totalIncome),
        expenses: Math.round(summary.totalExpenses),
        netBalance: Math.round(summary.netBalance),
        collectionRate: summary.collectionRate
      };
    });
  }, [evolutionYear, payments, expenses, apartments, manualMonthlyRecords, isAr]);

  // Recent 5 payments
  const recentPayments = useMemo(() => {
    return [...payments]
      .sort((a, b) => new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime())
      .slice(0, 5);
  }, [payments]);

  // Recent 5 expenses
  const recentExpenses = useMemo(() => {
    return [...expenses]
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 5);
  }, [expenses]);

  // WhatsApp Alert Generator for 6+ Months Delinquents
  const sendWhatsAppReminder = (residentName: string, phone: string, bld: string, aptNum: string, months: number, due: number) => {
    if (!phone) return;
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    const intlPhone = cleanPhone.startsWith('0') ? '212' + cleanPhone.slice(1) : cleanPhone;
    
    const message = isAr
      ? `السلام عليكم ورحمة الله، السادة ${residentName} (عمارة ${bld}، شقة ${aptNum}).\nنحيطكم علماً من مكتب سانديك ${RES.nameAr} أن لديكم متأخرات واجبات السانديك بلغت (${months} أشهُر) بمبلغ إجمالي قدره: ${due.toLocaleString()} درهم.\nيرجى التفضل بتسوية الوضعية أو التواصل معنا لترتيب الأداء وشكراً لتفهمكم.`
      : `Bonjour M/Mme ${residentName} (Imm ${bld}, Appt ${aptNum}). Le bureau du syndic ${RES.nameFr} vous informe d'un retard de cotisation de (${months} mois) soit un total de ${due.toLocaleString()} DH. Merci de régulariser votre situation.`;
    
    window.open(`https://wa.me/${intlPhone}?text=${encodeURIComponent(message)}`, '_blank');
  };

  return (
    <div className="space-y-6 sm:space-y-8">
      
      {/* ========================================================================= */}
      {/* 1. GRAND EXECUTIVE WELCOME BANNER (Moroccan Luxury Theme)                 */}
      {/* ========================================================================= */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-950 via-emerald-900 to-slate-950 text-white p-6 sm:p-8 shadow-xl border border-emerald-800/50">
        {/* Subtle Moroccan Radial Glow */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/20 rounded-full blur-3xl pointer-events-none aurora-blob aurora-a" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-emerald-400/20 rounded-full blur-3xl pointer-events-none aurora-blob aurora-b" />
        <Building2 className="absolute top-5 end-6 w-24 h-24 text-white/5 anim-float pointer-events-none hidden sm:block" />
        <Sparkles className="absolute bottom-6 start-1/2 w-8 h-8 text-amber-300/40 anim-float-2 pointer-events-none" />
        <Wallet className="absolute top-1/2 start-8 w-14 h-14 text-white/5 anim-spin-slow pointer-events-none hidden md:block" />

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2 flex-wrap text-xs text-amber-300 font-bold">
              <span>المملكة المغربية</span>
              <span>·</span>
              <span></span>
              <span>·</span>
              <span className="bg-amber-400/20 text-amber-300 px-2.5 py-0.5 rounded-full border border-amber-400/30 font-black">
                
              </span>
            </div>
            
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight text-white leading-tight">
              {isAr ? 'الإقامة  ' : 'Résidence - '}
            </h1>
            
            <p className="text-xs sm:text-sm text-emerald-200/90 leading-relaxed font-medium">
              {isAr 
                ? 'المنصة الرسمية الموحدة لتدبير الملكية المشتركة: جميع العمارات ( و B) · جميع الشقق · متابعة السيولة والتحصيل والتقارير المالية المعتمدة.'
                : 'Plateforme officielle unifiée de gestion de copropriété : tous les immeubles, tous les lots, suivi de trésorerie et bilans d\'assemblée.'}
            </p>
          </div>

          {/* Quick Balance & Status Card */}
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/20 min-w-[260px] sm:min-w-[280px] space-y-3">
            <div className="flex items-center justify-between text-xs text-emerald-200">
              <span className="font-bold flex items-center gap-1.5">
                <Wallet className="w-4 h-4 text-amber-400" />
                {isAr ? 'الرصيد الصافي المتاح' : 'Solde Net Disponible'}
              </span>
              <span className="live-dot w-2 h-2 rounded-full bg-emerald-400" />
            </div>

            <div className="text-3xl font-black font-mono tracking-tight text-white">
              {totalBalance.toLocaleString()} <span className="text-base text-amber-300 font-sans">درهم</span>
            </div>

            <div className="pt-2 border-t border-white/15 flex items-center justify-between text-xs text-emerald-100">
              <span>{isAr ? 'نسبة الاستخلاص الإجمالية' : 'Taux de Recouvrement'}</span>
              <span className="font-bold text-amber-300 font-mono">{collectionRate}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. THE 4 ESSENTIAL ACTION PILLARS (أركان العمل السريع المباشرة)             */}
      {/* ========================================================================= */}
      <div>
        <div className="mb-3 px-1 text-xs font-bold text-slate-500 uppercase tracking-wider">
          {isAr ? 'الإجراءات الأكثر استخداماً واستعمالاً' : 'Actions Fréquentes'}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Action 1: Enregistrer Paiement */}
          {!isOwner && (
            <button
              type="button"
              onClick={handleOpenPaymentRegistration}
              className="p-5 rounded-2xl bg-white hover:bg-emerald-50/70 border border-slate-200/90 hover:border-emerald-500/50 shadow-xs hover:shadow-md transition-all text-start group cursor-pointer flex flex-col justify-between"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center group-hover:scale-105 group-hover:bg-emerald-800 group-hover:text-amber-300 transition-all">
                  <Plus className="w-6 h-6 stroke-[2.5]" />
                </div>
                <ArrowUpRight className="w-4 h-4 text-slate-300 group-hover:text-emerald-700 transition-colors" />
              </div>
              <div>
                <div className="font-black text-base text-slate-900 group-hover:text-emerald-950">
                  {isAr ? 'تسجيل وصل أداء جديد' : 'Encaisser une cotisation'}
                </div>
                <div className="text-xs text-slate-500 mt-1">
                  {isAr ? 'استخلاص واجب السانديك وإصدار وصل رسمي فوري' : 'Émettre un reçu officiel de paiement'}
                </div>
              </div>
            </button>
          )}

          {/* Action 2: Ajouter Dépense */}
          {!isOwner && (
            <button
              type="button"
              onClick={handleOpenExpenseRegistration}
              className="p-5 rounded-2xl bg-white hover:bg-rose-50/70 border border-slate-200/90 hover:border-rose-500/50 shadow-xs hover:shadow-md transition-all text-start group cursor-pointer flex flex-col justify-between"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-800 flex items-center justify-center group-hover:scale-105 group-hover:bg-rose-800 group-hover:text-white transition-all">
                  <Receipt className="w-6 h-6 stroke-[2.2]" />
                </div>
                <ArrowUpRight className="w-4 h-4 text-slate-300 group-hover:text-rose-700 transition-colors" />
              </div>
              <div>
                <div className="font-black text-base text-slate-900 group-hover:text-rose-950">
                  {isAr ? 'تسجيل نفقة أو فاتورة' : 'Ajouter une dépense'}
                </div>
                <div className="text-xs text-slate-500 mt-1">
                  {isAr ? 'توثيق نفقات النظافة، الحراسة، العقاقير والمواد' : 'Saisir les factures d\'entretien & salaires'}
                </div>
              </div>
            </button>
          )}

          {/* Action 3: Bilan 2 Ans (2025-2026) */}
          <button
            type="button"
            onClick={() => setActiveSection('two-years-report')}
            className="p-5 rounded-2xl bg-gradient-to-br from-amber-50 to-amber-100/70 hover:from-amber-100 hover:to-amber-200/80 border-2 border-amber-300/80 shadow-xs hover:shadow-md transition-all text-start group cursor-pointer flex flex-col justify-between"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-2xl bg-amber-500 text-slate-950 flex items-center justify-center group-hover:scale-105 transition-all shadow-xs">
                <Scale className="w-6 h-6 stroke-[2.2]" />
              </div>
              <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-200 text-amber-900 border border-amber-300">
                2025 - 2026
              </span>
            </div>
            <div>
              <div className="font-black text-base text-amber-950 flex items-center gap-1.5">
                <span>{isAr ? 'حصيلة السنتين 2025 و 2026' : 'Bilan Financier 2 Ans'}</span>
                <Sparkles className="w-4 h-4 text-amber-800" />
              </div>
              <div className="text-xs text-amber-900/80 mt-1">
                {isAr ? 'التقرير المالي المقارن والرسوم البيانية وجاهز للطباعة' : 'Rapport financier complet et imprimable'}
              </div>
            </div>
          </button>

          {/* Action 4: Overdue Delinquents (6+ Months) */}
          <button
            type="button"
            onClick={() => setIsOverdueModalOpen(true)}
            className="p-5 rounded-2xl bg-white hover:bg-amber-50/70 border border-slate-200/90 hover:border-amber-500/50 shadow-xs hover:shadow-md transition-all text-start group cursor-pointer flex flex-col justify-between"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center group-hover:scale-105 group-hover:bg-amber-800 group-hover:text-white transition-all">
                <AlertTriangle className="w-6 h-6 stroke-[2.2]" />
              </div>
              <span className="text-xs font-black px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 font-mono">
                {overdueResidents.length}
              </span>
            </div>
            <div>
              <div className="font-black text-base text-slate-900 group-hover:text-amber-950">
                {isAr ? 'المتأخرون عن الأداء (6+ أشهر)' : 'Suivi des Impayés (+6 mois)'}
              </div>
              <div className="text-xs text-slate-500 mt-1">
                {isAr ? 'إرسال تنبيهات واتساب وتصنيف الالتزام' : 'Alertes WhatsApp & Suivi du recouvrement'}
              </div>
            </div>
          </button>

        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. FOUR CORE FINANCIAL KPIS (Zero-Pill Restraint)                         */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Recettes */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold">
            <span>{isAr ? 'إجمالي المداخيل المحصلة' : 'Total des Recettes'}</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black font-mono text-emerald-700">
            {totalIncome.toLocaleString()} <span className="text-xs font-sans">DH</span>
          </div>
          <div className="text-[11px] text-slate-400">
            {isAr ? 'واجبات السانديك والمداخيل الاستثنائية' : 'Cotisations et encaissements'}
          </div>
        </div>

        {/* Dépenses */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold">
            <span>{isAr ? 'إجمالي المصاريف والنفقات' : 'Total des Dépenses'}</span>
            <TrendingDown className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-2xl font-black font-mono text-rose-700">
            {totalExpenses.toLocaleString()} <span className="text-xs font-sans">DH</span>
          </div>
          <div className="text-[11px] text-slate-400">
            {isAr ? 'الأجور، النظافة، الصيانة، الفواتير' : 'Charges d\'entretien et salaires'}
          </div>
        </div>

        {/* Apartments Managed */}
        <div 
          onClick={() => setActiveSection('apartments')}
          className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-2 cursor-pointer hover:border-emerald-600 transition-colors"
        >
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold">
            <span>{isAr ? 'الشقق والمحلات' : 'Parc Immobilier'}</span>
            <Building2 className="w-4 h-4 text-emerald-700" />
          </div>
          <div className="text-2xl font-black font-mono text-slate-900">
            {apartments.length} <span className="text-xs font-sans text-slate-500">شقة</span>
          </div>
          <div className="text-[11px] text-slate-400">
            {isAr ? 'جميع العمارات (كتلة A وكتلة B)' : 'tous les immeubles  & B'}
          </div>
        </div>

        {/* Collection Status */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold">
            <span>{isAr ? 'المتأخرون أكثر من 6 أشهر' : 'Dossiers Contentieux'}</span>
            <AlertTriangle className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-black font-mono text-amber-700">
            {overdueResidents.length} <span className="text-xs font-sans text-slate-500">شقة</span>
          </div>
          <div className="text-[11px] text-slate-400">
            {isAr ? 'مستهدفون بالتنبيهات والمتابعة' : 'Sous surveillance stricte'}
          </div>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* 4. FINANCIAL EVOLUTION RECHARTS (2025 vs 2026)                            */}
      {/* ========================================================================= */}
      <div className="bg-white p-5 sm:p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
              <Activity className="w-5 h-5 text-emerald-700" />
              <span>{isAr ? 'تطور التدفقات المالية (المداخيل والمصاريف شهراً بشهر)' : 'Flux Financiers Mensuels'}</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {isAr ? 'مقارنة مرئية دقيقة لتطور المداخيل والنفقات وحساب الفائض المحقق' : 'Comparaison visuelle des encaissements et décaissements'}
            </p>
          </div>

          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl text-xs font-bold shrink-0">
            <button
              type="button"
              onClick={() => setEvolutionYear('2026')}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${evolutionYear === '2026' ? 'bg-white text-emerald-950 shadow-xs' : 'text-slate-600'}`}
            >
              2026
            </button>
            <button
              type="button"
              onClick={() => setEvolutionYear('2025')}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${evolutionYear === '2025' ? 'bg-white text-emerald-950 shadow-xs' : 'text-slate-600'}`}
            >
              2025
            </button>
            <button
              type="button"
              onClick={() => setEvolutionYear('all')}
              className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${evolutionYear === 'all' ? 'bg-white text-emerald-950 shadow-xs' : 'text-slate-600'}`}
            >
              {isAr ? 'السنتين معا' : '2 Ans'}
            </button>
          </div>
        </div>

        {/* The Recharts Graphic */}
        <div className="h-72 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis dataKey="label" stroke="#64748b" fontSize={11} tickLine={false} axisLine={{ stroke: '#e2e8f0' }} />
              <YAxis stroke="#64748b" fontSize={11} tickLine={false} axisLine={false} tickFormatter={(v) => `${Math.round(v / 1000)}k`} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#0f172a', borderRadius: '1rem', border: 'none', color: '#fff', fontSize: '12px' }}
                formatter={(val: any, name: any) => {
                  const label = name === 'income' ? (isAr ? 'المداخيل' : 'Recettes') : (isAr ? 'المصاريف' : 'Dépenses');
                  return [`${Number(val).toLocaleString()} DH`, label];
                }}
              />
              <Legend 
                verticalAlign="top" 
                align="right"
                formatter={(val) => {
                  if (val === 'income') return isAr ? 'المداخيل المحصلة' : 'Recettes';
                  if (val === 'expenses') return isAr ? 'المصاريف المصروفة' : 'Dépenses';
                  return val;
                }}
              />
              <Bar dataKey="income" fill="#059669" radius={[6, 6, 0, 0]} maxBarSize={32} />
              <Bar dataKey="expenses" fill="#e11d48" radius={[6, 6, 0, 0]} maxBarSize={32} />
              <Line type="monotone" dataKey="netBalance" stroke="#3b82f6" strokeWidth={2.5} dot={{ r: 3 }} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 5. WATCHLIST OF 6+ MONTHS OVERDUE RESIDENTS (قائمة المتأخرين الحرجة)       */}
      {/* ========================================================================= */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="p-5 sm:p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
              <h3 className="text-base sm:text-lg font-black text-slate-900">
                {isAr ? 'متابعة المتأخرين عن أداء واجبات السانديك (تأخر ابتداءً من 6 أشهر)' : 'Suivi des Copropriétaires en Retard (+6 mois)'}
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {isAr 
                ? 'وفق التوجيه المعتمد: يحتسب التأخر ابتداء من 6 أشهر، ويتيح هذا الجدول توجيه تنبيهات واتساب مباشرة بضغطة زر'
                : 'Conformément aux règles, le retard strict débute à partir de 6 mois d\'arriérés'}
            </p>
          </div>

          <button
            type="button"
            onClick={() => setIsOverdueModalOpen(true)}
            className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-colors cursor-pointer shrink-0 self-start sm:self-auto flex items-center gap-1.5"
          >
            <span>{isAr ? 'عرض الكشف الكامل والطباعة' : 'Voir tout le registre'}</span>
            <ChevronRight className={`w-3.5 h-3.5 ${isAr ? 'rotate-180' : ''}`} />
          </button>
        </div>

        {overdueResidents.length === 0 ? (
          <div className="p-8 text-center text-slate-500 text-sm">
            <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
            <p className="font-bold">{isAr ? 'لا يوجد أي ساكن متأخر عن الأداء لأكثر من 6 أشهر حالياً!' : 'Aucun retard supérieur à 6 mois !'}</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-start text-xs border-collapse">
              <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-100">
                <tr>
                  <th className="p-3.5 text-start">{isAr ? 'العمارة والشقة' : 'Lot'}</th>
                  <th className="p-3.5 text-start">{isAr ? 'الساكن / المالك' : 'Copropriétaire'}</th>
                  <th className="p-3.5 text-center">{isAr ? 'مدة التأخر' : 'Retard'}</th>
                  <th className="p-3.5 text-end">{isAr ? 'المبلغ المستحق' : 'Montant Dû'}</th>
                  <th className="p-3.5 text-center">{isAr ? 'الحالة والالتزام' : 'Statut'}</th>
                  <th className="p-3.5 text-center">{isAr ? 'تنبيه واتساب' : 'Action'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {overdueResidents.slice(0, 6).map((item) => (
                  <tr key={item.apartment.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="p-3.5 font-bold text-slate-900 font-mono">
                      {item.apartment.buildingCode} - شقة {item.apartment.number}
                    </td>
                    <td className="p-3.5 font-medium text-slate-800">
                      <div>{item.residentName}</div>
                      {item.phone && <div className="text-[10px] text-slate-400 font-mono">{item.phone}</div>}
                    </td>
                    <td className="p-3.5 text-center font-bold font-mono text-rose-700">
                      {item.unpaidMonthsCount} {isAr ? 'أشهر' : 'mois'}
                    </td>
                    <td className="p-3.5 text-end font-black font-mono text-slate-900">
                      {item.totalDue.toLocaleString()} DH
                    </td>
                    <td className="p-3.5 text-center">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${item.isCritical ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'}`}>
                        {item.statusLabel}
                      </span>
                    </td>
                    <td className="p-3.5 text-center">
                      {item.phone ? (
                        <button
                          type="button"
                          onClick={() => sendWhatsAppReminder(
                            item.residentName, 
                            item.phone, 
                            item.apartment.buildingCode, 
                            item.apartment.number, 
                            item.unpaidMonthsCount, 
                            item.totalDue
                          )}
                          className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] transition-colors cursor-pointer shadow-2xs"
                        >
                          <Send className="w-3 h-3" />
                          <span>واتساب</span>
                        </button>
                      ) : (
                        <span className="text-[10px] text-slate-400">{isAr ? 'لا يوجد هاتف' : 'Sans tél'}</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* 6. RECENT ACTIVITY (LATEST PAYMENTS & LATEST EXPENSES)                     */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Latest Payments */}
        <div className="bg-white rounded-3xl border border-slate-200/80 p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h3 className="font-black text-sm text-slate-900 flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-emerald-700" />
              <span>{isAr ? 'أحدث الوصولات المستخلصة' : 'Derniers Paiements Encaissés'}</span>
            </h3>
            <button
              onClick={() => setActiveSection('payments')}
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 cursor-pointer"
            >
              {isAr ? 'عرض الكل' : 'Voir tout'}
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {recentPayments.map(p => (
              <div key={p.id} className="py-2.5 flex items-center justify-between gap-2 text-xs">
                <div>
                  <div className="font-bold text-slate-900 font-mono">
                    عمارة {p.buildingCode} · شقة {p.apartmentNumber}
                  </div>
                  <div className="text-[10px] text-slate-400 font-medium">
                    {p.residentName} · {p.paymentDate}
                  </div>
                </div>
                <div className="text-end font-mono">
                  <div className="font-black text-emerald-700">+{Number(p.amount).toLocaleString()} DH</div>
                  <div className="text-[10px] text-slate-400">{p.periodMonth}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Latest Expenses */}
        <div className="bg-white rounded-3xl border border-slate-200/80 p-5 shadow-xs space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h3 className="font-black text-sm text-slate-900 flex items-center gap-2">
              <Receipt className="w-4 h-4 text-rose-700" />
              <span>{isAr ? 'أحدث المصاريف ونفقات التسيير' : 'Dernières Dépenses Réglées'}</span>
            </h3>
            <button
              onClick={() => setActiveSection('expenses')}
              className="text-xs font-bold text-rose-700 hover:text-rose-800 cursor-pointer"
            >
              {isAr ? 'عرض الكل' : 'Voir tout'}
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {recentExpenses.map(e => (
              <div key={e.id} className="py-2.5 flex items-center justify-between gap-2 text-xs">
                <div>
                  <div className="font-bold text-slate-900 truncate max-w-[200px]">
                    {e.title}
                  </div>
                  <div className="text-[10px] text-slate-400">
                    {e.category} · {e.date}
                  </div>
                </div>
                <div className="text-end font-mono">
                  <div className="font-black text-rose-700">-{Number(e.amount).toLocaleString()} DH</div>
                  <div className="text-[10px] text-slate-400">{e.paymentMethod || 'Espèces'}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* MODALS HOOKED CLEANLY                                                     */}
      {/* ========================================================================= */}
      {isOverdueModalOpen && (
        <OverduePayersModal isOpen={isOverdueModalOpen} onClose={() => setIsOverdueModalOpen(false)} />
      )}

      {isFinancialReportModalOpen && (
        <MonthlyFinancialReportModal
          isOpen={isFinancialReportModalOpen}
          initialMode={financialReportMode}
          onClose={() => setIsFinancialReportModalOpen(false)}
        />
      )}

      {isPaidReceiptsModalOpen && (
        <PaidReceiptsPdfModal isOpen={isPaidReceiptsModalOpen} onClose={() => setIsPaidReceiptsModalOpen(false)} />
      )}

      {isOwnersDuesExcelOpen && (
        <OwnersDuesExcelModal 
          isOpen={isOwnersDuesExcelOpen} 
          onClose={() => setIsOwnersDuesExcelOpen(false)} 
        />
      )}

      {isResidentsExcelImportOpen && (
        <ResidentsExcelImportModal 
          isOpen={isResidentsExcelImportOpen} 
          onClose={() => setIsResidentsExcelImportOpen(false)} 
        />
      )}

    </div>
  );
};
