import React from 'react';
import { GeneralAssemblyVoting } from './GeneralAssemblyVoting';

export const VotingFeature: React.FC = () => {
  return <GeneralAssemblyVoting />;
};
