import React from 'react';
import { motion } from 'motion/react';
import { Home, ShieldCheck, ArrowLeft, ArrowRight } from 'lucide-react';

interface PortalSelectorProps {
  isAr?: boolean;
  onSelectPortal: (portal: 'owner' | 'syndic') => void;
}

export const PortalSelector: React.FC<PortalSelectorProps> = ({ isAr = true, onSelectPortal }) => {
  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-800 via-emerald-900 to-emerald-950 p-5 sm:p-8 shadow-2xl">
      <div className="aurora-blob aurora-a w-72 h-72 -top-24 -end-16 bg-amber-400/20 pointer-events-none" />
      <div className="aurora-blob aurora-b w-64 h-64 -bottom-24 -start-10 bg-emerald-300/20 pointer-events-none" />
      <div className="relative z-10 grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
        <motion.button
          whileHover={{ scale: 1.03, y: -2 }}
          whileTap={{ scale: 0.97 }}
          type="button"
          id="portal-btn-owner"
          onClick={() => onSelectPortal('owner')}
          className="group/portal px-4 py-3.5 rounded-2xl bg-white/95 hover:bg-white border border-white/60 text-slate-900 shadow-xl flex items-center justify-between gap-3 cursor-pointer transition-all"
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="icon-wiggle w-11 h-11 rounded-xl bg-gradient-to-br from-emerald-400 to-emerald-600 text-white flex items-center justify-center shrink-0 shadow-md">
              <Home className="w-5 h-5" />
            </div>
            <div className="text-start leading-tight min-w-0">
              <span className="text-sm font-black block truncate">{isAr ? 'بوابة الملاك' : 'Copropriétaires'}</span>
              <span className="text-[11px] text-slate-500 font-semibold block truncate">{isAr ? 'كشف الشقة والوصولات' : 'Accès résident'}</span>
            </div>
          </div>
          <div className="text-slate-400 shrink-0">{isAr ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}</div>
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.03, y: -2 }}
          whileTap={{ scale: 0.97 }}
          type="button"
          id="portal-btn-syndic"
          onClick={() => onSelectPortal('syndic')}
          className="group/portal px-4 py-3.5 rounded-2xl bg-gradient-to-l from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 border border-amber-400 text-white shadow-xl flex items-center justify-between gap-3 cursor-pointer transition-all"
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="icon-wiggle w-11 h-11 rounded-xl bg-white/20 text-white flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div className="text-start leading-tight min-w-0">
              <span className="text-sm font-black block truncate">{isAr ? 'بوابة السنديك' : 'Portail Syndic'}</span>
              <span className="text-[11px] text-amber-100 font-semibold block truncate">{isAr ? 'لوحة القيادة والتسيير' : 'Console de gestion'}</span>
            </div>
          </div>
          <div className="text-white/80 shrink-0">{isAr ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}</div>
        </motion.button>
      </div>
    </div>
  );
};
