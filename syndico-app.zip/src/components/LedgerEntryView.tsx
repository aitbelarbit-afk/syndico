import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { ManualMonthlyRecord } from '../types';
import {
  filterPaymentsByMonth,
  getPreviousMonthKey,
  getUniqueExpenseBreakdown,
  ARABIC_MONTH_NAMES,
  FRENCH_MONTH_NAMES
} from '../utils/monthlyFinanceUtils';
import {
  Wallet, Lock, Unlock, Save, CalendarCheck, TrendingUp, TrendingDown,
  Gavel, FileSignature, Users, Briefcase, Hammer, Zap, Sprout, Droplets,
  Lightbulb, FlaskConical, Package, RefreshCw, ArrowLeft, CheckCircle2, AlertCircle,
  Pencil, BarChart3, Printer, Trash2
} from 'lucide-react';

type ExpenseKey =
  | 'syndicAndDeputyFees' | 'lawyerFees' | 'bailiffFees' | 'workerSalaries'
  | 'hardwareDroguerie' | 'buildingMaterials' | 'electricalMaterials' | 'irrigationTools' | 'otherExpenses'
  | 'stairsElectricity' | 'wellElectricity';

interface FieldDef {
  key: ExpenseKey;
  ar: string;
  fr: string;
  icon: React.ComponentType<{ className?: string }>;
  tone: string;
}

const GROUPS: { id: string; ar: string; fr: string; fields: FieldDef[] }[] = [
  {
    id: 'fees',
    ar: 'الأجور والأتعاب',
    fr: 'Salaires & Honoraires',
    fields: [
      { key: 'syndicAndDeputyFees', ar: 'أجرة السانديك', fr: 'Indemnité du syndic', icon: Briefcase, tone: 'from-indigo-400 to-indigo-600' },
      { key: 'lawyerFees', ar: 'أتعاب المحامي', fr: 'Honoraires avocat', icon: Gavel, tone: 'from-violet-400 to-violet-600' },
      { key: 'bailiffFees', ar: 'أتعاب المفوض القضائي', fr: 'Frais d\'huissier', icon: FileSignature, tone: 'from-fuchsia-400 to-fuchsia-600' },
      { key: 'workerSalaries', ar: 'أجور العمال', fr: 'Salaires des ouvriers', icon: Users, tone: 'from-amber-400 to-amber-600' }
    ]
  },
  {
    id: 'misc',
    ar: 'مصاريف مختلفة (الاستعمال اليومي)',
    fr: 'Dépenses diverses (usage quotidien)',
    fields: [
      { key: 'hardwareDroguerie', ar: 'العقاقير', fr: 'Droguerie', icon: FlaskConical, tone: 'from-emerald-400 to-emerald-600' },
      { key: 'buildingMaterials', ar: 'مواد البناء', fr: 'Matériaux de construction', icon: Hammer, tone: 'from-orange-400 to-orange-600' },
      { key: 'electricalMaterials', ar: 'مواد كهربائية', fr: 'Matériel électrique', icon: Zap, tone: 'from-yellow-400 to-yellow-600' },
      { key: 'irrigationTools', ar: 'أدوات السقي', fr: 'Matériel d\'arrosage', icon: Sprout, tone: 'from-lime-400 to-lime-600' },
      { key: 'otherExpenses', ar: 'أخرى (استعمال يومي)', fr: 'Autres (usage quotidien)', icon: Package, tone: 'from-slate-400 to-slate-600' }
    ]
  },
  {
    id: 'electricity',
    ar: 'فواتير الكهرباء',
    fr: 'Factures d\'électricité',
    fields: [
      { key: 'stairsElectricity', ar: 'كهرباء الدرج', fr: 'Électricité des escaliers', icon: Lightbulb, tone: 'from-amber-400 to-orange-500' },
      { key: 'wellElectricity', ar: 'كهرباء البئر', fr: 'Électricité du puits', icon: Droplets, tone: 'from-sky-400 to-sky-600' }
    ]
  }
];

const ALL_KEYS: ExpenseKey[] = GROUPS.flatMap(g => g.fields.map(f => f.key));
// حقول قديمة تُحفظ كما هي وتدخل في المجموع حتى لا يضيع أي إدخال سابق
const LEGACY_KEYS = ['salaries', 'utilities', 'maintenance', 'supplies'] as const;

const CATEGORY_LABELS: Record<string, { ar: string; fr: string; bar: string }> = {
  syndicAndDeputyFees: { ar: 'أجرة السانديك', fr: 'Indemnité du syndic', bar: 'bg-indigo-500' },
  lawyerFees: { ar: 'أتعاب المحامي', fr: 'Avocat', bar: 'bg-violet-500' },
  bailiffFees: { ar: 'أتعاب المفوض القضائي', fr: 'Huissier', bar: 'bg-fuchsia-500' },
  workerSalaries: { ar: 'أجور العمال', fr: 'Salaires ouvriers', bar: 'bg-amber-500' },
  salaries: { ar: 'أجور الحراسة والنظافة', fr: 'Gardiennage & nettoyage', bar: 'bg-orange-500' },
  hardwareDroguerie: { ar: 'العقاقير', fr: 'Droguerie', bar: 'bg-emerald-500' },
  buildingMaterials: { ar: 'مواد البناء', fr: 'Matériaux', bar: 'bg-orange-400' },
  electricalMaterials: { ar: 'مواد كهربائية', fr: 'Matériel électrique', bar: 'bg-yellow-500' },
  irrigationTools: { ar: 'أدوات السقي', fr: 'Arrosage', bar: 'bg-lime-500' },
  otherExpenses: { ar: 'أخرى (استعمال يومي)', fr: 'Autres', bar: 'bg-slate-400' },
  stairsElectricity: { ar: 'كهرباء الدرج', fr: 'Électricité escaliers', bar: 'bg-amber-400' },
  wellElectricity: { ar: 'كهرباء البئر', fr: 'Électricité puits', bar: 'bg-sky-500' },
  utilities: { ar: 'ماء وكهرباء المرافق', fr: 'Eau & électricité communes', bar: 'bg-cyan-500' },
  maintenance: { ar: 'صيانة وإصلاحات', fr: 'Entretien & réparations', bar: 'bg-teal-500' },
  supplies: { ar: 'مواد تنظيف ومكتبيات', fr: 'Fournitures', bar: 'bg-pink-400' },
  unclassified: { ar: 'غير مصنّف', fr: 'Non classé', bar: 'bg-slate-300' }
};

const money = (n: number) =>
  new Intl.NumberFormat('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n || 0);

const toNum = (v: string) => {
  const n = parseFloat(String(v).replace(',', '.'));
  return isNaN(n) || n < 0 ? 0 : n;
};

const currentMonthKey = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
};

export const LedgerEntryView: React.FC = () => {
  const {
    lang, currentUser, manualMonthlyRecords, payments,
    upsertManualMonthlyRecord, closeManualMonth, reopenManualMonth, deleteManualMonthlyRecord
  } = useApp();
  const isAr = lang === 'ar';
  const canEdit = currentUser?.role !== 'resident';

  // الأشهر المتاحة: من 04/2025 إلى الشهر الموالي للشهر الحالي
  const monthKeys = useMemo(() => {
    const list: string[] = [];
    const now = new Date();
    const endY = now.getFullYear() + (now.getMonth() === 11 ? 1 : 0);
    const endM = (now.getMonth() + 2 > 12) ? 1 : now.getMonth() + 2;
    let y = now.getFullYear() - 2, m = 1;
    while (y < endY || (y === endY && m <= endM)) {
      list.push(`${y}-${String(m).padStart(2, '0')}`);
      m += 1;
      if (m > 12) { m = 1; y += 1; }
    }
    return list;
  }, []);

  const monthLabel = (key: string) => {
    const [y, m] = key.split('-');
    return `${(isAr ? ARABIC_MONTH_NAMES : FRENCH_MONTH_NAMES)[m] || m} ${y}`;
  };

  const [monthKey, setMonthKey] = useState<string>(() => {
    try {
      const focus = sessionStorage.getItem('ledger_focus_month');
      if (focus && /^\d{4}-\d{2}$/.test(focus)) {
        sessionStorage.removeItem('ledger_focus_month');
        return focus;
      }
    } catch (e) { /* ignore */ }
    return currentMonthKey();
  });
  const [income, setIncome] = useState('');
  const [fields, setFields] = useState<Record<string, string>>({});
  const [notes, setNotes] = useState('');
  const [message, setMessage] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const record: ManualMonthlyRecord | undefined = useMemo(
    () => manualMonthlyRecords.find(r => r.monthKey === monthKey),
    [manualMonthlyRecords, monthKey]
  );
  const isClosed = !!record?.isClosed;
  const locked = isClosed || !canEdit;

  // تحميل بيانات الشهر المحدد في النموذج
  useEffect(() => {
    setIncome(record && record.totalIncome ? String(record.totalIncome) : '');
    const next: Record<string, string> = {};
    ALL_KEYS.forEach(k => {
      const v = record?.breakdownExpenses?.[k];
      next[k] = v ? String(v) : '';
    });
    setFields(next);
    setNotes(record?.notes || '');
  }, [record?.id, record?.updatedAt, monthKey]);

  const legacyTotal = useMemo(() => {
    const b = getUniqueExpenseBreakdown(record?.breakdownExpenses as Record<string, number | undefined> | undefined);
    return LEGACY_KEYS.reduce((s, k) => s + (Number(b[k]) || 0), 0);
  }, [record]);

  const expensesTotal = useMemo(
    () => ALL_KEYS.reduce((s, k) => s + toNum(fields[k] || ''), 0) + legacyTotal,
    [fields, legacyTotal]
  );
  const incomeTotal = toNum(income);

  // الرصيد المرحل من الشهر السابق (تلقائي)
  const openingBalance = useMemo(() => {
    const prevKey = getPreviousMonthKey(monthKey);
    const prev = manualMonthlyRecords.find(r => r.monthKey === prevKey);
    if (prev) {
      return prev.closingBalance !== undefined
        ? prev.closingBalance
        : (prev.openingBalance || 0) + prev.totalIncome - prev.totalExpenses;
    }
    return typeof record?.openingBalance === 'number' ? record.openingBalance : 0;
  }, [manualMonthlyRecords, monthKey, record]);

  const closingBalance = openingBalance + incomeTotal - expensesTotal;

  const buildRecord = () => {
    const prevBreak = getUniqueExpenseBreakdown(record?.breakdownExpenses as Record<string, number | undefined> | undefined) as Record<string, number | undefined>;
    const breakdownExpenses: Record<string, number> = {};
    LEGACY_KEYS.forEach(k => { if (prevBreak[k]) breakdownExpenses[k] = Number(prevBreak[k]); });
    ALL_KEYS.forEach(k => { const v = toNum(fields[k] || ''); if (v > 0) breakdownExpenses[k] = v; });

    let breakdownIncome = record?.breakdownIncome;
    if (breakdownIncome) {
      const sum = Object.values(breakdownIncome).reduce((s, v) => s + (Number(v) || 0), 0);
      if (Math.abs(sum - incomeTotal) > 0.009) breakdownIncome = undefined;
    }

    return {
      id: record?.id,
      monthKey,
      totalIncome: incomeTotal,
      totalExpenses: expensesTotal,
      openingBalance: record?.openingBalance,
      breakdownIncome,
      breakdownExpenses,
      notes: notes.trim() || undefined
    } as Omit<ManualMonthlyRecord, 'id' | 'updatedAt'> & { id?: string };
  };

  const handleSave = () => {
    if (locked) return;
    upsertManualMonthlyRecord(buildRecord());
    setMessage({
      type: 'ok',
      text: isAr ? `تم حفظ مداخيل ومصاريف ${monthLabel(monthKey)}` : `Recettes et dépenses de ${monthLabel(monthKey)} enregistrées`
    });
  };

  const handleClose = () => {
    if (locked) return;
    const ok = window.confirm(
      isAr
        ? `إغلاق شهر ${monthLabel(monthKey)}؟\nسيُرحَّل الرصيد (${money(closingBalance)} د.م) تلقائياً إلى بداية الشهر الموالي.`
        : `Clôturer ${monthLabel(monthKey)} ?\nLe solde (${money(closingBalance)} DH) sera reporté automatiquement au mois suivant.`
    );
    if (!ok) return;
    upsertManualMonthlyRecord(buildRecord());
    const res = closeManualMonth(monthKey);
    if (res.success) {
      setMessage({
        type: 'ok',
        text: isAr
          ? `تم إغلاق ${monthLabel(monthKey)} وترحيل ${money(res.closingBalance || 0)} د.م إلى ${monthLabel(res.nextMonthKey || '')}`
          : `${monthLabel(monthKey)} clôturé : ${money(res.closingBalance || 0)} DH reportés sur ${monthLabel(res.nextMonthKey || '')}`
      });
      if (res.nextMonthKey) setMonthKey(res.nextMonthKey);
    } else {
      setMessage({ type: 'err', text: isAr ? 'تعذّر إغلاق الشهر' : 'Impossible de clôturer le mois' });
    }
  };

  const handleReopen = () => {
    if (!canEdit || !isClosed) return;
    const res = reopenManualMonth(monthKey);
    setMessage(res.success
      ? { type: 'ok', text: isAr ? 'تمت إعادة فتح الشهر للتعديل' : 'Mois rouvert pour modification' }
      : { type: 'err', text: isAr ? 'لا يمكن إعادة فتح شهر لاحقه مغلق، أعد فتح الشهر اللاحق أولاً' : 'Rouvrez d\'abord le mois suivant (il est clôturé)' });
  };

  const fillIncomeFromReceipts = () => {
    if (locked) return;
    const sum = filterPaymentsByMonth(payments, monthKey).reduce((s, p) => s + (Number(p.amount) || 0), 0);
    setIncome(sum ? String(sum) : '');
  };


  // ===== التقرير المالي الشامل لـ 24 شهراً =====
  const report = useMemo(() => {
    const keys = manualMonthlyRecords.map(r => r.monthKey).sort();
    const nowKey = currentMonthKey();
    const addMonths = (key: string, n: number) => {
      const [yy, mm] = key.split('-').map(Number);
      const idx = yy * 12 + (mm - 1) + n;
      return `${Math.floor(idx / 12)}-${String((idx % 12) + 1).padStart(2, '0')}`;
    };
    const defaultStart = `${new Date().getFullYear() - 1}-01`;
    let start = keys[0] && keys[0] < defaultStart ? keys[0] : defaultStart;
    if (addMonths(start, 23) < nowKey) start = addMonths(nowKey, -23);
    const map = new Map<string, ManualMonthlyRecord>(manualMonthlyRecords.map(r => [r.monthKey, r] as [string, ManualMonthlyRecord]));
    const months = Array.from({ length: 24 }, (_, i) => addMonths(start, i));

    let running: number | null = null;
    const rows = months.map(key => {
      const rec = map.get(key);
      const income = rec?.totalIncome || 0;
      const expenses = rec?.totalExpenses || 0;
      const opening: number = rec ? (rec.openingBalance ?? running ?? 0) : (running ?? 0);
      const closing: number = rec ? (rec.closingBalance ?? opening + income - expenses) : opening;
      running = closing;
      return { key, rec, income, expenses, opening, closing, has: !!rec };
    });

    const sum = (arr: typeof rows, f: (r: typeof rows[number]) => number) => arr.reduce((t, r) => t + f(r), 0);
    const y1 = rows.slice(0, 12);
    const y2 = rows.slice(12);
    const withData = rows.filter(r => r.has);
    const totalIncome = sum(rows, r => r.income);
    const totalExpenses = sum(rows, r => r.expenses);

    const cats: Record<string, number> = {};
    let classified = 0;
    rows.forEach(r => {
      const b = getUniqueExpenseBreakdown(r.rec?.breakdownExpenses as Record<string, number | undefined> | undefined);
      let rowClassified = 0;
      Object.keys(b).forEach(k => {
        const v = Number(b[k]) || 0;
        if (v > 0) { cats[k] = (cats[k] || 0) + v; rowClassified += v; }
      });
      classified += rowClassified;
      const diff = r.expenses - rowClassified;
      if (diff > 0.009) cats.unclassified = (cats.unclassified || 0) + diff;
    });
    const catList = Object.entries(cats).filter(([, v]) => v > 0).sort((a, b) => b[1] - a[1]);

    const bestIncome = withData.length ? withData.reduce((a, b) => (b.income > a.income ? b : a)) : null;
    const worstExpense = withData.length ? withData.reduce((a, b) => (b.expenses > a.expenses ? b : a)) : null;
    const deficitMonths = withData.filter(r => r.income - r.expenses < 0).length;
    const maxBar = Math.max(1, ...rows.map(r => Math.max(r.income, r.expenses)));

    return {
      rows, y1, y2, withData, totalIncome, totalExpenses, catList, bestIncome, worstExpense, deficitMonths, maxBar,
      y1Income: sum(y1, r => r.income), y1Expenses: sum(y1, r => r.expenses),
      y2Income: sum(y2, r => r.income), y2Expenses: sum(y2, r => r.expenses),
      finalBalance: rows[rows.length - 1].closing,
      startKey: months[0], endKey: months[23],
      closedCount: rows.filter(r => r.rec?.isClosed).length
    };
  }, [manualMonthlyRecords]);

  const pct = (a: number, b: number) => (b > 0 ? ((a - b) / b) * 100 : 0);

  const shortMonth = (key: string) => {
    const [y, m] = key.split('-');
    return `${m}/${y.slice(2)}`;
  };

  // زر المسح أمام كل شهر: يحذف مداخيل ومصاريف الشهر المدوَّنة
  const handleDeleteMonth = (key: string) => {
    if (!canEdit) return;
    const rec = manualMonthlyRecords.find(r => r.monthKey === key);
    if (!rec) return;
    if (rec.isClosed) {
      setMessage({
        type: 'err',
        text: isAr ? `شهر ${monthLabel(key)} مغلق، اضغط "تغيير البيانات" لإعادة فتحه قبل مسحه` : `${monthLabel(key)} est clôturé : cliquez sur « Modifier » pour le rouvrir avant de le supprimer`
      });
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    const ok = window.confirm(
      isAr
        ? `مسح بيانات شهر ${monthLabel(key)} نهائياً؟\nالمداخيل: ${money(rec.totalIncome)} د.م — المصاريف: ${money(rec.totalExpenses)} د.م\nسيُعاد حساب الرصيد المرحل للأشهر الموالية.`
        : `Supprimer définitivement les données de ${monthLabel(key)} ?\nRecettes : ${money(rec.totalIncome)} DH — Dépenses : ${money(rec.totalExpenses)} DH\nLe solde reporté des mois suivants sera recalculé.`
    );
    if (!ok) return;
    deleteManualMonthlyRecord(rec.id);
    setMessage({ type: 'ok', text: isAr ? `تم مسح بيانات ${monthLabel(key)}` : `Données de ${monthLabel(key)} supprimées` });
  };

  // زر التغيير أمام كل شهر: يحدّد الشهر ويعيد فتحه إن كان مغلقاً
  const handleChangeMonth = (key: string) => {
    const rec = manualMonthlyRecords.find(r => r.monthKey === key);
    if (rec?.isClosed && canEdit) {
      const ok = window.confirm(
        isAr
          ? `شهر ${monthLabel(key)} مغلق. هل تريد إعادة فتحه لتغيير مداخيله ومصاريفه؟`
          : `${monthLabel(key)} est clôturé. Le rouvrir pour modifier ses recettes et dépenses ?`
      );
      if (!ok) return;
      const res = reopenManualMonth(key);
      if (!res.success) {
        setMonthKey(key);
        setMessage({
          type: 'err',
          text: isAr ? 'لا يمكن إعادة فتح هذا الشهر لأن الشهر الذي يليه مغلق، أعد فتح الشهر اللاحق أولاً' : 'Rouvrez d\'abord le mois suivant (il est clôturé)'
        });
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
      }
      setMessage({ type: 'ok', text: isAr ? 'تمت إعادة فتح الشهر، يمكنك تغيير البيانات ثم إغلاقه من جديد لترحيل الرصيد' : 'Mois rouvert : modifiez puis clôturez à nouveau pour reporter le solde' });
    } else {
      setMessage(null);
    }
    setMonthKey(key);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="relative overflow-hidden bg-white p-5 rounded-2xl border border-slate-200 border-t-4 border-t-emerald-500 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="icon-wiggle anim-bob w-11 h-11 rounded-2xl gradient-flow text-white flex items-center justify-center shadow-md shrink-0">
              <Wallet className="w-6 h-6" />
            </span>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900">
                {isAr ? 'المداخيل والمصاريف الشهرية' : 'Recettes & Dépenses du mois'}
              </h1>
              <p className="text-xs sm:text-sm text-slate-600 font-medium mt-0.5">
                {isAr
                  ? 'أدخل مجموع المداخيل والمصاريف، وعند إغلاق الشهر يُرحَّل الرصيد تلقائياً للشهر القادم'
                  : 'Saisissez les totaux ; à la clôture, le solde est reporté automatiquement au mois suivant'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <CalendarCheck className="w-5 h-5 text-emerald-600 shrink-0" />
            <select
              value={monthKey}
              onChange={e => { setMonthKey(e.target.value); setMessage(null); }}
              className="px-3 py-2.5 rounded-xl border border-slate-300 bg-white text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              {monthKeys.map(k => (
                <option key={k} value={k}>
                  {monthLabel(k)}{manualMonthlyRecords.find(r => r.monthKey === k)?.isClosed ? ' 🔒' : ''}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {message && (
        <div className={`flex items-start gap-2 p-3.5 rounded-xl text-sm font-bold border ${
          message.type === 'ok' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-rose-50 text-rose-800 border-rose-200'
        }`}>
          {message.type === 'ok' ? <CheckCircle2 className="w-5 h-5 shrink-0" /> : <AlertCircle className="w-5 h-5 shrink-0" />}
          <span>{message.text}</span>
        </div>
      )}

      {isClosed && (
        <div className="flex items-center justify-between gap-3 p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-sm font-bold">
          <span className="flex items-center gap-2"><Lock className="w-4 h-4 shrink-0" />
            {isAr ? 'هذا الشهر مغلق، وقد رُحِّل رصيده إلى الشهر التالي.' : 'Ce mois est clôturé ; son solde est reporté au mois suivant.'}
          </span>
          {canEdit && (
            <button type="button" onClick={handleReopen}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-amber-300 text-xs font-black cursor-pointer hover:bg-amber-100">
              <Unlock className="w-3.5 h-3.5" /> {isAr ? 'إعادة الفتح' : 'Rouvrir'}
            </button>
          )}
        </div>
      )}

      {/* Summary: carried → income → expenses → closing */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-500"><ArrowLeft className="w-3.5 h-3.5" />{isAr ? 'الرصيد المرحل' : 'Solde reporté'}</div>
          <div className={`mt-1 text-lg font-black ${openingBalance >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>{money(openingBalance)} <span className="text-xs">DH</span></div>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-500"><TrendingUp className="w-3.5 h-3.5 text-emerald-600" />{isAr ? 'مداخيل الشهر' : 'Recettes'}</div>
          <div className="mt-1 text-lg font-black text-emerald-700">{money(incomeTotal)} <span className="text-xs">DH</span></div>
        </div>
        <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm">
          <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-500"><TrendingDown className="w-3.5 h-3.5 text-rose-600" />{isAr ? 'مصاريف الشهر' : 'Dépenses'}</div>
          <div className="mt-1 text-lg font-black text-rose-600">{money(expensesTotal)} <span className="text-xs">DH</span></div>
        </div>
        <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-800 to-emerald-950 text-white shadow-md">
          <div className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-100"><Wallet className="w-3.5 h-3.5" />{isAr ? 'الرصيد الختامي (المرحل للشهر القادم)' : 'Solde final (reporté)'}</div>
          <div className={`mt-1 text-lg font-black ${closingBalance >= 0 ? 'text-white' : 'text-rose-200'}`}>{money(closingBalance)} <span className="text-xs">DH</span></div>
        </div>
      </div>

      {/* Income */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
        <div className="flex items-center justify-between gap-2">
          <h2 className="flex items-center gap-2 text-base font-black text-slate-900">
            <span className="icon-wiggle w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-400 to-emerald-600 text-white flex items-center justify-center shadow-sm"><TrendingUp className="w-[18px] h-[18px]" /></span>
            {isAr ? 'مجموع مداخيل الشهر' : 'Total des recettes du mois'}
          </h2>
          {!locked && (
            <button type="button" onClick={fillIncomeFromReceipts}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold cursor-pointer hover:bg-emerald-100">
              <RefreshCw className="w-3.5 h-3.5" /> {isAr ? 'جلب من الوصولات' : 'Depuis les reçus'}
            </button>
          )}
        </div>
        <div className="relative">
          <input
            type="number" inputMode="decimal" min="0" step="0.01"
            value={income} disabled={locked}
            onChange={e => setIncome(e.target.value)}
            placeholder="0.00"
            className="w-full px-4 py-3 rounded-xl border border-slate-300 text-lg font-black text-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 disabled:bg-slate-100"
          />
          <span className="absolute top-1/2 -translate-y-1/2 end-4 text-xs font-bold text-slate-500">DH</span>
        </div>
      </div>

      {/* Expense groups */}
      {GROUPS.map(g => {
        const groupTotal = g.fields.reduce((s, f) => s + toNum(fields[f.key] || ''), 0);
        return (
          <div key={g.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-black text-slate-900">{isAr ? g.ar : g.fr}</h2>
              <span className="text-xs font-black text-rose-600">{money(groupTotal)} DH</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {g.fields.map(f => {
                const Icon = f.icon;
                return (
                  <label key={f.key} className="group flex items-center gap-3 p-3 rounded-xl border border-slate-200 hover:border-emerald-300 transition-colors">
                    <span className={`icon-wiggle w-10 h-10 rounded-xl bg-gradient-to-br ${f.tone} text-white flex items-center justify-center shadow-sm shrink-0`}>
                      <Icon className="w-5 h-5" />
                    </span>
                    <span className="flex-1 min-w-0">
                      <span className="block text-xs font-bold text-slate-700 mb-1">{isAr ? f.ar : f.fr}</span>
                      <input
                        type="number" inputMode="decimal" min="0" step="0.01"
                        value={fields[f.key] || ''} disabled={locked}
                        onChange={e => setFields(prev => ({ ...prev, [f.key]: e.target.value }))}
                        placeholder="0.00"
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500 disabled:bg-slate-100"
                      />
                    </span>
                  </label>
                );
              })}
            </div>
          </div>
        );
      })}

      {legacyTotal > 0 && (
        <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold text-slate-600">
          {isAr
            ? `مبلغ ${money(legacyTotal)} د.م من مصاريف مدونة سابقاً (حراسة، ماء وكهرباء مشترك، صيانة، تنظيف) محتسب ضمن المجموع.`
            : `${money(legacyTotal)} DH de dépenses saisies précédemment (gardiennage, eau/électricité, entretien, nettoyage) sont inclus dans le total.`}
        </div>
      )}

      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
        <label className="block text-xs font-bold text-slate-700 mb-1.5">{isAr ? 'ملاحظات' : 'Remarques'}</label>
        <textarea
          rows={2} value={notes} disabled={locked}
          onChange={e => setNotes(e.target.value)}
          className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 disabled:bg-slate-100"
        />
      </div>

      {/* Actions */}
      {!locked && (
        <div className="flex flex-col sm:flex-row gap-3">
          <button type="button" onClick={handleSave}
            className="flex-1 flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-white border-2 border-emerald-600 text-emerald-800 font-black text-sm cursor-pointer hover:bg-emerald-50">
            <Save className="w-4 h-4" /> {isAr ? 'حفظ' : 'Enregistrer'}
          </button>
          <button type="button" onClick={handleClose}
            className="flex-1 flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-gradient-to-l from-emerald-700 to-emerald-500 text-white font-black text-sm shadow-md cursor-pointer hover:shadow-lg">
            <Lock className="w-4 h-4" /> {isAr ? 'إغلاق الشهر وترحيل الرصيد' : 'Clôturer et reporter le solde'}
          </button>
        </div>
      )}

      {/* ===== التقرير المالي الشامل 24 شهراً ===== */}
      <div className="bg-white rounded-2xl border border-slate-200 border-t-4 border-t-indigo-500 shadow-sm overflow-hidden">
        <div className="p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <span className="icon-wiggle anim-bob w-11 h-11 rounded-2xl bg-gradient-to-br from-indigo-400 to-indigo-600 text-white flex items-center justify-center shadow-md shrink-0">
              <BarChart3 className="w-6 h-6" />
            </span>
            <div>
              <h2 className="text-lg font-black text-slate-900">
                {isAr ? 'التقرير المالي الشامل لسنتين (24 شهراً)' : 'Rapport financier global sur 2 ans (24 mois)'}
              </h2>
              <p className="text-xs text-slate-600 font-medium">
                {monthLabel(report.startKey)} → {monthLabel(report.endKey)}
                {' · '}
                {isAr ? `${report.withData.length} شهراً مدوَّناً، ${report.closedCount} مغلقاً` : `${report.withData.length} mois saisis, ${report.closedCount} clôturés`}
              </p>
            </div>
          </div>
          <button type="button" onClick={() => window.print()}
            className="no-print flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold cursor-pointer hover:bg-slate-200 self-start">
            <Printer className="w-4 h-4" /> {isAr ? 'طباعة' : 'Imprimer'}
          </button>
        </div>

        <div className="p-5 space-y-6">
          {/* Plain-language summary */}
          <div className="p-4 rounded-xl bg-indigo-50 border border-indigo-100 text-sm font-semibold text-indigo-950 leading-relaxed">
            {isAr
              ? `خلاصة بسيطة: في ${report.withData.length} شهراً مدوَّناً، توصّلت الإقامة بمبلغ ${money(report.totalIncome)} د.م وصرفت ${money(report.totalExpenses)} د.م، فكانت النتيجة ${report.totalIncome - report.totalExpenses >= 0 ? 'فائضاً' : 'عجزاً'} قدره ${money(Math.abs(report.totalIncome - report.totalExpenses))} د.م. الرصيد في نهاية الفترة: ${money(report.finalBalance)} د.م.`
              : `En clair : sur ${report.withData.length} mois saisis, la résidence a encaissé ${money(report.totalIncome)} DH et dépensé ${money(report.totalExpenses)} DH, soit un ${report.totalIncome - report.totalExpenses >= 0 ? 'excédent' : 'déficit'} de ${money(Math.abs(report.totalIncome - report.totalExpenses))} DH. Solde en fin de période : ${money(report.finalBalance)} DH.`}
          </div>

          {/* KPIs */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-100">
              <div className="text-[11px] font-bold text-emerald-800">{isAr ? 'مجموع المداخيل' : 'Total recettes'}</div>
              <div className="mt-1 text-lg font-black text-emerald-800">{money(report.totalIncome)}</div>
              <div className="text-[11px] text-emerald-700 font-medium mt-0.5">
                {isAr ? 'المتوسط الشهري' : 'Moy. mensuelle'}: {money(report.withData.length ? report.totalIncome / report.withData.length : 0)}
              </div>
            </div>
            <div className="p-4 rounded-xl bg-rose-50 border border-rose-100">
              <div className="text-[11px] font-bold text-rose-800">{isAr ? 'مجموع المصاريف' : 'Total dépenses'}</div>
              <div className="mt-1 text-lg font-black text-rose-700">{money(report.totalExpenses)}</div>
              <div className="text-[11px] text-rose-700 font-medium mt-0.5">
                {isAr ? 'المتوسط الشهري' : 'Moy. mensuelle'}: {money(report.withData.length ? report.totalExpenses / report.withData.length : 0)}
              </div>
            </div>
            <div className="p-4 rounded-xl bg-indigo-50 border border-indigo-100">
              <div className="text-[11px] font-bold text-indigo-800">{isAr ? 'النتيجة الصافية' : 'Résultat net'}</div>
              <div className={`mt-1 text-lg font-black ${report.totalIncome - report.totalExpenses >= 0 ? 'text-indigo-800' : 'text-rose-700'}`}>
                {money(report.totalIncome - report.totalExpenses)}
              </div>
              <div className="text-[11px] text-indigo-700 font-medium mt-0.5">
                {isAr ? `${report.deficitMonths} أشهر بعجز` : `${report.deficitMonths} mois en déficit`}
              </div>
            </div>
            <div className="p-4 rounded-xl bg-gradient-to-br from-emerald-800 to-emerald-950 text-white">
              <div className="text-[11px] font-bold text-emerald-100">{isAr ? 'الرصيد في نهاية الفترة' : 'Solde fin de période'}</div>
              <div className="mt-1 text-lg font-black">{money(report.finalBalance)}</div>
              <div className="text-[11px] text-emerald-100 font-medium mt-0.5">DH</div>
            </div>
          </div>

          {/* Year over year */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {[
              { label: isAr ? 'السنة الأولى (12 شهراً)' : 'Année 1 (12 mois)', inc: report.y1Income, exp: report.y1Expenses },
              { label: isAr ? 'السنة الثانية (12 شهراً)' : 'Année 2 (12 mois)', inc: report.y2Income, exp: report.y2Expenses }
            ].map((y, idx) => (
              <div key={idx} className="p-4 rounded-xl border border-slate-200">
                <div className="text-sm font-black text-slate-800 mb-2">{y.label}</div>
                <div className="flex justify-between text-xs font-bold"><span className="text-slate-500">{isAr ? 'مداخيل' : 'Recettes'}</span><span className="text-emerald-700">{money(y.inc)}</span></div>
                <div className="flex justify-between text-xs font-bold mt-1"><span className="text-slate-500">{isAr ? 'مصاريف' : 'Dépenses'}</span><span className="text-rose-600">{money(y.exp)}</span></div>
                <div className="flex justify-between text-xs font-black mt-2 pt-2 border-t border-slate-100"><span className="text-slate-700">{isAr ? 'الصافي' : 'Net'}</span><span className={y.inc - y.exp >= 0 ? 'text-emerald-800' : 'text-rose-600'}>{money(y.inc - y.exp)}</span></div>
                {idx === 1 && report.y1Income + report.y1Expenses > 0 && (
                  <div className="mt-2 text-[11px] font-bold text-slate-600">
                    {isAr ? 'تغير المداخيل' : 'Recettes'}: {pct(report.y2Income, report.y1Income) >= 0 ? '+' : ''}{pct(report.y2Income, report.y1Income).toFixed(1)}%
                    {' · '}
                    {isAr ? 'تغير المصاريف' : 'Dépenses'}: {pct(report.y2Expenses, report.y1Expenses) >= 0 ? '+' : ''}{pct(report.y2Expenses, report.y1Expenses).toFixed(1)}%
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Chart */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-black text-slate-900">{isAr ? 'المداخيل مقابل المصاريف شهرياً' : 'Recettes vs dépenses par mois'}</h3>
              <div className="flex items-center gap-3 text-[11px] font-bold">
                <span className="flex items-center gap-1"><i className="w-2.5 h-2.5 rounded-sm bg-emerald-500 inline-block" />{isAr ? 'مداخيل' : 'Recettes'}</span>
                <span className="flex items-center gap-1"><i className="w-2.5 h-2.5 rounded-sm bg-rose-500 inline-block" />{isAr ? 'مصاريف' : 'Dépenses'}</span>
              </div>
            </div>
            <div className="overflow-x-auto pb-1">
              <div className="flex items-end gap-1.5 min-w-[760px] h-40 px-1" dir="ltr">
                {report.rows.map(r => (
                  <button
                    key={r.key} type="button" onClick={() => handleChangeMonth(r.key)}
                    title={`${monthLabel(r.key)} — ${money(r.income)} / ${money(r.expenses)}`}
                    className="group flex-1 flex flex-col items-center justify-end h-full cursor-pointer"
                  >
                    <div className="flex items-end gap-0.5 h-32 w-full justify-center">
                      <div className="w-2 sm:w-2.5 rounded-t bg-emerald-500 group-hover:bg-emerald-600 transition-all" style={{ height: `${(r.income / report.maxBar) * 100}%`, minHeight: r.income > 0 ? 3 : 0 }} />
                      <div className="w-2 sm:w-2.5 rounded-t bg-rose-500 group-hover:bg-rose-600 transition-all" style={{ height: `${(r.expenses / report.maxBar) * 100}%`, minHeight: r.expenses > 0 ? 3 : 0 }} />
                    </div>
                    <span className={`mt-1 text-[9px] font-bold ${r.key === monthKey ? 'text-emerald-700' : 'text-slate-500'}`}>{shortMonth(r.key)}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Categories */}
          {report.catList.length > 0 && (
            <div>
              <h3 className="text-sm font-black text-slate-900 mb-3">{isAr ? 'توزيع المصاريف حسب البنود' : 'Répartition des dépenses par poste'}</h3>
              <div className="space-y-2">
                {report.catList.map(([k, v]) => {
                  const meta = CATEGORY_LABELS[k] || CATEGORY_LABELS.unclassified;
                  const share = report.totalExpenses > 0 ? (v / report.totalExpenses) * 100 : 0;
                  return (
                    <div key={k}>
                      <div className="flex justify-between text-xs font-bold text-slate-700 mb-1">
                        <span>{isAr ? meta.ar : meta.fr}</span>
                        <span>{money(v)} <span className="text-slate-400">({share.toFixed(1)}%)</span></span>
                      </div>
                      <div className="h-2.5 rounded-full bg-slate-100 overflow-hidden">
                        <div className={`h-full rounded-full ${meta.bar}`} style={{ width: `${Math.min(100, share)}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Insights */}
          {report.withData.length > 0 && (
            <div className="p-4 rounded-xl bg-amber-50 border border-amber-100 space-y-1.5">
              <div className="flex items-center gap-2 text-sm font-black text-amber-900"><Lightbulb className="w-4 h-4 anim-bob" />{isAr ? 'ملاحظات توضيحية' : 'Points clés'}</div>
              <ul className="text-xs font-semibold text-amber-900/90 space-y-1 list-disc ps-5">
                {report.bestIncome && report.bestIncome.income > 0 && (
                  <li>{isAr ? `أعلى مداخيل شهرية: ${monthLabel(report.bestIncome.key)} بمبلغ ${money(report.bestIncome.income)} د.م.` : `Meilleures recettes : ${monthLabel(report.bestIncome.key)} avec ${money(report.bestIncome.income)} DH.`}</li>
                )}
                {report.worstExpense && report.worstExpense.expenses > 0 && (
                  <li>{isAr ? `أعلى مصاريف شهرية: ${monthLabel(report.worstExpense.key)} بمبلغ ${money(report.worstExpense.expenses)} د.م.` : `Dépenses les plus élevées : ${monthLabel(report.worstExpense.key)} avec ${money(report.worstExpense.expenses)} DH.`}</li>
                )}
                {report.catList[0] && (
                  <li>{isAr ? `أكبر بند للمصاريف: ${(CATEGORY_LABELS[report.catList[0][0]] || CATEGORY_LABELS.unclassified).ar} (${(report.totalExpenses > 0 ? (report.catList[0][1] / report.totalExpenses) * 100 : 0).toFixed(1)}% من المجموع).` : `Premier poste de dépenses : ${(CATEGORY_LABELS[report.catList[0][0]] || CATEGORY_LABELS.unclassified).fr} (${(report.totalExpenses > 0 ? (report.catList[0][1] / report.totalExpenses) * 100 : 0).toFixed(1)}% du total).`}</li>
                )}
                <li>{isAr ? (report.deficitMonths === 0 ? 'لا يوجد أي شهر بعجز في الفترة المدوَّنة.' : `سُجّل عجز في ${report.deficitMonths} شهراً، يغطيه الرصيد المرحل.`) : (report.deficitMonths === 0 ? 'Aucun mois en déficit sur la période saisie.' : `${report.deficitMonths} mois en déficit, couverts par le solde reporté.`)}</li>
                {report.totalIncome > 0 && (
                  <li>{isAr ? `المصاريف تمثل ${((report.totalExpenses / report.totalIncome) * 100).toFixed(1)}% من المداخيل خلال الفترة.` : `Les dépenses représentent ${((report.totalExpenses / report.totalIncome) * 100).toFixed(1)}% des recettes sur la période.`}</li>
                )}
              </ul>
            </div>
          )}

          {/* 24-month table with change button per month */}
          <div>
            <h3 className="text-sm font-black text-slate-900 mb-2">{isAr ? 'جدول الأشهر الأربعة والعشرين' : 'Tableau des 24 mois'}</h3>
            <div className="overflow-x-auto rounded-xl border border-slate-200">
              <table className="w-full text-xs sm:text-sm">
                <thead>
                  <tr className="bg-slate-50 text-slate-600">
                    <th className="px-3 py-2 text-start font-bold">{isAr ? 'الشهر' : 'Mois'}</th>
                    <th className="px-3 py-2 text-end font-bold">{isAr ? 'المرحل' : 'Reporté'}</th>
                    <th className="px-3 py-2 text-end font-bold">{isAr ? 'مداخيل' : 'Recettes'}</th>
                    <th className="px-3 py-2 text-end font-bold">{isAr ? 'مصاريف' : 'Dépenses'}</th>
                    <th className="px-3 py-2 text-end font-bold">{isAr ? 'الرصيد' : 'Solde'}</th>
                    <th className="px-3 py-2 text-center font-bold">{isAr ? 'الحالة' : 'État'}</th>
                    <th className="px-3 py-2 text-center font-bold no-print">{isAr ? 'الإجراءات' : 'Actions'}</th>
                  </tr>
                </thead>
                <tbody>
                  {report.rows.map(r => (
                    <tr key={r.key} className={`border-t border-slate-100 ${r.key === monthKey ? 'bg-emerald-50' : ''} ${r.has ? '' : 'text-slate-400'}`}>
                      <td className="px-3 py-2 font-bold whitespace-nowrap">{monthLabel(r.key)}</td>
                      <td className="px-3 py-2 text-end">{money(r.opening)}</td>
                      <td className={`px-3 py-2 text-end font-bold ${r.has ? 'text-emerald-700' : ''}`}>{money(r.income)}</td>
                      <td className={`px-3 py-2 text-end font-bold ${r.has ? 'text-rose-600' : ''}`}>{money(r.expenses)}</td>
                      <td className={`px-3 py-2 text-end font-black ${r.has ? (r.closing >= 0 ? 'text-emerald-800' : 'text-rose-600') : ''}`}>{money(r.closing)}</td>
                      <td className="px-3 py-2 text-center">
                        {r.rec?.isClosed
                          ? <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[11px] font-black"><Lock className="w-3 h-3" />{isAr ? 'مغلق' : 'Clôturé'}</span>
                          : r.has
                            ? <span className="inline-flex px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 text-[11px] font-bold">{isAr ? 'مفتوح' : 'Ouvert'}</span>
                            : <span className="text-[11px]">—</span>}
                      </td>
                      <td className="px-3 py-2 text-center no-print">
                        {canEdit ? (
                          <div className="inline-flex items-center gap-1.5">
                            <button type="button" onClick={() => handleChangeMonth(r.key)}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-600 text-white text-[11px] font-black cursor-pointer hover:bg-emerald-700 transition-colors whitespace-nowrap">
                              <Pencil className="w-3 h-3" /> {r.has ? (isAr ? 'تغيير البيانات' : 'Modifier') : (isAr ? 'إدخال' : 'Saisir')}
                            </button>
                            {r.has && (
                              <button type="button" onClick={() => handleDeleteMonth(r.key)}
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-rose-50 text-rose-700 border border-rose-200 text-[11px] font-black cursor-pointer hover:bg-rose-600 hover:text-white transition-colors whitespace-nowrap">
                                <Trash2 className="w-3 h-3" /> {isAr ? 'مسح' : 'Supprimer'}
                              </button>
                            )}
                          </div>
                        ) : <span className="text-slate-300">—</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
