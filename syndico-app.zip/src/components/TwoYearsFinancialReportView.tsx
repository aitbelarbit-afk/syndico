import { RES } from '../config/residence';
import React, { useState, useMemo, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { 
  getAvailableMonthsList,
  computeMonthlyFinanceSummary,
  getCarriedForwardBalance,
  getMonthlyCarryoverChain,
  getNextMonthKey,
  ARABIC_MONTH_NAMES,
  FRENCH_MONTH_NAMES, splitExpensePillars } from '../utils/monthlyFinanceUtils';
import { exportMonthlyFinancialReportToPdf } from '../utils/monthlyPdfReportUtils';
import { 
  Scale, Printer, Download, FileSpreadsheet, ArrowLeft, RefreshCw, 
  CheckCircle2, TrendingUp, TrendingDown, Wallet, Sparkles, Building2, 
  Users, Briefcase, FileText, Wrench, ShieldCheck, ChevronDown, ChevronUp,
  Activity, BarChart3, PieChart as PieIcon, Layers, Calendar, ArrowRightLeft,
  Info, Check, Percent, Table as TableIcon, Edit3, History
} from 'lucide-react';
import { 
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, 
  Legend, PieChart, Pie, Cell, ComposedChart, Line, CartesianGrid
} from 'recharts';

export const TwoYearsFinancialReportView: React.FC = () => {
  const { 
    lang, currentUser, setActiveSection, buildings, apartments, 
    payments, expenses, manualMonthlyRecords, showToast, deleteManualMonthlyRecord 
  } = useApp();

  const isAr = lang === 'ar';
  const [selectedBuilding, setSelectedBuilding] = useState<string>('ALL');
  const [isGeneratingPdf, setIsGeneratingPdf] = useState<boolean>(false);
  const [exportSuccessMsg, setExportSuccessMsg] = useState<string | null>(null);
  const [isManualPanelOpen, setIsManualPanelOpen] = useState<boolean>(false);
  const [showCharts, setShowCharts] = useState<boolean>(true);
  const [showCarryoverTable, setShowCarryoverTable] = useState<boolean>(true);
  const [activeViewMode, setActiveViewMode] = useState<'standard' | 'print_preview'>('standard');

  // Strict 2-Year range: 2025-01 to 2026-12 (24 months)
  const startYear = '2025';
  const startMonth = '01';
  const endYear = '2026';
  const endMonth = '12';

  const periodMonthKeys = useMemo(() => {
    const list: string[] = [];
    for (let m = 1; m <= 12; m++) {
      list.push(`2025-${String(m).padStart(2, '0')}`);
    }
    for (let m = 1; m <= 12; m++) {
      list.push(`2026-${String(m).padStart(2, '0')}`);
    }
    return list;
  }, []);

  const syndicMonthlyFee = 4000;

  // Filtered payments strictly within 2025-2026
  const filteredPayments = useMemo(() => {
    return payments.filter(p => {
      const pDate = p.paymentDate || '';
      const pPeriod = p.periodMonth || '';
      const pMonthKey = (pDate && pDate.length >= 7) ? pDate.slice(0, 7) : (pPeriod && pPeriod.length >= 7 ? pPeriod.slice(0, 7) : '');
      if (!pMonthKey || !periodMonthKeys.includes(pMonthKey)) return false;

      if (selectedBuilding !== 'ALL') {
        const cleanBld = selectedBuilding.replace(/\s+/g, '').toUpperCase();
        const pClean = p.buildingCode.replace(/\s+/g, '').toUpperCase();
        if (cleanBld !== pClean) return false;
      }
      return true;
    });
  }, [payments, periodMonthKeys, selectedBuilding]);

  // Filtered expenses strictly within 2025-2026
  const filteredExpenses = useMemo(() => {
    return expenses.filter(e => {
      const eDate = e.date || '';
      const eMonthKey = (eDate && eDate.length >= 7) ? eDate.slice(0, 7) : '';
      if (!eMonthKey || !periodMonthKeys.includes(eMonthKey)) return false;

      if (selectedBuilding !== 'ALL') {
        const cleanBld = selectedBuilding.replace(/\s+/g, '').toUpperCase();
        const b = (e.buildingCode || 'ALL').replace(/\s+/g, '').toUpperCase();
        if (b !== 'ALL' && b !== cleanBld) return false;
      }
      return true;
    });
  }, [expenses, periodMonthKeys, selectedBuilding]);

  // Prior carryover before 2025-01
  const openingCarryoverBefore2025 = useMemo(() => {
    const res = getCarriedForwardBalance(payments, expenses, '2025-01', selectedBuilding, manualMonthlyRecords);
    return res.carriedBalance;
  }, [payments, expenses, selectedBuilding, manualMonthlyRecords]);

  // Manual Bilan Storage Key
  const storageKey = 'syndico_bilan_manual_2025_01_2026_12';

  const [manualBilan, setManualBilan] = useState(() => {
    try {
      const saved = localStorage.getItem(storageKey) || localStorage.getItem('syndico_bilan_2ans_manual_data');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed.report === 'number') {
          return parsed;
        }
      }
    } catch (e) {
      console.error(e);
    }
    return {
      isManualActive: false,
      report: 0,
      recettes: 0,
      salaires: 0,
      syndic: 0,
      avocat: 0,
      huissier: 0,
      droguerie: 0,
      savedAt: null as string | null
    };
  });

  // Inputs for manual form
  const [tempManualReport, setTempManualReport] = useState<string>(String(manualBilan.report || 0));
  const [tempManualRecettes, setTempManualRecettes] = useState<string>(String(manualBilan.recettes || 0));
  const [tempManualSalaires, setTempManualSalaires] = useState<string>(String(manualBilan.salaires || 0));
  const [tempManualSyndic, setTempManualSyndic] = useState<string>(String(manualBilan.syndic || 0));
  const [tempManualAvocat, setTempManualAvocat] = useState<string>(String(manualBilan.avocat || 0));
  const [tempManualHuissier, setTempManualHuissier] = useState<string>(String(manualBilan.huissier || 0));
  const [tempManualDroguerie, setTempManualDroguerie] = useState<string>(String(manualBilan.droguerie || 0));

  // Automatic baseline from database
  const systemPeriodPillars = useMemo(() => {
    let rep = openingCarryoverBefore2025;
    let rec = 0;
    let sal = 0;
    let syn = 0;
    let avo = 0;
    let hui = 0;
    let dro = 0;

    const periodManualRecords = (manualMonthlyRecords || []).filter(r => periodMonthKeys.includes(r.monthKey));
    const recordedKeys = new Set(periodManualRecords.map(r => r.monthKey));

    periodManualRecords.forEach(r => {
      rec += (r.totalIncome || 0);
      const bExp = r.breakdownExpenses || {};
      const pil = splitExpensePillars(r);
          const w = pil.workers; const s = pil.syndic; const l = pil.lawyer; const b = pil.bailiff; const d = pil.diverse;

      sal += w;
      syn += s;
      avo += l;
      hui += b;
      dro += d;
    });

    filteredPayments.forEach(p => {
      const pDate = p.paymentDate || '';
      const pPeriod = p.periodMonth || '';
      const m = (pDate && pDate.length >= 7) ? pDate.slice(0, 7) : (pPeriod && pPeriod.length >= 7 ? pPeriod.slice(0, 7) : '');
      if (m && !recordedKeys.has(m) && periodMonthKeys.includes(m)) {
        rec += (Number(p.amount) || 0);
      }
    });

    filteredExpenses.forEach(exp => {
      const m = (exp.date && exp.date.length >= 7) ? exp.date.slice(0, 7) : '';
      if (m && !recordedKeys.has(m) && periodMonthKeys.includes(m)) {
        const amt = Number(exp.amount) || 0;
        const cat = exp.category;
        const title = (exp.title || '').toLowerCase();

        if (cat === 'worker_salaries' || cat === 'security_company' || title.includes('حراس') || title.includes('أجر') || title.includes('راتب')) {
          sal += amt;
        } else if (cat === 'syndic_fees' || title.includes('سانديك') || title.includes('syndic')) {
          syn += amt;
        } else if (cat === 'lawyer_fees' || title.includes('محام') || title.includes('avocat')) {
          avo += amt;
        } else if (cat === 'bailiff_fees' || title.includes('مفوض') || title.includes('huissier')) {
          hui += amt;
        } else {
          dro += amt;
        }
      }
    });

    // لا تُضاف أي مبالغ افتراضية للأشهر غير المدوَّنة: التقرير يعكس فقط ما سُجّل فعلاً

    const totalDisp = rep + rec;
    const totalExp = sal + syn + avo + hui + dro;
    const solde = totalDisp - totalExp;

    return {
      report: rep,
      recettes: rec,
      salaires: sal,
      syndic: syn,
      avocat: avo,
      huissier: hui,
      droguerie: dro,
      totalDisponible: totalDisp,
      depenses: totalExp,
      soldeRestant: solde
    };
  }, [openingCarryoverBefore2025, manualMonthlyRecords, periodMonthKeys, filteredPayments, filteredExpenses]);

  // Handle Save Manual Bilan
  const handleSaveManual = () => {
    const rep = Number(tempManualReport) || 0;
    const rec = Number(tempManualRecettes) || 0;
    const sal = Number(tempManualSalaires) || 0;
    const syn = Number(tempManualSyndic) || 0;
    const avo = Number(tempManualAvocat) || 0;
    const hui = Number(tempManualHuissier) || 0;
    const dro = Number(tempManualDroguerie) || 0;

    const data = {
      isManualActive: true,
      report: rep,
      recettes: rec,
      salaires: sal,
      syndic: syn,
      avocat: avo,
      huissier: hui,
      droguerie: dro,
      savedAt: new Date().toISOString()
    };

    setManualBilan(data);
    try {
      localStorage.setItem(storageKey, JSON.stringify(data));
      localStorage.setItem('syndico_bilan_2ans_manual_data', JSON.stringify(data));
    } catch (e) {
      console.error(e);
    }
    if (showToast) {
      showToast(isAr ? 'تم حفظ بيانات السنتين 2025 و 2026 بنجاح' : 'Bilan 2025-2026 enregistré avec succès', { type: 'success' });
    }
  };

  const handleResetToAuto = () => {
    const data = {
      isManualActive: false,
      report: systemPeriodPillars.report,
      recettes: systemPeriodPillars.recettes,
      salaires: systemPeriodPillars.salaires,
      syndic: systemPeriodPillars.syndic,
      avocat: systemPeriodPillars.avocat,
      huissier: systemPeriodPillars.huissier,
      droguerie: systemPeriodPillars.droguerie,
      savedAt: null
    };
    setManualBilan(data);
    setTempManualReport(String(systemPeriodPillars.report));
    setTempManualRecettes(String(systemPeriodPillars.recettes));
    setTempManualSalaires(String(systemPeriodPillars.salaires));
    setTempManualSyndic(String(systemPeriodPillars.syndic));
    setTempManualAvocat(String(systemPeriodPillars.avocat));
    setTempManualHuissier(String(systemPeriodPillars.huissier));
    setTempManualDroguerie(String(systemPeriodPillars.droguerie));
    try {
      localStorage.removeItem(storageKey);
    } catch (e) {
      console.error(e);
    }
    if (showToast) {
      showToast(isAr ? 'تمت استعادة الحساب التلقائي من قاعدة البيانات' : 'Calcul automatique rétabli', { type: 'info' });
    }
  };

  // Master Consolidated Statement
  const masterStatement = useMemo(() => {
    let rep = 0;
    let rec = 0;
    let sal = 0;
    let syn = 0;
    let avo = 0;
    let hui = 0;
    let dro = 0;

    if (manualBilan.isManualActive) {
      rep = manualBilan.report;
      rec = manualBilan.recettes;
      sal = manualBilan.salaires;
      syn = manualBilan.syndic;
      avo = manualBilan.avocat;
      hui = manualBilan.huissier;
      dro = manualBilan.droguerie;
    } else {
      rep = systemPeriodPillars.report;
      rec = systemPeriodPillars.recettes;
      sal = systemPeriodPillars.salaires;
      syn = systemPeriodPillars.syndic;
      avo = systemPeriodPillars.avocat;
      hui = systemPeriodPillars.huissier;
      dro = systemPeriodPillars.droguerie;
    }

    const totalExp = sal + syn + avo + hui + dro;
    const totalDisp = rep + rec;
    const soldeRestant = totalDisp - totalExp;

    const calcPct = (v: number) => totalExp > 0 ? Number(((v / totalExp) * 100).toFixed(1)) : 0;

    return {
      carriedBalance: rep,
      income: rec,
      workerSalaries: sal,
      syndicFees: syn,
      lawyerFees: avo,
      bailiffFees: hui,
      diverseExpenses: dro,
      totalIncomeWithCarried: totalDisp,
      totalExpenses: totalExp,
      remainingBalance: soldeRestant,
      workerSalariesPct: calcPct(sal),
      syndicFeesPct: calcPct(syn),
      lawyerFeesPct: calcPct(avo),
      bailiffFeesPct: calcPct(hui),
      diverseExpensesPct: calcPct(dro)
    };
  }, [manualBilan, systemPeriodPillars]);

  // Year 2025 vs Year 2026 In-depth Comparative Pillars
  const twoYearsComparison = useMemo(() => {
    const months2025 = periodMonthKeys.filter(k => k.startsWith('2025'));
    const months2026 = periodMonthKeys.filter(k => k.startsWith('2026'));

    const calcYear = (mKeys: string[], startingRep: number) => {
      let rec = 0;
      let sal = 0;
      let syn = 0;
      let avo = 0;
      let hui = 0;
      let dro = 0;

      if (manualBilan.isManualActive) {
        const ratio = (mKeys.length || 12) / 24;
        rec = Math.round(manualBilan.recettes * ratio);
        sal = Math.round(manualBilan.salaires * ratio);
        syn = Math.round(manualBilan.syndic * ratio);
        avo = Math.round(manualBilan.avocat * ratio);
        hui = Math.round(manualBilan.huissier * ratio);
        dro = Math.round(manualBilan.droguerie * ratio);
      } else {
        const keysSet = new Set(mKeys);
        const manRecs = (manualMonthlyRecords || []).filter(r => keysSet.has(r.monthKey));
        const manKeys = new Set(manRecs.map(r => r.monthKey));

        manRecs.forEach(r => {
          rec += (r.totalIncome || 0);
          const b = r.breakdownExpenses || {};
          const pil = splitExpensePillars(r);
          const w = pil.workers; const s = pil.syndic; const l = pil.lawyer; const bh = pil.bailiff; const d = pil.diverse;
          sal += w;
          syn += s;
          avo += l;
          hui += bh;
          dro += d;
        });

        filteredPayments.forEach(p => {
          const d = p.paymentDate || p.periodMonth || '';
          const m = d.slice(0, 7);
          if (m && keysSet.has(m) && !manKeys.has(m)) {
            rec += (Number(p.amount) || 0);
          }
        });

        filteredExpenses.forEach(exp => {
          const m = (exp.date || '').slice(0, 7);
          if (m && keysSet.has(m) && !manKeys.has(m)) {
            const amt = Number(exp.amount) || 0;
            const cat = exp.category;
            const title = (exp.title || '').toLowerCase();
            if (cat === 'worker_salaries' || cat === 'security_company' || title.includes('حراس') || title.includes('أجر')) {
              sal += amt;
            } else if (cat === 'syndic_fees' || title.includes('سانديك')) {
              syn += amt;
            } else if (cat === 'lawyer_fees' || title.includes('محام')) {
              avo += amt;
            } else if (cat === 'bailiff_fees' || title.includes('مفوض')) {
              hui += amt;
            } else {
              dro += amt;
            }
          }
        });

      }

      const exp = sal + syn + avo + hui + dro;
      const disp = startingRep + rec;
      const solde = disp - exp;

      const calcPct = (v: number) => exp > 0 ? Number(((v / exp) * 100).toFixed(1)) : 0;

      return {
        report: startingRep,
        recettes: rec,
        salaires: sal,
        syndic: syn,
        avocat: avo,
        huissier: hui,
        droguerie: dro,
        totalDisponible: disp,
        totalExpenses: exp,
        soldeRestant: solde,
        salairesPct: calcPct(sal),
        syndicPct: calcPct(syn),
        avocatPct: calcPct(avo),
        huissierPct: calcPct(hui),
        drogueriePct: calcPct(dro)
      };
    };

    const y2025 = calcYear(months2025, masterStatement.carriedBalance);
    const y2026 = calcYear(months2026, y2025.soldeRestant);

    const growthRecettes = y2025.recettes > 0 ? Number((((y2026.recettes - y2025.recettes) / y2025.recettes) * 100).toFixed(1)) : 0;
    const growthDepenses = y2025.totalExpenses > 0 ? Number((((y2026.totalExpenses - y2025.totalExpenses) / y2025.totalExpenses) * 100).toFixed(1)) : 0;
    const growthSolde = y2025.soldeRestant !== 0 ? Number((((y2026.soldeRestant - y2025.soldeRestant) / Math.abs(y2025.soldeRestant)) * 100).toFixed(1)) : 0;

    const comparativeBarData = [
      {
        metric: isAr ? 'المداخيل' : 'Recettes',
        y2025: y2025.recettes,
        y2026: y2026.recettes,
      },
      {
        metric: isAr ? 'المصاريف' : 'Dépenses',
        y2025: y2025.totalExpenses,
        y2026: y2026.totalExpenses,
      },
      {
        metric: isAr ? 'إجمالي السيولة' : 'Disponible',
        y2025: y2025.totalDisponible,
        y2026: y2026.totalDisponible,
      },
      {
        metric: isAr ? 'الباقي الصافي' : 'Solde Net',
        y2025: y2025.soldeRestant,
        y2026: y2026.soldeRestant,
      }
    ];

    const pillarsComparativeBarData = [
      {
        poste: isAr ? 'أجور العمال' : 'Salaires ouvriers',
        y2025: y2025.salaires,
        y2026: y2026.salaires,
      },
      {
        poste: isAr ? 'أجرة الوكيل' : 'Honoraires Syndic',
        y2025: y2025.syndic,
        y2026: y2026.syndic,
      },
      {
        poste: isAr ? 'أتعاب المحامي' : 'Avocat',
        y2025: y2025.avocat,
        y2026: y2026.avocat,
      },
      {
        poste: isAr ? 'مفوض قضائي' : 'Huissier',
        y2025: y2025.huissier,
        y2026: y2026.huissier,
      },
      {
        poste: isAr ? 'عقاقير ومختلفة' : 'Droguerie & Divers',
        y2025: y2025.droguerie,
        y2026: y2026.droguerie,
      },
    ];

    return {
      y2025,
      y2026,
      growthRecettes,
      growthDepenses,
      growthSolde,
      comparativeBarData,
      pillarsComparativeBarData
    };
  }, [periodMonthKeys, manualBilan, manualMonthlyRecords, filteredPayments, filteredExpenses, masterStatement.carriedBalance, isAr]);

  // 24-Month Chronological Evolution Data for Recharts ComposedChart
  const monthly24TrendData = useMemo(() => {
    let runningBalance = masterStatement.carriedBalance;

    return periodMonthKeys.map(mKey => {
      const [y, m] = mKey.split('-');
      const mNameAr = `${ARABIC_MONTH_NAMES[m] || m} ${y}`;
      const mNameFr = `${FRENCH_MONTH_NAMES[m] || m} ${y}`;

      const manual = manualMonthlyRecords?.find(r => r.monthKey === mKey);
      let mInc = 0;
      let mExp = 0;

      if (manual) {
        mInc = manual.totalIncome ?? 0;
        mExp = manual.totalExpenses ?? 0;
      } else {
        mInc = payments
          .filter(p => {
            const d = p.paymentDate || p.periodMonth || '';
            if (!d.startsWith(mKey)) return false;
            if (selectedBuilding !== 'ALL') {
              return p.buildingCode.replace(/\s+/g, '').toUpperCase() === selectedBuilding.replace(/\s+/g, '').toUpperCase();
            }
            return true;
          })
          .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);

        mExp = expenses
          .filter(e => {
            const d = e.date || '';
            if (!d.startsWith(mKey)) return false;
            if (selectedBuilding !== 'ALL') {
              const b = (e.buildingCode || 'ALL').replace(/\s+/g, '').toUpperCase();
              return b === 'ALL' || b === selectedBuilding.replace(/\s+/g, '').toUpperCase();
            }
            return true;
          })
          .reduce((sum, e) => sum + (Number(e.amount) || 0), 0);

      }

      const mNet = mInc - mExp;
      const closing = runningBalance + mNet;

      const item = {
        monthKey: mKey,
        month: isAr ? (ARABIC_MONTH_NAMES[m] || m).split(' ')[0] : (FRENCH_MONTH_NAMES[m] || m).slice(0, 3),
        year: y,
        label: isAr ? mNameAr : mNameFr,
        openingBalance: runningBalance,
        income: mInc,
        expenses: mExp,
        balance: mNet,
        closingBalance: closing,
        isClosingSurplus: closing >= 0
      };

      runningBalance = closing;
      return item;
    });
  }, [periodMonthKeys, masterStatement.carriedBalance, manualMonthlyRecords, payments, expenses, selectedBuilding, isAr]);

  // Donut data of 5 pillars
  const pillarsDonutData = useMemo(() => [
    { name: isAr ? 'أجور العمال' : 'Salaires ouvriers', value: masterStatement.workerSalaries, pct: masterStatement.workerSalariesPct, fill: '#0284c7' },
    { name: isAr ? 'أجرة الوكيل ونائبه' : 'Honoraires Syndic', value: masterStatement.syndicFees, pct: masterStatement.syndicFeesPct, fill: '#d97706' },
    { name: isAr ? 'أتعاب المحامي' : 'Avocat', value: masterStatement.lawyerFees, pct: masterStatement.lawyerFeesPct, fill: '#7c3aed' },
    { name: isAr ? 'أتعاب مفوض قضائي' : 'Huissier', value: masterStatement.bailiffFees, pct: masterStatement.bailiffFeesPct, fill: '#db2777' },
    { name: isAr ? 'عقاقير ومصاريف مختلفة' : 'Droguerie & Divers', value: masterStatement.diverseExpenses, pct: masterStatement.diverseExpensesPct, fill: '#ea580c' },
  ].filter(d => d.value > 0), [masterStatement, isAr]);

  // Cashflow flow data
  const cashflowData = useMemo(() => [
    { name: isAr ? 'المنقول' : 'Report', amount: masterStatement.carriedBalance, fill: '#6366f1' },
    { name: isAr ? 'المداخيل' : 'Recettes', amount: masterStatement.income, fill: '#059669' },
    { name: isAr ? 'السيولة (1+2)' : 'Disponible', amount: masterStatement.totalIncomeWithCarried, fill: '#0891b2' },
    { name: isAr ? 'المصاريف' : 'Dépenses', amount: masterStatement.totalExpenses, fill: '#dc2626' },
    { name: isAr ? 'الباقي الصافي' : 'Solde', amount: masterStatement.remainingBalance, fill: masterStatement.remainingBalance >= 0 ? '#10b981' : '#f43f5e' },
  ], [masterStatement, isAr]);

  // Handlers
  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPdf = async () => {
    setIsGeneratingPdf(true);
    setExportSuccessMsg(null);
    try {
      const success = await exportMonthlyFinancialReportToPdf(
        'two-years-report-page-container',
        'Bilan_2Ans_2025_et_2026',
        'custom_period'
      );
      if (success) {
        setExportSuccessMsg(isAr ? 'تم تحميل ملف PDF بنجاح!' : 'Rapport PDF généré avec succès !');
        setTimeout(() => setExportSuccessMsg(null), 4000);
      }
    } catch (e) {
      console.error(e);
      if (showToast) showToast(isAr ? 'حدث خطأ أثناء إنشاء PDF' : 'Erreur génération PDF', { type: 'error' });
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const handleDownloadCSV = () => {
    const rows = [
      ['N°', 'Rubrique', 'Exercice 2025 (DH)', 'Exercice 2026 (DH)', 'Total Consolidé 2 Ans (DH)', 'Part / Évolution'],
      ['1', 'Report Initial', twoYearsComparison.y2025.report, twoYearsComparison.y2026.report, masterStatement.carriedBalance, 'Solde Antérieur'],
      ['2', 'Recettes', twoYearsComparison.y2025.recettes, twoYearsComparison.y2026.recettes, masterStatement.income, `${twoYearsComparison.growthRecettes}%`],
      ['3', 'Salaires Ouvriers', twoYearsComparison.y2025.salaires, twoYearsComparison.y2026.salaires, masterStatement.workerSalaries, `${masterStatement.workerSalariesPct}%`],
      ['4', 'Honoraires Syndic & Adjoint', twoYearsComparison.y2025.syndic, twoYearsComparison.y2026.syndic, masterStatement.syndicFees, `${masterStatement.syndicFeesPct}%`],
      ['5', 'Honoraires Avocat', twoYearsComparison.y2025.avocat, twoYearsComparison.y2026.avocat, masterStatement.lawyerFees, `${masterStatement.lawyerFeesPct}%`],
      ['6', 'Huissier de Justice', twoYearsComparison.y2025.huissier, twoYearsComparison.y2026.huissier, masterStatement.bailiffFees, `${masterStatement.bailiffFeesPct}%`],
      ['7', 'Droguerie, Matériel & Divers', twoYearsComparison.y2025.droguerie, twoYearsComparison.y2026.droguerie, masterStatement.diverseExpenses, `${masterStatement.diverseExpensesPct}%`],
      ['8', 'Total Disponible (1+2)', twoYearsComparison.y2025.totalDisponible, twoYearsComparison.y2026.totalDisponible, masterStatement.totalIncomeWithCarried, '-'],
      ['9', 'Total Dépenses (3 à 7)', twoYearsComparison.y2025.totalExpenses, twoYearsComparison.y2026.totalExpenses, masterStatement.totalExpenses, `${twoYearsComparison.growthDepenses}%`],
      ['10', 'Solde Restant Final (8-9)', twoYearsComparison.y2025.soldeRestant, twoYearsComparison.y2026.soldeRestant, masterStatement.remainingBalance, `${twoYearsComparison.growthSolde}%`],
      [],
      ['Mois', 'Année', 'Report Début (DH)', 'Recettes (DH)', 'Dépenses (DH)', 'Solde Net (DH)', 'Report Fin (DH)'],
      ...monthly24TrendData.map(m => [m.label, m.year, m.openingBalance, m.income, m.expenses, m.balance, m.closingBalance])
    ];

    const csvContent = '\uFEFF' + rows.map(e => e.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `Bilan_2Ans_2025_2026_Al.csv`;
    link.click();
    URL.revokeObjectURL(link.href);
  };

  const todayStr = new Date().toISOString().slice(0, 10);

  return (
    <div className="space-y-6 pb-12">
      {/* ========================================================================= */}
      {/* SCREEN CONTROLS & ACTION HEADER (Hidden in print)                          */}
      {/* ========================================================================= */}
      <div className="no-print bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <button 
                type="button"
                onClick={() => setActiveSection('dashboard')}
                className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
                title={isAr ? 'الرجوع إلى لوحة التحكم' : 'Retour au tableau de bord'}
              >
                <ArrowLeft className="w-5 h-5 rtl:rotate-180" />
              </button>
              <div className="icon-wiggle anim-bob p-2.5 rounded-2xl gradient-flow text-white shadow-md">
                <Scale className="w-5 h-5" />
              </div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900">
                {isAr ? 'صفحة التقرير المالي الشامل لسنتي 2025 و 2026' : 'Rapport Financier Global des 2 Dernières Années (2025 et 2026)'}
              </h1>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 font-black text-[11px] border border-emerald-300">
                24 {isAr ? 'شهراً معتمداً' : 'mois'}
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-600">
              {isAr 
                ? 'الإقامة • جميع العمارات (جميع الشقق) • تحليل مقارن ورسوم بيانية Recharts وجاهزية تامة للطباعة A4'
                : 'Résidence • tous les immeubles • Analyse comparative & Graphiques Recharts'}
            </p>
          </div>

          {/* Action Toolbar */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-all shadow-xs cursor-pointer border border-slate-300"
              title={isAr ? 'طباعة التقرير بصيغة A4' : 'Imprimer en format A4'}
            >
              <Printer className="w-4 h-4 text-slate-700" />
              <span>{isAr ? 'طباعة A4' : 'Imprimer'}</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white text-xs font-black transition-all shadow-sm shadow-rose-600/30 cursor-pointer disabled:opacity-50"
              title={isAr ? 'تحميل التقرير كملف PDF عالي الجودة' : 'Télécharger le rapport en PDF'}
            >
              {isGeneratingPdf ? (
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <Download className="w-4 h-4 text-rose-200" />
              )}
              <span>{isGeneratingPdf ? (isAr ? 'جاري التحميل...' : 'Génération...') : (isAr ? 'تصدير PDF' : 'PDF')}</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadCSV}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
              title={isAr ? 'تصدير البيانات إلى ملف Excel CSV' : 'Exporter les données en CSV'}
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
              <span>{isAr ? 'إكسيل CSV' : 'CSV'}</span>
            </button>

            <button
              type="button"
              onClick={() => setIsManualPanelOpen(!isManualPanelOpen)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-black transition-all shadow-xs cursor-pointer border border-amber-400"
              title={isAr ? 'فتح نموذج الإدخال والتعديل اليدوي' : 'Modifier les chiffres manuellement'}
            >
              <Edit3 className="w-4 h-4" />
              <span>{isAr ? 'تعديل الأرقام يدوياً ✍️' : 'Saisie Manuelle'}</span>
            </button>
          </div>
        </div>

        {/* Filters and Notification */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 text-xs">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-bold text-slate-600 flex items-center gap-1">
              <Building2 className="w-3.5 h-3.5 text-indigo-600" />
              <span>{isAr ? 'نطاق التقرير:' : 'Périmètre :'}</span>
            </span>
            <select
              value={selectedBuilding}
              onChange={(e) => setSelectedBuilding(e.target.value)}
              className="px-3 py-1.5 text-xs font-bold rounded-xl border border-slate-200 bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="ALL">{isAr ? '🏢 كافة الإقامة (جميع العمارات • جميع الشقق)' : 'Toute la résidence (tous les immeubles • tous les lots)'}</option>
              {buildings.map(b => (
                <option key={b.id} value={b.code}>
                  {b.name} ({b.code})
                </option>
              ))}
            </select>

            <label className="flex items-center gap-1.5 cursor-pointer text-slate-700 font-bold bg-slate-50 px-2.5 py-1.5 rounded-xl border border-slate-200">
              <input 
                type="checkbox" 
                checked={showCharts} 
                onChange={(e) => setShowCharts(e.target.checked)} 
                className="rounded text-indigo-600"
              />
              <BarChart3 className="w-3.5 h-3.5 text-indigo-700" />
              <span>{isAr ? 'عرض الرسوم البيانية Recharts' : 'Graphiques Recharts'}</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer text-slate-700 font-bold bg-slate-50 px-2.5 py-1.5 rounded-xl border border-slate-200">
              <input 
                type="checkbox" 
                checked={showCarryoverTable} 
                onChange={(e) => setShowCarryoverTable(e.target.checked)} 
                className="rounded text-indigo-600"
              />
              <ArrowRightLeft className="w-3.5 h-3.5 text-emerald-700" />
              <span>{isAr ? 'جدول ترحيل الأرصدة (24 شهراً)' : 'Tableau 24 Mois'}</span>
            </label>
          </div>

          <div className="text-[11px] font-bold text-slate-600 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block animate-pulse" />
            <span>{isAr ? 'سجل معتمد وموثق قانونياً' : 'Données certifiées conformes'}</span>
            {exportSuccessMsg && (
              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-black animate-fade-in">
                {exportSuccessMsg}
              </span>
            )}
          </div>
        </div>

        {/* Manual Edit Drawer */}
        {isManualPanelOpen && (
          <div className="p-4 rounded-xl bg-amber-50/70 border-2 border-amber-300 space-y-4 animate-fade-in">
            <div className="flex items-center justify-between border-b border-amber-200 pb-2">
              <div className="flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-amber-800" />
                <h3 className="text-xs font-black text-amber-950">
                  {isAr ? 'تعديل أرقام الحصيلة يدوياً (الخانات السبع الأساسية) لسنتي 2025 و 2026:' : 'Saisie manuelle des 7 postes budgétaires (2025 et 2026) :'}
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleResetToAuto}
                  className="px-2.5 py-1 rounded-lg bg-white border border-amber-300 text-slate-700 hover:bg-amber-100 text-[11px] font-bold transition-all cursor-pointer"
                >
                  {isAr ? '↺ استعادة الحساب التلقائي' : '↺ Rétablir auto'}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5 text-xs">
              <div className="p-2 bg-white rounded-lg border border-indigo-200">
                <label className="text-[10px] font-bold text-indigo-900 block">1. المنقول (Report)</label>
                <input
                  type="number"
                  value={tempManualReport}
                  onChange={(e) => setTempManualReport(e.target.value)}
                  className="w-full mt-1 p-1 text-xs font-mono font-black border border-slate-200 rounded text-end"
                />
              </div>

              <div className="p-2 bg-white rounded-lg border border-emerald-200">
                <label className="text-[10px] font-bold text-emerald-900 block">2. المداخيل (Recettes)</label>
                <input
                  type="number"
                  value={tempManualRecettes}
                  onChange={(e) => setTempManualRecettes(e.target.value)}
                  className="w-full mt-1 p-1 text-xs font-mono font-black border border-slate-200 rounded text-end"
                />
              </div>

              <div className="p-2 bg-white rounded-lg border border-sky-200">
                <label className="text-[10px] font-bold text-sky-900 block">3. العمال (Salaires)</label>
                <input
                  type="number"
                  value={tempManualSalaires}
                  onChange={(e) => setTempManualSalaires(e.target.value)}
                  className="w-full mt-1 p-1 text-xs font-mono font-black border border-slate-200 rounded text-end"
                />
              </div>

              <div className="p-2 bg-white rounded-lg border border-amber-200">
                <label className="text-[10px] font-bold text-amber-900 block">4. السانديك (Syndic)</label>
                <input
                  type="number"
                  value={tempManualSyndic}
                  onChange={(e) => setTempManualSyndic(e.target.value)}
                  className="w-full mt-1 p-1 text-xs font-mono font-black border border-slate-200 rounded text-end"
                />
              </div>

              <div className="p-2 bg-white rounded-lg border border-purple-200">
                <label className="text-[10px] font-bold text-purple-900 block">5. المحامي (Avocat)</label>
                <input
                  type="number"
                  value={tempManualAvocat}
                  onChange={(e) => setTempManualAvocat(e.target.value)}
                  className="w-full mt-1 p-1 text-xs font-mono font-black border border-slate-200 rounded text-end"
                />
              </div>

              <div className="p-2 bg-white rounded-lg border border-rose-200">
                <label className="text-[10px] font-bold text-rose-900 block">6. المفوض (Huissier)</label>
                <input
                  type="number"
                  value={tempManualHuissier}
                  onChange={(e) => setTempManualHuissier(e.target.value)}
                  className="w-full mt-1 p-1 text-xs font-mono font-black border border-slate-200 rounded text-end"
                />
              </div>

              <div className="p-2 bg-white rounded-lg border border-orange-200">
                <label className="text-[10px] font-bold text-orange-900 block">7. العقاقير (Droguerie)</label>
                <input
                  type="number"
                  value={tempManualDroguerie}
                  onChange={(e) => setTempManualDroguerie(e.target.value)}
                  className="w-full mt-1 p-1 text-xs font-mono font-black border border-slate-200 rounded text-end"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-1">
              <span className="text-[11px] text-amber-900 font-bold">
                {isAr ? 'الخانات 8 و 9 و 10 يتم احتسابها تلقائياً بالمعادلات المحاسبية' : 'Les cases 8, 9 et 10 sont calculées automatiquement'}
              </span>
              <button
                type="button"
                onClick={handleSaveManual}
                className="px-4 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-black text-xs shadow-xs cursor-pointer"
              >
                💾 {isAr ? 'حفظ وتطبيق على التقرير' : 'Enregistrer'}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* PRINT & PDF CONTAINER (Wrapped with .pdf-page-block structure)            */}
      {/* ========================================================================= */}
      <div 
        id="two-years-report-page-container" 
        className="max-w-5xl mx-auto space-y-6 text-slate-900 font-sans print:p-0 print:border-none print:shadow-none"
      >
        {/* ========================================================================= */}
        {/* PAGE 1: RESIDENCE HEADER, 10-ITEM MASTER STATEMENT & CONSOLIDATED CHARTS  */}
        {/* ========================================================================= */}
        <div className="pdf-page-block print-avoid-break bg-white p-6 sm:p-8 rounded-2xl border-2 border-slate-300 shadow-sm space-y-5">
          {/* Official Residence Header */}
          <div className="border-b-2 border-[#0a8591] pb-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-start">
              <div className="space-y-1">
                <div className="text-[11px] font-extrabold text-slate-600 uppercase tracking-wider flex items-center justify-center sm:justify-start gap-1.5">
                  <span>المملكة المغربية</span>
                  <span>•</span>
                  <span></span>
                  <span>•</span>
                  <span>اتحاد الملاك المشتركين</span>
                </div>
                
                <h1 className="text-xl sm:text-2xl font-black text-[#0a8591] tracking-tight leading-tight">
                  {RES.fullNameAr}
                </h1>
                
                <div className="text-xs font-bold text-slate-700 flex items-center justify-center sm:justify-start gap-1.5">
                  <span>{RES.fullNameFr}</span>
                </div>
                <div className="text-[11px] text-slate-600 font-semibold">
                  {isAr ? 'جميع العمارات • جميع الشقق' : 'tous les immeubles • tous les lots'}
                </div>
              </div>

              <div className="p-3 sm:p-3.5 rounded-2xl bg-[#e9fbf8] border-2 border-[#0d5262] text-center sm:text-end shrink-0 shadow-2xs">
                <div className="text-[10px] font-extrabold text-[#0a8591] uppercase tracking-wider">
                  UN SEUL BILAN DES 2 DERNIÈRES ANNÉES (2025 ET 2026)
                </div>
                <div className="text-base sm:text-lg font-black text-[#0f172a] mt-0.5 font-mono">
                  {isAr ? 'الحصيلة المالية الشاملة لسنتي 2025 و 2026' : 'Bilan Financier Global 2025 - 2026'}
                </div>
                <div className="text-[10px] text-slate-600 mt-0.5 font-semibold">
                  {isAr ? `تاريخ الإصدار: ${todayStr}` : `Émis le: ${todayStr}`} • 24 {isAr ? 'شهراً' : 'mois'}
                </div>
              </div>
            </div>

            {selectedBuilding !== 'ALL' && (
              <div className="mt-2.5 px-3 py-1 rounded-xl bg-slate-100 text-xs font-bold text-slate-800 inline-flex items-center gap-1.5 border border-slate-200">
                <Building2 className="w-3.5 h-3.5 text-[#0a8591]" />
                <span>{isAr ? `نطاق التقرير المحدد: عمارة ${selectedBuilding}` : `Périmètre : Immeuble ${selectedBuilding}`}</span>
              </div>
            )}
          </div>

          {/* 5 KPI Summary Cards for the Consolidated 2-Year Period */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-xs">
            {/* 1. Report */}
            <div className="p-2.5 rounded-xl bg-indigo-50/80 border border-indigo-200">
              <div className="text-[10px] text-indigo-900 font-bold flex items-center justify-between">
                <span>1. {isAr ? 'المنقول (Report)' : 'Report initial'}</span>
                <History className="w-3.5 h-3.5 text-indigo-600" />
              </div>
              <div className={`text-base sm:text-lg font-black font-mono mt-1 ${masterStatement.carriedBalance >= 0 ? 'text-indigo-950' : 'text-rose-700'}`}>
                {masterStatement.carriedBalance >= 0 ? '+' : ''}{masterStatement.carriedBalance.toLocaleString()} <span className="text-[10px] font-sans font-normal">DH</span>
              </div>
              <div className="text-[9px] text-indigo-700 font-medium truncate mt-0.5">
                {isAr ? 'افتتاح 01/2025' : 'Début 2025'}
              </div>
            </div>

            {/* 2. Recettes */}
            <div className="p-2.5 rounded-xl bg-emerald-50/80 border border-emerald-200">
              <div className="text-[10px] text-emerald-900 font-bold flex items-center justify-between">
                <span>2. {isAr ? 'المداخيل (Recettes)' : 'Recettes (2 Ans)'}</span>
                <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
              </div>
              <div className="text-base sm:text-lg font-black font-mono mt-1 text-emerald-950">
                +{masterStatement.income.toLocaleString()} <span className="text-[10px] font-sans font-normal">DH</span>
              </div>
              <div className="text-[9px] text-emerald-700 font-medium truncate mt-0.5">
                {isAr ? 'مقبوضات 24 شهراً' : '24 mois encaissés'}
              </div>
            </div>

            {/* 3. Total Disponible */}
            <div className="p-2.5 rounded-xl bg-cyan-50/80 border border-cyan-200">
              <div className="text-[10px] text-cyan-900 font-bold flex items-center justify-between">
                <span>3. {isAr ? 'إجمالي السيولة (Disponible)' : 'Total Disponible'}</span>
                <Sparkles className="w-3.5 h-3.5 text-cyan-600" />
              </div>
              <div className="text-base sm:text-lg font-black font-mono mt-1 text-cyan-950">
                {masterStatement.totalIncomeWithCarried.toLocaleString()} <span className="text-[10px] font-sans font-normal">DH</span>
              </div>
              <div className="text-[9px] text-cyan-700 font-medium truncate mt-0.5">
                {isAr ? 'الخانة 1 + الخانة 2' : 'Case 1 + 2'}
              </div>
            </div>

            {/* 4. Total Dépenses */}
            <div className="p-2.5 rounded-xl bg-rose-50/80 border border-rose-200">
              <div className="text-[10px] text-rose-900 font-bold flex items-center justify-between">
                <span>4. {isAr ? 'مجموع المصاريف (Dépenses)' : 'Total Dépenses'}</span>
                <TrendingDown className="w-3.5 h-3.5 text-rose-600" />
              </div>
              <div className="text-base sm:text-lg font-black font-mono mt-1 text-rose-950">
                -{masterStatement.totalExpenses.toLocaleString()} <span className="text-[10px] font-sans font-normal">DH</span>
              </div>
              <div className="text-[9px] text-rose-700 font-medium truncate mt-0.5">
                {isAr ? 'النفقات المؤداة (100%)' : '100% des charges'}
              </div>
            </div>

            {/* 5. Solde Restant */}
            <div className={`p-2.5 rounded-xl border-2 ${
              masterStatement.remainingBalance >= 0 
                ? 'bg-emerald-100/70 border-emerald-400' 
                : 'bg-rose-100/70 border-rose-400'
            }`}>
              <div className="text-[10px] font-bold text-slate-800 flex items-center justify-between">
                <span>5. {isAr ? 'الباقي النهائي (Solde)' : 'Solde Restant'}</span>
                <Wallet className={`w-3.5 h-3.5 ${masterStatement.remainingBalance >= 0 ? 'text-emerald-700' : 'text-rose-700'}`} />
              </div>
              <div className={`text-base sm:text-lg font-black font-mono mt-1 ${masterStatement.remainingBalance >= 0 ? 'text-emerald-950' : 'text-rose-950'}`}>
                {masterStatement.remainingBalance >= 0 ? '+' : ''}{masterStatement.remainingBalance.toLocaleString()} <span className="text-[10px] font-sans font-normal">DH</span>
              </div>
              <div className="text-[9px] font-bold text-slate-700 truncate mt-0.5">
                {masterStatement.remainingBalance >= 0 ? (isAr ? '🟢 فائض مرحّل لـ 2027' : '🟢 Excédent reporté') : (isAr ? '🔴 عجز مرحّل' : '🔴 Déficit')}
              </div>
            </div>
          </div>

          {/* Master 10-Item Official Table */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg bg-[#0a8591] text-white flex items-center justify-center text-xs font-bold shadow-xs">
                  <TableIcon className="w-3.5 h-3.5" />
                </div>
                <h2 className="text-sm sm:text-base font-black text-slate-900">
                  {isAr 
                    ? 'الجدول المالي والمحاسباتي الرسمي المعتمد (الخانات العشر المحددة لسنتي 2025 و 2026)' 
                    : 'Tableau Financier Officiel de Synthèse des Deux Dernières Années (2025 et 2026)'}
                </h2>
              </div>
              <span className="text-[11px] font-mono font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-lg border border-slate-200">
                24 {isAr ? 'شهراً متتالياً' : 'Mois consécutifs'}
              </span>
            </div>

            <div className="overflow-x-auto rounded-xl border-2 border-slate-300 shadow-xs bg-white">
              <table className="w-full text-xs text-start border-collapse">
                <thead className="bg-slate-900 text-white font-black text-xs">
                  <tr>
                    <th className="p-2.5 text-center w-12 border-e border-slate-700">{isAr ? 'الرقم' : 'N°'}</th>
                    <th className="p-2.5 text-start min-w-[200px] border-e border-slate-700">{isAr ? 'البيان المحاسبي المعتمد' : 'Poste Budgétaire'}</th>
                    <th className="p-2.5 text-start min-w-[220px] hidden md:table-cell border-e border-slate-700">{isAr ? 'التفصيل والتوضيح' : 'Détails & Nature'}</th>
                    <th className="p-2.5 text-center min-w-[90px] border-e border-slate-700">{isAr ? 'النسبة (%)' : 'Part (%)'}</th>
                    <th className="p-2.5 text-end min-w-[130px]">{isAr ? 'المبلغ (درهم)' : 'Montant (DH)'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-mono">
                  {/* 1. Report */}
                  <tr className="bg-indigo-50/60 hover:bg-indigo-50 transition-colors">
                    <td className="p-2.5 text-center font-black text-indigo-900 border-e border-slate-200">1</td>
                    <td className="p-2.5 font-sans font-black text-indigo-950 border-e border-slate-200 flex items-center gap-2">
                      <History className="w-4 h-4 text-indigo-700" />
                      <span>{isAr ? 'المنقول الافتتاحي (Report)' : 'Report au Début de la Période (01/2025)'}</span>
                    </td>
                    <td className="p-2.5 font-sans text-slate-600 text-[11px] hidden md:table-cell border-e border-slate-200">
                      {isAr ? 'الرصيد المالي المنقول ببداية شهر يناير 2025' : 'Solde antérieur initial à reporter'}
                    </td>
                    <td className="p-2.5 text-center border-e border-slate-200 font-sans text-[11px] text-slate-500">—</td>
                    <td className="p-2.5 text-end font-black text-indigo-950 text-sm">
                      {masterStatement.carriedBalance.toLocaleString()} <span className="text-xs font-normal">DH</span>
                    </td>
                  </tr>

                  {/* 2. Recettes */}
                  <tr className="bg-emerald-50/40 hover:bg-emerald-50 transition-colors">
                    <td className="p-2.5 text-center font-black text-emerald-900 border-e border-slate-200">2</td>
                    <td className="p-2.5 font-sans font-black text-emerald-950 border-e border-slate-200 flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-emerald-600" />
                      <span>{isAr ? 'المداخيل (Recettes)' : 'Recettes des Deux Années (2025 + 2026)'}</span>
                    </td>
                    <td className="p-2.5 font-sans text-slate-600 text-[11px] hidden md:table-cell border-e border-slate-200">
                      {isAr ? 'مجموع مقبوضات واجبات السانديك الشهرية ومستحقات الملاك لـ 24 شهراً' : 'Cotisations de copropriété perçues sur 24 mois'}
                    </td>
                    <td className="p-2.5 text-center border-e border-slate-200 font-sans text-[11px] text-emerald-700 font-bold">100%</td>
                    <td className="p-2.5 text-end font-black text-emerald-900 text-sm">
                      +{masterStatement.income.toLocaleString()} <span className="text-xs font-normal">DH</span>
                    </td>
                  </tr>

                  {/* 3. Salaires */}
                  <tr className="hover:bg-slate-50 transition-colors">
                    <td className="p-2.5 text-center font-bold text-slate-700 border-e border-slate-200">3</td>
                    <td className="p-2.5 font-sans font-bold text-slate-900 border-e border-slate-200 flex items-center gap-2">
                      <Users className="w-4 h-4 text-sky-600" />
                      <span>{isAr ? 'أجور العمال (Salaires)' : 'Salaires des Ouvriers (Gardiens, Nettoyage, Jardinier)'}</span>
                    </td>
                    <td className="p-2.5 font-sans text-slate-600 text-[11px] hidden md:table-cell border-e border-slate-200">
                      {isAr ? 'مستحقات حراس الأمن، عمال النظافة، والبستاني (طيلة سنتين)' : 'Salaires du personnel permanent et gardiennage'}
                    </td>
                    <td className="p-2.5 text-center border-e border-slate-200">
                      <span className="px-2 py-0.5 rounded-md text-xs font-black bg-sky-100 text-sky-800 border border-sky-300">
                        {masterStatement.workerSalariesPct}%
                      </span>
                    </td>
                    <td className="p-2.5 text-end font-black text-rose-700 text-sm">
                      -{masterStatement.workerSalaries.toLocaleString()} <span className="text-xs font-normal">DH</span>
                    </td>
                  </tr>

                  {/* 4. Syndic */}
                  <tr className="hover:bg-slate-50 transition-colors">
                    <td className="p-2.5 text-center font-bold text-slate-700 border-e border-slate-200">4</td>
                    <td className="p-2.5 font-sans font-bold text-slate-900 border-e border-slate-200 flex items-center gap-2">
                      <Briefcase className="w-4 h-4 text-amber-600" />
                      <span>{isAr ? 'أجرة الوكيل ونائبه (Syndic)' : 'Honoraires du Syndic et de son Adjoint'}</span>
                    </td>
                    <td className="p-2.5 font-sans text-slate-600 text-[11px] hidden md:table-cell border-e border-slate-200">
                      {isAr ? 'مستحقات الإدارة والتسيير طبقاً للمادة 18 من القانون 18.00 (4,000 درهم/شهرياً)' : 'Gestion administrative et comptable légale (4.000 DH/mois)'}
                    </td>
                    <td className="p-2.5 text-center border-e border-slate-200">
                      <span className="px-2 py-0.5 rounded-md text-xs font-black bg-amber-100 text-amber-800 border border-amber-300">
                        {masterStatement.syndicFeesPct}%
                      </span>
                    </td>
                    <td className="p-2.5 text-end font-black text-rose-700 text-sm">
                      -{masterStatement.syndicFees.toLocaleString()} <span className="text-xs font-normal">DH</span>
                    </td>
                  </tr>

                  {/* 5. Avocat */}
                  <tr className="hover:bg-slate-50 transition-colors">
                    <td className="p-2.5 text-center font-bold text-slate-700 border-e border-slate-200">5</td>
                    <td className="p-2.5 font-sans font-bold text-slate-900 border-e border-slate-200 flex items-center gap-2">
                      <Scale className="w-4 h-4 text-purple-600" />
                      <span>{isAr ? 'أتعاب المحامي (Avocat)' : 'Honoraires de l\'Avocat'}</span>
                    </td>
                    <td className="p-2.5 font-sans text-slate-600 text-[11px] hidden md:table-cell border-e border-slate-200">
                      {isAr ? 'المتابعات القضائية، الدفوع، وملفات استخلاص الديون المتراكمة' : 'Procédures de recouvrement contentieux'}
                    </td>
                    <td className="p-2.5 text-center border-e border-slate-200">
                      <span className="px-2 py-0.5 rounded-md text-xs font-black bg-purple-100 text-purple-800 border border-purple-300">
                        {masterStatement.lawyerFeesPct}%
                      </span>
                    </td>
                    <td className="p-2.5 text-end font-black text-rose-700 text-sm">
                      -{masterStatement.lawyerFees.toLocaleString()} <span className="text-xs font-normal">DH</span>
                    </td>
                  </tr>

                  {/* 6. Huissier */}
                  <tr className="hover:bg-slate-50 transition-colors">
                    <td className="p-2.5 text-center font-bold text-slate-700 border-e border-slate-200">6</td>
                    <td className="p-2.5 font-sans font-bold text-slate-900 border-e border-slate-200 flex items-center gap-2">
                      <FileText className="w-4 h-4 text-rose-600" />
                      <span>{isAr ? 'أتعاب مفوض قضائي (Huissier)' : 'Honoraires d\'Huissier de Justice'}</span>
                    </td>
                    <td className="p-2.5 font-sans text-slate-600 text-[11px] hidden md:table-cell border-e border-slate-200">
                      {isAr ? 'تبليغ الإنذارات الرسمية، المحاضر القانونية والمعاينات' : 'Sommations et significations d\'actes'}
                    </td>
                    <td className="p-2.5 text-center border-e border-slate-200">
                      <span className="px-2 py-0.5 rounded-md text-xs font-black bg-rose-100 text-rose-800 border border-rose-300">
                        {masterStatement.bailiffFeesPct}%
                      </span>
                    </td>
                    <td className="p-2.5 text-end font-black text-rose-700 text-sm">
                      -{masterStatement.bailiffFees.toLocaleString()} <span className="text-xs font-normal">DH</span>
                    </td>
                  </tr>

                  {/* 7. Droguerie */}
                  <tr className="hover:bg-slate-50 transition-colors">
                    <td className="p-2.5 text-center font-bold text-slate-700 border-e border-slate-200">7</td>
                    <td className="p-2.5 font-sans font-bold text-slate-900 border-e border-slate-200 flex items-center gap-2">
                      <Wrench className="w-4 h-4 text-orange-600" />
                      <span>{isAr ? 'العقاقير بمختلفها ومصاريف متنوعة (Droguerie & Divers)' : 'Droguerie, Matériel & Divers (Ciment, Arrosage...)'}</span>
                    </td>
                    <td className="p-2.5 font-sans text-slate-600 text-[11px] hidden md:table-cell border-e border-slate-200">
                      {isAr ? 'عقاقير، إسمنت، مضخات الري، مواد النظافة، الكهرباء، والسباكة والصيانة العامة' : 'Droguerie, quincaillerie, ciment, arrosage, entretien'}
                    </td>
                    <td className="p-2.5 text-center border-e border-slate-200">
                      <span className="px-2 py-0.5 rounded-md text-xs font-black bg-orange-100 text-orange-800 border border-orange-300">
                        {masterStatement.diverseExpensesPct}%
                      </span>
                    </td>
                    <td className="p-2.5 text-end font-black text-rose-700 text-sm">
                      -{masterStatement.diverseExpenses.toLocaleString()} <span className="text-xs font-normal">DH</span>
                    </td>
                  </tr>

                  {/* 8. Total Disponible */}
                  <tr className="bg-cyan-900 text-white font-black">
                    <td className="p-2.5 text-center border-e border-cyan-800">8</td>
                    <td className="p-2.5 font-sans border-e border-cyan-800 flex items-center gap-2 text-cyan-200">
                      <Sparkles className="w-4 h-4 text-amber-300" />
                      <span>{isAr ? 'مجموع المداخيل مع إضافة المنقول (Total Disponible)' : 'Total Disponible (Report + Recettes)'}</span>
                    </td>
                    <td className="p-2.5 font-sans text-cyan-100 text-[11px] hidden md:table-cell border-e border-cyan-800">
                      {isAr ? 'إجمالي السيولة المالية الإجمالية المتوفرة بالصندوق (الخانة 1 + الخانة 2)' : 'Total des disponibilités en caisse'}
                    </td>
                    <td className="p-2.5 text-center border-e border-cyan-800 font-sans text-cyan-300 text-xs">(1 + 2)</td>
                    <td className="p-2.5 text-end font-black text-cyan-200 text-base">
                      {masterStatement.totalIncomeWithCarried.toLocaleString()} <span className="text-xs font-normal text-white">DH</span>
                    </td>
                  </tr>

                  {/* 9. Total Dépenses */}
                  <tr className="bg-rose-900 text-white font-black">
                    <td className="p-2.5 text-center border-e border-rose-800">9</td>
                    <td className="p-2.5 font-sans border-e border-rose-800 flex items-center gap-2 text-rose-200">
                      <TrendingDown className="w-4 h-4 text-rose-300" />
                      <span>{isAr ? 'مجموع المصاريف (Dépenses)' : 'Total Général des Dépenses'}</span>
                    </td>
                    <td className="p-2.5 font-sans text-rose-100 text-[11px] hidden md:table-cell border-e border-rose-800">
                      {isAr ? 'إجمالي كافة النفقات المؤداة لسنتي 2025 و 2026 (مجموع البنود من 3 إلى 7)' : 'Somme totale des charges décaissées (3 à 7)'}
                    </td>
                    <td className="p-2.5 text-center border-e border-rose-800 font-sans text-rose-200 text-xs">100%</td>
                    <td className="p-2.5 text-end font-black text-rose-200 text-base">
                      -{masterStatement.totalExpenses.toLocaleString()} <span className="text-xs font-normal text-white">DH</span>
                    </td>
                  </tr>

                  {/* 10. Solde Restant */}
                  <tr className={`${
                    masterStatement.remainingBalance >= 0 
                      ? 'bg-gradient-to-r from-emerald-800 via-teal-900 to-emerald-950 text-white' 
                      : 'bg-gradient-to-r from-rose-900 to-red-950 text-white'
                  } font-black`}>
                    <td className="p-3 text-center border-e border-emerald-700 text-amber-300 text-sm"></td>
                    <td className="p-3 font-sans border-e border-emerald-700 flex items-center gap-2 text-white text-sm">
                      <Wallet className="w-5 h-5 text-amber-300" />
                      <span>{isAr ? 'الباقي النهائي الصافي (Solde Restant)' : 'Solde Restant Final (Reporté à 2027)'}</span>
                    </td>
                    <td className="p-3 font-sans text-emerald-100 text-[11px] hidden md:table-cell border-e border-emerald-700">
                      {isAr ? 'المعادلة: مجموع المداخيل مع المنقول (8) - مجموع المصاريف (9) = التحفة المرحّلة' : 'Solde net final reporté: Total Disponible (8) - Dépenses (9)'}
                    </td>
                    <td className="p-3 text-center border-e border-emerald-700 font-sans">
                      <span className="px-2.5 py-1 rounded-full bg-white/20 text-white text-[11px] font-black">
                        {masterStatement.remainingBalance >= 0 ? (isAr ? 'فائض 🟢' : 'Excédent') : (isAr ? 'عجز 🔴' : 'Déficit')}
                      </span>
                    </td>
                    <td className="p-3 text-end font-black text-amber-300 text-lg">
                      {masterStatement.remainingBalance >= 0 ? '+' : ''}{masterStatement.remainingBalance.toLocaleString()} <span className="text-xs font-normal text-white">DH</span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Visual Expense Percentages Distribution Bar & Badges */}
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-800">
                <span className="flex items-center gap-1.5">
                  <Percent className="w-3.5 h-3.5 text-indigo-600" />
                  <span>{isAr ? 'توزيع نسب النفقات كم في المئة (%) من مجموع المصاريف لسنتي 2025 و 2026:' : 'Ventilation en Pourcentage (%) des Dépenses (2025-2026):'}</span>
                </span>
                <span className="text-[10px] text-slate-500 font-mono">100% = {masterStatement.totalExpenses.toLocaleString()} DH</span>
              </div>

              <div className="w-full bg-slate-200 rounded-full h-3.5 overflow-hidden flex shadow-inner">
                <div style={{ width: `${masterStatement.workerSalariesPct}%` }} className="bg-sky-500 h-full transition-all" title={`أجور العمال: ${masterStatement.workerSalariesPct}%`} />
                <div style={{ width: `${masterStatement.syndicFeesPct}%` }} className="bg-amber-500 h-full transition-all" title={`أجرة الوكيل: ${masterStatement.syndicFeesPct}%`} />
                <div style={{ width: `${masterStatement.lawyerFeesPct}%` }} className="bg-purple-500 h-full transition-all" title={`أتعاب المحامي: ${masterStatement.lawyerFeesPct}%`} />
                <div style={{ width: `${masterStatement.bailiffFeesPct}%` }} className="bg-rose-500 h-full transition-all" title={`أتعاب مفوض قضائي: ${masterStatement.bailiffFeesPct}%`} />
                <div style={{ width: `${masterStatement.diverseExpensesPct}%` }} className="bg-orange-500 h-full transition-all" title={`مصاريف مختلفة: ${masterStatement.diverseExpensesPct}%`} />
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-1 text-[11px]">
                <div className="p-2 rounded-lg bg-sky-50 border border-sky-200 flex flex-col justify-between">
                  <span className="text-slate-600 font-semibold text-[10px]">{isAr ? 'أجور العمال' : 'Salaires'}</span>
                  <span className="font-mono font-black text-sky-900 text-xs mt-0.5">{masterStatement.workerSalariesPct}%</span>
                  <span className="text-[9px] text-slate-500 font-mono">{masterStatement.workerSalaries.toLocaleString()} DH</span>
                </div>

                <div className="p-2 rounded-lg bg-amber-50 border border-amber-200 flex flex-col justify-between">
                  <span className="text-slate-600 font-semibold text-[10px]">{isAr ? 'أجرة الوكيل ونائبه' : 'Syndic'}</span>
                  <span className="font-mono font-black text-amber-900 text-xs mt-0.5">{masterStatement.syndicFeesPct}%</span>
                  <span className="text-[9px] text-slate-500 font-mono">{masterStatement.syndicFees.toLocaleString()} DH</span>
                </div>

                <div className="p-2 rounded-lg bg-purple-50 border border-purple-200 flex flex-col justify-between">
                  <span className="text-slate-600 font-semibold text-[10px]">{isAr ? 'أتعاب المحامي' : 'Avocat'}</span>
                  <span className="font-mono font-black text-purple-900 text-xs mt-0.5">{masterStatement.lawyerFeesPct}%</span>
                  <span className="text-[9px] text-slate-500 font-mono">{masterStatement.lawyerFees.toLocaleString()} DH</span>
                </div>

                <div className="p-2 rounded-lg bg-rose-50 border border-rose-200 flex flex-col justify-between">
                  <span className="text-slate-600 font-semibold text-[10px]">{isAr ? 'أتعاب مفوض قضائي' : 'Huissier'}</span>
                  <span className="font-mono font-black text-rose-900 text-xs mt-0.5">{masterStatement.bailiffFeesPct}%</span>
                  <span className="text-[9px] text-slate-500 font-mono">{masterStatement.bailiffFees.toLocaleString()} DH</span>
                </div>

                <div className="p-2 rounded-lg bg-orange-50 border border-orange-200 flex flex-col justify-between">
                  <span className="text-slate-600 font-semibold text-[10px]">{isAr ? 'عقاقير ومختلفة' : 'Droguerie'}</span>
                  <span className="font-mono font-black text-orange-900 text-xs mt-0.5">{masterStatement.diverseExpensesPct}%</span>
                  <span className="text-[9px] text-slate-500 font-mono">{masterStatement.diverseExpenses.toLocaleString()} DH</span>
                </div>
              </div>
            </div>

            {/* Consolidated Recharts Charts for Page 1 */}
            {showCharts && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/60">
                  <div className="text-xs font-bold text-slate-800 mb-1.5 flex items-center justify-between">
                    <span>{isAr ? 'مخطط التوزيع النسبي للمصاريف (%)' : 'Répartition des 5 Postes de Dépenses (%)'}</span>
                    <span className="text-[10px] font-mono font-bold text-rose-800">{masterStatement.totalExpenses.toLocaleString()} DH</span>
                  </div>
                  <div className="h-52">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={pillarsDonutData}
                          dataKey="value"
                          nameKey="name"
                          cx="50%"
                          cy="50%"
                          outerRadius={65}
                          innerRadius={32}
                          paddingAngle={3}
                        >
                          {pillarsDonutData.map((entry, index) => (
                            <Cell key={`pillar-cell-${index}`} fill={entry.fill} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(val: any) => [`${Number(val).toLocaleString()} DH`, isAr ? 'المبلغ' : 'Montant']} />
                        <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontSize: '10px', fontWeight: 'bold' }} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/60">
                  <div className="text-xs font-bold text-slate-800 mb-1.5 flex items-center justify-between">
                    <span>{isAr ? 'مخطط الموازنة العامة والسيولة للسنتين (DH)' : 'Comparatif Global des Flux Financiers (DH)'}</span>
                    <span className={`text-[10px] font-mono font-bold ${masterStatement.remainingBalance >= 0 ? 'text-emerald-800' : 'text-rose-800'}`}>
                      {isAr ? 'الباقي:' : 'Reste:'} {masterStatement.remainingBalance >= 0 ? '+' : ''}{masterStatement.remainingBalance.toLocaleString()} DH
                    </span>
                  </div>
                  <div className="h-52">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={cashflowData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                        <XAxis dataKey="name" tick={{ fontSize: 9, fontWeight: 'bold' }} stroke="#64748b" />
                        <YAxis tick={{ fontSize: 9 }} stroke="#64748b" />
                        <Tooltip formatter={(val: any) => [`${Number(val).toLocaleString()} DH`, isAr ? 'المبلغ' : 'Montant']} />
                        <Bar dataKey="amount" radius={[6, 6, 0, 0]} barSize={32}>
                          {cashflowData.map((entry, idx) => (
                            <Cell key={`cf-cell-${idx}`} fill={entry.fill} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* PRINT PAGE BREAK */}
        <div className="pdf-page-break print:block hidden" />

        {/* ========================================================================= */}
        {/* PAGE 2: DETAILED RECHARTS COMPARISON (2025 vs 2026) & 24-MONTH EVOLUTION */}
        {/* ========================================================================= */}
        <div className="pdf-page-block print-avoid-break bg-white p-6 sm:p-8 rounded-2xl border-2 border-slate-300 shadow-sm space-y-5">
          {/* Page 2 Header */}
          <div className="border-b-2 border-indigo-600 pb-3 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-start">
            <div>
              <div className="flex items-center justify-center sm:justify-start gap-2">
                <div className="p-1.5 rounded-lg bg-indigo-600 text-white shadow-xs">
                  <Activity className="w-4 h-4" />
                </div>
                <h2 className="text-base sm:text-lg font-black text-indigo-950">
                  {isAr ? 'التحليل المقارن والرسوم البيانية للسنتين (2025 مقابل 2026)' : 'Analyse Détaillée et Graphiques Comparatifs (2025 vs 2026)'}
                </h2>
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                {isAr ? 'مقارنة دقيقة للخانات العشر بين سنة 2025 وسنة 2026 مع نسب التطور والتوزيع' : 'Comparatif poste par poste entre l\'exercice 2025 et l\'exercice 2026'}
              </p>
            </div>
            <div className="text-xs font-mono font-bold text-indigo-900 bg-indigo-50 border border-indigo-200 px-3 py-1 rounded-xl">
              {isAr ? 'الصفحة 2 من 3 • التحليل المقارن' : 'Page 2 sur 3 • Analyse Comparative'}
            </div>
          </div>

          {/* 3 Comparative KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Recettes */}
            <div className="p-3 rounded-xl bg-emerald-50/90 border border-emerald-200 space-y-1.5">
              <div className="flex items-center justify-between text-xs font-bold text-emerald-950">
                <span className="flex items-center gap-1.5">
                  <TrendingUp className="w-4 h-4 text-emerald-600" />
                  <span>{isAr ? 'مداخيل 2025 مقابل 2026' : 'Recettes 2025 vs 2026'}</span>
                </span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-black ${twoYearsComparison.growthRecettes >= 0 ? 'bg-emerald-200 text-emerald-900' : 'bg-rose-200 text-rose-900'}`}>
                  {twoYearsComparison.growthRecettes >= 0 ? '+' : ''}{twoYearsComparison.growthRecettes}%
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-1">
                <div>
                  <span className="text-[10px] text-slate-500 font-sans block">{isAr ? 'سنة 2025' : 'Année 2025'}</span>
                  <span className="font-bold text-emerald-900">{twoYearsComparison.y2025.recettes.toLocaleString()} DH</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 font-sans block">{isAr ? 'سنة 2026' : 'Année 2026'}</span>
                  <span className="font-bold text-emerald-900">{twoYearsComparison.y2026.recettes.toLocaleString()} DH</span>
                </div>
              </div>
              <div className="text-[10px] text-emerald-800 font-sans pt-1 border-t border-emerald-200/80 flex items-center justify-between">
                <span>{isAr ? 'المجموع الموحد للسنتين:' : 'Total consolidé :'}</span>
                <span className="font-mono font-black">{masterStatement.income.toLocaleString()} DH</span>
              </div>
            </div>

            {/* Dépenses */}
            <div className="p-3 rounded-xl bg-rose-50/90 border border-rose-200 space-y-1.5">
              <div className="flex items-center justify-between text-xs font-bold text-rose-950">
                <span className="flex items-center gap-1.5">
                  <TrendingDown className="w-4 h-4 text-rose-600" />
                  <span>{isAr ? 'مصاريف 2025 مقابل 2026' : 'Dépenses 2025 vs 2026'}</span>
                </span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-black ${twoYearsComparison.growthDepenses <= 0 ? 'bg-emerald-200 text-emerald-900' : 'bg-rose-200 text-rose-900'}`}>
                  {twoYearsComparison.growthDepenses >= 0 ? '+' : ''}{twoYearsComparison.growthDepenses}%
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-1">
                <div>
                  <span className="text-[10px] text-slate-500 font-sans block">{isAr ? 'سنة 2025' : 'Année 2025'}</span>
                  <span className="font-bold text-rose-900">{twoYearsComparison.y2025.totalExpenses.toLocaleString()} DH</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 font-sans block">{isAr ? 'سنة 2026' : 'Année 2026'}</span>
                  <span className="font-bold text-rose-900">{twoYearsComparison.y2026.totalExpenses.toLocaleString()} DH</span>
                </div>
              </div>
              <div className="text-[10px] text-rose-800 font-sans pt-1 border-t border-rose-200/80 flex items-center justify-between">
                <span>{isAr ? 'المجموع الموحد للسنتين:' : 'Total consolidé :'}</span>
                <span className="font-mono font-black">{masterStatement.totalExpenses.toLocaleString()} DH</span>
              </div>
            </div>

            {/* Solde */}
            <div className="p-3 rounded-xl bg-indigo-50/90 border border-indigo-200 space-y-1.5">
              <div className="flex items-center justify-between text-xs font-bold text-indigo-950">
                <span className="flex items-center gap-1.5">
                  <Wallet className="w-4 h-4 text-indigo-600" />
                  <span>{isAr ? 'الباقي الصافي (Solde)' : 'Solde 2025 vs 2026'}</span>
                </span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-black ${twoYearsComparison.growthSolde >= 0 ? 'bg-emerald-200 text-emerald-900' : 'bg-rose-200 text-rose-900'}`}>
                  {twoYearsComparison.growthSolde >= 0 ? '+' : ''}{twoYearsComparison.growthSolde}%
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-1">
                <div>
                  <span className="text-[10px] text-slate-500 font-sans block">{isAr ? 'رصيد نهاية 2025' : 'Fin 2025'}</span>
                  <span className={`font-bold ${twoYearsComparison.y2025.soldeRestant >= 0 ? 'text-emerald-900' : 'text-rose-900'}`}>
                    {twoYearsComparison.y2025.soldeRestant >= 0 ? '+' : ''}{twoYearsComparison.y2025.soldeRestant.toLocaleString()} DH
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 font-sans block">{isAr ? 'رصيد نهاية 2026' : 'Fin 2026'}</span>
                  <span className={`font-bold ${twoYearsComparison.y2026.soldeRestant >= 0 ? 'text-emerald-900' : 'text-rose-900'}`}>
                    {twoYearsComparison.y2026.soldeRestant >= 0 ? '+' : ''}{twoYearsComparison.y2026.soldeRestant.toLocaleString()} DH
                  </span>
                </div>
              </div>
              <div className="text-[10px] text-indigo-800 font-sans pt-1 border-t border-indigo-200/80 flex items-center justify-between">
                <span>{isAr ? 'الرصيد النهائي المرحل:' : 'Solde restant final :'}</span>
                <span className={`font-mono font-black ${masterStatement.remainingBalance >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                  {masterStatement.remainingBalance >= 0 ? '+' : ''}{masterStatement.remainingBalance.toLocaleString()} DH
                </span>
              </div>
            </div>
          </div>

          {/* Recharts Grouped Charts */}
          {showCharts && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
              {/* Grouped Bar Chart: Financial Metrics 2025 vs 2026 */}
              <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/60">
                <div className="text-xs font-bold text-slate-800 mb-2 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <BarChart3 className="w-4 h-4 text-indigo-600" />
                    <span>{isAr ? 'مقارنة المداخيل والمصاريف والسيولة (2025 مقابل 2026)' : 'Comparatif Global : Recettes, Dépenses et Solde (2025 vs 2026)'}</span>
                  </span>
                </div>
                <div className="h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={twoYearsComparison.comparativeBarData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                      <XAxis dataKey="metric" tick={{ fontSize: 9, fontWeight: 'bold' }} stroke="#64748b" />
                      <YAxis tick={{ fontSize: 9 }} stroke="#64748b" />
                      <Tooltip formatter={(val: any) => [`${Number(val).toLocaleString()} DH`, '']} />
                      <Legend verticalAlign="top" height={32} wrapperStyle={{ fontSize: '10px', fontWeight: 'bold' }} />
                      <Bar dataKey="y2025" name={isAr ? 'سنة 2025' : 'Année 2025'} fill="#3b82f6" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="y2026" name={isAr ? 'سنة 2026' : 'Année 2026'} fill="#10b981" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Grouped Bar Chart: 5 Expense Pillars 2025 vs 2026 */}
              <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/60">
                <div className="text-xs font-bold text-slate-800 mb-2 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Activity className="w-4 h-4 text-amber-600" />
                    <span>{isAr ? 'مقارنة أبواب المصاريف الخمسة (2025 مقابل 2026)' : 'Comparatif des 5 Postes de Dépenses (2025 vs 2026)'}</span>
                  </span>
                </div>
                <div className="h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={twoYearsComparison.pillarsComparativeBarData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                      <XAxis dataKey="poste" tick={{ fontSize: 9, fontWeight: 'bold' }} stroke="#64748b" />
                      <YAxis tick={{ fontSize: 9 }} stroke="#64748b" />
                      <Tooltip formatter={(val: any) => [`${Number(val).toLocaleString()} DH`, '']} />
                      <Legend verticalAlign="top" height={32} wrapperStyle={{ fontSize: '10px', fontWeight: 'bold' }} />
                      <Bar dataKey="y2025" name={isAr ? 'سنة 2025' : 'Année 2025'} fill="#6366f1" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="y2026" name={isAr ? 'سنة 2026' : 'Année 2026'} fill="#f59e0b" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}

          {/* Side-by-side 10-Line Master Statement Table for 2025 vs 2026 */}
          <div className="space-y-2 pt-1">
            <div className="flex items-center justify-between">
              <h3 className="text-xs sm:text-sm font-black text-slate-900 flex items-center gap-1.5">
                <TableIcon className="w-4 h-4 text-indigo-700" />
                <span>{isAr ? 'جدول مقارنة الخانات العشر بالتفصيل (2025 و 2026 والمجموع الموحد)' : 'Tableau Comparatif Détaillé des 10 Rubriques (2025 vs 2026 & Consolidé)'}</span>
              </h3>
              <span className="text-[10px] font-mono text-slate-500 font-bold">
                {isAr ? 'سنتين متكاملتين (2025 و 2026)' : '2 Ans complets (2025 et 2026)'}
              </span>
            </div>

            <div className="overflow-x-auto rounded-xl border-2 border-slate-300 shadow-2xs bg-white">
              <table className="w-full text-xs text-start border-collapse">
                <thead className="bg-slate-900 text-white font-black text-xs">
                  <tr>
                    <th className="p-2.5 text-center w-10 border-e border-slate-700">{isAr ? 'الرقم' : 'N°'}</th>
                    <th className="p-2.5 text-start min-w-[200px] border-e border-slate-700">{isAr ? 'البيان المحاسبي المعتمد' : 'Poste Budgétaire'}</th>
                    <th className="p-2.5 text-end min-w-[110px] border-e border-slate-700 text-sky-300">{isAr ? 'سنة 2025' : 'Année 2025'}</th>
                    <th className="p-2.5 text-end min-w-[110px] border-e border-slate-700 text-amber-300">{isAr ? 'سنة 2026' : 'Année 2026'}</th>
                    <th className="p-2.5 text-end min-w-[130px] border-e border-slate-700 text-emerald-300">{isAr ? 'المجموع الموحد (2 سنتين)' : 'Total Consolidé 2 Ans'}</th>
                    <th className="p-2.5 text-center min-w-[90px]">{isAr ? 'التطور / النسبة' : 'Évolution / Part'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-mono">
                  {/* 1. Report */}
                  <tr className="bg-indigo-50/50 hover:bg-indigo-50">
                    <td className="p-2 text-center font-black text-indigo-900 border-e border-slate-200">1</td>
                    <td className="p-2 font-sans font-bold text-slate-900 border-e border-slate-200">
                      {isAr ? 'المنقول الافتتاحي (Report)' : 'Report initial'}
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 font-bold text-indigo-950">
                      {twoYearsComparison.y2025.report.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 font-bold text-indigo-950">
                      {twoYearsComparison.y2026.report.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 font-black text-indigo-950">
                      {masterStatement.carriedBalance.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-center font-sans text-[10px] text-slate-500">
                      {isAr ? 'مرحل سابق' : 'Solde antérieur'}
                    </td>
                  </tr>

                  {/* 2. Recettes */}
                  <tr className="bg-emerald-50/40 hover:bg-emerald-50">
                    <td className="p-2 text-center font-black text-emerald-900 border-e border-slate-200">2</td>
                    <td className="p-2 font-sans font-bold text-slate-900 border-e border-slate-200">
                      {isAr ? 'المداخيل (Recettes)' : 'Recettes perçues'}
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 font-bold text-emerald-900">
                      +{twoYearsComparison.y2025.recettes.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 font-bold text-emerald-900">
                      +{twoYearsComparison.y2026.recettes.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 font-black text-emerald-950">
                      +{masterStatement.income.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-black ${twoYearsComparison.growthRecettes >= 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>
                        {twoYearsComparison.growthRecettes >= 0 ? '+' : ''}{twoYearsComparison.growthRecettes}%
                      </span>
                    </td>
                  </tr>

                  {/* 3. Salaires */}
                  <tr className="hover:bg-slate-50">
                    <td className="p-2 text-center font-bold text-slate-700 border-e border-slate-200">3</td>
                    <td className="p-2 font-sans font-medium text-slate-800 border-e border-slate-200">
                      {isAr ? 'أجور العمال (Salaires)' : 'Salaires ouvriers'}
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 text-rose-700 font-semibold">
                      -{twoYearsComparison.y2025.salaires.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 text-rose-700 font-semibold">
                      -{twoYearsComparison.y2026.salaires.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 text-rose-800 font-black">
                      -{masterStatement.workerSalaries.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-center">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-800">
                        {masterStatement.workerSalariesPct}%
                      </span>
                    </td>
                  </tr>

                  {/* 4. Syndic */}
                  <tr className="hover:bg-slate-50">
                    <td className="p-2 text-center font-bold text-slate-700 border-e border-slate-200">4</td>
                    <td className="p-2 font-sans font-medium text-slate-800 border-e border-slate-200">
                      {isAr ? 'أجرة الوكيل ونائبه (Syndic)' : 'Honoraires Syndic & adjoint'}
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 text-rose-700 font-semibold">
                      -{twoYearsComparison.y2025.syndic.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 text-rose-700 font-semibold">
                      -{twoYearsComparison.y2026.syndic.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 text-rose-800 font-black">
                      -{masterStatement.syndicFees.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-center">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800">
                        {masterStatement.syndicFeesPct}%
                      </span>
                    </td>
                  </tr>

                  {/* 5. Avocat */}
                  <tr className="hover:bg-slate-50">
                    <td className="p-2 text-center font-bold text-slate-700 border-e border-slate-200">5</td>
                    <td className="p-2 font-sans font-medium text-slate-800 border-e border-slate-200">
                      {isAr ? 'أتعاب المحامي (Avocat)' : 'Honoraires Avocat'}
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 text-rose-700 font-semibold">
                      -{twoYearsComparison.y2025.avocat.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 text-rose-700 font-semibold">
                      -{twoYearsComparison.y2026.avocat.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 text-rose-800 font-black">
                      -{masterStatement.lawyerFees.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-center">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-800">
                        {masterStatement.lawyerFeesPct}%
                      </span>
                    </td>
                  </tr>

                  {/* 6. Huissier */}
                  <tr className="hover:bg-slate-50">
                    <td className="p-2 text-center font-bold text-slate-700 border-e border-slate-200">6</td>
                    <td className="p-2 font-sans font-medium text-slate-800 border-e border-slate-200">
                      {isAr ? 'أتعاب مفوض قضائي (Huissier)' : 'Huissier de Justice'}
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 text-rose-700 font-semibold">
                      -{twoYearsComparison.y2025.huissier.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 text-rose-700 font-semibold">
                      -{twoYearsComparison.y2026.huissier.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 text-rose-800 font-black">
                      -{masterStatement.bailiffFees.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-center">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800">
                        {masterStatement.bailiffFeesPct}%
                      </span>
                    </td>
                  </tr>

                  {/* 7. Droguerie */}
                  <tr className="hover:bg-slate-50">
                    <td className="p-2 text-center font-bold text-slate-700 border-e border-slate-200">7</td>
                    <td className="p-2 font-sans font-medium text-slate-800 border-e border-slate-200">
                      {isAr ? 'العقاقير ومصاريف متنوعة (Droguerie & Divers)' : 'Droguerie, Matériel & Divers'}
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 text-rose-700 font-semibold">
                      -{twoYearsComparison.y2025.droguerie.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 text-rose-700 font-semibold">
                      -{twoYearsComparison.y2026.droguerie.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-end border-e border-slate-200 text-rose-800 font-black">
                      -{masterStatement.diverseExpenses.toLocaleString()} DH
                    </td>
                    <td className="p-2 text-center">
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-orange-100 text-orange-800">
                        {masterStatement.diverseExpensesPct}%
                      </span>
                    </td>
                  </tr>

                  {/* 8. Total Disponible */}
                  <tr className="bg-cyan-900 text-white font-black">
                    <td className="p-2.5 text-center border-e border-cyan-800">8</td>
                    <td className="p-2.5 font-sans border-e border-cyan-800 text-cyan-200">
                      {isAr ? 'مجموع المداخيل مع المنقول (Total Disponible)' : 'Total Disponible (1 + 2)'}
                    </td>
                    <td className="p-2.5 text-end border-e border-cyan-800 text-cyan-200">
                      {twoYearsComparison.y2025.totalDisponible.toLocaleString()} DH
                    </td>
                    <td className="p-2.5 text-end border-e border-cyan-800 text-cyan-200">
                      {twoYearsComparison.y2026.totalDisponible.toLocaleString()} DH
                    </td>
                    <td className="p-2.5 text-end border-e border-cyan-800 text-cyan-200 text-sm">
                      {masterStatement.totalIncomeWithCarried.toLocaleString()} DH
                    </td>
                    <td className="p-2.5 text-center text-[10px] text-cyan-300 font-sans">
                      (1 + 2)
                    </td>
                  </tr>

                  {/* 9. Dépenses */}
                  <tr className="bg-rose-900 text-white font-black">
                    <td className="p-2.5 text-center border-e border-rose-800">9</td>
                    <td className="p-2.5 font-sans border-e border-rose-800 text-rose-200">
                      {isAr ? 'مجموع المصاريف (Dépenses)' : 'Total Dépenses (3 à 7)'}
                    </td>
                    <td className="p-2.5 text-end border-e border-rose-800 text-rose-200">
                      -{twoYearsComparison.y2025.totalExpenses.toLocaleString()} DH
                    </td>
                    <td className="p-2.5 text-end border-e border-rose-800 text-rose-200">
                      -{twoYearsComparison.y2026.totalExpenses.toLocaleString()} DH
                    </td>
                    <td className="p-2.5 text-end border-e border-rose-800 text-rose-200 text-sm">
                      -{masterStatement.totalExpenses.toLocaleString()} DH
                    </td>
                    <td className="p-2.5 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-black ${twoYearsComparison.growthDepenses <= 0 ? 'bg-emerald-200 text-emerald-900' : 'bg-rose-200 text-rose-900'}`}>
                        {twoYearsComparison.growthDepenses >= 0 ? '+' : ''}{twoYearsComparison.growthDepenses}%
                      </span>
                    </td>
                  </tr>

                  {/* 10. Solde Restant */}
                  <tr className={`${masterStatement.remainingBalance >= 0 ? 'bg-emerald-950 text-white' : 'bg-rose-950 text-white'} font-black`}>
                    <td className="p-2.5 text-center border-e border-emerald-800 text-amber-300"></td>
                    <td className="p-2.5 font-sans border-e border-emerald-800 text-white">
                      {isAr ? 'الباقي النهائي الصافي (Solde Restant)' : 'Solde Restant (8 - 9)'}
                    </td>
                    <td className="p-2.5 text-end border-e border-emerald-800 text-amber-300">
                      {twoYearsComparison.y2025.soldeRestant >= 0 ? '+' : ''}{twoYearsComparison.y2025.soldeRestant.toLocaleString()} DH
                    </td>
                    <td className="p-2.5 text-end border-e border-emerald-800 text-amber-300">
                      {twoYearsComparison.y2026.soldeRestant >= 0 ? '+' : ''}{twoYearsComparison.y2026.soldeRestant.toLocaleString()} DH
                    </td>
                    <td className="p-2.5 text-end border-e border-emerald-800 text-amber-300 text-sm">
                      {masterStatement.remainingBalance >= 0 ? '+' : ''}{masterStatement.remainingBalance.toLocaleString()} DH
                    </td>
                    <td className="p-2.5 text-center">
                      <span className="px-2 py-0.5 rounded-full bg-white/20 text-white text-[10px] font-black">
                        {masterStatement.remainingBalance >= 0 ? (isAr ? 'فائض 🟢' : 'Excédent') : (isAr ? 'عجز 🔴' : 'Déficit')}
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Continuous 24-Month Chronological Evolution ComposedChart */}
          {showCharts && (
            <div className="space-y-2 pt-2">
              <div className="flex items-center justify-between border-b border-slate-200 pb-1.5">
                <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                  <Activity className="w-4 h-4 text-emerald-700" />
                  <span>
                    {isAr ? 'منحنى تطور المداخيل والمصاريف والأرصدة طيلة 24 شهراً (من 01/2025 إلى 12/2026)' : 'Évolution Chronologique Mensuelle Recettes / Dépenses (24 mois)'}
                  </span>
                </h3>
                <span className="text-[10px] font-mono font-bold text-emerald-800">
                  24 {isAr ? 'شهراً متسلسلاً' : 'mois consécutifs'}
                </span>
              </div>

              <div className="p-3 rounded-xl border border-slate-200 bg-slate-50/50">
                <div className="h-56">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={monthly24TrendData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                      <XAxis dataKey="month" tick={{ fontSize: 8, fontWeight: 'bold' }} stroke="#64748b" />
                      <YAxis tick={{ fontSize: 9 }} stroke="#64748b" />
                      <Tooltip formatter={(val: any) => [`${Number(val).toLocaleString()} DH`, '']} />
                      <Legend verticalAlign="top" height={32} wrapperStyle={{ fontSize: '10px', fontWeight: 'bold' }} />
                      <Bar dataKey="income" name={isAr ? 'المداخيل الشهرية' : 'Recettes'} fill="#059669" radius={[3, 3, 0, 0]} barSize={8} />
                      <Bar dataKey="expenses" name={isAr ? 'المصاريف الشهرية' : 'Dépenses'} fill="#dc2626" radius={[3, 3, 0, 0]} barSize={8} />
                      <Line type="monotone" dataKey="balance" name={isAr ? 'صافي الشهر' : 'Solde Net'} stroke="#0284c7" strokeWidth={2} dot={{ r: 2 }} />
                      <Line type="monotone" dataKey="closingBalance" name={isAr ? 'الرصيد التراكمي' : 'Report Cumulé'} stroke="#d97706" strokeWidth={2.5} strokeDasharray="4 4" dot={{ r: 2.5, fill: '#d97706' }} />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* PRINT PAGE BREAK */}
        <div className="pdf-page-break print:block hidden" />

        {/* ========================================================================= */}
        {/* PAGE 3: 24-MONTH CARRYOVER TABLE, AUDIT ANALYSIS & OFFICIAL SIGNATURES    */}
        {/* ========================================================================= */}
        <div className="pdf-page-block print-avoid-break bg-white p-6 sm:p-8 rounded-2xl border-2 border-slate-300 shadow-sm space-y-5">
          {/* Page 3 Header */}
          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
            <div className="text-xs font-black text-slate-800">
              {isAr ? 'ملحق الكشوفات المحاسبية والتوقيعات الرسمية للإقامة' : 'Annexes Comptables, Observations & Signatures Officielles'}
            </div>
            <div className="text-[10px] text-slate-500 font-mono">
              {isAr ? 'الصفحة 3 من 3 • الإقامة ' : 'Page 3 sur 3 • Résidence'}
            </div>
          </div>

          {/* Legal reference banner */}
          <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-amber-700" />
                <h4 className="text-xs font-black text-amber-950">
                  {isAr ? 'مستحقات وأتعاب إدارة السانديك ونائبه لسنتي 2025 و 2026:' : 'Honoraires de Gestion Syndic & Adjoint (2 Ans) :'}
                </h4>
              </div>
              <span className="font-mono font-black text-amber-950 text-xs bg-white px-2 py-0.5 rounded border border-amber-300">
                {masterStatement.syndicFees.toLocaleString()} DH
              </span>
            </div>
            <div className="text-[11px] text-slate-700 flex flex-wrap items-center justify-between gap-2">
              <span>{isAr ? 'الأتعاب المعتمدة: 4,000 درهم شهرياً نظير الإشراف الإداري والمالي والقانوني على جميع العمارات (جميع الشقق).' : 'Honoraires mensuels de 4.000 DH/mois pour tous les immeubles (tous les lots).'}</span>
              <span className="text-[10px] font-bold text-amber-900 bg-amber-100 px-2 py-0.5 rounded">
                ⚖️ {isAr ? 'المادة 18 من القانون رقم 18.00 المتعلق بالملكية المشتركة بالمملكة المغربية' : 'Loi 18.00 Article 18'}
              </span>
            </div>
          </div>

          {/* 24-Month Table */}
          {showCarryoverTable && (
            <div className="carryover-24 space-y-1.5">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                  <ArrowRightLeft className="w-3.5 h-3.5 text-blue-600" />
                  <span>
                    {isAr ? 'جدول تسلسل ترحيل الأرصدة شهراً بشهر طيلة 24 شهراً (2025 و 2026):' : 'Suivi Chronologique du Report à Nouveau sur 24 Mois :'}
                  </span>
                </h4>
              </div>
              <div className="carryover-scroll overflow-x-auto rounded-xl border border-slate-200 max-h-72 overflow-y-auto print:max-h-none print:overflow-visible">
                <table className="w-full text-start text-[10px] border-collapse font-mono">
                  <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200 sticky top-0">
                    <tr>
                      <th className="p-1.5 text-start font-sans">{isAr ? 'الشهر والسنة' : 'Mois'}</th>
                      <th className="p-1.5 text-end">{isAr ? 'المنقول الافتتاحي' : 'Début'}</th>
                      <th className="p-1.5 text-end text-emerald-800">{isAr ? '(+) المداخيل' : '(+) Recettes'}</th>
                      <th className="p-1.5 text-end text-rose-800">{isAr ? '(-) المصاريف' : '(-) Dépenses'}</th>
                      <th className="p-1.5 text-end font-black">{isAr ? '(=) الرصيد المرحّل' : '(=) Report'}</th>
                      <th className="p-1.5 text-center font-sans">{isAr ? 'الوضعية' : 'Statut'}</th>
                      <th className="p-1.5 text-center font-sans no-print">{isAr ? 'إجراءات' : 'Actions'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {monthly24TrendData.map((item) => (
                      <tr key={item.monthKey} className="hover:bg-slate-50">
                        <td className="p-1.5 font-sans font-bold">{item.label}</td>
                        <td className="p-1.5 text-end text-slate-600">{item.openingBalance.toLocaleString()}</td>
                        <td className="p-1.5 text-end text-emerald-700 font-bold">+{item.income.toLocaleString()}</td>
                        <td className="p-1.5 text-end text-rose-700 font-bold">-{item.expenses.toLocaleString()}</td>
                        <td className="p-1.5 text-end font-black text-slate-900">{item.closingBalance.toLocaleString()} DH</td>
                        <td className="p-1.5 text-center font-sans text-[9px]">
                          {item.isClosingSurplus ? (isAr ? 'فائض 🟢' : 'Excédent') : (isAr ? 'عجز 🔴' : 'Déficit')}
                        </td>
                        <td className="p-1.5 text-center font-sans no-print whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => {
                              try { sessionStorage.setItem('ledger_focus_month', item.monthKey); } catch (e) { /* ignore */ }
                              setActiveSection('ledger');
                            }}
                            className="px-2 py-1 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-black cursor-pointer"
                          >
                            {manualMonthlyRecords.some(r => r.monthKey === item.monthKey) ? (isAr ? 'تغيير' : 'Modifier') : (isAr ? 'إدخال' : 'Saisir')}
                          </button>
                          {manualMonthlyRecords.some(r => r.monthKey === item.monthKey) && (
                            <button
                              type="button"
                              onClick={() => {
                                const rec = manualMonthlyRecords.find(r => r.monthKey === item.monthKey);
                                if (!rec) return;
                                if (rec.isClosed) {
                                  window.alert(isAr ? 'هذا الشهر مغلق. أعد فتحه من صفحة المداخيل والمصاريف الشهرية قبل مسحه.' : 'Ce mois est clôturé. Rouvrez-le depuis la page Recettes & Dépenses avant de le supprimer.');
                                  return;
                                }
                                if (window.confirm(isAr ? `مسح بيانات ${item.label} نهائياً؟` : `Supprimer définitivement ${item.label} ?`)) {
                                  deleteManualMonthlyRecord(rec.id);
                                }
                              }}
                              className="ms-1 px-2 py-1 rounded bg-rose-50 hover:bg-rose-600 hover:text-white text-rose-700 text-[10px] font-black cursor-pointer"
                            >
                              {isAr ? 'مسح' : 'Supprimer'}
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Audit Committee Observations */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2 text-xs">
            <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>{isAr ? 'خلاصة الافتحاص والملاحظات المحاسبية للجمع العام (2025 و 2026):' : 'Synthèse d\'Audit & Recommandations pour l\'Assemblée Générale :'}</span>
            </h4>
            <ul className="space-y-1 text-[11px] text-slate-600 list-disc list-inside">
              <li>
                {isAr 
                  ? `تغيّرت المداخيل بين 2025 و 2026 بنسبة (${twoYearsComparison.growthRecettes >= 0 ? '+' : ''}${twoYearsComparison.growthRecettes}%).`
                  : `Les recettes ont évolué de (${twoYearsComparison.growthRecettes >= 0 ? '+' : ''}${twoYearsComparison.growthRecettes}%) entre 2025 et 2026.`}
              </li>
              <li>
                {isAr 
                  ? `تغيّرت المصاريف بين 2025 و 2026 بنسبة (${twoYearsComparison.growthDepenses >= 0 ? '+' : ''}${twoYearsComparison.growthDepenses}%).`
                  : `Les dépenses ont évolué de (${twoYearsComparison.growthDepenses >= 0 ? '+' : ''}${twoYearsComparison.growthDepenses}%) entre 2025 et 2026.`}
              </li>
              <li>
                {isAr 
                  ? `الرصيد الصافي النهائي المرحل لسنة 2027 يستقر على (${masterStatement.remainingBalance.toLocaleString()} درهم) وهو في وضعية ${masterStatement.remainingBalance >= 0 ? 'فائض مالي إيجابي يضمن استقرار الصندوق' : 'عجز يتطلب مواصلة خطة التحصيل'}.`
                  : `Le solde de clôture reporté sur l'exercice 2027 s'établit à (${masterStatement.remainingBalance.toLocaleString()} DH).`}
              </li>
            </ul>
          </div>

          {/* Official Signatures & Stamp Block */}
          <div className="pt-4 border-t-2 border-slate-300 space-y-3">
            <div className="max-w-md mx-auto text-center text-xs">
              {/* Syndic Stamp */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-6 shadow-xs">
                <div className="font-bold text-slate-900 text-sm">
                  {isAr ? 'خاتم وتوقيع وكيل السانديك' : 'Cachet & Signature du Syndic'}
                </div>
                <div className="text-xs text-emerald-950 font-black">
                  مكتب السانديك - الإقامة
                </div>
              </div>
            </div>

            <div className="text-[10px] text-slate-500 text-center pt-1">
              {isAr 
                ? 'تم استخراج هذا التقرير المحاسباتي الرسمي طبقاً لمقتضيات القانون رقم 18.00 المتعلق بنظام الملكية المشتركة للعقارات المبنية بالمملكة المغربية.'
                : 'Document financier conforme aux dispositions de la loi n° 18.00 régissant la copropriété au Royaume du Maroc.'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
