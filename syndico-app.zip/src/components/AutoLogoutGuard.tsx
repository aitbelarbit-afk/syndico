import React, { useEffect, useState, useRef, useCallback } from 'react';
import { useApp } from '../context/AppContext';
import { ShieldAlert, Clock, Save, Lock, CheckCircle2 } from 'lucide-react';

export const AUTO_LOGOUT_DURATION_SECONDS = 300; // 5 minutes
export const AUTO_LOGOUT_WARNING_SECONDS = 30;   // Warning during final 30 seconds

export const AutoLogoutGuard: React.FC = () => {
  const { currentUser, logout, saveAllDataExplicitly, lang, logActivity } = useApp();
  const [secondsRemaining, setSecondsRemaining] = useState<number>(AUTO_LOGOUT_DURATION_SECONDS);
  const [showWarningModal, setShowWarningModal] = useState<boolean>(false);
  const lastActivityTimestampRef = useRef<number>(Date.now());
  const isArabic = lang === 'ar';

  // Keep session alive
  const handleKeepSessionAlive = useCallback(() => {
    lastActivityTimestampRef.current = Date.now();
    setShowWarningModal(false);
    setSecondsRemaining(AUTO_LOGOUT_DURATION_SECONDS);
  }, []);

  // Execute explicit save and logout
  const handlePerformSaveAndLogout = useCallback(() => {
    // 1. Explicitly flush all in-memory collections to local storage
    saveAllDataExplicitly();

    // 2. Add audit activity log entry
    if (currentUser) {
      logActivity(
        'LOGOUT',
        'AUTH',
        currentUser.id,
        'إغلاق تلقائي للتطبيق وحفظ كافة البيانات بعد 5 دقائق من عدم الاستعمال',
        'Déconnexion automatique et sauvegarde intégrale des données après 5 minutes d\'inactivité'
      );
    }

    // 3. Mark session flag so LoginScreen can show a confirmation notification
    try {
      sessionStorage.setItem('residence_auto_logout_msg', '5min_inactivity');
    } catch {
      // Storage unavailable or blocked
    }

    // 4. Terminate active session
    logout();
  }, [currentUser, logout, saveAllDataExplicitly, logActivity]);

  useEffect(() => {
    if (!currentUser) {
      setShowWarningModal(false);
      return;
    }

    lastActivityTimestampRef.current = Date.now();

    // Throttled user activity handler
    let lastThrottledCall = 0;
    const handleUserInteraction = () => {
      const now = Date.now();
      if (now - lastThrottledCall > 600) {
        lastThrottledCall = now;
        lastActivityTimestampRef.current = now;
        // If warning modal is shown and user performs an action, reset it
        setShowWarningModal(false);
      }
    };

    const monitoredEvents = [
      'mousemove',
      'mousedown',
      'keydown',
      'touchstart',
      'scroll',
      'wheel',
      'pointerdown'
    ];

    monitoredEvents.forEach(evt => {
      window.addEventListener(evt, handleUserInteraction, { passive: true });
    });

    // Check inactivity every second
    const intervalTimer = setInterval(() => {
      const idleTimeSeconds = Math.floor((Date.now() - lastActivityTimestampRef.current) / 1000);
      const remaining = AUTO_LOGOUT_DURATION_SECONDS - idleTimeSeconds;

      if (remaining <= 0) {
        clearInterval(intervalTimer);
        handlePerformSaveAndLogout();
      } else if (remaining <= AUTO_LOGOUT_WARNING_SECONDS) {
        setSecondsRemaining(remaining);
        setShowWarningModal(true);
      } else {
        setSecondsRemaining(remaining);
        setShowWarningModal(false);
      }
    }, 1000);

    return () => {
      clearInterval(intervalTimer);
      monitoredEvents.forEach(evt => {
        window.removeEventListener(evt, handleUserInteraction);
      });
    };
  }, [currentUser, handlePerformSaveAndLogout]);

  if (!currentUser || !showWarningModal) {
    return null;
  }

  return (
    <div 
      className="fixed inset-0 z-[100000] bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200"
      dir={isArabic ? 'rtl' : 'ltr'}
    >
      <div 
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="auto-logout-title"
        aria-describedby="auto-logout-desc"
        className="w-full max-w-md bg-white rounded-3xl shadow-2xl border-2 border-rose-300 overflow-hidden"
      >
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-[#0a8591] to-[#0b6a78] text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/15 rounded-xl text-amber-300 animate-pulse">
              <Clock className="w-6 h-6" />
            </div>
            <div>
              <h3 id="auto-logout-title" className="font-extrabold text-base sm:text-lg leading-tight">
                {isArabic ? 'تنبيه الأمان: إغلاق تلقائي' : 'Alerte de sécurité : Inactivité'}
              </h3>
              <p className="text-xs text-rose-200 mt-0.5">
                {isArabic ? 'حماية بيانات الإقامة' : 'Protection des données de la résidence'}
              </p>
            </div>
          </div>
          
          <div className="flex flex-col items-center">
            <span className="w-11 h-11 rounded-2xl bg-white/15 text-amber-300 font-mono font-black text-lg flex items-center justify-center border border-white/20 shadow-inner">
              {secondsRemaining}s
            </span>
            <span className="text-[10px] text-rose-200 mt-0.5 font-bold">
              {isArabic ? 'ثانية' : 'sec'}
            </span>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-4">
          <div className="flex items-start gap-3.5 p-4 bg-rose-50 border border-rose-200 rounded-2xl">
            <ShieldAlert className="w-5 h-5 text-rose-700 shrink-0 mt-0.5" />
            <div id="auto-logout-desc" className="text-xs sm:text-sm text-slate-800 leading-relaxed">
              {isArabic ? (
                <>
                  لم يتم رصد أي نشاط منذ <strong className="text-rose-900 font-bold">4 دقائق و30 ثانية</strong>. 
                  لحماية سرية الحساب ومنع الوصول غير المصرح به، سيتم <strong className="text-[#0a8591] font-bold">حفظ كافة البيانات تلقائياً</strong> وإغلاق التطبيق خلال{' '}
                  <span className="font-extrabold text-rose-700 text-base underline decoration-rose-400">{secondsRemaining} ثانية</span>.
                </>
              ) : (
                <>
                  Aucune activité depuis <strong className="text-rose-900 font-bold">4 min 30 s</strong>. 
                  Par mesure de sécurité, toutes vos modifications seront <strong className="text-[#0a8591] font-bold">sauvegardées automatiquement</strong> et votre session sera fermée dans{' '}
                  <span className="font-extrabold text-rose-700 text-base underline decoration-rose-400">{secondsRemaining} secondes</span>.
                </>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2.5 p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-900 text-xs font-bold">
            <Save className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              {isArabic 
                ? 'الحفظ الآمن مفعل: لن تفقد أي مدفوعات أو مصاريف أو تعديلات قمت بها.' 
                : 'Sauvegarde active : aucune perte de données ou de modifications.'}
            </span>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex flex-col sm:flex-row gap-2.5">
            <button
              type="button"
              id="btn-keep-session-alive"
              onClick={handleKeepSessionAlive}
              className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white text-xs sm:text-sm font-bold shadow-md shadow-emerald-700/20 cursor-pointer flex items-center justify-center gap-2 active:scale-95 transition-all"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isArabic ? 'متابعة العمل في التطبيق' : 'Continuer la session'}</span>
            </button>

            <button
              type="button"
              id="btn-save-and-logout-immediate"
              onClick={handlePerformSaveAndLogout}
              className="py-3 px-4 rounded-xl bg-slate-100 hover:bg-rose-100 text-slate-700 hover:text-rose-900 border border-slate-200 text-xs sm:text-sm font-bold cursor-pointer flex items-center justify-center gap-1.5 active:scale-95 transition-all"
            >
              <Lock className="w-4 h-4" />
              <span>{isArabic ? 'حفظ وإغلاق الآن' : 'Sauvegarder & Quitter'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
