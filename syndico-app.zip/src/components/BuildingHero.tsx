import React from 'react';

// Illustration d'accueil : un immeuble résidentiel simple au coucher du soleil.
export const BuildingHero: React.FC<{ className?: string }> = ({ className = '' }) => {
  const windows: { x: number; y: number; lit: boolean }[] = [];
  for (let r = 0; r < 5; r++) {
    for (let c = 0; c < 4; c++) {
      windows.push({ x: 252 + c * 26, y: 72 + r * 32, lit: (r * 4 + c) % 3 !== 1 });
    }
  }
  return (
    <div className={`relative overflow-hidden rounded-3xl border border-white/10 shadow-2xl ${className}`}>
      <svg viewBox="0 0 600 300" className="w-full h-auto block" role="img" aria-label="Immeuble résidentiel" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice">
        <defs>
          <linearGradient id="bh-sky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#0d1022" />
            <stop offset="0.55" stopColor="#0f3d4f" />
            <stop offset="1" stopColor="#ff8240" />
          </linearGradient>
          <linearGradient id="bh-wall" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#e9fbf8" />
            <stop offset="1" stopColor="#c8f4ee" />
          </linearGradient>
          <linearGradient id="bh-side" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#92e8dd" />
            <stop offset="1" stopColor="#52d5c9" />
          </linearGradient>
        </defs>

        <rect width="600" height="300" fill="url(#bh-sky)" />
        {/* Soleil */}
        <circle cx="470" cy="205" r="44" fill="#ffc8a0" opacity="0.85" />
        <circle cx="470" cy="205" r="70" fill="#ff8240" opacity="0.18" />
        {/* Étoiles */}
        {[[60, 40], [140, 22], [210, 58], [400, 30], [520, 48], [560, 90], [90, 100]].map(([x, y], i) => (
          <circle key={i} cx={x} cy={y} r="1.6" fill="#ffffff">
            <animate attributeName="opacity" values="0.2;1;0.2" dur={`${2.5 + i * 0.4}s`} repeatCount="indefinite" />
          </circle>
        ))}
        {/* Nuages */}
        <g fill="#ffffff" opacity="0.16">
          <g>
            <ellipse cx="120" cy="80" rx="46" ry="12" />
            <ellipse cx="150" cy="72" rx="30" ry="11" />
            <animateTransform attributeName="transform" type="translate" values="-30 0; 40 0; -30 0" dur="26s" repeatCount="indefinite" />
          </g>
          <g>
            <ellipse cx="470" cy="62" rx="40" ry="10" />
            <ellipse cx="495" cy="55" rx="26" ry="9" />
            <animateTransform attributeName="transform" type="translate" values="20 0; -50 0; 20 0" dur="32s" repeatCount="indefinite" />
          </g>
        </g>

        {/* Sol */}
        <rect x="0" y="262" width="600" height="38" fill="#072833" />
        <rect x="0" y="262" width="600" height="3" fill="#1fbfb8" opacity="0.5" />

        {/* Arbres */}
        <g>
          <rect x="150" y="238" width="6" height="26" fill="#5b3a29" />
          <circle cx="153" cy="228" r="22" fill="#0b6a78" />
          <circle cx="141" cy="238" r="14" fill="#0a8591" />
          <rect x="446" y="240" width="6" height="24" fill="#5b3a29" />
          <circle cx="449" cy="230" r="20" fill="#0b6a78" />
          <circle cx="460" cy="240" r="13" fill="#0a8591" />
        </g>

        {/* Immeuble : volume latéral */}
        <rect x="350" y="96" width="62" height="168" fill="url(#bh-side)" />
        {[0, 1, 2, 3, 4].map(r => (
          <rect key={r} x="362" y={110 + r * 32} width="14" height="18" rx="2" fill="#0d5262" opacity="0.65" />
        ))}
        {/* Immeuble : volume principal */}
        <rect x="236" y="48" width="122" height="216" fill="url(#bh-wall)" />
        <rect x="228" y="40" width="138" height="12" rx="3" fill="#0f3d4f" />
        <rect x="236" y="52" width="122" height="4" fill="#ff8240" />
        {/* Fenêtres */}
        {windows.map((w, i) => (
          <g key={i}>
            <rect x={w.x} y={w.y} width="16" height="22" rx="2.5" fill={w.lit ? '#ffc8a0' : '#0d5262'} opacity={w.lit ? 1 : 0.7}>
              {w.lit && (
                <animate attributeName="opacity" values="1;0.65;1" dur={`${4 + (i % 5)}s`} repeatCount="indefinite" />
              )}
            </rect>
            <rect x={w.x} y={w.y + 11} width="16" height="1.4" fill="#0f3d4f" opacity="0.35" />
          </g>
        ))}
        {/* Entrée */}
        <rect x="278" y="228" width="38" height="36" rx="3" fill="#0f3d4f" />
        <rect x="282" y="232" width="14" height="32" fill="#ff8240" />
        <rect x="298" y="232" width="14" height="32" fill="#ff8240" opacity="0.8" />
        <rect x="270" y="256" width="54" height="8" rx="2" fill="#c3c8e3" />
        <rect x="266" y="262" width="62" height="4" rx="2" fill="#9097bd" />
        {/* Lampadaire */}
        <rect x="214" y="224" width="3" height="40" fill="#272c47" />
        <circle cx="215.5" cy="222" r="5" fill="#ffc8a0">
          <animate attributeName="opacity" values="1;0.6;1" dur="3s" repeatCount="indefinite" />
        </circle>
      </svg>
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-[#0b0e13] to-transparent" />
    </div>
  );
};
