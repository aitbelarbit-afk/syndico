import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { MaintenanceChecklistItem, DailyMaintenanceLog, MaintenanceCategory } from '../types';
import { 
  CheckCircle2, AlertTriangle, Clock, Calendar, CheckSquare, 
  Square, ShieldCheck, Sparkles, Lightbulb, Droplets, Wrench, 
  ShieldAlert, Plus, Printer, Save, RefreshCw, ChevronDown, 
  ChevronUp, User, Building, FileText, Check, AlertCircle, ArrowRight
} from 'lucide-react';

interface DailyChecklistProps {
  onConvertToTicket: (item: MaintenanceChecklistItem) => void;
}

export const DailyMaintenanceChecklist: React.FC<DailyChecklistProps> = ({ onConvertToTicket }) => {
  const { 
    t, lang, currentUser, buildings, dailyChecklistItems, 
    dailyMaintenanceLogs, toggleChecklistItem, updateChecklistItem, 
    addChecklistItem, saveDailyLog, resetTodayChecklist,
    setAllChecklistStatus 
  } = useApp();

  const isOwner = currentUser?.role === 'resident';

  // State
  const [selectedBuilding, setSelectedBuilding] = useState<string>('ALL');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [inspectorName, setInspectorName] = useState<string>(currentUser?.name || '');
  const [generalNotes, setGeneralNotes] = useState<string>('');
  const [weatherCondition, setWeatherCondition] = useState<string>('normal');
  
  // New Item Modal
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newItemTitle, setNewItemTitle] = useState('');
  const [newItemCategory, setNewItemCategory] = useState<MaintenanceCategory>('lighting');
  const [newItemArea, setNewItemArea] = useState('');
  const [newItemBuilding, setNewItemBuilding] = useState('ALL');

  // History expansion
  const [showHistory, setShowHistory] = useState(false);
  const [selectedHistoryLog, setSelectedHistoryLog] = useState<DailyMaintenanceLog | null>(null);

  // Success Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Filter items
  const filteredItems = useMemo(() => {
    return dailyChecklistItems.filter(item => {
      const matchBuilding = selectedBuilding === 'ALL' || item.buildingCode === 'ALL' || item.buildingCode === selectedBuilding;
      const matchCategory = selectedCategory === 'ALL' || item.category === selectedCategory;
      return matchBuilding && matchCategory;
    });
  }, [dailyChecklistItems, selectedBuilding, selectedCategory]);

  // Statistics
  const totalCount = filteredItems.length;
  const completedCount = filteredItems.filter(i => i.isCompleted).length;
  const issuesCount = filteredItems.filter(i => i.hasIssue).length;
  const pendingCount = totalCount - completedCount;
  const completionPercentage = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const todayStr = new Date().toISOString().slice(0, 10);

  const getCategoryBadge = (cat: MaintenanceCategory) => {
    switch (cat) {
      case 'lighting':
        return { icon: <Lightbulb className="w-3.5 h-3.5 text-amber-500" />, label: lang === 'ar' ? 'إنارة وكهرباء' : 'Éclairage', bg: 'bg-amber-50 text-amber-700 border-amber-200' };
      case 'plumbing':
        return { icon: <Droplets className="w-3.5 h-3.5 text-blue-600" />, label: lang === 'ar' ? 'مضخات وسباكة' : 'Plomberie', bg: 'bg-blue-50 text-blue-700 border-blue-200' };
      case 'cleaning':
        return { icon: <Sparkles className="w-3.5 h-3.5 text-emerald-600" />, label: lang === 'ar' ? 'نظافة ومرافق' : 'Propreté', bg: 'bg-emerald-50 text-emerald-700 border-emerald-200' };
      case 'security':
        return { icon: <ShieldAlert className="w-3.5 h-3.5 text-red-600" />, label: lang === 'ar' ? 'أمن وبوابات' : 'Sécurité', bg: 'bg-red-50 text-red-700 border-red-200' };
      default:
        return { icon: <Wrench className="w-3.5 h-3.5 text-slate-600" />, label: lang === 'ar' ? 'عام' : 'Général', bg: 'bg-slate-50 text-slate-700 border-slate-200' };
    }
  };

  const handleAddNewItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemTitle.trim()) return;

    addChecklistItem({
      title: newItemTitle.trim(),
      category: newItemCategory,
      area: newItemArea.trim() || (lang === 'ar' ? 'المرافق المشتركة' : 'Parties communes'),
      buildingCode: newItemBuilding,
      isCompleted: false,
    });

    setNewItemTitle('');
    setNewItemArea('');
    setIsAddModalOpen(false);
    showToast(lang === 'ar' ? 'تمت إضافة مهمة الفحص بنجاح' : 'Tâche ajoutée avec succès');
  };

  const handleSaveLog = () => {
    if (isOwner) return;
    const log = saveDailyLog(inspectorName, generalNotes, weatherCondition);
    showToast(t.maintenance.logSavedSuccess);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-5 py-3 rounded-2xl bg-slate-900 text-white text-xs font-semibold shadow-xl animate-in fade-in duration-200">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Checklist Header Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="p-2.5 rounded-xl bg-amber-50 text-amber-700 border border-amber-200">
                <CheckSquare className="w-6 h-6" />
              </span>
              <div>
                <h2 className="text-lg sm:text-xl font-bold text-slate-900">
                  {t.maintenance.checklistTitle}
                </h2>
                <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                  {t.maintenance.checklistSubtitle}
                </p>
              </div>
            </div>

            {/* Quick Context & Date */}
            <div className="flex flex-wrap items-center gap-3 mt-4 text-xs font-medium text-slate-600">
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-100 border border-slate-200">
                <Calendar className="w-3.5 h-3.5 text-amber-600" />
                <span>{todayStr}</span>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-100 border border-slate-200">
                <User className="w-3.5 h-3.5 text-slate-600" />
                <span>{inspectorName}</span>
              </div>
              {dailyMaintenanceLogs.length > 0 && (
                <button
                  onClick={() => setShowHistory(!showHistory)}
                  className="flex items-center gap-1 px-3 py-1 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 transition-colors cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5 text-amber-700" />
                  <span>{t.maintenance.historyLogs} ({dailyMaintenanceLogs.length})</span>
                  {showHistory ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>
              )}
            </div>
          </div>

          {/* KPI & Completion Progress Dial */}
          <div className="flex items-center gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-200 min-w-[280px]">
            <div className="relative flex items-center justify-center">
              <div className={`w-16 h-16 rounded-full flex flex-col items-center justify-center border-4 ${
                completionPercentage === 100 
                  ? 'border-emerald-500 bg-emerald-50 text-emerald-900' 
                  : completionPercentage > 50 
                  ? 'border-amber-500 bg-amber-50 text-amber-900'
                  : 'border-slate-300 bg-white text-slate-700'
              }`}>
                <span className="text-base font-black font-mono leading-none">{completionPercentage}%</span>
                <span className="text-[9px] font-bold text-slate-400 mt-0.5">{completedCount}/{totalCount}</span>
              </div>
            </div>

            <div className="space-y-1 text-xs">
              <div className="font-bold text-slate-800 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>{t.maintenance.todayProgress}</span>
              </div>
              <div className="flex items-center gap-2 text-[11px] text-slate-500 font-medium">
                <span className="text-emerald-700 font-bold">{completedCount} {t.maintenance.allDone}</span>
                <span>•</span>
                <span className={issuesCount > 0 ? 'text-red-600 font-bold' : 'text-slate-500'}>
                  {issuesCount} {lang === 'ar' ? 'ملاحظة/عطل' : 'anomalies'}
                </span>
              </div>
              <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all duration-300 ${
                    completionPercentage === 100 ? 'bg-emerald-500' : 'bg-amber-500'
                  }`}
                  style={{ width: `${completionPercentage}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Quick Batch Actions & Controls */}
        {!isOwner && (
          <div className="flex flex-wrap items-center justify-between gap-3 pt-4 mt-5 border-t border-slate-100">
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => setAllChecklistStatus(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-bold transition-all cursor-pointer"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>{t.maintenance.markAllCompleted}</span>
              </button>

              <button
                onClick={() => {
                  if (confirm(lang === 'ar' ? 'هل تريد إعادة ضبط حالة المهام لليوم لبدء فحص جديد؟' : 'Réinitialiser la checklist du jour ?')) {
                    resetTodayChecklist();
                    showToast(lang === 'ar' ? 'تمت إعادة ضبط مهام اليوم' : 'Checklist réinitialisée');
                  }
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-medium transition-all cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
                <span>{t.maintenance.resetTodayChecklist}</span>
              </button>

              <button
                onClick={() => setIsAddModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 text-xs font-bold transition-all cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 text-amber-700" />
                <span>{t.maintenance.addTaskBtn}</span>
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handlePrint}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition-all cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5 text-slate-600" />
                <span>{t.maintenance.exportDailyReport}</span>
              </button>

              <button
                onClick={handleSaveLog}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
              >
                <Save className="w-3.5 h-3.5 text-emerald-100" />
                <span>{t.maintenance.saveDailyLog}</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* History Drawer / Log Viewer */}
      {showHistory && (
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-amber-600" />
              <h3 className="font-bold text-sm sm:text-base text-slate-900">{t.maintenance.historyLogs}</h3>
            </div>
            <button 
              onClick={() => setShowHistory(false)}
              className="text-xs text-slate-400 hover:text-slate-700 font-semibold"
            >
              {lang === 'ar' ? 'إغلاق السجل' : 'Fermer'}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {dailyMaintenanceLogs.map(log => (
              <div 
                key={log.id}
                onClick={() => setSelectedHistoryLog(log)}
                className="p-3.5 rounded-xl border border-slate-200 hover:border-amber-400 hover:bg-amber-50/40 transition-all cursor-pointer space-y-2 bg-slate-50/50"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900">{log.date}</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    log.completionRate === 100 ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {log.completionRate}%
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 flex items-center justify-between">
                  <span>{log.inspectorName}</span>
                  <span>{log.items.filter(i => i.isCompleted).length}/{log.items.length} {lang === 'ar' ? 'مهمة' : 'points'}</span>
                </div>
                {log.generalNotes && (
                  <p className="text-[11px] text-slate-600 truncate italic">
                    "{log.generalNotes}"
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Selected Historical Log View Modal */}
      {selectedHistoryLog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 max-h-[85vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-amber-600" />
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-slate-900">
                    {lang === 'ar' ? `تقرير الفحص اليومي المؤرخ في ${selectedHistoryLog.date}` : `Fiche de contrôle du ${selectedHistoryLog.date}`}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {lang === 'ar' ? `الفاحص: ${selectedHistoryLog.inspectorName} • نسبة الإنجاز: ${selectedHistoryLog.completionRate}%` : `Contrôleur: ${selectedHistoryLog.inspectorName} • ${selectedHistoryLog.completionRate}% réalisé`}
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setSelectedHistoryLog(null)}
                className="p-1 rounded-lg hover:bg-slate-200 text-slate-500 font-bold"
              >
                ✕
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-3 flex-1">
              {selectedHistoryLog.generalNotes && (
                <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 mb-3">
                  <span className="font-bold block mb-0.5">{lang === 'ar' ? 'ملاحظات عامة:' : 'Observations générales:'}</span>
                  {selectedHistoryLog.generalNotes}
                </div>
              )}

              <div className="space-y-2">
                {selectedHistoryLog.items.map((item, idx) => (
                  <div 
                    key={item.id || idx} 
                    className={`p-3 rounded-xl border flex items-start justify-between gap-3 text-xs ${
                      item.isCompleted ? 'bg-white border-slate-200' : 'bg-rose-50/50 border-rose-200'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      {item.isCompleted ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      ) : (
                        <Clock className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                      )}
                      <div>
                        <div className="font-bold text-slate-900">{item.title}</div>
                        <div className="text-[11px] text-slate-400 font-medium">
                          {item.area} {item.buildingCode !== 'ALL' && `(${item.buildingCode})`}
                        </div>
                        {item.notes && (
                          <p className="text-[11px] text-slate-600 mt-1 italic">
                            {item.notes}
                          </p>
                        )}
                        {item.hasIssue && item.issueNotes && (
                          <p className="text-[11px] text-red-600 mt-1 font-semibold">
                            ⚠️ {item.issueNotes}
                          </p>
                        )}
                      </div>
                    </div>

                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 ${
                      item.isCompleted ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {item.isCompleted ? t.maintenance.itemCompleted : t.maintenance.itemPending}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-4 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => setSelectedHistoryLog(null)}
                className="px-4 py-2 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800"
              >
                {t.common.close || 'إغلاق'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Filter and Categorization Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2 flex-1">
          {/* Building Filter */}
          <select
            value={selectedBuilding}
            onChange={(e) => setSelectedBuilding(e.target.value)}
            className="h-9 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden font-medium text-slate-700"
          >
            <option value="ALL">{t.maintenance.allBuildings}</option>
            {buildings.map(b => (
              <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
            ))}
          </select>

          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="h-9 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden font-medium text-slate-700"
          >
            <option value="ALL">{t.maintenance.filterCategory}</option>
            <option value="lighting">{t.maintenance.catLighting}</option>
            <option value="plumbing">{t.maintenance.catPlumbing}</option>
            <option value="cleaning">{t.maintenance.catCleaning}</option>
            <option value="security">{t.maintenance.catSecurity}</option>
          </select>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
          <span>{filteredItems.length} {lang === 'ar' ? 'نقطة مراقبة' : 'points de contrôle'}</span>
        </div>
      </div>

      {/* Checklist Interactive Item Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {filteredItems.map(item => {
          const badge = getCategoryBadge(item.category);
          return (
            <div
              key={item.id}
              className={`rounded-2xl border p-4 sm:p-4.5 transition-all flex flex-col justify-between ${
                item.isCompleted 
                  ? 'bg-white border-slate-200 shadow-xs' 
                  : item.hasIssue
                  ? 'bg-rose-50/40 border-rose-300 shadow-xs'
                  : 'bg-white border-amber-200/80 shadow-xs'
              }`}
            >
              <div>
                {/* Header line */}
                <div className="flex items-start justify-between gap-2.5">
                  <div className="flex items-start gap-3">
                    <button
                      disabled={isOwner}
                      onClick={() => toggleChecklistItem(item.id)}
                      className={`mt-0.5 transition-transform active:scale-90 ${isOwner ? 'cursor-default' : 'cursor-pointer'}`}
                    >
                      {item.isCompleted ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                      ) : (
                        <div className="w-5 h-5 rounded-md border-2 border-slate-300 hover:border-amber-500 bg-white" />
                      )}
                    </button>

                    <div>
                      <h4 className={`text-xs sm:text-sm font-bold ${
                        item.isCompleted ? 'text-slate-800 line-through decoration-slate-300' : 'text-slate-900'
                      }`}>
                        {item.title}
                      </h4>
                      <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400 font-medium">
                        <span className="text-slate-600">{item.area}</span>
                        <span>•</span>
                        <span className="text-slate-500">{item.buildingCode === 'ALL' ? (lang === 'ar' ? 'كل العمارات' : 'Tous les blocs') : item.buildingCode}</span>
                      </div>
                    </div>
                  </div>

                  <span className={`px-2 py-0.5 rounded-lg border text-[10px] font-bold flex items-center gap-1 shrink-0 ${badge.bg}`}>
                    {badge.icon}
                    <span>{badge.label}</span>
                  </span>
                </div>

                {/* Sub-Notes or Issue Section */}
                <div className="mt-3 space-y-2">
                  {!isOwner && (
                    <div className="flex items-center gap-2">
                      <input
                        type="text"
                        value={item.notes || ''}
                        onChange={(e) => updateChecklistItem(item.id, { notes: e.target.value })}
                        placeholder={lang === 'ar' ? 'إضافة ملاحظة فنية / تقرير...' : 'Ajouter une note de contrôle...'}
                        className="w-full h-8 px-2.5 text-[11px] rounded-lg bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
                      />
                    </div>
                  )}

                  {item.hasIssue && (
                    <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-900 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-bold flex items-center gap-1 text-[11px] text-rose-800">
                          <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                          {lang === 'ar' ? 'تم رصد خلل بحاجة لتدخل:' : 'Anomalie détectée :'}
                        </span>
                        {!isOwner && (
                          <button
                            onClick={() => onConvertToTicket(item)}
                            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-[10px] font-bold transition-all shadow-2xs cursor-pointer"
                          >
                            <span>{t.maintenance.convertIssueToTicket}</span>
                            <ArrowRight className="w-3 h-3 rtl:rotate-180" />
                          </button>
                        )}
                      </div>
                      <input
                        type="text"
                        disabled={isOwner}
                        value={item.issueNotes || ''}
                        onChange={(e) => updateChecklistItem(item.id, { issueNotes: e.target.value })}
                        placeholder={lang === 'ar' ? 'تفاصيل العطل أو الخلل الملاحظ...' : 'Détails de l\'anomalie...'}
                        className="w-full h-7 px-2 text-[11px] rounded-md bg-white border border-rose-300 focus:outline-hidden"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Bottom Card Controls */}
              {!isOwner && (
                <div className="flex items-center justify-between gap-2 pt-3 mt-3 border-t border-slate-100 text-[11px]">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => updateChecklistItem(item.id, { 
                        hasIssue: !item.hasIssue,
                        issueNotes: !item.hasIssue ? (item.issueNotes || (lang === 'ar' ? 'عطل مرصود أثناء الفحص اليومي' : 'Anomalie détectée')) : '' 
                      })}
                      className={`px-2 py-0.5 rounded-md font-bold transition-colors cursor-pointer flex items-center gap-1 ${
                        item.hasIssue ? 'bg-rose-100 text-rose-900' : 'bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-700'
                      }`}
                    >
                      <AlertCircle className="w-3 h-3" />
                      <span>{item.hasIssue ? (lang === 'ar' ? 'خلل مسجل' : 'Anomalie') : (lang === 'ar' ? 'تسجيل عطل' : 'Signaler panne')}</span>
                    </button>
                  </div>

                  {item.completedAt && (
                    <span className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md font-mono flex items-center gap-1 border border-emerald-100 font-medium">
                      <Clock className="w-2.5 h-2.5 text-emerald-600" />
                      <span>{lang === 'ar' ? 'أُنجز في: ' : 'Fait à: '} {item.completedAt.slice(11, 19)}</span>
                    </span>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Daily Inspector Notes & Documentation Footer */}
      {!isOwner && (
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900 border-b border-slate-100 pb-2.5">
            <FileText className="w-4 h-4 text-amber-600" />
            <span>{lang === 'ar' ? 'توثيق تقرير المشرف والملاحظات الختامية' : 'Rapport et observations de clôture du superviseur'}</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">{t.maintenance.inspector}</label>
              <input
                type="text"
                value={inspectorName}
                onChange={(e) => setInspectorName(e.target.value)}
                placeholder={lang === 'ar' ? 'اسم المشرف أو التقني الفاحص' : 'Nom du contrôleur'}
                className="w-full h-10 px-3 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden font-medium"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">{lang === 'ar' ? 'حالة الطقس أو الوضع العام' : 'Conditions météo / État général'}</label>
              <select
                value={weatherCondition}
                onChange={(e) => setWeatherCondition(e.target.value)}
                className="w-full h-10 px-3 rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden font-medium"
              >
                <option value="normal">{lang === 'ar' ? 'عادي ومستقر' : 'Normal / Stable'}</option>
                <option value="rainy">{lang === 'ar' ? 'أجواء ماطرة (مراقبة تصريف المياه)' : 'Pluvieux (Vérif écoulement)'}</option>
                <option value="hot">{lang === 'ar' ? 'حرارة مرتفعة (مراقبة تهوية المضخات والخزانات)' : 'Forte chaleur (Vérif aération)'}</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">{lang === 'ar' ? 'ملاحظات وتوصيات المشرف العامة' : 'Observations générales et recommandations'}</label>
            <textarea
              rows={2}
              value={generalNotes}
              onChange={(e) => setGeneralNotes(e.target.value)}
              placeholder={lang === 'ar' ? 'تم تفقد جميع عمارات الإقامة والتأكد من اشتغال المضخات والإنارة والنظافة العامة...' : 'Rapport de synthèse du jour...'}
              className="w-full p-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              onClick={handleSaveLog}
              className="px-6 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-2 cursor-pointer"
            >
              <Save className="w-4 h-4 text-emerald-200" />
              <span>{t.maintenance.saveDailyLog}</span>
            </button>
          </div>
        </div>
      )}

      {/* Add Item Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4.5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-sm sm:text-base text-slate-900 flex items-center gap-2">
                <Plus className="w-4 h-4 text-amber-600" />
                <span>{t.maintenance.addTaskBtn}</span>
              </h3>
              <button 
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-200 text-slate-400 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddNewItem} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{lang === 'ar' ? 'عنوان نقطة المراقبة والفحص *' : 'Titre du point de contrôle *'}</label>
                <input
                  type="text"
                  required
                  value={newItemTitle}
                  onChange={(e) => setNewItemTitle(e.target.value)}
                  placeholder={lang === 'ar' ? 'مثال: فحص إنارة بهو المدخل والدرج...' : 'Ex: Contrôle éclairage hall...'}
                  className="w-full h-10 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{t.maintenance.category}</label>
                  <select
                    value={newItemCategory}
                    onChange={(e) => setNewItemCategory(e.target.value as MaintenanceCategory)}
                    className="w-full h-10 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
                  >
                    <option value="lighting">{t.maintenance.catLighting}</option>
                    <option value="plumbing">{t.maintenance.catPlumbing}</option>
                    <option value="cleaning">{t.maintenance.catCleaning}</option>
                    <option value="security">{t.maintenance.catSecurity}</option>
                    <option value="other">{lang === 'ar' ? 'أخرى' : 'Autre'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{t.maintenance.building}</label>
                  <select
                    value={newItemBuilding}
                    onChange={(e) => setNewItemBuilding(e.target.value)}
                    className="w-full h-10 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
                  >
                    <option value="ALL">{t.maintenance.allBuildings}</option>
                    {buildings.map(b => (
                      <option key={b.id} value={b.code}>{b.code}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.maintenance.apartmentOrArea || 'الموقع'}</label>
                <input
                  type="text"
                  value={newItemArea}
                  onChange={(e) => setNewItemArea(e.target.value)}
                  placeholder={lang === 'ar' ? 'مثال: السطح، غرفة المحركات، المدخل...' : 'Ex: Terrasse, local technique...'}
                  className="w-full h-10 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-semibold"
                >
                  {t.common.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold shadow-xs"
                >
                  {t.common.create}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
