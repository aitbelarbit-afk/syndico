import { RES } from '../config/residence';
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  MaintenanceTicket, MaintenanceCategory, MaintenancePriority, 
  MaintenanceStatus 
} from '../types';
import { 
  Wrench, Plus, Search, CheckCircle2, Trash2, Edit2, 
  Check, X, ShieldAlert, Sparkles, Lightbulb, Droplets, 
  MessageSquare, User, Phone, Send, Calendar, Clock, 
  FileText, CheckCircle, AlertTriangle, Printer, Share2, 
  ArrowRight, Filter, ChevronDown, CheckCheck, RefreshCw
} from 'lucide-react';
import { Wrench as HeaderIcon } from 'lucide-react';

export const MaintenanceView: React.FC = () => {
  const { 
    t, lang, currentUser, maintenanceTickets, buildings, 
    addMaintenanceTicket, updateMaintenanceTicket, deleteMaintenanceTicket 
  } = useApp();
  
  const isOwner = currentUser?.role === 'resident';

  // Active View Tabs: 'all_complaints' | 'new_form' | 'interventions_log'
  const [activeTab, setActiveTab] = useState<'all_complaints' | 'new_form' | 'interventions_log'>('all_complaints');

  // Search and Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [filterBuilding, setFilterBuilding] = useState<string>('ALL');
  const [filterPriority, setFilterPriority] = useState<string>('ALL');

  // Modals state
  const [replyModalTicket, setReplyModalTicket] = useState<MaintenanceTicket | null>(null);
  const [replyText, setReplyText] = useState('');
  
  const [interventionModalTicket, setInterventionModalTicket] = useState<MaintenanceTicket | null>(null);
  const [technicianName, setTechnicianName] = useState('');
  const [technicianPhone, setTechnicianPhone] = useState('');
  const [interventionDetails, setInterventionDetails] = useState('');
  const [interventionDate, setInterventionDate] = useState('');
  const [estimatedCost, setEstimatedCost] = useState<number>(0);
  const [actualCost, setActualCost] = useState<number>(0);
  const [interventionReport, setInterventionReport] = useState('');
  const [interventionStatus, setInterventionStatus] = useState<'pending' | 'in_progress' | 'completed'>('in_progress');

  // Printable Modal State
  const [printTicket, setPrintTicket] = useState<MaintenanceTicket | null>(null);

  // New / Edit Complaint Form State
  const [formTitle, setFormTitle] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formBuildingCode, setFormBuildingCode] = useState(currentUser?.building || buildings[0]?.code || '');
  const [formApartmentOrArea, setFormApartmentOrArea] = useState(isOwner && currentUser?.apartment ? `شقة ${currentUser.apartment}` : '');
  const [formCategory, setFormCategory] = useState<MaintenanceCategory>('lighting');
  const [formPriority, setFormPriority] = useState<MaintenancePriority>('medium');
  const [formReportedBy, setFormReportedBy] = useState(currentUser?.name || '');
  const [formOwnerPhone, setFormOwnerPhone] = useState(currentUser?.phone || '');
  const [editingTicketId, setEditingTicketId] = useState<string | null>(null);
  const [ticketToDelete, setTicketToDelete] = useState<MaintenanceTicket | null>(null);

  // Toast Notification State
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Metrics Calculation
  const totalComplaints = maintenanceTickets.length;
  const newPendingReplies = maintenanceTickets.filter(t => !t.syndicResponse && t.status !== 'resolved').length;
  const inProgressCount = maintenanceTickets.filter(t => t.status === 'in_progress' || (t.interventionDetails && t.status !== 'resolved')).length;
  const resolvedCount = maintenanceTickets.filter(t => t.status === 'resolved').length;
  const totalCost = maintenanceTickets.reduce((acc, curr) => acc + (curr.actualCost || curr.estimatedCost || 0), 0);

  // Open Form to Create
  const handleOpenCreateForm = () => {
    setEditingTicketId(null);
    setFormTitle('');
    setFormDescription('');
    setFormBuildingCode(currentUser?.building || buildings[0]?.code || '');
    setFormApartmentOrArea(isOwner && currentUser?.apartment ? `شقة ${currentUser.apartment}` : (lang === 'ar' ? 'المدخل الرئيسي / المرافق' : 'Hall d\'entrée'));
    setFormCategory('lighting');
    setFormPriority('medium');
    setFormReportedBy(currentUser?.name || (isOwner ? 'المالك' : ''));
    setFormOwnerPhone(currentUser?.phone || '');
    setActiveTab('new_form');
  };

  // Open Form to Edit Complaint
  const handleOpenEditForm = (ticket: MaintenanceTicket) => {
    setEditingTicketId(ticket.id);
    setFormTitle(ticket.title);
    setFormDescription(ticket.description);
    setFormBuildingCode(ticket.buildingCode);
    setFormApartmentOrArea(ticket.apartmentOrArea);
    setFormCategory(ticket.category);
    setFormPriority(ticket.priority);
    setFormReportedBy(ticket.reportedBy);
    setFormOwnerPhone(ticket.ownerPhone || '');
    setActiveTab('new_form');
  };

  // Handle Submit New or Edit Complaint
  const handleSubmitComplaint = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formBuildingCode) {
      showToast(lang === 'ar' ? 'يرجى ملء موضوع الشكاية والعمارة' : 'Veuillez renseigner le titre et le bâtiment');
      return;
    }

    if (editingTicketId) {
      updateMaintenanceTicket(editingTicketId, {
        title: formTitle.trim(),
        description: formDescription.trim(),
        buildingCode: formBuildingCode,
        apartmentOrArea: formApartmentOrArea.trim() || (lang === 'ar' ? 'المرافق المشتركة' : 'Parties communes'),
        category: formCategory,
        priority: formPriority,
        reportedBy: formReportedBy.trim() || (lang === 'ar' ? 'ساكن العمارة' : 'Copropriétaire'),
        ownerPhone: formOwnerPhone.trim()
      });
      showToast(lang === 'ar' ? 'تم تحديث الشكاية بنجاح' : 'Réclamation mise à jour avec succès');
    } else {
      addMaintenanceTicket({
        title: formTitle.trim(),
        description: formDescription.trim(),
        buildingCode: formBuildingCode,
        apartmentOrArea: formApartmentOrArea.trim() || (lang === 'ar' ? 'المرافق المشتركة' : 'Parties communes'),
        category: formCategory,
        priority: formPriority,
        status: 'open',
        reportedBy: formReportedBy.trim() || currentUser?.name || (lang === 'ar' ? 'مالك الشقة' : 'Copropriétaire'),
        ownerPhone: formOwnerPhone.trim() || currentUser?.phone || ''
      });
      showToast(
        lang === 'ar' 
          ? (isOwner ? 'تم إرسال الشكاية إلى السانديك بنجاح 🚀' : 'تم تسجيل وتدوين الشكاية الواردة بنجاح 🚀') 
          : 'Réclamation enregistrée avec succès 🚀'
      );
    }

    // Reset Form & Switch to List
    setEditingTicketId(null);
    setActiveTab('all_complaints');
  };

  // Open Syndic Response Modal
  const handleOpenReplyModal = (ticket: MaintenanceTicket) => {
    setReplyModalTicket(ticket);
    setReplyText(ticket.syndicResponse || '');
  };

  // Save Syndic Response
  const handleSaveReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyModalTicket) return;

    const now = new Date();
    const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    updateMaintenanceTicket(replyModalTicket.id, {
      syndicResponse: replyText.trim(),
      syndicResponseDate: dateStr,
      syndicResponderName: currentUser?.name || (lang === 'ar' ? 'مكتب السانديك' : 'Bureau du Syndic'),
      status: replyModalTicket.status === 'open' ? 'in_progress' : replyModalTicket.status
    });

    showToast(lang === 'ar' ? 'تم تسجيل رد السانديك وإرساله للمالك بنجاح' : 'Réponse du syndic enregistrée');
    setReplyModalTicket(null);
  };

  // Open Technical Intervention Modal
  const handleOpenInterventionModal = (ticket: MaintenanceTicket) => {
    setInterventionModalTicket(ticket);
    setTechnicianName(ticket.assignedTo || '');
    setTechnicianPhone(ticket.technicianPhone || '');
    setInterventionDetails(ticket.interventionDetails || (lang === 'ar' ? 'معاينة العطل واستبدال القطع المتضررة وإعادة التشغيل' : 'Inspection et remplacement des pièces défectueuses'));
    setInterventionDate(ticket.interventionScheduledDate || new Date().toISOString().slice(0, 10));
    setEstimatedCost(ticket.estimatedCost || 0);
    setActualCost(ticket.actualCost || 0);
    setInterventionReport(ticket.interventionReport || '');
    setInterventionStatus(ticket.interventionStatus || (ticket.status === 'resolved' ? 'completed' : 'in_progress'));
  };

  // Save Technical Intervention
  const handleSaveIntervention = (e: React.FormEvent) => {
    e.preventDefault();
    if (!interventionModalTicket) return;

    const isDone = interventionStatus === 'completed';
    const now = new Date();
    const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    updateMaintenanceTicket(interventionModalTicket.id, {
      assignedTo: technicianName.trim(),
      technicianPhone: technicianPhone.trim(),
      interventionDetails: interventionDetails.trim(),
      interventionScheduledDate: interventionDate,
      estimatedCost: Number(estimatedCost) || 0,
      actualCost: Number(actualCost) || (isDone ? Number(estimatedCost) : 0),
      interventionReport: interventionReport.trim(),
      interventionStatus: interventionStatus,
      status: isDone ? 'resolved' : 'in_progress',
      resolvedAt: isDone ? dateStr : undefined
    });

    showToast(lang === 'ar' ? 'تم تسجيل وتحديث بطاقة التدخل التقني بنجاح' : 'Intervention technique mise à jour avec succès');
    setInterventionModalTicket(null);
  };

  // Quick Resolve Ticket
  const handleQuickResolve = (ticket: MaintenanceTicket) => {
    const cost = prompt(
      lang === 'ar' ? 'أدخل التكلفة الفعلية النهائية للإصلاح (درهم):' : 'Coût réel final de réparation (DH) :', 
      String(ticket.actualCost || ticket.estimatedCost || 0)
    );
    if (cost === null) return;

    const now = new Date();
    const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    updateMaintenanceTicket(ticket.id, {
      status: 'resolved',
      interventionStatus: 'completed',
      actualCost: Number(cost) || 0,
      resolvedAt: dateStr,
      interventionReport: ticket.interventionReport || (lang === 'ar' ? 'تم إنجاز التدخل بنجاح وإصلاح العطل والتأكد من السلامة التشغيلية.' : 'Intervention achevée et panne résolue.')
    });
    showToast(lang === 'ar' ? 'تم تعيين العطل كـ "مكتمل بنجاح" 🟢' : 'Panne marquée comme résolue');
  };
  // Quick In-Progress Ticket
  const handleMarkInProgress = (ticket: MaintenanceTicket) => {
    updateMaintenanceTicket(ticket.id, {
      status: "in_progress",
      interventionStatus: "in_progress",
    });
    showToast(lang === "ar" ? "تم تحويل الحالة إلى \"تحت الإجراء\" ⏳" : "Statut mis à \"En cours\"");
  };


  // Resolve and Delete/Clear Complaint
  const handleResolveAndClear = (ticket: MaintenanceTicket) => {
    const isAlreadyResolved = ticket.status === 'resolved';
    const confirmMsg = isAlreadyResolved
      ? (lang === 'ar' ? `هل أنت متأكد من مسح هذه الشكاية التي تم إصلاحها (${ticket.title}) نهائياً من القائمة؟` : `Voulez-vous supprimer définitivement cette réclamation résolue (${ticket.title}) ?`)
      : (lang === 'ar' ? `هل تم إصلاح العطل (${ticket.title}) بنجاح وتريد مسح الشكاية وإغلاقها نهائياً؟` : `La panne (${ticket.title}) a-t-elle été réparée et souhaitez-vous effacer la réclamation ?`);

    if (confirm(confirmMsg)) {
      deleteMaintenanceTicket(ticket.id);
      showToast(lang === 'ar' ? 'تم مسح الشكاية بعد إتمام الإصلاح بنجاح 🧹✅' : 'Réclamation réparée et supprimée avec succès');
    }
  };

  // WhatsApp helper for Resident
  const handleSendWhatsAppToOwner = (ticket: MaintenanceTicket) => {
    if (!ticket.ownerPhone) {
      alert(lang === 'ar' ? 'لا يوجد رقم هاتف مسجل لهذا المالك' : 'Aucun numéro de téléphone pour ce copropriétaire');
      return;
    }
    const cleanPhone = ticket.ownerPhone.replace(/\D/g, '');
    const phoneWithCode = cleanPhone.startsWith('0') ? `212${cleanPhone.slice(1)}` : cleanPhone;
    const msg = encodeURIComponent(
      `السلام عليكم ${ticket.reportedBy} المحترم،\n` +
      `بخصوص شكايتكم المتعلقة بـ (${ticket.title}) - ${ticket.buildingCode} ${ticket.apartmentOrArea} :\n\n` +
      `📌 رد إدارة السانديك:\n${ticket.syndicResponse || 'تم استلام شكايتكم ونحن بصدد التنسيق مع الفريق التقني للتدخل.'}\n\n` +
      (ticket.assignedTo ? `🔧 التقني المكلف: ${ticket.assignedTo}\n` : '') +
      (ticket.status === 'resolved' ? '✅ الحالة: مكتمل بنجاح.\n' : '⏳ الحالة: جاري المتابعة والإصلاح.\n') +
      `شكراً لتعاونكم - إدارة سانديك ${RES.nameAr}.`
    );
    window.open(`https://wa.me/${phoneWithCode}?text=${msg}`, '_blank');
  };

  // WhatsApp helper for Technician
  const handleSendWhatsAppToTechnician = (ticket: MaintenanceTicket) => {
    if (!ticket.technicianPhone) {
      alert(lang === 'ar' ? 'يرجى إدخال رقم هاتف التقني أولاً' : 'Veuillez renseigner le numéro du technicien');
      return;
    }
    const cleanPhone = ticket.technicianPhone.replace(/\D/g, '');
    const phoneWithCode = cleanPhone.startsWith('0') ? `212${cleanPhone.slice(1)}` : cleanPhone;
    const msg = encodeURIComponent(
      `السلام عليكم ${ticket.assignedTo || 'المعلم'}،\n` +
      `طلب تدخل وصيانة عاجل ب${RES.nameAr}:\n` +
      `📍 المكان: ${ticket.buildingCode} - ${ticket.apartmentOrArea}\n` +
      `⚠️ موضوع العطل: ${ticket.title}\n` +
      `📝 التفاصيل: ${ticket.description}\n` +
      `🔧 المطلوب: ${ticket.interventionDetails || 'معاينة وإصلاح العطل في أقرب وقت'}\n` +
      `📅 الموعد المبرمج: ${ticket.interventionScheduledDate || 'اليوم'}\n` +
      (ticket.ownerPhone ? `📞 هاتف المالك/الساكن: ${ticket.ownerPhone}\n` : '') +
      `يرجى التأكيد عند الانطلاق. شكراً.`
    );
    window.open(`https://wa.me/${phoneWithCode}?text=${msg}`, '_blank');
  };

  // Get Icon based on Category
  const getCategoryIcon = (cat: MaintenanceCategory) => {
    switch (cat) {
      case 'lighting': return <Lightbulb className="w-4 h-4 text-amber-500" />;
      case 'plumbing': return <Droplets className="w-4 h-4 text-blue-600" />;
      case 'security': return <ShieldAlert className="w-4 h-4 text-red-600" />;
      case 'cleaning': return <Sparkles className="w-4 h-4 text-emerald-600" />;
      default: return <Wrench className="w-4 h-4 text-slate-600" />;
    }
  };

  const getCategoryName = (cat: MaintenanceCategory) => {
    switch (cat) {
      case 'lighting': return lang === 'ar' ? 'إنارة وكهرباء' : 'Éclairage / Électricité';
      case 'plumbing': return lang === 'ar' ? 'سباكة ومياه' : 'Plomberie & Eau';
      case 'security': return lang === 'ar' ? 'أمن وبوابات' : 'Sécurité & Portails';
      case 'cleaning': return lang === 'ar' ? 'نظافة ومرافق' : 'Nettoyage';
      default: return lang === 'ar' ? 'صيانة عامة' : 'Maintenance Générale';
    }
  };

  // Filtered Tickets
  const filteredTickets = maintenanceTickets.filter(ticket => {
    const matchesSearch = 
      ticket.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.buildingCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.apartmentOrArea.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.reportedBy.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (ticket.assignedTo && ticket.assignedTo.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (ticket.syndicResponse && ticket.syndicResponse.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesStatus = 
      filterStatus === 'ALL' ? true :
      filterStatus === 'pending_reply' ? (!ticket.syndicResponse && ticket.status !== 'resolved') :
      filterStatus === 'replied' ? (!!ticket.syndicResponse && ticket.status !== 'resolved') :
      ticket.status === filterStatus;

    const matchesCategory = filterCategory === 'ALL' || ticket.category === filterCategory;
    const matchesBuilding = filterBuilding === 'ALL' || ticket.buildingCode === filterBuilding;
    const matchesPriority = filterPriority === 'ALL' || ticket.priority === filterPriority;

    return matchesSearch && matchesStatus && matchesCategory && matchesBuilding && matchesPriority;
  });

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2.5 px-6 py-3.5 rounded-2xl bg-slate-900 text-white text-xs font-bold shadow-2xl border border-slate-700 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Header with Professional Hero Design */}
      <div className="bg-white p-5 sm:p-6 rounded-3xl border-2 border-[#92e8dd] shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-[#e9fbf8] border border-[#92e8dd] text-[#0a8591] shadow-2xs">
              <Wrench className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="icon-wiggle anim-bob w-10 h-10 rounded-2xl bg-gradient-to-br from-orange-400 to-orange-600 text-white flex items-center justify-center shadow-md shrink-0"><HeaderIcon className="w-5 h-5" /></span>
                <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                  {isOwner 
                    ? (lang === 'ar' ? 'الشكاوى وبلاغات الأعطال' : 'Mes Réclamations & Signalements')
                    : (lang === 'ar' ? 'استقبال الشكايات وتدبير الأعطال والتدخلات' : 'Réception des Réclamations, Pannes & Interventions')}
                </h1>
              </div>
              <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1">
                {isOwner
                  ? (lang === 'ar' 
                      ? 'إرسال شكاوى وبلاغات الأعطال إلى مكتب السانديك، ومتابعة الردود وحالة التدخلات التقنية للإصلاح'
                      : 'Envoyez vos réclamations et signalements de pannes au syndic et suivez les interventions techniques')
                  : (lang === 'ar' 
                      ? 'منظومة مركزية لاستقبال شكاوى وبلاغات الملاك، تدوين الإجابات والردود، وبرمجة التدخلات التقنية للإصلاح'
                      : 'Plateforme centrale de réception des réclamations copropriétaires, réponses du syndic et suivi des interventions techniques')}
              </p>
            </div>
          </div>
        </div>

        {/* Action Button: Create New Complaint / Register Incoming Complaint */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleOpenCreateForm}
            className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-[#0a8591] hover:bg-[#0b6a78] active:scale-98 text-white text-xs font-black shadow-md shadow-[#0a8591]/20 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>
              {isOwner 
                ? (lang === 'ar' ? 'كتابة شكاية أو إبلاغ عن عطل' : 'Déposer une réclamation')
                : (lang === 'ar' ? 'استقبال وتدوين شكاية واردة' : 'Enregistrer une réclamation reçue')}
            </span>
          </button>
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div 
          onClick={() => { setFilterStatus('ALL'); setActiveTab('all_complaints'); }}
          className={`p-4 rounded-2xl border transition-all cursor-pointer ${
            filterStatus === 'ALL' && activeTab === 'all_complaints'
              ? 'bg-[#0a8591] text-white border-[#0a8591] shadow-sm'
              : 'bg-white text-slate-900 border-slate-200/80 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-bold opacity-80 mb-2">
            <span>{lang === 'ar' ? 'إجمالي الشكاوى' : 'Total Réclamations'}</span>
            <FileText className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black">{totalComplaints}</div>
          <div className="text-[11px] opacity-70 mt-1">{lang === 'ar' ? 'سجل كافة البلاغات' : 'Toutes les demandes'}</div>
        </div>

        <div 
          onClick={() => { setFilterStatus('pending_reply'); setActiveTab('all_complaints'); }}
          className={`p-4 rounded-2xl border transition-all cursor-pointer ${
            filterStatus === 'pending_reply' && activeTab === 'all_complaints'
              ? 'bg-amber-600 text-white border-amber-600 shadow-sm'
              : 'bg-amber-50/70 text-amber-950 border-amber-200/80 hover:border-amber-300'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-bold mb-2">
            <span>{lang === 'ar' ? 'بانتظار رد السانديك' : 'En attente de réponse'}</span>
            <MessageSquare className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-black text-amber-700">{newPendingReplies}</div>
          <div className="text-[11px] text-amber-800 font-medium mt-1">{lang === 'ar' ? 'شكاوى جديدة واردة' : 'Nouvelles réclamations'}</div>
        </div>

        <div 
          onClick={() => { setFilterStatus('in_progress'); setActiveTab('all_complaints'); }}
          className={`p-4 rounded-2xl border transition-all cursor-pointer ${
            filterStatus === 'in_progress' && activeTab === 'all_complaints'
              ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
              : 'bg-blue-50/70 text-blue-950 border-blue-200/80 hover:border-blue-300'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-bold mb-2">
            <span>{lang === 'ar' ? 'تحت الإجراء' : 'Intervention en cours'}</span>
            <Wrench className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-black text-blue-700">{inProgressCount}</div>
          <div className="text-[11px] text-blue-800 font-medium mt-1">{lang === 'ar' ? 'تقنيون مكلفون ميدانياً' : 'Réparations programmées'}</div>
        </div>

        <div 
          onClick={() => { setFilterStatus('resolved'); setActiveTab('all_complaints'); }}
          className={`p-4 rounded-2xl border transition-all cursor-pointer ${
            filterStatus === 'resolved' && activeTab === 'all_complaints'
              ? 'bg-emerald-700 text-white border-emerald-700 shadow-sm'
              : 'bg-emerald-50/70 text-emerald-950 border-emerald-200/80 hover:border-emerald-300'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-bold mb-2">
            <span>{lang === 'ar' ? 'مكتمل' : 'Pannes Résolues'}</span>
            <CheckCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-emerald-800">{resolvedCount}</div>
          <div className="text-[11px] text-emerald-800 font-medium mt-1">
            {lang === 'ar' ? `التكلفة: ${totalCost.toLocaleString()} درهم` : `Coût: ${totalCost.toLocaleString()} DH`}
          </div>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex items-center justify-between gap-3 border-b border-slate-200 pb-2">
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <button
            onClick={() => setActiveTab('all_complaints')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-black transition-all cursor-pointer ${
              activeTab === 'all_complaints'
                ? 'bg-[#0a8591] text-white shadow-xs'
                : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
            }`}
          >
            <MessageSquare className="w-4 h-4 text-amber-300" />
            <span>
              {isOwner 
                ? (lang === 'ar' ? 'سجل شكاواي والردود' : 'Mes Réclamations & Réponses') 
                : (lang === 'ar' ? 'صندوق الشكاوى الواردة والردود' : 'Boîte des Réclamations Reçues')}
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-[#0b6a78] text-white font-bold">
              {filteredTickets.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('interventions_log')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-black transition-all cursor-pointer ${
              activeTab === 'interventions_log'
                ? 'bg-[#0a8591] text-white shadow-xs'
                : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
            }`}
          >
            <Wrench className="w-4 h-4 text-rose-200" />
            <span>{lang === 'ar' ? 'سجل التدخلات الفنية والإصلاحات' : 'Registre des Interventions Techniques'}</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-white/20 text-white font-bold">
              {maintenanceTickets.filter(t => t.assignedTo || t.interventionDetails).length}
            </span>
          </button>

          <button
            onClick={() => { setEditingTicketId(null); setActiveTab('new_form'); }}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-black transition-all cursor-pointer ${
              activeTab === 'new_form'
                ? 'bg-[#0a8591] text-white shadow-xs'
                : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
            }`}
          >
            <Plus className="w-4 h-4 text-rose-200" />
            <span>
              {isOwner 
                ? (lang === 'ar' ? 'كتابة شكاية جديدة' : 'Nouvelle Réclamation') 
                : (lang === 'ar' ? 'تدوين شكاية واردة' : 'Nouvelle Réclamation Reçue')}
            </span>
          </button>
        </div>
      </div>

      {/* VIEW 1: All Complaints & Syndic Responses List */}
      {activeTab === 'all_complaints' && (
        <div className="space-y-4">
          {/* Search & Filters Bar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs flex flex-wrap items-center justify-between gap-3">
            <div className="flex-1 min-w-[240px] relative">
              <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3 rtl:right-3.5 rtl:left-auto ltr:left-3.5 ltr:right-auto" />
              <input
                type="text"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                placeholder={lang === 'ar' ? 'بحث بموضوع الشكاية، رقم الشقة، المالك، الرد، أو التقني...' : 'Recherche par titre, appartement, propriétaire, réponse...'}
                className="w-full h-10 pr-10 pl-10 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* Status Filter */}
              <select
                value={filterStatus}
                onChange={e => setFilterStatus(e.target.value)}
                className="h-10 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 font-bold text-slate-700"
              >
                <option value="ALL">{lang === 'ar' ? 'جميع الحالات' : 'Tous les états'}</option>
                <option value="pending_reply">{lang === 'ar' ? '⏳ بانتظار رد السانديك' : '⏳ En attente de réponse'}</option>
                <option value="replied">{lang === 'ar' ? '💬 تم الرد من السانديك' : '💬 Répondu par le syndic'}</option>
                <option value="in_progress">{lang === 'ar' ? '🛠️ تحت الإجراء' : '🛠️ Intervention en cours'}</option>
                <option value="resolved">{lang === 'ar' ? '✅ مكتمل' : '✅ Panne résolue'}</option>
              </select>

              {/* Building Filter */}
              <select
                value={filterBuilding}
                onChange={e => setFilterBuilding(e.target.value)}
                className="h-10 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 font-bold text-slate-700"
              >
                <option value="ALL">{lang === 'ar' ? 'جميع العمارات' : 'Tous les bâtiments'}</option>
                {buildings.map(b => (
                  <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                ))}
              </select>

              {/* Category Filter */}
              <select
                value={filterCategory}
                onChange={e => setFilterCategory(e.target.value)}
                className="h-10 px-3 text-xs rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 font-bold text-slate-700"
              >
                <option value="ALL">{lang === 'ar' ? 'جميع الأقسام' : 'Toutes les catégories'}</option>
                <option value="lighting">{lang === 'ar' ? 'إنارة وكهرباء' : 'Éclairage'}</option>
                <option value="plumbing">{lang === 'ar' ? 'سباكة ومياه' : 'Plomberie'}</option>
                <option value="security">{lang === 'ar' ? 'أمن وبوابات' : 'Sécurité'}</option>
                <option value="cleaning">{lang === 'ar' ? 'نظافة' : 'Nettoyage'}</option>
                <option value="general">{lang === 'ar' ? 'صيانة عامة' : 'Autre'}</option>
              </select>

              {/* Reset Filters */}
              {(searchTerm || filterStatus !== 'ALL' || filterBuilding !== 'ALL' || filterCategory !== 'ALL') && (
                <button
                  onClick={() => { setSearchTerm(''); setFilterStatus('ALL'); setFilterBuilding('ALL'); setFilterCategory('ALL'); }}
                  className="h-10 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>{lang === 'ar' ? 'إعادة ضبط' : 'Réinitialiser'}</span>
                </button>
              )}
            </div>
          </div>

          {/* Complaints List Cards */}
          {filteredTickets.length === 0 ? (
            <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center space-y-3">
              <div className="w-16 h-16 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center mx-auto">
                <CheckCircle className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold text-slate-800">
                {lang === 'ar' ? 'لا توجد شكاوى مطابقة للفلاتر الحالية' : 'Aucune réclamation ne correspond aux critères'}
              </h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                {lang === 'ar' ? 'يمكنك إضافة شكاية جديدة بالنقر على زر كتابة شكاية بالأعلى.' : 'Vous pouvez enregistrer une nouvelle demande en cliquant sur le bouton ci-dessus.'}
              </p>
              <button
                onClick={handleOpenCreateForm}
                className="px-4 py-2 rounded-xl bg-amber-600 text-white text-xs font-bold cursor-pointer"
              >
                {lang === 'ar' ? 'كتابة شكاية جديدة' : 'Nouvelle Réclamation'}
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredTickets.map(ticket => {
                const hasSyndicReply = !!ticket.syndicResponse;
                const isResolved = ticket.status === 'resolved';

                return (
                  <div 
                    key={ticket.id}
                    className="bg-white rounded-3xl border border-slate-200/90 shadow-2xs hover:shadow-md transition-all overflow-hidden"
                  >
                    {/* Card Header */}
                    <div className="p-5 sm:p-6 border-b border-slate-100 bg-slate-50/40 flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="flex items-start gap-3">
                        <div className="p-2.5 rounded-2xl bg-white border border-slate-200 shadow-2xs shrink-0">
                          {getCategoryIcon(ticket.category)}
                        </div>
                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <h3 className="text-base font-black text-slate-900">{ticket.title}</h3>
                            <span className={`text-[10px] font-black px-2.5 py-0.5 rounded-full border ${
                              ticket.priority === 'urgent' ? 'bg-red-50 text-red-700 border-red-200' :
                              ticket.priority === 'high' ? 'bg-amber-50 text-amber-700 border-amber-200' :
                              'bg-slate-100 text-slate-700 border-slate-200'
                            }`}>
                              {ticket.priority === 'urgent' ? '🚨 عاجل جداً' :
                               ticket.priority === 'high' ? '⚠️ أولوية مرتفعة' : 'أولوية عادية'}
                            </span>
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                              {getCategoryName(ticket.category)}
                            </span>
                          </div>
                          
                          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 font-medium">
                            <span className="font-bold text-slate-800 font-mono">
                              {ticket.buildingCode} - {ticket.apartmentOrArea}
                            </span>
                            <span>•</span>
                            <span className="flex items-center gap-1">
                              <User className="w-3.5 h-3.5 text-slate-400" />
                              <strong className="text-slate-700">{ticket.reportedBy}</strong>
                              {ticket.ownerPhone && (
                                <span className="text-slate-400 font-mono text-[11px]">({ticket.ownerPhone})</span>
                              )}
                            </span>
                            <span>•</span>
                            <span className="flex items-center gap-1 text-[11px] text-slate-400">
                              <Clock className="w-3.5 h-3.5" />
                              <span>{ticket.createdAt}</span>
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Status Badges */}
                      <div className="flex flex-wrap items-center gap-2 self-start md:self-center">
                        {isResolved ? (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-emerald-100 text-emerald-900 font-black text-xs border border-emerald-300">
                            <CheckCircle className="w-4 h-4 text-emerald-700" />
                            <span>{lang === 'ar' ? 'مكتمل' : 'Résolu'}</span>
                          </span>
                        ) : ticket.status === 'in_progress' ? (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-blue-100 text-blue-900 font-black text-xs border border-blue-300">
                            <Wrench className="w-4 h-4 text-blue-700" />
                            <span>{lang === 'ar' ? 'تحت الإجراء' : 'En cours'}</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-100 text-amber-950 font-black text-xs border border-amber-300">
                            <Clock className="w-4 h-4 text-amber-700" />
                            <span>{lang === 'ar' ? 'شكاية جديدة' : 'Nouveau'}</span>
                          </span>
                        )}

                        {hasSyndicReply ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-emerald-50 text-emerald-800 text-[11px] font-black border border-emerald-200">
                            <Check className="w-3 h-3 text-emerald-600" />
                            <span>{lang === 'ar' ? 'تم رد السانديك' : 'Répondu'}</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-rose-50 text-rose-800 text-[11px] font-black border border-rose-200">
                            <MessageSquare className="w-3 h-3 text-rose-600" />
                            <span>{lang === 'ar' ? 'بانتظار الرد' : 'En attente réponse'}</span>
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Card Body: 2 Columns for Complaint & Syndic/Intervention */}
                    <div className="p-5 sm:p-6 grid grid-cols-1 lg:grid-cols-2 gap-5">
                      {/* Left: Original Owner Complaint Description */}
                      <div className="space-y-3 p-4 rounded-2xl bg-slate-50/70 border border-slate-200/70">
                        <div className="flex items-center justify-between text-xs font-bold text-slate-800">
                          <span className="flex items-center gap-1.5 text-amber-900">
                            <FileText className="w-4 h-4 text-amber-600" />
                            <span>{lang === 'ar' ? 'تفاصيل شكاية وبلاغ المالك:' : 'Description de la réclamation :'}</span>
                          </span>
                          {ticket.ownerPhone && (
                            <button
                              onClick={() => handleSendWhatsAppToOwner(ticket)}
                              className="text-[11px] text-emerald-700 hover:text-emerald-800 font-black flex items-center gap-1 cursor-pointer bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200"
                            >
                              <Phone className="w-3 h-3 text-emerald-600" />
                              <span>{lang === 'ar' ? 'مراسلة عبر واتساب' : 'WhatsApp'}</span>
                            </button>
                          )}
                        </div>
                        <p className="text-xs text-slate-700 leading-relaxed font-medium whitespace-pre-wrap">
                          {ticket.description || (lang === 'ar' ? 'لا توجد تفاصيل إضافية مكتوبة.' : 'Aucun détail fourni.')}
                        </p>
                      </div>

                      {/* Right: Syndic Response & Intervention Status */}
                      <div className="space-y-3">
                        {/* Syndic Reply Box */}
                        <div className={`p-4 rounded-2xl border transition-all ${
                          hasSyndicReply 
                            ? 'bg-emerald-50/50 border-emerald-200 text-emerald-950' 
                            : 'bg-amber-50/40 border-dashed border-amber-300 text-amber-900'
                        }`}>
                          <div className="flex items-center justify-between text-xs font-bold mb-1.5">
                            <span className="flex items-center gap-1.5">
                              <MessageSquare className={`w-4 h-4 ${hasSyndicReply ? 'text-emerald-600' : 'text-amber-600'}`} />
                              <span>{lang === 'ar' ? 'رد وإجابة مكتب السانديك للمالك:' : 'Réponse du bureau de syndic :'}</span>
                            </span>
                            {ticket.syndicResponseDate && (
                              <span className="text-[10px] text-slate-400 font-normal">
                                {ticket.syndicResponseDate}
                              </span>
                            )}
                          </div>

                          {hasSyndicReply ? (
                            <p className="text-xs text-slate-800 font-medium leading-relaxed bg-white/80 p-3 rounded-xl border border-emerald-100">
                              {ticket.syndicResponse}
                            </p>
                          ) : (
                            <div className="py-2 text-xs text-amber-800 font-medium flex items-center justify-between gap-2">
                              <span>{lang === 'ar' ? 'لم يتم الرد بعد من طرف السانديك.' : 'Aucune réponse enregistrée pour le moment.'}</span>
                              {!isOwner && (
                                <button
                                  onClick={() => handleOpenReplyModal(ticket)}
                                  className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold cursor-pointer"
                                >
                                  {lang === 'ar' ? 'كتابة الرد الآن' : 'Répondre'}
                                </button>
                              )}
                            </div>
                          )}
                        </div>

                        {/* Technical Intervention Summary Box (if scheduled or completed) */}
                        {ticket.interventionDetails && (
                          <div className="p-4 rounded-2xl bg-blue-50/50 border border-blue-200 text-blue-950 space-y-2">
                            <div className="flex items-center justify-between text-xs font-bold">
                              <span className="flex items-center gap-1.5 text-blue-900">
                                <Wrench className="w-4 h-4 text-blue-600" />
                                <span>{lang === 'ar' ? 'التدخل التقني والإصلاح المطلوب:' : 'Intervention technique requise :'}</span>
                              </span>
                              <span className="font-mono font-bold text-blue-800 text-xs">
                                {ticket.actualCost ? `${ticket.actualCost} DH` : ticket.estimatedCost ? `${ticket.estimatedCost} DH (${lang === 'ar' ? 'تقديري' : 'est.'})` : '0 DH'}
                              </span>
                            </div>
                            <p className="text-xs text-slate-700 font-medium leading-relaxed">
                              {ticket.interventionDetails}
                            </p>
                            {ticket.assignedTo && (
                              <div className="flex items-center justify-between text-[11px] text-slate-600 pt-1 border-t border-blue-100">
                                <span>{lang === 'ar' ? 'التقني المكلف:' : 'Technicien :'} <strong>{ticket.assignedTo}</strong></span>
                                {ticket.technicianPhone && (
                                  <button
                                    onClick={() => handleSendWhatsAppToTechnician(ticket)}
                                    className="text-emerald-700 font-bold flex items-center gap-1 hover:underline cursor-pointer"
                                  >
                                    <Phone className="w-3 h-3" />
                                    <span>{lang === 'ar' ? 'مراسلة الفني' : 'WhatsApp Fni'}</span>
                                  </button>
                                )}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Card Actions Footer */}
                    <div className="p-4 sm:px-6 bg-slate-50 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        {/* Print Order */}
                        <button
                          onClick={() => setPrintTicket(ticket)}
                          className="px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-700 text-xs font-bold border border-slate-200 flex items-center gap-1.5 transition-colors cursor-pointer"
                        >
                          <Printer className="w-3.5 h-3.5 text-slate-500" />
                          <span>{lang === 'ar' ? 'طباعة تقرير الشكاية / أمر التدخل' : 'Imprimer bon'}</span>
                        </button>

                        {/* WhatsApp to Owner */}
                        {ticket.ownerPhone && (
                          <button
                            onClick={() => handleSendWhatsAppToOwner(ticket)}
                            className="px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold border border-emerald-200 flex items-center gap-1.5 transition-colors cursor-pointer"
                          >
                            <Share2 className="w-3.5 h-3.5 text-emerald-600" />
                            <span>{lang === 'ar' ? 'إرسال التحديث للمالك (WhatsApp)' : 'Envoyer statut au client'}</span>
                          </button>
                        )}
                      </div>

                      {/* Syndic Management Buttons */}
                      {!isOwner && (
                        <div className="flex items-center gap-2">
                          {/* Reply Button */}
                          <button
                            onClick={() => handleOpenReplyModal(ticket)}
                            className="px-3.5 py-1.5 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-950 text-xs font-black flex items-center gap-1.5 transition-colors cursor-pointer"
                          >
                            <MessageSquare className="w-3.5 h-3.5 text-amber-700" />
                            <span>{hasSyndicReply ? (lang === 'ar' ? 'تعديل رد السانديك' : 'Modifier réponse') : (lang === 'ar' ? 'الرد على الشكاية' : 'Répondre')}</span>
                          </button>

                          {/* Technical Intervention Button */}
                          <button
                            onClick={() => handleOpenInterventionModal(ticket)}
                            className="px-3.5 py-1.5 rounded-xl bg-blue-100 hover:bg-blue-200 text-blue-950 text-xs font-black flex items-center gap-1.5 transition-colors cursor-pointer"
                          >
                            <Wrench className="w-3.5 h-3.5 text-blue-700" />
                            <span>{lang === 'ar' ? 'برمجة التدخل والإصلاح' : 'Programmer intervention'}</span>
                          </button>

                          {/* Quick In-Progress Button */}
                          {ticket.status === "open" && (
                            <button
                              onClick={() => handleMarkInProgress(ticket)}
                              className="px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-black flex items-center gap-1.5 transition-colors shadow-2xs cursor-pointer"
                            >
                              <Wrench className="w-3.5 h-3.5" />
                              <span>{lang === "ar" ? "تحت الإجراء" : "Mettre en cours"}</span>
                            </button>
                          )}

                          {/* Quick Resolve Button */}
                          {!isResolved ? (
                            <button
                              onClick={() => handleQuickResolve(ticket)}
                              className="px-3.5 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-black flex items-center gap-1.5 transition-colors shadow-2xs cursor-pointer"
                            >
                              <CheckCheck className="w-3.5 h-3.5" />
                              <span>{lang === 'ar' ? 'تعيين كمكتمل' : 'Marquer résolu'}</span>
                            </button>
                          ) : null}

                          {/* Clear / Delete upon Repair Button */}
                          <button
                            onClick={() => handleResolveAndClear(ticket)}
                            className={`px-3.5 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 transition-colors cursor-pointer ${
                              isResolved 
                                ? 'bg-rose-100 hover:bg-rose-200 text-rose-900 border border-rose-200' 
                                : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300'
                            }`}
                            title={lang === 'ar' ? 'مسح الشكاية بعد إتمام الإصلاح والتسوية' : 'Supprimer après réparation'}
                          >
                            <Trash2 className={`w-3.5 h-3.5 ${isResolved ? 'text-rose-700' : 'text-emerald-700'}`} />
                            <span>{lang === 'ar' ? 'مسح الشكاية عند الإصلاح' : 'Effacer après réparation'}</span>
                          </button>

                          {/* Edit / Delete */}
                          <button
                            onClick={() => handleOpenEditForm(ticket)}
                            className="p-2 rounded-xl bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 cursor-pointer"
                            title={lang === 'ar' ? 'تعديل بيانات الشكاية' : 'Modifier'}
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => setTicketToDelete(ticket)}
                            className="p-2 rounded-xl bg-white hover:bg-rose-50 text-slate-400 hover:text-rose-600 border border-slate-200 cursor-pointer"
                            title={lang === 'ar' ? 'حذف' : 'Supprimer'}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* VIEW 2: New Complaint Creation Form */}
      {activeTab === 'new_form' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6 animate-in fade-in duration-150 max-w-4xl mx-auto">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-amber-50 text-amber-700 border border-amber-200">
                <Plus className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-lg font-black text-slate-900">
                  {editingTicketId 
                    ? (lang === 'ar' ? 'تعديل بيانات الشكاية' : 'Modifier la réclamation')
                    : isOwner
                      ? (lang === 'ar' ? 'كتابة شكاية أو إبلاغ عن عطل' : 'Nouvelle Réclamation & Signalement de Panne')
                      : (lang === 'ar' ? 'استقبال وتدوين شكاية أو بلاغ عطل وارد من مالك' : 'Enregistrement d\'une réclamation reçue')}
                </h2>
                <p className="text-xs text-slate-500 font-medium">
                  {isOwner
                    ? (lang === 'ar' 
                        ? 'سيتم إرسال هذا الطلب مباشرة إلى مكتب السانديك للإجابة وتكليف الفريق التقني للإصلاح' 
                        : 'Votre demande sera transmise instantanément au syndic pour traitement')
                    : (lang === 'ar'
                        ? 'تسجيل وتدوين الشكاية الواردة من المالك أو الساكن لمعالجتها والرد عليها وبرمجة الإصلاح'
                        : 'Enregistrement de la réclamation reçue du copropriétaire pour traitement et intervention')}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setActiveTab('all_complaints')}
              className="p-2 rounded-xl hover:bg-slate-100 text-slate-400 hover:text-slate-700 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmitComplaint} className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Title */}
              <div className="md:col-span-2 space-y-1.5">
                <label className="block text-xs font-black text-slate-800">
                  {lang === 'ar' ? 'موضوع الشكاية أو نوع العطل *' : 'Objet de la réclamation / panne *'}
                </label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={e => setFormTitle(e.target.value)}
                  placeholder={lang === 'ar' ? 'مثال: عطل في إنارة مدخل العمارة، تسرب ماء في المرآب...' : 'Ex: Panne éclairage hall , fuite d\'eau sous-sol...'}
                  className="w-full h-11 px-4 text-xs font-bold rounded-2xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
                />
              </div>

              {/* Building */}
              <div className="space-y-1.5">
                <label className="block text-xs font-black text-slate-800">
                  {lang === 'ar' ? 'العمارة المعنية *' : 'Bâtiment concerné *'}
                </label>
                <select
                  value={formBuildingCode}
                  onChange={e => setFormBuildingCode(e.target.value)}
                  className="w-full h-11 px-4 text-xs font-bold rounded-2xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
                >
                  {buildings.map(b => (
                    <option key={b.id} value={b.code}>{b.code} ({b.name})</option>
                  ))}
                </select>
              </div>

              {/* Apartment or Area */}
              <div className="space-y-1.5">
                <label className="block text-xs font-black text-slate-800">
                  {lang === 'ar' ? 'رقم الشقة أو المرفق المشترك المتضرر' : 'N° Appartement ou Espace commun'}
                </label>
                <input
                  type="text"
                  value={formApartmentOrArea}
                  onChange={e => setFormApartmentOrArea(e.target.value)}
                  placeholder={lang === 'ar' ? 'مثال: شقة 12 أو بهو المدخل أو المرآب' : 'Ex: Appt 12 ou Hall d\'entrée'}
                  className="w-full h-11 px-4 text-xs font-bold rounded-2xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
                />
              </div>

              {/* Category */}
              <div className="space-y-1.5">
                <label className="block text-xs font-black text-slate-800">
                  {lang === 'ar' ? 'تصنيف العطل' : 'Catégorie'}
                </label>
                <select
                  value={formCategory}
                  onChange={e => setFormCategory(e.target.value as MaintenanceCategory)}
                  className="w-full h-11 px-4 text-xs font-bold rounded-2xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
                >
                  <option value="lighting">{lang === 'ar' ? 'إنارة وكهرباء' : 'Éclairage / Électricité'}</option>
                  <option value="plumbing">{lang === 'ar' ? 'سباكة وتسرب مياه' : 'Plomberie & Eau'}</option>
                  <option value="security">{lang === 'ar' ? 'أمن وبوابات إلكترونية' : 'Sécurité & Portails'}</option>
                  <option value="cleaning">{lang === 'ar' ? 'نظافة ومرافق' : 'Nettoyage'}</option>
                  <option value="general">{lang === 'ar' ? 'صيانة عامة وأخرى' : 'Autre maintenance'}</option>
                </select>
              </div>

              {/* Priority */}
              <div className="space-y-1.5">
                <label className="block text-xs font-black text-slate-800">
                  {lang === 'ar' ? 'درجة الاستعجال' : 'Degré d\'urgence'}
                </label>
                <select
                  value={formPriority}
                  onChange={e => setFormPriority(e.target.value as MaintenancePriority)}
                  className="w-full h-11 px-4 text-xs font-bold rounded-2xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
                >
                  <option value="low">{lang === 'ar' ? 'منخفضة (لا تؤثر على السير العادي)' : 'Basse'}</option>
                  <option value="medium">{lang === 'ar' ? 'متوسطة (عادية)' : 'Moyenne'}</option>
                  <option value="high">{lang === 'ar' ? 'مرتفعة (تتطلب تدخلاً سريعاً)' : 'Élevée'}</option>
                  <option value="urgent">{lang === 'ar' ? '🚨 عاجل جداً (خطر أو انقطاع كلي)' : 'Très urgent 🚨'}</option>
                </select>
              </div>

              {/* Reporter Name */}
              <div className="space-y-1.5">
                <label className="block text-xs font-black text-slate-800">
                  {lang === 'ar' ? 'اسم صاحب الشكاية / المالك *' : 'Nom du déclarant / copropriétaire *'}
                </label>
                <input
                  type="text"
                  required
                  value={formReportedBy}
                  onChange={e => setFormReportedBy(e.target.value)}
                  placeholder={lang === 'ar' ? 'الاسم الكامل' : 'Nom complet'}
                  className="w-full h-11 px-4 text-xs font-bold rounded-2xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden"
                />
              </div>

              {/* Owner Phone */}
              <div className="space-y-1.5">
                <label className="block text-xs font-black text-slate-800">
                  {lang === 'ar' ? 'رقم الهاتف للتواصل والمتابعة عبر WhatsApp' : 'Téléphone WhatsApp pour suivi'}
                </label>
                <input
                  type="text"
                  value={formOwnerPhone}
                  onChange={e => setFormOwnerPhone(e.target.value)}
                  placeholder="06XXXXXXXX"
                  className="w-full h-11 px-4 text-xs font-bold rounded-2xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden font-mono"
                />
              </div>

              {/* Description */}
              <div className="md:col-span-2 space-y-1.5">
                <label className="block text-xs font-black text-slate-800">
                  {lang === 'ar' ? 'وصف المشكل بدقة وتفاصيل العطل' : 'Description détaillée du problème'}
                </label>
                <textarea
                  rows={4}
                  value={formDescription}
                  onChange={e => setFormDescription(e.target.value)}
                  placeholder={lang === 'ar' ? 'اكتب تفاصيل ما حدث، التوقيت، وأي ملاحظات تساعد التقني على إحضار القطع المناسبة للإصلاح...' : 'Précisez l\'emplacement exact, les symptômes...'}
                  className="w-full p-4 text-xs font-medium rounded-2xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden leading-relaxed"
                />
              </div>
            </div>

            {/* Submit Actions */}
            <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setActiveTab('all_complaints')}
                className="px-5 py-3 rounded-2xl border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-bold cursor-pointer"
              >
                {lang === 'ar' ? 'إلغاء' : 'Annuler'}
              </button>

              <button
                type="submit"
                className="px-7 py-3 rounded-2xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-black shadow-lg shadow-amber-600/20 cursor-pointer flex items-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>
                  {editingTicketId 
                    ? (lang === 'ar' ? 'حفظ التعديلات' : 'Enregistrer') 
                    : isOwner 
                      ? (lang === 'ar' ? 'إرسال الشكاية إلى السانديك' : 'Envoyer la réclamation')
                      : (lang === 'ar' ? 'تسجيل وتأكيد الشكاية في النظام' : 'Enregistrer la réclamation reçue')}
                </span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* VIEW 3: Technical Interventions Log */}
      {activeTab === 'interventions_log' && (
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Wrench className="w-5 h-5 text-blue-600" />
                <span>{lang === 'ar' ? 'سجل التدخلات الفنية والإصلاحات الميدانية' : 'Registre des Interventions Techniques'}</span>
              </h2>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                {lang === 'ar' ? 'متابعة الأعمال المنجزة من طرف التقنيين، التكاليف الفعلية، ومواعيد الإصلاح' : 'Suivi des travaux, techniciens assignés et coûts de réparation'}
              </p>
            </div>

            <div className="flex items-center gap-2 text-xs font-bold text-slate-700 bg-slate-50 px-4 py-2 rounded-2xl border border-slate-200">
              <span>{lang === 'ar' ? 'إجمالي تكلفة التدخلات:' : 'Total Coûts :'}</span>
              <span className="text-amber-700 font-black font-mono text-sm">{totalCost.toLocaleString()} DH</span>
            </div>
          </div>

          {/* Interventions Table */}
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full whitespace-nowrap text-xs text-start">
                <thead className="bg-slate-900 text-white font-black text-start">
                  <tr>
                    <th className="p-3.5 text-start">{lang === 'ar' ? 'موضوع العطل والشكاية' : 'Objet / Panne'}</th>
                    <th className="p-3.5 text-start">{lang === 'ar' ? 'المكان / العمارة' : 'Bâtiment / Lieu'}</th>
                    <th className="p-3.5 text-start">{lang === 'ar' ? 'طبيعة التدخل المطلوب' : 'Intervention Requise'}</th>
                    <th className="p-3.5 text-start">{lang === 'ar' ? 'التقني / الشركة المكلفة' : 'Technicien'}</th>
                    <th className="p-3.5 text-start">{lang === 'ar' ? 'التكلفة (درهم)' : 'Coût (DH)'}</th>
                    <th className="p-3.5 text-start">{lang === 'ar' ? 'حالة التدخل' : 'Statut'}</th>
                    <th className="p-3.5 text-center">{lang === 'ar' ? 'الإجراءات' : 'Actions'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {maintenanceTickets.filter(t => t.assignedTo || t.interventionDetails).length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-12 text-center text-slate-400 font-medium">
                        {lang === 'ar' ? 'لا توجد تدخلات فنية مسجلة حالياً. يمكنك برمجة تدخل من شاشة الشكاوى.' : 'Aucune intervention programmée pour le moment.'}
                      </td>
                    </tr>
                  ) : (
                    maintenanceTickets
                      .filter(t => t.assignedTo || t.interventionDetails)
                      .map(ticket => (
                        <tr key={ticket.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="p-3.5 font-bold text-slate-900">
                            <div className="flex items-center gap-2">
                              {getCategoryIcon(ticket.category)}
                              <span>{ticket.title}</span>
                            </div>
                            <div className="text-[10px] text-slate-400 font-normal mt-0.5">
                              {lang === 'ar' ? 'صاحب الشكاية:' : 'Demandeur :'} {ticket.reportedBy}
                            </div>
                          </td>

                          <td className="p-3.5 font-bold font-mono text-slate-800">
                            {ticket.buildingCode} • {ticket.apartmentOrArea}
                          </td>

                          <td className="p-3.5 text-slate-700 max-w-xs font-medium">
                            <div className="line-clamp-2">
                              {ticket.interventionDetails || (lang === 'ar' ? 'معاينة وإصلاح العطل' : 'Inspection et réparation')}
                            </div>
                          </td>

                          <td className="p-3.5 font-bold text-slate-900">
                            <div>{ticket.assignedTo || (lang === 'ar' ? 'غير مخصص' : 'Non assigné')}</div>
                            {ticket.technicianPhone && (
                              <div className="text-[10px] text-slate-400 font-mono">{ticket.technicianPhone}</div>
                            )}
                          </td>

                          <td className="p-3.5 font-black font-mono text-amber-700">
                            {ticket.actualCost ? `${ticket.actualCost} DH` : ticket.estimatedCost ? `${ticket.estimatedCost} DH` : '0 DH'}
                          </td>

                          <td className="p-3.5">
                            {ticket.status === 'resolved' ? (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-900 font-bold text-[11px]">
                                <CheckCircle className="w-3 h-3 text-emerald-700" />
                                <span>{lang === 'ar' ? 'تم الإنجاز' : 'Achevé'}</span>
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-100 text-blue-900 font-bold text-[11px]">
                                <Wrench className="w-3 h-3 text-blue-700" />
                                <span>{lang === 'ar' ? 'تحت الإجراء' : 'En cours'}</span>
                              </span>
                            )}
                          </td>

                          <td className="p-3.5 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                onClick={() => handleResolveAndClear(ticket)}
                                className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold cursor-pointer"
                                title={lang === 'ar' ? 'مسح الشكاية عند الإصلاح' : 'Effacer après réparation'}
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>

                              <button
                                onClick={() => handleOpenInterventionModal(ticket)}
                                className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold cursor-pointer"
                                title={lang === 'ar' ? 'تعديل التدخل' : 'Modifier'}
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>

                              <button
                                onClick={() => setPrintTicket(ticket)}
                                className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold cursor-pointer"
                                title={lang === 'ar' ? 'طباعة' : 'Imprimer'}
                              >
                                <Printer className="w-3.5 h-3.5" />
                              </button>

                              {ticket.technicianPhone && (
                                <button
                                  onClick={() => handleSendWhatsAppToTechnician(ticket)}
                                  className="p-1.5 rounded-lg bg-emerald-100 hover:bg-emerald-200 text-emerald-800 font-bold cursor-pointer"
                                  title={lang === 'ar' ? 'واتساب الفني' : 'WhatsApp'}
                                >
                                  <Phone className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 1: Syndic Reply Modal */}
      {replyModalTicket && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-150">
            <div className="p-5 sm:p-6 border-b border-slate-100 bg-amber-50/50 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-amber-600 text-white">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    {lang === 'ar' ? 'الرد على شكاية المالك' : 'Réponse du syndic au copropriétaire'}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium">
                    {replyModalTicket.buildingCode} - {replyModalTicket.apartmentOrArea} ({replyModalTicket.reportedBy})
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setReplyModalTicket(null)}
                className="p-2 rounded-xl hover:bg-slate-200 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveReply} className="p-6 space-y-4">
              {/* Original Complaint Reminder */}
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-1">
                <div className="text-[11px] font-black text-slate-700 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-amber-600" />
                  <span>{replyModalTicket.title}</span>
                </div>
                <p className="text-xs text-slate-600 line-clamp-2">
                  {replyModalTicket.description}
                </p>
              </div>

              {/* Reply Textarea */}
              <div className="space-y-1.5">
                <label className="block text-xs font-black text-slate-800">
                  {lang === 'ar' ? 'نص إجابة وتوضيح السانديك للمالك *' : 'Texte de la réponse officielle du syndic *'}
                </label>
                <textarea
                  required
                  rows={4}
                  value={replyText}
                  onChange={e => setReplyText(e.target.value)}
                  placeholder={lang === 'ar' ? 'مثال: تم استلام الشكاية، وتم تكليف الفني للحضور غداً الساعة 10:00 صباحاً للمعاينة والإصلاح...' : 'Rédigez votre réponse ici...'}
                  className="w-full p-3.5 text-xs font-medium rounded-2xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-amber-500 focus:outline-hidden leading-relaxed"
                />
              </div>

              {/* Quick Reply Suggestions */}
              <div className="space-y-1">
                <span className="text-[10px] font-bold text-slate-400 block">{lang === 'ar' ? 'ردود نموذجية سريعة:' : 'Réponses rapides :'}</span>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => setReplyText(lang === 'ar' ? 'تم استلام الشكاية وجاري التنسيق مع التقني للتدخل في أقرب وقت.' : 'Demande reçue, coordination en cours avec le technicien.')}
                    className="text-[10px] px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold cursor-pointer"
                  >
                    {lang === 'ar' ? '⚡ تم الاستلام وجاري التنسيق' : 'En cours'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setReplyText(lang === 'ar' ? 'تمت معاينة العطل وسيتم إحضار قطع الغيار لإتمام الإصلاح خلال 24 ساعة.' : 'Constat effectué, pièces en commande pour réparation.')}
                    className="text-[10px] px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold cursor-pointer"
                  >
                    {lang === 'ar' ? '🔍 تمت المعاينة وجلب القطع' : 'Pièces commandées'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setReplyText(lang === 'ar' ? 'تم الانتهاء من كافة الإصلاحات والتأكد من اشتغال المرفق بشكل طبيعي.' : 'Réparation terminée avec succès.')}
                    className="text-[10px] px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold cursor-pointer"
                  >
                    {lang === 'ar' ? '✅ تم الإصلاح بنجاح' : 'Réparé'}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setReplyModalTicket(null)}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-bold cursor-pointer"
                >
                  {lang === 'ar' ? 'إلغاء' : 'Annuler'}
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-black shadow-md shadow-amber-600/20 cursor-pointer"
                >
                  {lang === 'ar' ? 'حفظ وإرسال الرد' : 'Enregistrer la réponse'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Technical Intervention Programming Modal */}
      {interventionModalTicket && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden animate-in zoom-in-95 duration-150 max-h-[90vh] flex flex-col">
            <div className="p-5 sm:p-6 border-b border-slate-100 bg-blue-50/50 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-2xl bg-blue-600 text-white">
                  <Wrench className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    {lang === 'ar' ? 'برمجة وتسجيل التدخل الفني لإصلاح العطل' : 'Fiche d\'Intervention & Réparation Technique'}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium">
                    {interventionModalTicket.title} ({interventionModalTicket.buildingCode} - {interventionModalTicket.apartmentOrArea})
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setInterventionModalTicket(null)}
                className="p-2 rounded-xl hover:bg-slate-200 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveIntervention} className="p-6 space-y-4 overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Technician Name */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-black text-slate-800">
                    {lang === 'ar' ? 'اسم التقني أو الشركة المكلفة *' : 'Nom du technicien / société *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={technicianName}
                    onChange={e => setTechnicianName(e.target.value)}
                    placeholder={lang === 'ar' ? 'اسم التقني أو الشركة المسؤولة' : 'Nom du technicien ou entreprise'}
                    className="w-full h-10 px-3.5 text-xs font-bold rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 focus:outline-hidden"
                  />
                </div>

                {/* Technician Phone */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-black text-slate-800">
                    {lang === 'ar' ? 'رقم هاتف التقني (WhatsApp)' : 'Téléphone WhatsApp'}
                  </label>
                  <input
                    type="text"
                    value={technicianPhone}
                    onChange={e => setTechnicianPhone(e.target.value)}
                    placeholder="06XXXXXXXX"
                    className="w-full h-10 px-3.5 text-xs font-bold rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 focus:outline-hidden font-mono"
                  />
                </div>

                {/* Scheduled Date */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-black text-slate-800">
                    {lang === 'ar' ? 'تاريخ ووقت التدخل المبرمج' : 'Date d\'intervention'}
                  </label>
                  <input
                    type="date"
                    value={interventionDate}
                    onChange={e => setInterventionDate(e.target.value)}
                    className="w-full h-10 px-3.5 text-xs font-bold rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 focus:outline-hidden"
                  />
                </div>

                {/* Intervention Status */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-black text-slate-800">
                    {lang === 'ar' ? 'حالة التدخل والإصلاح' : 'Statut de l\'intervention'}
                  </label>
                  <select
                    value={interventionStatus}
                    onChange={e => setInterventionStatus(e.target.value as any)}
                    className="w-full h-10 px-3.5 text-xs font-bold rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 focus:outline-hidden"
                  >
                    <option value="pending">{lang === 'ar' ? '⏳ في انتظار وصول التقني' : 'En attente'}</option>
                    <option value="in_progress">{lang === 'ar' ? '🛠️ جاري العمل والإصلاح' : 'En cours de travaux'}</option>
                    <option value="completed">{lang === 'ar' ? '✅ تم الإنجاز والإصلاح بنجاح' : 'Terminé avec succès'}</option>
                  </select>
                </div>

                {/* Estimated Cost */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-black text-slate-800">
                    {lang === 'ar' ? 'التكلفة التقديرية (درهم)' : 'Coût estimé (DH)'}
                  </label>
                  <input
                    type="number"
                    value={estimatedCost || ''}
                    onChange={e => setEstimatedCost(parseFloat(e.target.value) || 0)}
                    placeholder="0.00"
                    className="w-full h-10 px-3.5 text-xs font-bold rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 focus:outline-hidden font-mono"
                  />
                </div>

                {/* Actual Cost */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-black text-slate-800">
                    {lang === 'ar' ? 'التكلفة الفعلية النهائية (درهم)' : 'Coût réel payé (DH)'}
                  </label>
                  <input
                    type="number"
                    value={actualCost || ''}
                    onChange={e => setActualCost(parseFloat(e.target.value) || 0)}
                    placeholder="0.00"
                    className="w-full h-10 px-3.5 text-xs font-bold rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 focus:outline-hidden font-mono text-emerald-800"
                  />
                </div>
              </div>

              {/* Required Interventions & Repairs Details */}
              <div className="space-y-1.5">
                <label className="block text-xs font-black text-slate-800">
                  {lang === 'ar' ? 'طبيعة التدخلات والإصلاحات التي يجب عملها *' : 'Détails des travaux et réparations à effectuer *'}
                </label>
                <textarea
                  required
                  rows={3}
                  value={interventionDetails}
                  onChange={e => setInterventionDetails(e.target.value)}
                  placeholder={lang === 'ar' ? 'مثال: تغيير قفل الباب الرئيسي، استبدال أنبوب التوصيل، تغيير مصابيح السلالم...' : 'Travaux à réaliser, pièces à changer...'}
                  className="w-full p-3 text-xs font-medium rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 focus:outline-hidden leading-relaxed"
                />
              </div>

              {/* Final Technical Report */}
              <div className="space-y-1.5">
                <label className="block text-xs font-black text-slate-800">
                  {lang === 'ar' ? 'تقرير وخلاصة المعاينة بعد التدخل' : 'Rapport technique / Constat final'}
                </label>
                <textarea
                  rows={2}
                  value={interventionReport}
                  onChange={e => setInterventionReport(e.target.value)}
                  placeholder={lang === 'ar' ? 'ملاحظات التقني، حالة التجهيزات بعد الإصلاح، فترة الضمان...' : 'Observations finales...'}
                  className="w-full p-3 text-xs font-medium rounded-xl bg-slate-50 border border-slate-200 focus:bg-white focus:border-blue-500 focus:outline-hidden leading-relaxed"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 shrink-0">
                <button
                  type="button"
                  onClick={() => setInterventionModalTicket(null)}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-bold cursor-pointer"
                >
                  {lang === 'ar' ? 'إلغاء' : 'Annuler'}
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-black shadow-md shadow-blue-600/20 cursor-pointer"
                >
                  {lang === 'ar' ? 'حفظ وتحديث بطاقة التدخل' : 'Enregistrer l\'intervention'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: Printable Complaint & Intervention Receipt */}
      {printTicket && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs print:p-0">
          <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden p-6 sm:p-8 space-y-6">
            <div className="flex items-center justify-between border-b-2 border-slate-900 pb-4">
              <div className="space-y-0.5">
                <h2 className="text-xl font-black text-slate-900">الإقامة - RÉSIDENCE</h2>
                <p className="text-xs text-slate-600 font-bold">مكتب اتحاد الملاك المشتركين (السانديك)</p>
              </div>
              <div className="text-end">
                <div className="text-xs font-mono font-black text-slate-800">بطاقة رقم: {printTicket.id}</div>
                <div className="text-[11px] text-slate-500">{printTicket.createdAt}</div>
              </div>
            </div>

            <div className="text-center py-2 bg-amber-50 rounded-2xl border border-amber-200">
              <h3 className="text-base font-black text-amber-950">
                بطاقة تقرير شكاية وتدخل صيانة
              </h3>
              <p className="text-xs text-amber-800 font-medium">FICHE DE RÉCLAMATION & ORDRE D'INTERVENTION</p>
            </div>

            {/* Complaint Info */}
            <div className="grid grid-cols-2 gap-4 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-slate-400 font-bold block">بيانات المشتكي / المالك:</span>
                <div className="font-black text-slate-900">{printTicket.reportedBy}</div>
                <div className="text-slate-600 font-mono">{printTicket.ownerPhone || 'لا يوجد هاتف'}</div>
                <div className="font-bold text-amber-800">{printTicket.buildingCode} - {printTicket.apartmentOrArea}</div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <span className="text-slate-400 font-bold block">تصنيف وحالة العطل:</span>
                <div className="font-black text-slate-900">{getCategoryName(printTicket.category)}</div>
                <div className="font-bold text-slate-700">الأولوية: {printTicket.priority}</div>
                <div className="font-bold text-emerald-800">
                  الحالة: {printTicket.status === 'resolved' ? 'مكتمل' : printTicket.status === 'in_progress' ? 'تحت الإجراء' : 'مفتوح'}
                </div>
              </div>
            </div>

            {/* Complaint Subject & Description */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1">
              <span className="text-slate-500 font-bold block">موضوع وتفاصيل الشكاية:</span>
              <div className="font-black text-slate-900">{printTicket.title}</div>
              <p className="text-slate-700 whitespace-pre-wrap">{printTicket.description}</p>
            </div>

            {/* Syndic Reply */}
            {printTicket.syndicResponse && (
              <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200 text-xs space-y-1">
                <span className="text-emerald-800 font-bold block">رد وإجابة مكتب السانديك:</span>
                <p className="text-emerald-950 font-medium">{printTicket.syndicResponse}</p>
              </div>
            )}

            {/* Technical Intervention & Costs */}
            {printTicket.interventionDetails && (
              <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200 text-xs space-y-1">
                <div className="flex items-center justify-between font-bold text-blue-900">
                  <span>التدخلات المنجزة والمكلف:</span>
                  <span className="font-mono text-amber-800 font-black">
                    التكلفة: {printTicket.actualCost || printTicket.estimatedCost || 0} درهم
                  </span>
                </div>
                <p className="text-slate-800">{printTicket.interventionDetails}</p>
                <div className="text-slate-600 text-[11px] pt-1">
                  التقني المكلف: <strong>{printTicket.assignedTo || 'الفريق التقني'}</strong>
                </div>
              </div>
            )}

            {/* Signatures */}
            <div className="grid grid-cols-2 gap-8 pt-6 border-t border-slate-200 text-xs text-center">
              <div>
                <span className="font-bold text-slate-600 block mb-8">توقيع صاحب الشكاية / المشتكي</span>
                <span className="text-[11px] text-slate-400">..................................</span>
              </div>
              <div>
                <span className="font-bold text-slate-600 block mb-8">خاتم وتوقيع وكيل السانديك</span>
                <span className="text-[11px] text-slate-400">..................................</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100 print:hidden">
              <button
                onClick={() => setPrintTicket(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-bold cursor-pointer"
              >
                {lang === 'ar' ? 'إغلاق' : 'Fermer'}
              </button>
              <button
                onClick={() => window.print()}
                className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-black flex items-center gap-2 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>{lang === 'ar' ? 'طباعة البطاقة' : 'Imprimer'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* In-App Delete Confirmation Modal */}
      {ticketToDelete && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95">
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mb-4 mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            
            <h3 className="text-base font-bold text-slate-900 text-center mb-2">
              {lang === 'ar' ? 'تأكيد حذف الشكاية' : 'Confirmation de suppression'}
            </h3>
            
            <p className="text-xs text-slate-600 text-center mb-6 leading-relaxed">
              {lang === 'ar' 
                ? `هل أنت متأكد من حذف هذه الشكاية نهائياً: "${ticketToDelete.title}"؟`
                : `Êtes-vous sûr de vouloir supprimer définitivement cette réclamation "${ticketToDelete.title}" ?`}
            </p>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setTicketToDelete(null)}
                className="flex-1 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-bold transition-all cursor-pointer"
              >
                {lang === 'ar' ? 'تراجع' : t.common.cancel}
              </button>
              <button
                type="button"
                onClick={() => {
                  deleteMaintenanceTicket(ticketToDelete.id);
                  showToast(lang === 'ar' ? 'تم حذف الشكاية بنجاح' : 'Réclamation supprimée');
                  setTicketToDelete(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold shadow-md transition-all cursor-pointer"
              >
                {lang === 'ar' ? 'تأكيد الحذف' : 'Supprimer'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
