import React, { useState, useMemo, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { ManualMonthlyRecord } from '../types';
import {
  Calendar, DollarSign, TrendingUp, TrendingDown, FileText,
  Plus, Edit3, Trash2, CheckCircle2, AlertCircle, Save,
  Printer, Download, Upload, ArrowUpRight, ArrowDownRight,
  Sparkles, RefreshCw, BarChart3, PieChart as PieChartIcon,
  ChevronRight, Info, Check, ShieldCheck, History, Calculator
} from 'lucide-react';
import { Pencil as HeaderIcon } from 'lucide-react';

export const ManualFinancialEntryView: React.FC = () => {
  const {
    lang, t, currentUser,
    manualMonthlyRecords,
    upsertManualMonthlyRecord,
    deleteManualMonthlyRecord,
    batchSaveManualMonthlyRecords,
    clearManualMonthlyRecords,
    totalIncome: systemIncome,
    totalExpenses: systemExpenses,
    totalBalance: systemBalance,
    payments,
    expenses,
    setActiveSection
  } = useApp();

  const printRef = useRef<HTMLDivElement>(null);
  const isOwner = currentUser?.role === 'resident';

  // Available months starting from 04/2025 to 12/2027
  const generateMonthList = () => {
    const list: { key: string; labelAr: string; labelFr: string; year: number; month: number }[] = [];
    const arMonths = [
      'يناير', 'فبراير', 'مارس', 'أبريل', 'ماي', 'يونيو',
      'يوليوز', 'غشت', 'شتنبر', 'أكتوبر', 'نونبر', 'دجنبر'
    ];
    const frMonths = [
      'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
      'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
    ];

    // Plage glissante : 2 ans en arrière jusqu'à 2 ans en avant
    const thisYear = new Date().getFullYear();
    for (let y = thisYear - 2; y <= thisYear + 2; y++) {
      const startM = 1;
      const endM = 12;
      for (let m = startM; m <= endM; m++) {
        const monthStr = String(m).padStart(2, '0');
        const key = `${y}-${monthStr}`;
        list.push({
          key,
          year: y,
          month: m,
          labelAr: `${arMonths[m - 1]} ${y} (${monthStr}/${y})`,
          labelFr: `${frMonths[m - 1]} ${y} (${monthStr}/${y})`
        });
      }
    }
    return list;
  };

  const monthOptions = useMemo(() => generateMonthList(), []);

  // Filter & Active tab
  const [activeTab, setActiveTab] = useState<'records' | 'entry' | 'report'>('records');
  const [selectedYearFilter, setSelectedYearFilter] = useState<string>('ALL');

  // Form State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formMonthKey, setFormMonthKey] = useState<string>('2025-04');
  const [formIncome, setFormIncome] = useState<string>('');
  const [formExpenses, setFormExpenses] = useState<string>('');
  const [formOpeningBalance, setFormOpeningBalance] = useState<string>('0');
  const [formNotes, setFormNotes] = useState<string>('');

  // Detailed breakdowns
  const [showDetailedBreakdown, setShowDetailedBreakdown] = useState(false);
  const [incRegular, setIncRegular] = useState<string>('');
  const [incExceptional, setIncExceptional] = useState<string>('');
  const [incArrears, setIncArrears] = useState<string>('');
  const [incOther, setIncOther] = useState<string>('');

  const [expSalaries, setExpSalaries] = useState<string>('');
  const [expUtilities, setExpUtilities] = useState<string>('');
  const [expMaintenance, setExpMaintenance] = useState<string>('');
  const [expSupplies, setExpSupplies] = useState<string>('');
  const [expOther, setExpOther] = useState<string>('');

  // Feedback status
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Sorted and filtered manual records
  const sortedRecords = useMemo(() => {
    return [...manualMonthlyRecords].sort((a, b) => a.monthKey.localeCompare(b.monthKey));
  }, [manualMonthlyRecords]);

  const filteredRecords = useMemo(() => {
    if (selectedYearFilter === 'ALL') return sortedRecords;
    return sortedRecords.filter(r => r.monthKey.startsWith(selectedYearFilter));
  }, [sortedRecords, selectedYearFilter]);

  // Aggregate Totals
  const totals = useMemo(() => {
    let income = 0;
    let exp = 0;
    sortedRecords.forEach(r => {
      income += Number(r.totalIncome) || 0;
      exp += Number(r.totalExpenses) || 0;
    });
    const net = income - exp;
    return {
      income,
      expenses: exp,
      net,
      count: sortedRecords.length
    };
  }, [sortedRecords]);

  // Handle Edit existing
  const handleEdit = (record: ManualMonthlyRecord) => {
    setEditingId(record.id);
    setFormMonthKey(record.monthKey);
    setFormIncome(String(record.totalIncome));
    setFormExpenses(String(record.totalExpenses));
    setFormOpeningBalance(String(record.openingBalance || 0));
    setFormNotes(record.notes || '');

    if (record.breakdownIncome) {
      setIncRegular(record.breakdownIncome.regularFees ? String(record.breakdownIncome.regularFees) : '');
      setIncExceptional(record.breakdownIncome.exceptionalContributions ? String(record.breakdownIncome.exceptionalContributions) : '');
      setIncArrears(record.breakdownIncome.priorArrears ? String(record.breakdownIncome.priorArrears) : '');
      setIncOther(record.breakdownIncome.otherIncome ? String(record.breakdownIncome.otherIncome) : '');
    } else {
      setIncRegular('');
      setIncExceptional('');
      setIncArrears('');
      setIncOther('');
    }

    if (record.breakdownExpenses) {
      setExpSalaries(record.breakdownExpenses.salaries ? String(record.breakdownExpenses.salaries) : '');
      setExpUtilities(record.breakdownExpenses.utilities ? String(record.breakdownExpenses.utilities) : '');
      setExpMaintenance(record.breakdownExpenses.maintenance ? String(record.breakdownExpenses.maintenance) : '');
      setExpSupplies(record.breakdownExpenses.supplies ? String(record.breakdownExpenses.supplies) : '');
      setExpOther(record.breakdownExpenses.otherExpenses ? String(record.breakdownExpenses.otherExpenses) : '');
    } else {
      setExpSalaries('');
      setExpUtilities('');
      setExpMaintenance('');
      setExpSupplies('');
      setExpOther('');
    }

    setActiveTab('entry');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleResetForm = () => {
    setEditingId(null);
    setFormIncome('');
    setFormExpenses('');
    setFormOpeningBalance('0');
    setFormNotes('');
    setIncRegular('');
    setIncExceptional('');
    setIncArrears('');
    setIncOther('');
    setExpSalaries('');
    setExpUtilities('');
    setExpMaintenance('');
    setExpSupplies('');
    setExpOther('');
    setFeedback(null);
  };

  // Save record
  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const incomeNum = parseFloat(formIncome);
    const expensesNum = parseFloat(formExpenses);
    const openingNum = parseFloat(formOpeningBalance) || 0;

    if (isNaN(incomeNum) || isNaN(expensesNum)) {
      setFeedback({
        type: 'error',
        text: lang === 'ar' ? 'يرجى إدخال مبالغ رقمية صحيحة للمداخيل والمصاريف.' : 'Veuillez saisir des montants valides.'
      });
      return;
    }

    const closingBalance = openingNum + incomeNum - expensesNum;

    const breakdownIncomeObj = {
      regularFees: parseFloat(incRegular) || undefined,
      exceptionalContributions: parseFloat(incExceptional) || undefined,
      priorArrears: parseFloat(incArrears) || undefined,
      otherIncome: parseFloat(incOther) || undefined
    };

    const breakdownExpensesObj = {
      salaries: parseFloat(expSalaries) || undefined,
      utilities: parseFloat(expUtilities) || undefined,
      maintenance: parseFloat(expMaintenance) || undefined,
      supplies: parseFloat(expSupplies) || undefined,
      otherExpenses: parseFloat(expOther) || undefined
    };

    upsertManualMonthlyRecord({
      ...(editingId ? { id: editingId } : {}),
      monthKey: formMonthKey,
      totalIncome: incomeNum,
      totalExpenses: expensesNum,
      openingBalance: openingNum,
      closingBalance,
      isUserModified: true,
      notes: formNotes.trim(),
      breakdownIncome: breakdownIncomeObj,
      breakdownExpenses: breakdownExpensesObj,
      recordedBy: currentUser?.name || 'وكيل السانديك'
    });

    setFeedback({
      type: 'success',
      text: lang === 'ar'
        ? `✅ تم حفظ بيانات شهر (${formMonthKey}) بنجاح! الفائض الشهري: ${(incomeNum - expensesNum).toLocaleString()} درهم.`
        : `✅ Données enregistrées avec succès pour le mois (${formMonthKey})!`
    });

    // Advance month to next one
    const [y, m] = formMonthKey.split('-').map(Number);
    let nextY = y;
    let nextM = m + 1;
    if (nextM > 12) {
      nextM = 1;
      nextY++;
    }
    const nextKey = `${nextY}-${String(nextM).padStart(2, '0')}`;
    setFormMonthKey(nextKey);
    setFormOpeningBalance(String(closingBalance));
    setEditingId(null);
    setFormIncome('');
    setFormExpenses('');
    setFormNotes('');
  };

  // Quick autofill from system payments and expenses for current month
  const handleAutoFillFromSystem = () => {
    const sysPaymentsInMonth = payments.filter(p => p.periodMonth === formMonthKey || p.paymentDate?.startsWith(formMonthKey));
    const sysExpensesInMonth = expenses.filter(e => e.date?.startsWith(formMonthKey));

    const totalSysInc = sysPaymentsInMonth.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
    const totalSysExp = sysExpensesInMonth.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);

    setFormIncome(String(totalSysInc));
    setFormExpenses(String(totalSysExp));

    setFeedback({
      type: 'success',
      text: lang === 'ar'
        ? `💡 تم جلب الإحصائيات المسجلة بالنظام لشهر ${formMonthKey}: مداخيل ${totalSysInc} د.م (${sysPaymentsInMonth.length} وصل)، مصاريف ${totalSysExp} د.م (${sysExpensesInMonth.length} نفقة).`
        : `💡 Données importées du système pour ${formMonthKey}.`
    });
  };

  // Print Detailed Financial Report
  const handlePrintReport = () => {
    window.print();
  };

  // Helper label for month
  const getMonthLabel = (key: string) => {
    const opt = monthOptions.find(o => o.key === key);
    if (!opt) return key;
    return lang === 'ar' ? opt.labelAr : opt.labelFr;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="icon-wiggle anim-bob w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-white flex items-center justify-center shadow-md shrink-0"><HeaderIcon className="w-5 h-5" /></span>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">
              {lang === 'ar' ? 'السجل والتقرير المالي للأشهر السابقة واللاحقة' : 'Registre & Rapport Financier Mensuel'}
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 font-medium mt-1">
            {lang === 'ar'
              ? 'إدخال مجموع المداخيل والمصاريف الشهرية يدوياً ابتداءً من شهر 04/2025 وإصدار تقرير مالي مفصل لكل الأشهر المدونة'
              : 'Saisie manuelle des recettes et dépenses dès avril 2025 et génération d\'un rapport financier complet'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('entry')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer border ${
              activeTab === 'entry'
                ? 'bg-indigo-700 text-white border-indigo-800'
                : 'bg-white text-indigo-700 border-indigo-200 hover:bg-indigo-50'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>{lang === 'ar' ? 'إدخال شهر جديد ✍️' : 'Nouvelle saisie'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('records')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer border ${
              activeTab === 'records'
                ? 'bg-slate-800 text-white border-slate-900'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>{lang === 'ar' ? `الأشهر المدونة (${sortedRecords.length})` : `Mois saisis (${sortedRecords.length})`}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('report')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer border ${
              activeTab === 'report'
                ? 'bg-emerald-700 text-white border-emerald-800'
                : 'bg-white text-emerald-700 border-emerald-200 hover:bg-emerald-50'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>{lang === 'ar' ? 'التقرير المالي المفصل 📄' : 'Rapport Détaillé'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSection('monthly-sheet')}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-black transition-all shadow-xs cursor-pointer border bg-indigo-50 hover:bg-indigo-100 text-indigo-900 border-indigo-300"
            title={lang === 'ar' ? 'الانتقال إلى جدول الحساب المالي المفصل (10 خانات)' : 'Voir la feuille de caisse mensuelle'}
          >
            <Calculator className="w-4 h-4 text-indigo-700" />
            <span>{lang === 'ar' ? 'جدول الحساب (10 خانات) 📊' : 'Tableau de Caisse (10 Cases)'}</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-800">
              {lang === 'ar' ? 'مجموع المداخيل المدونة' : 'Recettes Totales'}
            </span>
            <div className="p-2 rounded-xl bg-emerald-600 text-white">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-xl sm:text-2xl font-black text-emerald-950">
              {totals.income.toLocaleString()} <span className="text-xs font-bold text-emerald-700">{lang === 'ar' ? 'درهم' : 'DH'}</span>
            </div>
            <div className="text-[11px] text-emerald-700 mt-0.5">
              {lang === 'ar' ? `مجموع مدخول ${totals.count} أشهر سابقة ولاحقة` : `${totals.count} mois comptabilisés`}
            </div>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-gradient-to-br from-rose-50 to-orange-50 border border-rose-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-rose-800">
              {lang === 'ar' ? 'مجموع المصاريف المدونة' : 'Dépenses Totales'}
            </span>
            <div className="p-2 rounded-xl bg-rose-600 text-white">
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-xl sm:text-2xl font-black text-rose-950">
              {totals.expenses.toLocaleString()} <span className="text-xs font-bold text-rose-700">{lang === 'ar' ? 'درهم' : 'DH'}</span>
            </div>
            <div className="text-[11px] text-rose-700 mt-0.5">
              {lang === 'ar' ? 'رواتب، ماء، كهرباء، ونظافة' : 'Salaires, eau, électricité, etc.'}
            </div>
          </div>
        </div>

        <div className={`p-4 rounded-2xl border shadow-xs ${
          totals.net >= 0 
            ? 'bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200' 
            : 'bg-gradient-to-br from-amber-50 to-red-50 border-amber-200'
        }`}>
          <div className="flex items-center justify-between">
            <span className={`text-xs font-bold ${totals.net >= 0 ? 'text-blue-800' : 'text-red-800'}`}>
              {lang === 'ar' ? 'الفائض الإجمالي الصافي' : 'Solde Net Cumulé'}
            </span>
            <div className={`p-2 rounded-xl text-white ${totals.net >= 0 ? 'bg-blue-600' : 'bg-red-600'}`}>
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className={`text-xl sm:text-2xl font-black ${totals.net >= 0 ? 'text-blue-950' : 'text-red-950'}`}>
              {totals.net >= 0 ? `+${totals.net.toLocaleString()}` : totals.net.toLocaleString()}{' '}
              <span className="text-xs font-bold text-slate-600">{lang === 'ar' ? 'درهم' : 'DH'}</span>
            </div>
            <div className="text-[11px] text-slate-600 mt-0.5">
              {totals.net >= 0 
                ? (lang === 'ar' ? '🟢 وضعية مالية إيجابية ومريحة' : '🟢 Situation excédentaire')
                : (lang === 'ar' ? '🔴 عجز يتطلب تسريع الاستخلاص' : '🔴 Déficit à combler')}
            </div>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-50 to-fuchsia-50 border border-purple-200 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-purple-800">
              {lang === 'ar' ? 'الأشهر المسجلة' : 'Période Couverte'}
            </span>
            <div className="p-2 rounded-xl bg-purple-600 text-white">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-xl sm:text-2xl font-black text-purple-950">
              {totals.count} <span className="text-xs font-bold text-purple-700">{lang === 'ar' ? 'شهراً' : 'mois'}</span>
            </div>
            <div className="text-[11px] text-purple-700 mt-0.5">
              {sortedRecords.length > 0 
                ? `${sortedRecords[0].monthKey} ➔ ${sortedRecords[sortedRecords.length - 1].monthKey}`
                : (lang === 'ar' ? 'تبتدئ من 04/2025' : 'Dès 04/2025')}
            </div>
          </div>
        </div>
      </div>

      {/* TAB 1: ENTRY FORM */}
      {activeTab === 'entry' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden animate-in fade-in duration-200">
          <div className="px-5 py-4 bg-gradient-to-r from-indigo-900 to-slate-900 text-white flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-white/10 text-indigo-300">
                <Edit3 className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-black">
                  {editingId
                    ? (lang === 'ar' ? `تعديل بيانات شهر (${formMonthKey})` : `Modifier le mois (${formMonthKey})`)
                    : (lang === 'ar' ? 'إدخال مداخيل ومصاريف شهر (ابتداء من 04/2025)' : 'Saisie manuelle des flux mensuels')}
                </h2>
                <p className="text-xs text-indigo-200">
                  {lang === 'ar' ? 'سجل مجموع المداخيل والمصاريف بدقة مع إمكانية إضافة تفاصيل المصاريف والمداخيل' : 'Enregistrez les totaux mensuels avec ventilation optionnelle'}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={handleAutoFillFromSystem}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold border border-white/20 transition-all cursor-pointer"
              title={lang === 'ar' ? 'جلب المداخيل والمصاريف المسجلة حالياً بهذا الشهر من قاعدة البيانات' : 'Importer depuis le système'}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>{lang === 'ar' ? 'جلب تلقائي من وصولات النظام' : 'Importer du système'}</span>
            </button>
          </div>

          <form onSubmit={handleSave} className="p-6 space-y-6">
            {feedback && (
              <div className={`p-4 rounded-xl text-xs font-bold border flex items-center gap-2 ${
                feedback.type === 'success'
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                  : 'bg-rose-50 text-rose-800 border-rose-200'
              }`}>
                {feedback.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
                <span>{feedback.text}</span>
              </div>
            )}

            {/* Target Month Selector */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex-1">
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  {lang === 'ar' ? 'الشهر المالي المستهدف (من 04/2025 فما فوق) *' : 'Mois ciblé (Dès 04/2025) *'}
                </label>
                <select
                  value={formMonthKey}
                  onChange={e => {
                    const newKey = e.target.value;
                    setFormMonthKey(newKey);
                    // Check if there is already a manual record for this month
                    const existing = manualMonthlyRecords.find(r => r.monthKey === newKey);
                    if (existing) {
                      setEditingId(existing.id);
                      setFormIncome(String(existing.totalIncome));
                      setFormExpenses(String(existing.totalExpenses));
                      setFormOpeningBalance(String(existing.openingBalance || 0));
                      setFormNotes(existing.notes || '');
                    } else {
                      setEditingId(null);
                      setFormIncome('');
                      setFormExpenses('');
                      const [y, m] = newKey.split('-').map(Number);
                      let prevY = y;
                      let prevM = m - 1;
                      if (prevM < 1) {
                        prevM = 12;
                        prevY--;
                      }
                      const prevKey = `${prevY}-${String(prevM).padStart(2, '0')}`;
                      const prevRec = manualMonthlyRecords.find(r => r.monthKey === prevKey);
                      setFormOpeningBalance(prevRec ? String(prevRec.closingBalance) : '0');
                      setFormNotes('');
                    }
                  }}
                  className="w-full sm:w-80 px-3.5 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-600 focus:outline-none bg-white font-black text-slate-900"
                >
                  {monthOptions.map(opt => (
                    <option key={opt.key} value={opt.key}>
                      {lang === 'ar' ? opt.labelAr : opt.labelFr}
                    </option>
                  ))}
                </select>
              </div>
              <div className="text-xs text-slate-500">
                {lang === 'ar' ? 'تفعيل الخانات الثلاث لإدخال البيانات الناقصة لكل شهر على حدة' : 'Saisie des 3 champs mensuels'}
              </div>
            </div>

            {/* The 3 Activated Main Financial Input Fields (الخانات الثلاث) */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Field 1: Opening Balance / Carried Forward */}
              <div className="p-4 rounded-2xl bg-amber-50/70 border-2 border-amber-300 space-y-2 shadow-2xs">
                <div className="flex items-center justify-between text-amber-900">
                  <label className="text-xs font-black flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-amber-600 text-white flex items-center justify-center text-[10px]">1</span>
                    <span>{lang === 'ar' ? 'الخانة الأولى: الرصيد المنقول السابق' : 'Champ 1: Solde reporté'}</span>
                  </label>
                  <History className="w-4 h-4 text-amber-700" />
                </div>
                <div className="relative">
                  <input
                    type="number"
                    step="any"
                    value={formOpeningBalance}
                    onChange={e => setFormOpeningBalance(e.target.value)}
                    placeholder="0"
                    className="w-full px-3.5 py-2 text-sm rounded-xl border border-amber-400 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white font-black font-mono text-slate-900"
                  />
                  <span className="absolute end-3 top-1/2 -translate-y-1/2 text-xs font-bold text-amber-800">
                    DH
                  </span>
                </div>
                <span className="text-[11px] text-amber-800 font-medium block">
                  {lang === 'ar' ? 'الرصيد الافتتاحي المنقول من الشهر السابق' : 'Solde antérieur reporté'}
                </span>
              </div>

              {/* Field 2: Monthly Receipts / Income */}
              <div className="p-4 rounded-2xl bg-emerald-50/70 border-2 border-emerald-300 space-y-2 shadow-2xs">
                <div className="flex items-center justify-between text-emerald-900">
                  <label className="text-xs font-black flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px]">2</span>
                    <span>{lang === 'ar' ? 'الخانة الثانية: مقبوضات الشهرية' : 'Champ 2: Recettes mensuelles'}</span>
                  </label>
                  <TrendingUp className="w-4 h-4 text-emerald-700" />
                </div>
                <div className="relative">
                  <input
                    type="number"
                    step="any"
                    required
                    value={formIncome}
                    onChange={e => setFormIncome(e.target.value)}
                    placeholder="مثال: 48000"
                    className="w-full px-3.5 py-2 text-sm rounded-xl border border-emerald-400 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-black font-mono text-emerald-950"
                  />
                  <span className="absolute end-3 top-1/2 -translate-y-1/2 text-xs font-bold text-emerald-800">
                    DH
                  </span>
                </div>
                <span className="text-[11px] text-emerald-800 font-medium block">
                  {lang === 'ar' ? 'مجموع واجبات ومداخيل هذا الشهر المحصلة' : 'Cotisations et encaissements'}
                </span>
              </div>

              {/* Field 3: Monthly Expenses */}
              <div className="p-4 rounded-2xl bg-rose-50/70 border-2 border-rose-300 space-y-2 shadow-2xs">
                <div className="flex items-center justify-between text-rose-900">
                  <label className="text-xs font-black flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-rose-600 text-white flex items-center justify-center text-[10px]">3</span>
                    <span>{lang === 'ar' ? 'الخانة الثالثة: مصاريف الشهر' : 'Champ 3: Dépenses du mois'}</span>
                  </label>
                  <TrendingDown className="w-4 h-4 text-rose-700" />
                </div>
                <div className="relative">
                  <input
                    type="number"
                    step="any"
                    required
                    value={formExpenses}
                    onChange={e => setFormExpenses(e.target.value)}
                    placeholder="مثال: 32000"
                    className="w-full px-3.5 py-2 text-sm rounded-xl border border-rose-400 focus:ring-2 focus:ring-rose-500 focus:outline-none bg-white font-black font-mono text-rose-950"
                  />
                  <span className="absolute end-3 top-1/2 -translate-y-1/2 text-xs font-bold text-rose-800">
                    DH
                  </span>
                </div>
                <span className="text-[11px] text-rose-800 font-medium block">
                  {lang === 'ar' ? 'مجموع النفقات والمصاريف المؤداة هذا الشهر' : 'Dépenses et charges réglées'}
                </span>
              </div>
            </div>

            {/* Calculated Monthly Net & Final Balance Preview */}
            {(formIncome !== '' || formExpenses !== '' || formOpeningBalance !== '') && (
              <div className="p-4 rounded-xl bg-slate-900 text-white flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs">
                <div className="flex items-center gap-4 text-xs">
                  <div>
                    <span className="text-slate-400 block text-[10px]">{lang === 'ar' ? 'صافي الشهر الخالص (2 - 3):' : 'Solde net:'}</span>
                    <span className={`text-base font-black font-mono ${
                      ((parseFloat(formIncome) || 0) - (parseFloat(formExpenses) || 0)) >= 0
                        ? 'text-cyan-300'
                        : 'text-amber-300'
                    }`}>
                      {(((parseFloat(formIncome) || 0) - (parseFloat(formExpenses) || 0)) >= 0 ? '+' : '')}
                      {((parseFloat(formIncome) || 0) - (parseFloat(formExpenses) || 0)).toLocaleString()} DH
                    </span>
                  </div>
                  <div className="w-px h-8 bg-slate-700" />
                  <div>
                    <span className="text-slate-400 block text-[10px]">{lang === 'ar' ? 'الرصيد النهائي المرحل (1 + 2 - 3):' : 'Solde final reporté:'}</span>
                    <span className={`text-base font-black font-mono ${
                      ((parseFloat(formOpeningBalance) || 0) + (parseFloat(formIncome) || 0) - (parseFloat(formExpenses) || 0)) >= 0
                        ? 'text-emerald-300'
                        : 'text-rose-300'
                    }`}>
                      {(((parseFloat(formOpeningBalance) || 0) + (parseFloat(formIncome) || 0) - (parseFloat(formExpenses) || 0)) >= 0 ? '+' : '')}
                      {((parseFloat(formOpeningBalance) || 0) + (parseFloat(formIncome) || 0) - (parseFloat(formExpenses) || 0)).toLocaleString()} DH
                    </span>
                  </div>
                </div>
                <div className="text-[11px] text-slate-400">
                  {lang === 'ar' ? 'يتم حفظ السجل وتحديث التقارير التراكمية وسلسلة الترحيل فوراً' : 'Mise à jour en temps réel'}
                </div>
              </div>
            )}

            {/* Optional Detailed Breakdown Accordion */}
            <div className="pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowDetailedBreakdown(!showDetailedBreakdown)}
                className="flex items-center gap-2 text-xs font-bold text-indigo-700 hover:text-indigo-900 cursor-pointer"
              >
                <PieChartIcon className="w-4 h-4" />
                <span>
                  {showDetailedBreakdown
                    ? (lang === 'ar' ? 'إخفاء تفاصيل بنود المداخيل والمصاريف 🔼' : 'Masquer le détail')
                    : (lang === 'ar' ? 'إضافة تفاصيل دقيقة لبنود المداخيل والمصاريف (اختياري) 🔽' : 'Afficher la ventilation détaillée (optionnel)')}
                </span>
              </button>

              {showDetailedBreakdown && (
                <div className="mt-4 p-4 rounded-xl bg-indigo-50/50 border border-indigo-100 space-y-4 animate-in fade-in duration-150">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Income Breakdown */}
                    <div className="space-y-3">
                      <h4 className="text-xs font-extrabold text-emerald-900 flex items-center gap-1.5">
                        <TrendingUp className="w-4 h-4 text-emerald-600" />
                        <span>{lang === 'ar' ? 'تفصيل المداخيل (درهم):' : 'Détail Recettes:'}</span>
                      </h4>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div>
                          <label className="block text-[11px] text-slate-600 mb-1">{lang === 'ar' ? 'واجبات السانديك الشهرية' : 'Cotisations'}</label>
                          <input
                            type="number"
                            value={incRegular}
                            onChange={e => setIncRegular(e.target.value)}
                            placeholder="0"
                            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-slate-600 mb-1">{lang === 'ar' ? 'مساهمات استثنائية' : 'Contrib. exceptionnelles'}</label>
                          <input
                            type="number"
                            value={incExceptional}
                            onChange={e => setIncExceptional(e.target.value)}
                            placeholder="0"
                            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-slate-600 mb-1">{lang === 'ar' ? 'متأخرات مستخلصة' : 'Arriérés récupérés'}</label>
                          <input
                            type="number"
                            value={incArrears}
                            onChange={e => setIncArrears(e.target.value)}
                            placeholder="0"
                            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-slate-600 mb-1">{lang === 'ar' ? 'مداخيل أخرى' : 'Autres recettes'}</label>
                          <input
                            type="number"
                            value={incOther}
                            onChange={e => setIncOther(e.target.value)}
                            placeholder="0"
                            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Expenses Breakdown */}
                    <div className="space-y-3">
                      <h4 className="text-xs font-extrabold text-rose-900 flex items-center gap-1.5">
                        <TrendingDown className="w-4 h-4 text-rose-600" />
                        <span>{lang === 'ar' ? 'تفصيل المصاريف (درهم):' : 'Détail Dépenses:'}</span>
                      </h4>
                      <div className="grid grid-cols-2 gap-2 text-xs">
                        <div>
                          <label className="block text-[11px] text-slate-600 mb-1">{lang === 'ar' ? 'أجور الحراسة والنظافة' : 'Salaires'}</label>
                          <input
                            type="number"
                            value={expSalaries}
                            onChange={e => setExpSalaries(e.target.value)}
                            placeholder="0"
                            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-slate-600 mb-1">{lang === 'ar' ? 'الماء والكهرباء (المشترك)' : 'Eau / Électricité'}</label>
                          <input
                            type="number"
                            value={expUtilities}
                            onChange={e => setExpUtilities(e.target.value)}
                            placeholder="0"
                            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-slate-600 mb-1">{lang === 'ar' ? 'الصيانة والإصلاحات' : 'Maintenance'}</label>
                          <input
                            type="number"
                            value={expMaintenance}
                            onChange={e => setExpMaintenance(e.target.value)}
                            placeholder="0"
                            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-slate-600 mb-1">{lang === 'ar' ? 'مواد تنظيف ولوازم' : 'Fournitures'}</label>
                          <input
                            type="number"
                            value={expSupplies}
                            onChange={e => setExpSupplies(e.target.value)}
                            placeholder="0"
                            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                          />
                        </div>
                        <div className="col-span-2">
                          <label className="block text-[11px] text-slate-600 mb-1">{lang === 'ar' ? 'مصاريف أخرى متنوعة' : 'Autres charges'}</label>
                          <input
                            type="number"
                            value={expOther}
                            onChange={e => setExpOther(e.target.value)}
                            placeholder="0"
                            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Notes */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                {lang === 'ar' ? 'ملاحظات وتوضيحات حول هذا الشهر (اختياري)' : 'Observations du Syndic (optionnel)'}
              </label>
              <textarea
                rows={2}
                value={formNotes}
                onChange={e => setFormNotes(e.target.value)}
                placeholder={lang === 'ar' ? 'مثال: تم أداء مستحقات شركة النظافة وصيانة مضخات الماء المشتركة...' : 'Remarques...'}
                className="w-full px-3.5 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-600 focus:outline-none bg-white"
              />
            </div>

            {/* Submit & Reset actions */}
            <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
              {editingId && (
                <button
                  type="button"
                  onClick={handleResetForm}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-bold transition-all cursor-pointer"
                >
                  {lang === 'ar' ? 'إلغاء التعديل' : 'Annuler'}
                </button>
              )}

              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-indigo-700 hover:bg-indigo-800 text-white text-xs font-bold transition-all shadow-md cursor-pointer flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                <span>{editingId ? (lang === 'ar' ? 'تحديث بيانات الشهر' : 'Mettre à jour') : (lang === 'ar' ? 'حفظ وتدوين هذا الشهر 💾' : 'Enregistrer le mois')}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB 2: TABLE OF ENTERED RECORDS */}
      {activeTab === 'records' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden animate-in fade-in duration-200">
          <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-slate-900 text-sm">
                {lang === 'ar' ? 'لائحة الأشهر المدونة يدوياً:' : 'Mois enregistrés:'}
              </span>
              <span className="px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 text-xs font-bold">
                {filteredRecords.length} {lang === 'ar' ? 'شهر' : 'mois'}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <label className="text-xs font-bold text-slate-600">
                {lang === 'ar' ? 'تصفية حسب السنة:' : 'Filtrer:'}
              </label>
              <select
                value={selectedYearFilter}
                onChange={e => setSelectedYearFilter(e.target.value)}
                className="px-3 py-1.5 text-xs rounded-lg border border-slate-300 bg-white font-bold text-slate-800"
              >
                <option value="ALL">{lang === 'ar' ? 'كافة السنوات (من 2025 فما فوق)' : 'Toutes les années'}</option>
                <option value="2025">2025</option>
                <option value="2026">2026</option>
                <option value="2027">2027</option>
              </select>

              <button
                type="button"
                onClick={() => setActiveTab('entry')}
                className="px-3 py-1.5 rounded-lg bg-indigo-700 hover:bg-indigo-800 text-white text-xs font-bold cursor-pointer transition-all flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{lang === 'ar' ? 'إضافة شهر' : 'Ajouter'}</span>
              </button>
            </div>
          </div>

          {filteredRecords.length === 0 ? (
            <div className="p-12 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-indigo-50 text-indigo-600 mx-auto flex items-center justify-center">
                <Calendar className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-bold text-slate-900">
                {lang === 'ar' ? 'لم يتم تدوين أي شهر مالي بعد' : 'Aucun mois saisi pour le moment'}
              </h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                {lang === 'ar'
                  ? 'يمكنك البدء الآن في تدوين المداخيل والمصاريف الشهرية للأشهر السابقة ابتداءً من شهر 04/2025 فما بعد لإنشاء التقرير المالي المفصل.'
                  : 'Commencez à saisir les recettes et dépenses mensuelles dès avril 2025.'}
              </p>
              <button
                type="button"
                onClick={() => setActiveTab('entry')}
                className="px-4 py-2 rounded-xl bg-indigo-700 hover:bg-indigo-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer inline-flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>{lang === 'ar' ? 'تدوين أول شهر الآن (04/2025)' : 'Saisir le premier mois'}</span>
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-start">
                <thead className="bg-slate-100/80 text-slate-700 border-b border-slate-200">
                  <tr>
                    <th className="p-3 font-extrabold text-start">{lang === 'ar' ? 'الشهر المالي' : 'Mois'}</th>
                    <th className="p-3 font-extrabold text-start">{lang === 'ar' ? 'الرصيد السابق (الخانة 1)' : 'Report Antérieur (1)'}</th>
                    <th className="p-3 font-extrabold text-start">{lang === 'ar' ? 'المقبوضات (الخانة 2)' : 'Recettes (2)'}</th>
                    <th className="p-3 font-extrabold text-start">{lang === 'ar' ? 'المصاريف (الخانة 3)' : 'Dépenses (3)'}</th>
                    <th className="p-3 font-extrabold text-start">{lang === 'ar' ? 'صافي الشهر (2 - 3)' : 'Net Mensuel'}</th>
                    <th className="p-3 font-extrabold text-start">{lang === 'ar' ? 'الرصيد المرحل (التحفة)' : 'Solde Final Reporté'}</th>
                    <th className="p-3 font-extrabold text-start">{lang === 'ar' ? 'الملاحظات' : 'Remarques'}</th>
                    <th className="p-3 font-extrabold text-end">{lang === 'ar' ? 'الإجراءات' : 'Actions'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredRecords.map((r, idx) => {
                    const surplus = r.totalIncome - r.totalExpenses;
                    const opening = Number(r.openingBalance) || 0;
                    const closing = r.closingBalance !== undefined ? r.closingBalance : (opening + surplus);
                    return (
                      <tr key={r.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="p-3 font-black text-slate-900">
                          <div className="flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5 text-indigo-600" />
                            <span>{getMonthLabel(r.monthKey)}</span>
                          </div>
                        </td>
                        <td className="p-3 font-bold text-slate-700 font-mono">
                          {opening.toLocaleString()} DH
                        </td>
                        <td className="p-3 font-black text-emerald-700 font-mono">
                          +{r.totalIncome.toLocaleString()} DH
                        </td>
                        <td className="p-3 font-black text-rose-700 font-mono">
                          -{r.totalExpenses.toLocaleString()} DH
                        </td>
                        <td className="p-3 font-black font-mono">
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md ${
                            surplus >= 0
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : 'bg-rose-50 text-rose-800 border border-rose-200'
                          }`}>
                            {surplus >= 0 ? '+' : ''}{surplus.toLocaleString()} DH
                          </span>
                        </td>
                        <td className="p-3 font-black font-mono">
                          <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-black shadow-2xs ${
                            closing >= 0
                              ? 'bg-indigo-50 text-indigo-900 border border-indigo-200 font-black'
                              : 'bg-rose-50 text-rose-900 border border-rose-200 font-black'
                          }`}>
                            {closing >= 0 ? '+' : ''}{closing.toLocaleString()} DH
                          </span>
                        </td>
                        <td className="p-3 text-slate-600 max-w-xs truncate">
                          {r.notes || (lang === 'ar' ? 'لا توجد ملاحظات' : '-')}
                        </td>
                        <td className="p-3 text-end">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleEdit(r)}
                              className="p-1.5 rounded-lg text-indigo-700 hover:bg-indigo-50 transition-colors cursor-pointer"
                              title={lang === 'ar' ? 'تعديل' : 'Modifier'}
                            >
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                if (window.confirm(lang === 'ar' ? `هل أنت متأكد من حذف بيانات شهر ${r.monthKey}؟` : `Supprimer le mois ${r.monthKey}?`)) {
                                  deleteManualMonthlyRecord(r.id);
                                }
                              }}
                              className="p-1.5 rounded-lg text-rose-700 hover:bg-rose-50 transition-colors cursor-pointer"
                              title={lang === 'ar' ? 'حذف' : 'Supprimer'}
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot className="bg-slate-100 font-black text-slate-900 border-t-2 border-slate-300">
                  <tr>
                    <td className="p-3">{lang === 'ar' ? 'المجموع الإجمالي العام:' : 'Total Général:'}</td>
                    <td className="p-3 text-slate-500 font-mono">-</td>
                    <td className="p-3 text-emerald-800 font-mono">+{totals.income.toLocaleString()} DH</td>
                    <td className="p-3 text-rose-800 font-mono">-{totals.expenses.toLocaleString()} DH</td>
                    <td className="p-3 font-mono">
                      <span className={`px-2.5 py-1 rounded-lg ${
                        totals.net >= 0 ? 'bg-emerald-200 text-emerald-950' : 'bg-rose-200 text-rose-950'
                      }`}>
                        {totals.net >= 0 ? '+' : ''}{totals.net.toLocaleString()} DH
                      </span>
                    </td>
                    <td className="p-3 font-mono text-indigo-950" colSpan={3}>
                      {sortedRecords.length > 0 ? (
                        <span>
                          {lang === 'ar' ? 'آخر رصيد مرحل مسجل:' : 'Dernier solde reporté:'}{' '}
                          <strong className="font-mono text-indigo-800">
                            {((sortedRecords[sortedRecords.length - 1].closingBalance ?? 0)).toLocaleString()} DH
                          </strong>
                        </span>
                      ) : '-'}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: DETAILED FINANCIAL REPORT (تقرير مالي مفصل لجميع الأشهر) */}
      {activeTab === 'report' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          {/* Print & Export Bar */}
          <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-slate-200 shadow-xs print:hidden">
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-indigo-700" />
              <span className="text-sm font-extrabold text-slate-900">
                {lang === 'ar' ? 'التقرير المالي المفصل الشامل لكافة الأشهر المدونة' : 'Rapport Financier Détaillé'}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handlePrintReport}
                className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-black text-white text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>{lang === 'ar' ? 'طباعة التقرير أو حفظ كـ PDF 🖨️' : 'Imprimer / PDF'}</span>
              </button>
            </div>
          </div>

          {/* Printable Report Document Sheet */}
          <div ref={printRef} className="bg-white p-6 sm:p-10 rounded-2xl border border-slate-200 shadow-sm space-y-8 text-slate-900 print:border-none print:shadow-none print:p-0">
            {/* Document Header */}
            <div className="border-b-2 border-slate-800 pb-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                    {lang === 'ar' ? 'المملكة المغربية • اتحاد الملاك المشتركين' : 'Royaume du Maroc • Copropriété'}
                  </div>
                  <h2 className="text-2xl sm:text-3xl font-black text-slate-950 mt-1">
                    {lang === 'ar' ? 'التقرير المالي المفصل للسانديك' : 'Rapport Financier Détaillé du Syndic'}
                  </h2>
                  <div className="text-xs font-semibold text-slate-600 mt-1">
                    {lang === 'ar'
                      ? `بيان المداخيل والمصاريف للأشهر السابقة واللاحقة تبتدئ من شهر 04/2025`
                      : `État des recettes et dépenses à partir d'avril 2025`}
                  </div>
                </div>

                <div className="text-end text-xs space-y-1 bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <div><span className="font-bold">{lang === 'ar' ? 'تاريخ التقرير:' : 'Date:'}</span> {new Date().toLocaleDateString(lang === 'ar' ? 'ar-MA' : 'fr-FR')}</div>
                  <div><span className="font-bold">{lang === 'ar' ? 'عدد الأشهر المدونة:' : 'Mois:'}</span> {sortedRecords.length} {lang === 'ar' ? 'أشهر' : 'mois'}</div>
                  <div><span className="font-bold">{lang === 'ar' ? 'المحرر:' : 'Par:'}</span> {currentUser?.name || 'مكتب السانديك'}</div>
                </div>
              </div>
            </div>

            {/* Financial Summary KPI Box */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-center">
                <div className="text-xs font-bold text-emerald-800 mb-1">{lang === 'ar' ? 'مجموع المداخيل الإجمالية' : 'Total Recettes'}</div>
                <div className="text-2xl font-black text-emerald-950 font-mono">+{totals.income.toLocaleString()} DH</div>
              </div>

              <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-center">
                <div className="text-xs font-bold text-rose-800 mb-1">{lang === 'ar' ? 'مجموع المصاريف الإجمالية' : 'Total Dépenses'}</div>
                <div className="text-2xl font-black text-rose-950 font-mono">-{totals.expenses.toLocaleString()} DH</div>
              </div>

              <div className={`p-4 rounded-xl text-center border ${
                totals.net >= 0 ? 'bg-indigo-50 border-indigo-200 text-indigo-950' : 'bg-amber-50 border-amber-200 text-amber-950'
              }`}>
                <div className="text-xs font-bold mb-1">{lang === 'ar' ? 'الفائض الإجمالي الصافي (Surplus)' : 'Solde Net Global'}</div>
                <div className="text-2xl font-black font-mono">
                  {totals.net >= 0 ? `+${totals.net.toLocaleString()}` : totals.net.toLocaleString()} DH
                </div>
              </div>
            </div>

            {/* Detailed Monthly Table */}
            <div className="space-y-3">
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-indigo-700" />
                <span>{lang === 'ar' ? 'جدول المداخيل والمصاريف الشهري المفصل' : 'Tableau Mensuel Détaillé'}</span>
              </h3>

              <div className="overflow-x-auto">
                <table className="w-full text-xs text-start border border-slate-300">
                  <thead className="bg-slate-200 text-slate-900 border-b border-slate-300">
                    <tr>
                      <th className="p-2.5 font-black border-e border-slate-300 text-center w-10">#</th>
                      <th className="p-2.5 font-black border-e border-slate-300 text-start">{lang === 'ar' ? 'الشهر المالي' : 'Mois'}</th>
                      <th className="p-2.5 font-black border-e border-slate-300 text-end">{lang === 'ar' ? 'الرصيد السابق (1)' : 'Report (1)'}</th>
                      <th className="p-2.5 font-black border-e border-slate-300 text-end">{lang === 'ar' ? 'المداخيل (2)' : 'Recettes (2)'}</th>
                      <th className="p-2.5 font-black border-e border-slate-300 text-end">{lang === 'ar' ? 'المصاريف (3)' : 'Dépenses (3)'}</th>
                      <th className="p-2.5 font-black border-e border-slate-300 text-end">{lang === 'ar' ? 'صافي الشهر (2-3)' : 'Net (2-3)'}</th>
                      <th className="p-2.5 font-black border-e border-slate-300 text-end">{lang === 'ar' ? 'الرصيد المرحل (التحفة)' : 'Reporté (Final)'}</th>
                      <th className="p-2.5 font-black text-start">{lang === 'ar' ? 'الملاحظات والبيان' : 'Observations'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {sortedRecords.map((r, i) => {
                      const netMonth = r.totalIncome - r.totalExpenses;
                      const opening = Number(r.openingBalance) || 0;
                      const closing = r.closingBalance !== undefined ? r.closingBalance : (opening + netMonth);
                      return (
                        <tr key={r.id} className={i % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
                          <td className="p-2.5 text-center font-bold text-slate-500 border-e border-slate-200 font-mono">
                            {i + 1}
                          </td>
                          <td className="p-2.5 font-bold border-e border-slate-200">
                            {getMonthLabel(r.monthKey)}
                          </td>
                          <td className="p-2.5 text-end font-semibold text-slate-700 border-e border-slate-200 font-mono">
                            {opening.toLocaleString()}
                          </td>
                          <td className="p-2.5 text-end font-bold text-emerald-800 border-e border-slate-200 font-mono">
                            +{r.totalIncome.toLocaleString()}
                          </td>
                          <td className="p-2.5 text-end font-bold text-rose-800 border-e border-slate-200 font-mono">
                            -{r.totalExpenses.toLocaleString()}
                          </td>
                          <td className={`p-2.5 text-end font-black border-e border-slate-200 font-mono ${
                            netMonth >= 0 ? 'text-emerald-900 bg-emerald-50/50' : 'text-rose-900 bg-rose-50/50'
                          }`}>
                            {netMonth >= 0 ? '+' : ''}{netMonth.toLocaleString()}
                          </td>
                          <td className="p-2.5 text-end font-black text-indigo-950 bg-indigo-50/40 border-e border-slate-200 font-mono">
                            {closing >= 0 ? '+' : ''}{closing.toLocaleString()}
                          </td>
                          <td className="p-2.5 text-slate-700">
                            {r.notes || (lang === 'ar' ? 'أداء واجبات السانديك والنفقات الشهرية الاعتيادية' : 'Opérations courantes')}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot className="bg-slate-200/90 font-black text-slate-950 border-t-2 border-slate-400">
                    <tr>
                      <td colSpan={3} className="p-3 text-start border-e border-slate-300">
                        {lang === 'ar' ? 'المجموع الإجمالي العام:' : 'Total Général:'}
                      </td>
                      <td className="p-3 text-end text-emerald-900 font-mono border-e border-slate-300">
                        +{totals.income.toLocaleString()} DH
                      </td>
                      <td className="p-3 text-end text-rose-900 font-mono border-e border-slate-300">
                        -{totals.expenses.toLocaleString()} DH
                      </td>
                      <td className="p-3 text-end font-mono border-e border-slate-300">
                        <span className={totals.net >= 0 ? 'text-emerald-950' : 'text-rose-950'}>
                          {totals.net >= 0 ? '+' : ''}{totals.net.toLocaleString()} DH
                        </span>
                      </td>
                      <td className="p-3 text-end font-mono text-indigo-950 border-e border-slate-300 font-black">
                        {sortedRecords.length > 0 ? (
                          <span>{((sortedRecords[sortedRecords.length - 1].closingBalance ?? 0)).toLocaleString()} DH</span>
                        ) : '-'}
                      </td>
                      <td className="p-3 text-slate-600 text-xs">
                        {lang === 'ar' ? `تقرير مالي رسمي معتمد ومحكم` : 'Rapport officiel certifié'}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>

            {/* Official Stamps / Signatures for Report */}
            <div className="pt-8 border-t-2 border-slate-300 grid grid-cols-2 gap-8 text-center text-xs">
              <div className="p-4 rounded-xl border border-dashed border-slate-300 min-h-[100px] flex flex-col justify-between">
                <span className="font-bold text-slate-700">{lang === 'ar' ? 'توقيع وكيل السانديك' : 'Signature du Syndic'}</span>
                <span className="text-[11px] text-slate-400">{lang === 'ar' ? '(خاتم وتوقيع)' : '(Cachet et signature)'}</span>
              </div>
              <div className="p-4 rounded-xl border border-dashed border-slate-300 min-h-[100px] flex flex-col justify-between">
                <span className="font-bold text-slate-700">{lang === 'ar' ? 'تأشيرة مجلس الملاك المشتركين' : 'Conseil syndical'}</span>
                <span className="text-[11px] text-slate-400">{lang === 'ar' ? '(المصادقة والتأكيد)' : '(Visa)'}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
