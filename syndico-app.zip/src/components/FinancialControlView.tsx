import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { getApartmentDebtStatus } from '../utils/debtUtils';
import { exportElementToPdf } from '../utils/monthlyPdfReportUtils';
import { PaymentDueAlertModal } from './PaymentDueAlertModal';
import { MonthlyFinancialReportModal } from './MonthlyFinancialReportModal';
import { 
  Building2, Home, Receipt, Layers, LayoutDashboard, 
  ArrowUpDown, Filter, CheckCircle2, TrendingDown,
  AlertCircle, ArrowUpRight, Search, Printer,
  Sparkles, Check, Bell, BarChart as BarChartIcon,
  FileText, FileSpreadsheet, Download, FileClock, Calculator, Scale
} from 'lucide-react';
import { 
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, 
  Legend, Cell, ComposedChart, Line, CartesianGrid
} from 'recharts';

export const FinancialControlView: React.FC = () => {
  const { 
    t, lang, setActiveSection, buildings, apartments, 
    payments, expenses, totalIncome, totalExpenses, totalBalance, showToast,
    openActivityLog, trash
  } = useApp();

  const [buildingFilter, setBuildingFilter] = useState<'ALL' | 'GROUP_A' | 'GROUP_B' | 'DEFICIT'>('ALL');
  const [selectedComplexTab, setSelectedComplexTab] = useState<string>('ALL');
  const [buildingSearch, setBuildingSearch] = useState<string>('');
  const [sortBy, setSortBy] = useState<'rate' | 'income' | 'expense' | 'code'>('code');
  const [chartViewType, setChartViewType] = useState<'comparison' | 'rateOnly'>('comparison');
  const [isPaymentDueModalOpen, setIsPaymentDueModalOpen] = useState(false);
  const [isFinancialReportModalOpen, setIsFinancialReportModalOpen] = useState(false);
  const [financialReportMode, setFinancialReportMode] = useState<'monthly' | 'annual' | 'custom_period'>('monthly');
  const [financialReportStartYear, setFinancialReportStartYear] = useState<string>('2025');
  const [financialReportStartMonth, setFinancialReportStartMonth] = useState<string>('01');
  const [financialReportEndYear, setFinancialReportEndYear] = useState<string>('2026');
  const [financialReportEndMonth, setFinancialReportEndMonth] = useState<string>('12');
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  const handleOpenFinancialReport = (
    mode: 'monthly' | 'annual' | 'custom_period',
    sYear?: string,
    sMonth?: string,
    eYear?: string,
    eMonth?: string
  ) => {
    setFinancialReportMode(mode);
    if (sYear) setFinancialReportStartYear(sYear);
    if (sMonth) setFinancialReportStartMonth(sMonth);
    if (eYear) setFinancialReportEndYear(eYear);
    if (eMonth) setFinancialReportEndMonth(eMonth);
    setIsFinancialReportModalOpen(true);
  };

  const handleExportDashboardPdf = async () => {
    setIsGeneratingPdf(true);
    try {
      const success = await exportElementToPdf('financial-control-dashboard-export', 'TableauBord_Financier');
      if (success) {
        showToast(lang === 'ar' ? 'تم تصدير لوحة التحكم إلى PDF بنجاح!' : 'Tableau de bord exporté en PDF avec succès !', { type: 'success' });
      } else {
        showToast(lang === 'ar' ? 'حدث خطأ أثناء تصدير PDF' : 'Erreur lors de l\'exportation PDF', { type: 'error' });
      }
    } catch (err) {
      console.error(err);
      showToast(lang === 'ar' ? 'حدث خطأ أثناء التصدير' : 'Erreur d\'exportation', { type: 'error' });
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // Compute building-by-building metrics: Expected, Collected, Expenses, Collection Rate %, Surplus/Deficit
  const buildingsAnalytics = useMemo(() => {
    // Total shared expenses that are not assigned to a specific building
    const sharedExpenses = expenses
      .filter(e => !e.buildingCode || e.buildingCode === 'ALL')
      .reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
    
    const sharedPerBuilding = buildings.length > 0 ? Math.round(sharedExpenses / buildings.length) : 0;

    return buildings.map(bld => {
      const cleanCode = bld.code.replace(/\s+/g, '').toUpperCase();
      
      // Apartments in this building
      const bldApartments = apartments.filter(
        a => a.buildingCode.replace(/\s+/g, '').toUpperCase() === cleanCode
      );

      // Expected monthly revenue from all apartments in this building
      const expectedMonthly = bldApartments.reduce(
        (sum, a) => sum + (Number(a.monthlyFee) || 0), 
        0
      );

      // Total collected payments for this building
      const collectedIncome = payments
        .filter(p => p.buildingCode.replace(/\s+/g, '').toUpperCase() === cleanCode)
        .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);

      // Direct expenses attributed directly to this building
      const directExpenses = expenses
        .filter(e => e.buildingCode && e.buildingCode.replace(/\s+/g, '').toUpperCase() === cleanCode)
        .reduce((sum, e) => sum + (Number(e.amount) || 0), 0);

      // Total expenses (direct + distributed shared quota)
      const totalBldExpenses = directExpenses + sharedPerBuilding;

      // Collection Rate %
      let collectionRate = 0;
      if (expectedMonthly > 0) {
        collectionRate = Math.min(100, Math.round((collectedIncome / expectedMonthly) * 100));
      } else if (collectedIncome > 0) {
        collectionRate = 100;
      }

      // Net Balance for this building (Income - Expenses)
      const netBalance = collectedIncome - totalBldExpenses;

      // Paid vs Unpaid apartments count
      const paidApartmentsCount = bldApartments.filter(a => getApartmentDebtStatus(a, payments).isPaid && !a.isSyndicOffice).length;
      const occupiedCount = bldApartments.filter(a => a.status === 'occupied').length;

      return {
        id: bld.id,
        code: bld.code,
        name: bld.name,
        isGroupA: bld.code.trim().toUpperCase().endsWith('A'),
        isGroupB: bld.code.trim().toUpperCase().endsWith('B'),
        apartmentsCount: bldApartments.length,
        occupiedCount,
        paidApartmentsCount,
        expectedMonthly,
        collectedIncome,
        directExpenses,
        sharedExpenses: sharedPerBuilding,
        totalExpenses: totalBldExpenses,
        collectionRate,
        netBalance,
      };
    });
  }, [buildings, apartments, payments, expenses]);

  // Filtered and Sorted buildings analytics for charts & tables
  const filteredBuildingsData = useMemo(() => {
    let list = [...buildingsAnalytics];

    if (buildingFilter === 'GROUP_A') {
      list = list.filter(b => b.isGroupA);
    } else if (buildingFilter === 'GROUP_B') {
      list = list.filter(b => b.isGroupB);
    } else if (buildingFilter === 'DEFICIT') {
      list = list.filter(b => b.netBalance < 0 || b.collectionRate < 50);
    }

    if (selectedComplexTab !== 'ALL') {
      list = list.filter(b => b.code.replace(/\s+/g, '').includes(selectedComplexTab.replace(/\s+/g, '')));
    }

    if (buildingSearch.trim()) {
      const q = buildingSearch.toLowerCase().trim();
      list = list.filter(b => 
        b.code.toLowerCase().includes(q) || 
        b.name.toLowerCase().includes(q)
      );
    }

    if (sortBy === 'rate') {
      list.sort((a, b) => b.collectionRate - a.collectionRate);
    } else if (sortBy === 'income') {
      list.sort((a, b) => b.collectedIncome - a.collectedIncome);
    } else if (sortBy === 'expense') {
      list.sort((a, b) => b.totalExpenses - a.totalExpenses);
    } else {
      list.sort((a, b) => a.code.localeCompare(b.code, undefined, { numeric: true }));
    }

    return list;
  }, [buildingsAnalytics, buildingFilter, selectedComplexTab, buildingSearch, sortBy]);

  // Overall Global Residence Metrics
  const globalExpected = useMemo(() => {
    return apartments.reduce((sum, a) => sum + (Number(a.monthlyFee) || 0), 0);
  }, [apartments]);

  const globalCollectionRate = useMemo(() => {
    if (globalExpected <= 0) return 0;
    return Math.min(100, Math.round((totalIncome / globalExpected) * 100));
  }, [totalIncome, globalExpected]);

  const topCollectionBuilding = useMemo(() => {
    if (buildingsAnalytics.length === 0) return null;
    return [...buildingsAnalytics].sort((a, b) => b.collectionRate - a.collectionRate)[0];
  }, [buildingsAnalytics]);

  const highestExpenseBuilding = useMemo(() => {
    if (buildingsAnalytics.length === 0) return null;
    return [...buildingsAnalytics].sort((a, b) => b.totalExpenses - a.totalExpenses)[0];
  }, [buildingsAnalytics]);

  const complexCodes = Array.from(new Set(buildingsAnalytics.map((b: any) => String(b.code || '').replace(/\s*[A-Za-z]$/, '').trim()).filter(Boolean)));

  return (
    <div className="space-y-6" id="financial-control-dashboard-export">
      {/* Page Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="icon-wiggle anim-bob p-2.5 rounded-xl gradient-flow text-white shadow-md">
              <LayoutDashboard className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900">
                {lang === 'ar' ? 'لوحة التحكم والمتابعة المالية الدقيقة لكل عمارة' : 'Tableau de Bord & Suivi Financier par Immeuble'}
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                {lang === 'ar' 
                  ? 'متابعة تفصيلية وشاملة لجميع عمارات الإقامة الـ 20: المداخيل المحصلة، المصاريف والنفقات، نسب التحصيل، والفائض/العجز المالي' 
                  : 'Suivi analytique complet des recettes, dépenses et soldes pour chacun des tous les immeubles de la résidence'}
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap" data-html2canvas-ignore>
          <button
            id="btn-ctrl-dashboard-pdf"
            onClick={handleExportDashboardPdf}
            disabled={isGeneratingPdf}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-white text-xs font-bold transition-all shadow-xs cursor-pointer border ${isGeneratingPdf ? 'bg-slate-400 border-slate-400 cursor-not-allowed' : 'bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 border-red-500/40'}`}
            title={lang === 'ar' ? 'تصدير لوحة التحكم الحالية إلى PDF' : 'Exporter le tableau de bord en PDF'}
          >
            {isGeneratingPdf ? (
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Download className="w-4 h-4 text-amber-200" />
            )}
            <span>{lang === 'ar' ? 'PDF لوحة التحكم' : 'PDF Tableau'}</span>
          </button>

          <button
            id="btn-ctrl-budget-simulator"
            onClick={() => setActiveSection('budget-simulator')}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-purple-800 to-indigo-900 hover:from-purple-700 hover:to-indigo-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer border border-purple-500/40"
            title={lang === 'ar' ? 'محاكاة الميزانية التقديرية للسنة القادمة وأثرها على الواجبات الشهرية' : 'Simulateur du budget prévisionnel'}
          >
            <Calculator className="w-4 h-4 text-amber-300" />
            <span>{lang === 'ar' ? 'محاكاة الميزانية التقديرية 🧮' : 'Simulateur Budget'}</span>
          </button>

          <button
            id="btn-ctrl-financial-register"
            onClick={() => setActiveSection('manual-financial')}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-black transition-all shadow-xs cursor-pointer border border-amber-300"
            title={lang === 'ar' ? 'السجل والتقرير المالي للأشهر (الخانات الثلاث والرصيد المنقول)' : 'Registre & Rapport Financier Mensuel'}
          >
            <FileSpreadsheet className="w-4 h-4 text-slate-950" />
            <span>{lang === 'ar' ? 'السجل والتقرير المالي 📑' : 'Registre & Rapport'}</span>
          </button>

          <button
            id="btn-ctrl-monthly-report"
            onClick={() => handleOpenFinancialReport('monthly')}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-800 to-teal-900 hover:from-emerald-700 hover:to-teal-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer border border-emerald-600/40"
            title={lang === 'ar' ? 'التقرير المالي الشهري المفصل - قابل للتحميل والطباعة' : 'Rapport financier mensuel'}
          >
            <FileText className="w-4 h-4 text-emerald-300" />
            <span>{lang === 'ar' ? 'التقرير المالي الشهري 📊' : 'Rapport Mensuel'}</span>
          </button>

          <button
            id="btn-ctrl-annual-report"
            onClick={() => handleOpenFinancialReport('annual')}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-indigo-800 to-slate-900 hover:from-indigo-700 hover:to-slate-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer border border-indigo-500/40"
            title={lang === 'ar' ? 'التقرير المالي السنوي الشامل - قابل للتحميل والطباعة' : 'Rapport financier annuel'}
          >
            <FileSpreadsheet className="w-4 h-4 text-amber-300" />
            <span>{lang === 'ar' ? 'التقرير المالي السنوي 📑' : 'Rapport Annuel'}</span>
          </button>

          <button
            id="btn-ctrl-custom-period-report"
            onClick={() => setActiveSection('two-years-report')}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-600 via-amber-700 to-orange-700 hover:from-amber-500 hover:to-orange-600 text-white text-xs font-black transition-all shadow-xs cursor-pointer border border-amber-400/40"
            title={lang === 'ar' ? 'صفحة التقرير المالي الشامل لسنتي 2025 و 2026 مع التفاصيل والرسوم البيانية Recharts' : 'Page Rapport Financier 2025-2026 avec Graphiques'}
          >
            <Scale className="w-4 h-4 text-amber-200" />
            <span>{lang === 'ar' ? 'صفحة تقرير السنتين (2025 و 2026) ⚖️' : 'Page Bilan 2 Ans (2025-2026) ⚖️'}</span>
          </button>

          <button
            id="btn-ctrl-activity-log"
            type="button"
            onClick={openActivityLog}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#0a8591] to-[#0b6a78] hover:from-[#0d5262] hover:to-[#0a8591] text-white text-xs font-bold transition-all shadow-xs cursor-pointer border border-rose-400/40"
            title={lang === 'ar' ? 'سجل النشاطات والمحذوفات القابلة للاسترجاع' : 'Journal des activités et corbeille'}
          >
            <FileClock className="w-4 h-4 text-amber-200" />
            <span>{lang === 'ar' ? 'سجل النشاطات والمحذوفات 🕒' : 'Activités & Corbeille'}</span>
            {trash && trash.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[9px] font-black bg-rose-400 text-white">
                {trash.length}
              </span>
            )}
          </button>

          <button
            id="btn-ctrl-back-home"
            type="button"
            onClick={() => setActiveSection('dashboard')}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all shadow-xs cursor-pointer"
          >
            <Home className="w-4 h-4 text-slate-600" />
            <span>{lang === 'ar' ? 'الصفحة الرئيسية' : 'Accueil'}</span>
          </button>

          <button
            id="btn-ctrl-payment-due-alerts"
            onClick={() => setIsPaymentDueModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
            title={lang === 'ar' ? 'نظام تنبيهات وإشعارات اقتراب موعد سداد السانديك' : 'Alertes d\'échéance'}
          >
            <Bell className="w-4 h-4" />
            <span>{lang === 'ar' ? 'تنبيهات اقتراب موعد السداد ⏰' : 'Alertes Échéance'}</span>
          </button>

          <button
            id="btn-ctrl-manage-apartments"
            onClick={() => setActiveSection('apartments')}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
          >
            <Building2 className="w-4 h-4" />
            <span>{lang === 'ar' ? 'إدارة الشقق' : 'Appartements'}</span>
          </button>
        </div>
      </div>

      {/* Financial Performance Highlights Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-slate-500">{lang === 'ar' ? 'الهدف الشهري' : 'Objectif'}</span>
          <div className="text-base font-black font-mono text-slate-900">{globalExpected.toLocaleString()} DH</div>
          <div className="text-[10px] text-slate-400">جميع الشقق</div>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-emerald-700">{lang === 'ar' ? 'المحصل الفعلي' : 'Recouvré'}</span>
          <div className="text-base font-black font-mono text-emerald-700">+{totalIncome.toLocaleString()} DH</div>
          <div className="text-[10px] text-emerald-600 font-bold">{globalCollectionRate}% {lang === 'ar' ? 'نسبة التحصيل' : 'Taux'}</div>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-rose-700">{lang === 'ar' ? 'المصاريف المسجلة' : 'Dépenses'}</span>
          <div className="text-base font-black font-mono text-rose-700">-{totalExpenses.toLocaleString()} DH</div>
          <div className="text-[10px] text-slate-400">مباشرة + مشتركة</div>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-slate-500">{lang === 'ar' ? 'الرصيد الصافي' : 'Solde Net'}</span>
          <div className={`text-base font-black font-mono ${totalBalance >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
            {totalBalance >= 0 ? `+${totalBalance.toLocaleString()}` : `${totalBalance.toLocaleString()}`} DH
          </div>
          <div className="text-[10px] text-slate-400">{totalBalance >= 0 ? (lang === 'ar' ? 'فائض مالي' : 'Excédent') : (lang === 'ar' ? 'عجز مالي' : 'Déficit')}</div>
        </div>

        <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-emerald-900">{lang === 'ar' ? 'الأعلى تحصيلاً' : 'Top Recouvrement'}</span>
          <div className="text-xs font-black text-emerald-900 truncate">
            {topCollectionBuilding ? `${topCollectionBuilding.code} (${topCollectionBuilding.collectionRate}%)` : '—'}
          </div>
          <div className="text-[10px] text-emerald-700 font-mono font-bold">
            +{topCollectionBuilding ? topCollectionBuilding.collectedIncome.toLocaleString() : 0} DH
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-rose-900">{lang === 'ar' ? 'عمارات بحاجة لمتابعة' : 'À Relancer'}</span>
          <div className="text-base font-black font-mono text-rose-800">
            {buildingsAnalytics.filter(b => b.netBalance < 0 || b.collectionRate < 50).length} {lang === 'ar' ? 'عمارة' : 'Imm.'}
          </div>
          <div className="text-[10px] text-rose-700">{lang === 'ar' ? 'عجز أو تحصيل < 50%' : 'Déficit ou < 50%'}</div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* DETAILED BUILDING-BY-BUILDING PERFORMANCE TABLE                           */}
      {/* ========================================================================= */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5">
        
        {/* Table Title, Complex Tabs & Search Filter */}
        <div className="flex flex-col gap-4 pb-4 border-b border-slate-100">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800">
                  <BarChartIcon className="w-4 h-4" />
                </div>
                <h2 className="text-base sm:text-lg font-black text-slate-900">
                  {lang === 'ar' ? 'جدول المتابعة المالية الدقيقة لكل عمارة' : 'Tableau de Suivi Financier par Immeuble'}
                </h2>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                {lang === 'ar' 
                  ? 'تفاصيل المداخيل، المصاريف، الفائض/العجز ونسبة استخلاص الواجبات لجميع عمارات الإقامة الـ 20' 
                  : 'Détail des recettes, dépenses, solde net et taux pour chacun des tous les immeubles'}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 text-xs font-bold font-mono">
                {filteredBuildingsData.length} / {buildings.length} {lang === 'ar' ? 'عمارة' : 'immeubles'}
              </span>
            </div>
          </div>

          {/* Complex Filter Pills + Search Input + Group Filter */}
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 pt-1" data-html2canvas-ignore>
            
            {/* Search Input */}
            <div className="relative w-full lg:w-72">
              <Search className="w-4 h-4 absolute start-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              <input
                id="search-building-control"
                type="text"
                value={buildingSearch}
                onChange={e => setBuildingSearch(e.target.value)}
                placeholder={lang === 'ar' ? 'بحث برمز العمارة أو الكتلة (مثال: )...' : 'Rechercher par immeuble...'}
                className="w-full ps-9 pe-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-600 transition-colors"
              />
              {buildingSearch && (
                <button
                  type="button"
                  onClick={() => setBuildingSearch('')}
                  className="absolute end-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs font-bold"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Filter buttons */}
            <div className="flex items-center gap-2 flex-wrap">
              {/* Group filter */}
              <div className="flex items-center p-1 bg-slate-100 rounded-xl text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setBuildingFilter('ALL')}
                  className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                    buildingFilter === 'ALL' 
                      ? 'bg-emerald-800 text-white font-bold shadow-xs' 
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {lang === 'ar' ? 'الكل (20)' : 'Tous (20)'}
                </button>
                <button
                  type="button"
                  onClick={() => setBuildingFilter('GROUP_A')}
                  className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                    buildingFilter === 'GROUP_A' 
                      ? 'bg-emerald-800 text-white font-bold shadow-xs' 
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {lang === 'ar' ? 'المجموعة A (10)' : 'Gr. A'}
                </button>
                <button
                  type="button"
                  onClick={() => setBuildingFilter('GROUP_B')}
                  className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                    buildingFilter === 'GROUP_B' 
                      ? 'bg-emerald-800 text-white font-bold shadow-xs' 
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {lang === 'ar' ? 'المجموعة B (10)' : 'Gr. B'}
                </button>
                <button
                  type="button"
                  onClick={() => setBuildingFilter('DEFICIT')}
                  className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                    buildingFilter === 'DEFICIT' 
                      ? 'bg-rose-700 text-white font-bold shadow-xs' 
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  title="العمارات التي بها عجز مالي أو نسبة تحصيل أقل من 50%"
                >
                  {lang === 'ar' ? 'عجز / متأخرة' : 'Déficit'}
                </button>
              </div>

              {/* Sort selector */}
              <select
                id="select-sort-building-control"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-600 cursor-pointer"
              >
                <option value="code">{lang === 'ar' ? 'رمز العمارة' : 'Par Immeuble'}</option>
                <option value="rate">{lang === 'ar' ? 'الأعلى نسبة تحصيل (%)' : 'Taux le plus élevé'}</option>
                <option value="income">{lang === 'ar' ? 'الأعلى تحصيلاً (درهم)' : 'Plus de recettes'}</option>
                <option value="expense">{lang === 'ar' ? 'الأعلى مصاريف (درهم)' : 'Plus de dépenses'}</option>
              </select>
            </div>
          </div>

          {/* Complex (.. ) Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs" data-html2canvas-ignore>
            <span className="text-[11px] font-bold text-slate-400 me-1 shrink-0">{lang === 'ar' ? 'الكتلة:' : 'Bloc:'}</span>
            <button
              type="button"
              onClick={() => setSelectedComplexTab('ALL')}
              className={`px-2.5 py-1 rounded-lg font-bold text-[11px] shrink-0 transition-all cursor-pointer ${
                selectedComplexTab === 'ALL'
                  ? 'bg-emerald-900 text-white shadow-2xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {lang === 'ar' ? 'جميع الكتل' : 'Tous'}
            </button>
            {complexCodes.map(code => (
              <button
                key={code}
                type="button"
                onClick={() => setSelectedComplexTab(code)}
                className={`px-2.5 py-1 rounded-lg font-bold text-[11px] shrink-0 transition-all cursor-pointer font-mono ${
                  selectedComplexTab === code
                    ? 'bg-emerald-800 text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {code}
              </button>
            ))}
          </div>
        </div>

        {/* Detailed Table */}
        <div className="overflow-x-auto border border-slate-200/80 rounded-xl">
          <table className="w-full whitespace-nowrap text-start text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-slate-700 font-bold">
                <th className="p-3 text-start">{lang === 'ar' ? 'العمارة' : 'Immeuble'}</th>
                <th className="p-3 text-start">{lang === 'ar' ? 'عدد الشقق' : 'Lots'}</th>
                <th className="p-3 text-start">{lang === 'ar' ? 'المستحق الشهري' : 'Objectif'}</th>
                <th className="p-3 text-start">{lang === 'ar' ? 'المحصل الفعلي' : 'Recouvré'}</th>
                <th className="p-3 text-start">{lang === 'ar' ? 'المصاريف المسجلة' : 'Dépenses'}</th>
                <th className="p-3 text-start min-w-[140px]">{lang === 'ar' ? 'نسبة التحصيل' : 'Taux (%)'}</th>
                <th className="p-3 text-start">{lang === 'ar' ? 'الفائض / العجز' : 'Solde Net'}</th>
                <th className="p-3 text-start">{lang === 'ar' ? 'الوضعية' : 'Statut'}</th>
                <th className="p-3 text-start">{lang === 'ar' ? 'إجراءات' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredBuildingsData.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-8 text-center text-slate-400 text-xs">
                    {lang === 'ar' ? 'لا توجد عمارات تطابق شروط البحث أو الفلتر' : 'Aucun immeuble ne correspond aux critères'}
                  </td>
                </tr>
              ) : (
                filteredBuildingsData.map((b) => {
                  const isPositive = b.netBalance >= 0;
                  return (
                    <tr key={b.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="p-3 font-bold text-slate-900">
                        <div className="flex items-center gap-2">
                          <span className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-800 font-mono font-bold flex items-center justify-center text-xs border border-emerald-200">
                            {b.code.replace('GH ', '')}
                          </span>
                          <div>
                            <div className="font-bold text-slate-900">{b.name}</div>
                            <div className="text-[10px] text-slate-400 font-mono">{b.code}</div>
                          </div>
                        </div>
                      </td>
                      <td className="p-3 text-slate-600 font-medium">
                        <div className="font-mono">{b.occupiedCount}/{b.apartmentsCount}</div>
                        <div className="text-[10px] text-slate-400">{lang === 'ar' ? 'مشغولة' : 'occupés'}</div>
                      </td>
                      <td className="p-3 font-mono text-slate-600 font-bold">
                        {b.expectedMonthly.toLocaleString()} DH
                      </td>
                      <td className="p-3 font-mono font-black text-emerald-700">
                        +{b.collectedIncome.toLocaleString()} DH
                      </td>
                      <td className="p-3 font-mono font-black text-rose-600">
                        -{b.totalExpenses.toLocaleString()} DH
                        <div className="text-[10px] text-slate-400 font-normal">
                          {b.directExpenses > 0 ? `(${b.directExpenses} خاص)` : `(حصة مشتركة)`}
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="space-y-1">
                          <div className="flex items-center justify-between text-[11px] font-bold font-mono">
                            <span className={b.collectionRate >= 70 ? 'text-emerald-700' : b.collectionRate >= 40 ? 'text-amber-700' : 'text-rose-700'}>
                              {b.collectionRate}%
                            </span>
                            <span className="text-[10px] text-slate-400 font-normal">
                              {b.paidApartmentsCount}/{b.apartmentsCount}
                            </span>
                          </div>
                          <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                            <div 
                              className={`h-full rounded-full transition-all ${
                                b.collectionRate >= 70 ? 'bg-emerald-600' :
                                b.collectionRate >= 40 ? 'bg-amber-500' : 'bg-rose-500'
                              }`}
                              style={{ width: `${Math.min(100, b.collectionRate)}%` }}
                            />
                          </div>
                        </div>
                      </td>
                      <td className="p-3 font-mono font-black">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-lg text-xs ${
                          isPositive ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-rose-50 text-rose-700 border border-rose-200'
                        }`}>
                          {isPositive ? `+${b.netBalance.toLocaleString()}` : `${b.netBalance.toLocaleString()}`} DH
                        </span>
                      </td>
                      <td className="p-3">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          b.collectionRate >= 80 
                            ? 'bg-emerald-100 text-emerald-800' 
                            : b.collectionRate >= 50 
                            ? 'bg-blue-100 text-blue-800' 
                            : 'bg-rose-100 text-rose-800'
                        }`}>
                          {b.collectionRate >= 80 
                            ? (lang === 'ar' ? 'ممتاز' : 'Excellent') 
                            : b.collectionRate >= 50 
                            ? (lang === 'ar' ? 'متوسط' : 'Moyen') 
                            : (lang === 'ar' ? 'متابعة مطلوبة' : 'À Relancer')}
                        </span>
                      </td>
                      <td className="p-3">
                        <button
                          type="button"
                          onClick={() => setActiveSection('apartments')}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-emerald-100 text-slate-700 hover:text-emerald-800 text-[11px] font-bold transition-colors cursor-pointer flex items-center gap-1"
                          title={lang === 'ar' ? 'عرض شقق العمارة' : 'Voir appartements'}
                        >
                          <span>{lang === 'ar' ? 'الشقق' : 'Lots'}</span>
                          <ArrowUpRight className="w-3 h-3" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
            {/* Totals Summary Footer */}
            {filteredBuildingsData.length > 0 && (
              <tfoot>
                <tr className="bg-slate-100/80 border-t-2 border-slate-300 font-bold text-slate-900 text-xs">
                  <td className="p-3">
                    {lang === 'ar' ? `المجموع (${filteredBuildingsData.length} عمارة):` : `Total (${filteredBuildingsData.length}) :`}
                  </td>
                  <td className="p-3 font-mono">
                    {filteredBuildingsData.reduce((sum, b) => sum + b.occupiedCount, 0)}/{filteredBuildingsData.reduce((sum, b) => sum + b.apartmentsCount, 0)}
                  </td>
                  <td className="p-3 font-mono">
                    {filteredBuildingsData.reduce((sum, b) => sum + b.expectedMonthly, 0).toLocaleString()} DH
                  </td>
                  <td className="p-3 font-mono text-emerald-700 font-black">
                    +{filteredBuildingsData.reduce((sum, b) => sum + b.collectedIncome, 0).toLocaleString()} DH
                  </td>
                  <td className="p-3 font-mono text-rose-700 font-black">
                    -{filteredBuildingsData.reduce((sum, b) => sum + b.totalExpenses, 0).toLocaleString()} DH
                  </td>
                  <td className="p-3 font-mono">
                    {Math.round(
                      (filteredBuildingsData.reduce((sum, b) => sum + b.collectedIncome, 0) /
                        (filteredBuildingsData.reduce((sum, b) => sum + b.expectedMonthly, 0) || 1)) * 100
                    )}% {lang === 'ar' ? 'متوسط' : 'Moy.'}
                  </td>
                  <td className="p-3 font-mono font-black">
                    {(() => {
                      const net = filteredBuildingsData.reduce((sum, b) => sum + b.netBalance, 0);
                      return (
                        <span className={net >= 0 ? 'text-emerald-700' : 'text-rose-700'}>
                          {net >= 0 ? `+${net.toLocaleString()}` : `${net.toLocaleString()}`} DH
                        </span>
                      );
                    })()}
                  </td>
                  <td colSpan={2} className="p-3 text-[11px] text-slate-500 font-normal">
                    {lang === 'ar' ? 'مجموع النتائج المعروضة' : 'Total des lignes affichées'}
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* INTERACTIVE COMPARISON RECHARTS                                           */}
      {/* ========================================================================= */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs space-y-5">
        
        {/* Section Header & Controls */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-emerald-100 text-emerald-800">
                <BarChartIcon className="w-5 h-5" />
              </div>
              <h2 className="text-base sm:text-lg font-black text-slate-900">
                {lang === 'ar' 
                  ? 'رسم بياني مقارن: التحصيل والمصاريف لكل عمارة' 
                  : 'Graphique Comparatif : Recouvrement vs Dépenses par Immeuble'}
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {lang === 'ar' 
                ? 'رسم بياني تفاعلي يوضح المبالغ المحصلة، المصاريف المسجلة، ونسبة التحصيل المئوية لكل عمارة' 
                : 'Comparaison graphique des cotisations recouvrées, des charges et des taux de recouvrement'}
            </p>
          </div>

          {/* View Type Toggle */}
          <div className="flex items-center p-1 bg-slate-100 rounded-xl text-xs font-semibold">
            <button
              type="button"
              onClick={() => setChartViewType('comparison')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                chartViewType === 'comparison' 
                  ? 'bg-white text-emerald-950 font-bold shadow-xs' 
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {lang === 'ar' ? 'المداخيل والمصاريف (درهم)' : 'Recettes & Dépenses (DH)'}
            </button>
            <button
              type="button"
              onClick={() => setChartViewType('rateOnly')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                chartViewType === 'rateOnly' 
                  ? 'bg-white text-emerald-950 font-bold shadow-xs' 
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {lang === 'ar' ? 'نسب التحصيل (%)' : 'Taux Recouvrement (%)'}
            </button>
          </div>
        </div>

        {/* Recharts Container */}
        <div className="h-80 sm:h-96 w-full pt-2">
          {filteredBuildingsData.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 text-xs gap-2">
              <AlertCircle className="w-8 h-8 text-slate-300" />
              <span>{lang === 'ar' ? 'لا توجد بيانات تطابق الفلتر المحدد' : 'Aucune donnée pour ce filtre'}</span>
            </div>
          ) : chartViewType === 'comparison' ? (
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart
                data={filteredBuildingsData}
                margin={{ top: 20, right: 10, left: -10, bottom: 25 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis 
                  dataKey="code" 
                  stroke="#64748b" 
                  fontSize={11}
                  tickLine={false}
                  interval={0}
                  angle={-35}
                  textAnchor="end"
                />
                <YAxis 
                  yAxisId="left"
                  stroke="#64748b" 
                  fontSize={11}
                  tickLine={false}
                  tickFormatter={(val) => `${val} DH`}
                />
                <YAxis 
                  yAxisId="right"
                  orientation="right"
                  stroke="#059669" 
                  fontSize={11}
                  tickLine={false}
                  domain={[0, 100]}
                  tickFormatter={(val) => `${val}%`}
                />
                <Tooltip 
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xl text-xs space-y-1.5 min-w-[210px]">
                          <div className="font-bold text-slate-900 border-b border-slate-100 pb-1 flex items-center justify-between">
                            <span>{data.name || data.code}</span>
                            <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                              نسبة التحصيل: {data.collectionRate}%
                            </span>
                          </div>
                          <div className="flex items-center justify-between text-emerald-800 font-semibold">
                            <span>المداخيل المحصلة:</span>
                            <span className="font-mono font-bold">+{data.collectedIncome.toLocaleString()} DH</span>
                          </div>
                          <div className="flex items-center justify-between text-rose-700 font-semibold">
                            <span>المصاريف والنفقات:</span>
                            <span className="font-mono font-bold">-{data.totalExpenses.toLocaleString()} DH</span>
                          </div>
                          <div className="flex items-center justify-between text-slate-600">
                            <span>المستحقات المتوقعة:</span>
                            <span className="font-mono">{data.expectedMonthly.toLocaleString()} DH</span>
                          </div>
                          <div className={`pt-1 border-t border-slate-100 flex items-center justify-between font-bold ${
                            data.netBalance >= 0 ? 'text-emerald-700' : 'text-rose-700'
                          }`}>
                            <span>{data.netBalance >= 0 ? 'فائض العمارة:' : 'عجز العمارة:'}</span>
                            <span className="font-mono">{data.netBalance >= 0 ? `+${data.netBalance.toLocaleString()}` : `${data.netBalance.toLocaleString()}`} DH</span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Legend 
                  wrapperStyle={{ fontSize: '11px', paddingTop: '16px' }} 
                  verticalAlign="top"
                  align="right"
                />
                <Bar 
                  yAxisId="left"
                  dataKey="collectedIncome" 
                  name={lang === 'ar' ? 'واجبات السانديك المحصلة (DH)' : 'Cotisations Recouvrées (DH)'} 
                  fill="#059669" 
                  radius={[4, 4, 0, 0]} 
                  barSize={16}
                />
                <Bar 
                  yAxisId="left"
                  dataKey="totalExpenses" 
                  name={lang === 'ar' ? 'المصاريف المسجلة (DH)' : 'Dépenses Enregistrées (DH)'} 
                  fill="#e11d48" 
                  radius={[4, 4, 0, 0]} 
                  barSize={16}
                />
                <Line 
                  yAxisId="right"
                  type="monotone" 
                  dataKey="collectionRate" 
                  name={lang === 'ar' ? 'نسبة التحصيل (%)' : 'Taux de Recouvrement (%)'} 
                  stroke="#0284c7" 
                  strokeWidth={2.5}
                  dot={{ r: 3, fill: '#0284c7' }}
                  activeDot={{ r: 5 }}
                />
              </ComposedChart>
            </ResponsiveContainer>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={filteredBuildingsData}
                margin={{ top: 20, right: 10, left: -10, bottom: 25 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis 
                  dataKey="code" 
                  stroke="#64748b" 
                  fontSize={11}
                  tickLine={false}
                  interval={0}
                  angle={-35}
                  textAnchor="end"
                />
                <YAxis 
                  stroke="#64748b" 
                  fontSize={11}
                  tickLine={false}
                  domain={[0, 100]}
                  tickFormatter={(val) => `${val}%`}
                />
                <Tooltip 
                  formatter={(val: number) => [`${val}%`, lang === 'ar' ? 'نسبة التحصيل' : 'Taux de Recouvrement']}
                  contentStyle={{ backgroundColor: '#ffffff', borderRadius: '10px', border: '1px solid #e2e8f0', fontSize: '12px' }}
                />
                <Bar 
                  dataKey="collectionRate" 
                  name={lang === 'ar' ? 'نسبة التحصيل (%)' : 'Taux (%)'} 
                  radius={[4, 4, 0, 0]}
                  barSize={20}
                >
                  {filteredBuildingsData.map((entry, index) => {
                    const color = entry.collectionRate >= 75 ? '#059669' : entry.collectionRate >= 40 ? '#d97706' : '#e11d48';
                    return <Cell key={`rate-cell-${index}`} fill={color} />;
                  })}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Visual Chart Legend Guide */}
        <div className="flex items-center justify-center gap-6 pt-2 text-xs text-slate-600 flex-wrap">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-xs bg-emerald-600" />
            <span>{lang === 'ar' ? 'المداخيل المحصلة (درهم)' : 'Recettes encaissées'}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-xs bg-rose-600" />
            <span>{lang === 'ar' ? 'المصاريف والنفقات (درهم)' : 'Dépenses engagées'}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-4 h-1 bg-sky-600 rounded-full" />
            <span>{lang === 'ar' ? 'نسبة التحصيل (%)' : 'Taux de recouvrement (%)'}</span>
          </div>
        </div>

      </div>

      {/* Payment Due Date Approaching Alert Modal */}
      <PaymentDueAlertModal
        isOpen={isPaymentDueModalOpen}
        onClose={() => setIsPaymentDueModalOpen(false)}
      />

      {/* Monthly, Annual and 2-Year Financial Report Modal with Print & PDF Export */}
      <MonthlyFinancialReportModal
        isOpen={isFinancialReportModalOpen}
        onClose={() => setIsFinancialReportModalOpen(false)}
        initialMode={financialReportMode}
        initialStartYear={financialReportStartYear}
        initialStartMonth={financialReportStartMonth}
        initialEndYear={financialReportEndYear}
        initialEndMonth={financialReportEndMonth}
      />
    </div>
  );
};
