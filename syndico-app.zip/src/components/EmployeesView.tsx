import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Employee, EmployeeRole, Expense, PaymentMethod } from '../types';
import { 
  UserCheck, Plus, Search, Phone, Trash2, Edit2, Check, X, Shield, 
  Sparkles, Wrench, Flower2, Briefcase, Lock, Eye, CreditCard, 
  Calendar, CheckCircle2, ArrowRight, DollarSign, Receipt, Wallet, Brush, AlertTriangle, Printer
} from 'lucide-react';
import { getAvailableMonthsList, ARABIC_MONTH_NAMES, FRENCH_MONTH_NAMES } from '../utils/monthlyFinanceUtils';
import { PointageView } from './PointageView';
import { calculateEmployeeSalary, getEmployeeEffectiveStartDate, isEmployeeActiveInMonth } from '../utils/pointageUtils';
import { HardHat as HeaderIcon } from 'lucide-react';

export const EmployeesView: React.FC = () => {
  const { 
    t, lang, currentUser, employees, expenses, payments,
    addEmployee, updateEmployee, deleteEmployee, addExpense, updateExpense, deleteExpense, setActiveSection,
    pointageRecords, pointageAdvances, pointageBonuses
  } = useApp();
  
  const isOwner = currentUser?.role === 'resident';

  const [activeTab, setActiveTab] = useState<'pointage' | 'directory'>('pointage');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState('ALL');
  const [viewMonth, setViewMonth] = useState('2026-05');
  const [filterScope, setFilterScope] = useState<'month_active' | 'all'>('month_active');

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Payroll Batch Modal State
  const [isPayrollModalOpen, setIsPayrollModalOpen] = useState(false);
  const [payMonth, setPayMonth] = useState('2026-05');
  const [payDate, setPayDate] = useState('2026-05-31');
  const [payMethod, setPayMethod] = useState<PaymentMethod>('cash');
  const [selectedToPay, setSelectedToPay] = useState<Record<string, boolean>>({});
  const [paySuccessMsg, setPaySuccessMsg] = useState<string | null>(null);

  // Single Pay Modal State
  const [singlePayEmp, setSinglePayEmp] = useState<Employee | null>(null);
  const [singleMonth, setSingleMonth] = useState('2026-05');
  const [singleAmount, setSingleAmount] = useState(0);
  const [singleMethod, setSingleMethod] = useState<PaymentMethod>('cash');
  const [singleDate, setSingleDate] = useState('2026-05-31');
  const [singleNotes, setSingleNotes] = useState('');

  // Edit Mistaken Worker Salary Modal State (تعديل وتغيير أجرة عامل مسجلة بالخطأ)
  const [editingExpenseForEmp, setEditingExpenseForEmp] = useState<{ emp: Employee; expense: Expense } | null>(null);
  const [editEmpExpAmount, setEditEmpExpAmount] = useState<number>(0);
  const [editEmpExpDate, setEditEmpExpDate] = useState<string>('');
  const [editEmpExpMethod, setEditEmpExpMethod] = useState<PaymentMethod>('cash');
  const [editEmpExpNotes, setEditEmpExpNotes] = useState<string>('');

  // Delete Mistaken Worker Salary Modal State (مسح أجرة عامل مسجلة بالخطأ)
  const [deletingExpenseForEmp, setDeletingExpenseForEmp] = useState<{ emp: Employee; expense: Expense } | null>(null);

  // Delete Employee Confirmation State (مسح عامل مسجل بالخطأ)
  const [deletingEmployee, setDeletingEmployee] = useState<Employee | null>(null);

  // Success Feedback & Worker Salary Receipt State
  const [empSuccessMsg, setEmpSuccessMsg] = useState<string | null>(null);
  const [workerReceiptData, setWorkerReceiptData] = useState<{
    employee: Employee;
    expense: Expense;
    monthName: string;
    year: string;
    amount: number;
    method: string;
    date: string;
    invoiceRef: string;
    notes?: string;
  } | null>(null);

  // Form State (New / Edit Employee)
  const [name, setName] = useState('');
  const [role, setRole] = useState<EmployeeRole>('security');
  const [phone, setPhone] = useState('+212 6');
  const [shift, setShift] = useState('08:00 - 16:00');
  const [salary, setSalary] = useState(4000);
  const [assignedBuilding, setAssignedBuilding] = useState('جميع المرافق');
  const [status, setStatus] = useState<'active' | 'leave'>('active');
  const [cin, setCin] = useState('');
  const [startDate, setStartDate] = useState('');

  const availableMonths = useMemo(() => getAvailableMonthsList(payments, expenses), [payments, expenses]);

  // Check if an employee or syndic was already paid in expenses for a given month
  const getEmployeePaymentExpense = (emp: Employee, monthKey: string) => {
    return expenses.find(e => {
      const matchesCategory = e.category === 'worker_salaries' || e.category === 'syndic_fees';
      if (!matchesCategory) return false;

      const dateMatches = (e.date && e.date.startsWith(monthKey)) || 
                          (e.invoiceRef && e.invoiceRef.includes(monthKey)) ||
                          (e.title && e.title.includes(monthKey));
      if (!dateMatches) return false;

      if (emp.role === 'syndic') {
        return e.category === 'syndic_fees' && (e.title.includes('وكيل الاتحاد') || e.title.includes('السانديك') || e.supplier.includes(emp.name));
      }
      if (emp.role === 'deputy_syndic') {
        return e.category === 'syndic_fees' && (e.title.includes('نائب') || e.supplier.includes(emp.name));
      }
      return e.supplier.includes(emp.name) || e.title.includes(emp.name);
    });
  };

  const handleOpenNew = () => {
    if (isOwner) return;
    setEditingId(null);
    setName('');
    setRole('security');
    setPhone('+212 6');
    setShift('08:00 - 16:00');
    setSalary(3500);
    setAssignedBuilding('البوابة الرئيسية');
    setStatus('active');
    setCin('');
    setStartDate(new Date().toISOString().split('T')[0]);
    setIsFormOpen(true);
  };

  const handleOpenEdit = (emp: Employee) => {
    if (isOwner) return;
    setEditingId(emp.id);
    setName(emp.name);
    setRole(emp.role);
    setPhone(emp.phone);
    setShift(emp.shift);
    setSalary(emp.salary);
    setAssignedBuilding(emp.assignedBuilding || '');
    setStatus(emp.status);
    setCin(emp.cin || '');
    setStartDate(emp.startDate || '');
    setIsFormOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isOwner) return;
    if (!name.trim() || !phone.trim()) return;

    const today = new Date().toISOString().split('T')[0];
    const finalStartDate = startDate.trim() || today;

    if (editingId) {
      updateEmployee(editingId, {
        name,
        role,
        phone,
        shift,
        salary: Number(salary),
        assignedBuilding,
        status,
        cin,
        startDate: finalStartDate,
      });
      setEmpSuccessMsg(
        lang === 'ar'
          ? `✅ تم تحديث بيانات العامل (${name}) وحفظ التعديلات فوراً بنجاح!`
          : `✅ Employé (${name}) mis à jour avec succès immédiatement !`
      );
    } else {
      addEmployee({
        name,
        role,
        phone,
        shift,
        salary: Number(salary),
        assignedBuilding,
        status,
        cin,
        startDate: finalStartDate,
      });
      // CRITICAL: Ensure filterScope includes the new employee immediately so they are never hidden!
      setFilterScope('all');
      setEmpSuccessMsg(
        lang === 'ar'
          ? `✅ تم تسجيل العامل الجديد (${name}) بنجاح وإضافته إلى السجل من المحاولة الأولى!`
          : `✅ Nouvel employé (${name}) enregistré avec succès dès la 1ère tentative !`
      );
    }
    setTimeout(() => setEmpSuccessMsg(null), 6000);
    setIsFormOpen(false);
  };

  const handleOpenPayrollModal = () => {
    const initialSelected: Record<string, boolean> = {};
    employees.forEach(emp => {
      // default select all active employees in payMonth (strictly excluding those registered in later months)
      if (isEmployeeActiveInMonth(emp, payMonth)) {
        initialSelected[emp.id] = emp.status === 'active';
      }
    });
    setSelectedToPay(initialSelected);
    setPaySuccessMsg(null);
    setIsPayrollModalOpen(true);
  };

  const handleOpenSinglePay = (emp: Employee) => {
    setSinglePayEmp(emp);
    const empStartMonth = getEmployeeEffectiveStartDate(emp).slice(0, 7);
    const targetMonth = isEmployeeActiveInMonth(emp, viewMonth) ? viewMonth : (empStartMonth || '2026-05');
    setSingleMonth(targetMonth);
    
    // Check if worker has pointage records
    if (emp.role !== 'syndic' && emp.role !== 'deputy_syndic') {
      const adv = pointageAdvances[`${emp.id}_${targetMonth}`] || 0;
      const bon = pointageBonuses[`${emp.id}_${targetMonth}`] || 0;
      const calc = calculateEmployeeSalary(emp, targetMonth, pointageRecords, adv, bon);
      setSingleAmount(calc.netSalary);
      if (calc.absentDays > 0) {
        setSingleNotes(lang === 'ar'
          ? `حسب جدول التنقيط: حضور ${calc.presentDays} يوماً، راحة ${calc.restDays} أيام، غياب ${calc.absentDays} يوماً (اقتطاع: ${calc.totalAbsenceDeduction} درهم). صافي: ${calc.netSalary} درهم.`
          : `Pointage: ${calc.presentDays}j présence, ${calc.restDays}j repos, ${calc.absentDays}j absence (déduction: ${calc.totalAbsenceDeduction} DH). Net: ${calc.netSalary} DH.`
        );
      } else {
        setSingleNotes('');
      }
    } else {
      setSingleAmount(emp.salary);
      setSingleNotes('');
    }
    setSingleMethod(emp.role === 'syndic' || emp.role === 'deputy_syndic' ? 'bank_transfer' : 'cash');
    setSingleDate(`${targetMonth}-30`);
  };

  const handleConfirmSinglePay = (e: React.FormEvent) => {
    e.preventDefault();
    if (!singlePayEmp) return;

    const [y, m] = singleMonth.split('-');
    const mName = lang === 'ar' ? (ARABIC_MONTH_NAMES[m] || m) : (FRENCH_MONTH_NAMES[m] || m);
    const isSyndicOrDeputy = singlePayEmp.role === 'syndic' || singlePayEmp.role === 'deputy_syndic';

    let category: 'worker_salaries' | 'syndic_fees' = isSyndicOrDeputy ? 'syndic_fees' : 'worker_salaries';
    let title = '';
    let invoiceRef = '';

    if (singlePayEmp.role === 'syndic') {
      title = lang === 'ar' 
        ? `أجرة وتعويض وكيل الاتحاد (السانديك) عن شهر ${mName} ${y}`
        : `Honoraires et gestion agent syndic mois ${mName} ${y}`;
      invoiceRef = `SYN-IND-${y}-${m}`;
    } else if (singlePayEmp.role === 'deputy_syndic') {
      title = lang === 'ar' 
        ? `أجرة وتعويض نائب وكيل الاتحاد عن شهر ${mName} ${y}`
        : `Honoraires et indemnités adjoint au syndic mois ${mName} ${y}`;
      invoiceRef = `DEP-SYN-${y}-${m}`;
    } else {
      title = lang === 'ar'
        ? `أجرة العامل: ${singlePayEmp.name} (${getRoleLabel(singlePayEmp.role)}) عن شهر ${mName} ${y}`
        : `Salaire agent: ${singlePayEmp.name} (${getRoleLabel(singlePayEmp.role)}) mois ${mName} ${y}`;
      invoiceRef = `SAL-${y}-${m}-${singlePayEmp.id.slice(-4)}`;
    }

    const createdExp = addExpense({
      category,
      title,
      amount: Number(singleAmount),
      buildingCode: 'ALL',
      date: singleDate,
      supplier: singlePayEmp.name,
      invoiceRef,
      paidBy: lang === 'ar' ? 'مكتب السانديك وأمين المال' : 'Bureau du Syndic & Trésorier',
      paymentMethod: singleMethod,
      notes: singleNotes || (lang === 'ar' ? `صرف الأجر الشهري لشهر ${mName} ${y}` : `Règlement salaire ${mName} ${y}`)
    });

    // Provide Worker Payment Receipt Modal (وصل صرف الأجرة للعامل) immediately!
    setWorkerReceiptData({
      employee: singlePayEmp,
      expense: createdExp,
      monthName: mName,
      year: y,
      amount: Number(singleAmount),
      method: singleMethod,
      date: singleDate,
      invoiceRef,
      notes: singleNotes
    });

    setEmpSuccessMsg(
      lang === 'ar'
        ? `✅ تم تسجيل وصرف أجرة ${singlePayEmp.name} بمبلغ ${singleAmount} DH فوراً وتوليد وصل الأداء!`
        : `✅ Salaire de ${singlePayEmp.name} (${singleAmount} DH) enregistré avec succès et reçu généré !`
    );
    setTimeout(() => setEmpSuccessMsg(null), 6000);

    setSinglePayEmp(null);
  };

  const handleConfirmBatchPayroll = () => {
    const [y, m] = payMonth.split('-');
    const mName = lang === 'ar' ? (ARABIC_MONTH_NAMES[m] || m) : (FRENCH_MONTH_NAMES[m] || m);

    let recordedCount = 0;
    employees.forEach(emp => {
      if (selectedToPay[emp.id]) {
        const isSyndicOrDeputy = emp.role === 'syndic' || emp.role === 'deputy_syndic';
        let category: 'worker_salaries' | 'syndic_fees' = isSyndicOrDeputy ? 'syndic_fees' : 'worker_salaries';
        let title = '';
        let invoiceRef = '';
        let amount = Number(emp.salary);
        let notes = lang === 'ar' ? `صرف الأجر الشهري المسجل في سجل الإدارة لشهر ${mName} ${y}` : `Règlement salaire ${mName} ${y}`;

        if (emp.role === 'syndic') {
          title = lang === 'ar' 
            ? `أجرة وتعويض وكيل الاتحاد (السانديك) عن شهر ${mName} ${y}`
            : `Honoraires et gestion agent syndic mois ${mName} ${y}`;
          invoiceRef = `SYN-IND-${y}-${m}`;
        } else if (emp.role === 'deputy_syndic') {
          title = lang === 'ar' 
            ? `أجرة وتعويض نائب وكيل الاتحاد عن شهر ${mName} ${y}`
            : `Honoraires et indemnités adjoint au syndic mois ${mName} ${y}`;
          invoiceRef = `DEP-SYN-${y}-${m}`;
        } else {
          title = lang === 'ar'
            ? `أجرة العامل: ${emp.name} (${getRoleLabel(emp.role)}) عن شهر ${mName} ${y}`
            : `Salaire agent: ${emp.name} (${getRoleLabel(emp.role)}) mois ${mName} ${y}`;
          invoiceRef = `SAL-${y}-${m}-${emp.id.slice(-4)}`;

          // Apply Pointage attendance calculation:
          const adv = pointageAdvances[`${emp.id}_${payMonth}`] || 0;
          const bon = pointageBonuses[`${emp.id}_${payMonth}`] || 0;
          const calc = calculateEmployeeSalary(emp, payMonth, pointageRecords, adv, bon);
          amount = calc.netSalary;
          if (calc.absentDays > 0) {
            notes = lang === 'ar'
              ? `احتساب حسب التنقيط: حضور ${calc.presentDays} يوم، راحة ${calc.restDays} أيام، غياب ${calc.absentDays} يوم (اقتطاع: ${calc.totalAbsenceDeduction} درهم). صافي الأجر المؤدى: ${calc.netSalary} درهم.`
              : `Pointage: ${calc.presentDays}j présence, ${calc.restDays}j repos, ${calc.absentDays}j absence (déduction: ${calc.totalAbsenceDeduction} DH). Net payé: ${calc.netSalary} DH.`;
          }
        }

        addExpense({
          category,
          title,
          amount,
          buildingCode: 'ALL',
          date: payDate,
          supplier: emp.name,
          invoiceRef,
          paidBy: lang === 'ar' ? 'مكتب السانديك وأمين المال' : 'Bureau du Syndic & Trésorier',
          paymentMethod: payMethod,
          notes,
        });
        recordedCount++;
      }
    });

    setPaySuccessMsg(lang === 'ar' 
      ? `تم بنجاح تسجيل ${recordedCount} من الأجور والتعويضات في مصاريف شهر ${mName} ${y} حسب الحضور والتنقيط!`
      : `${recordedCount} salaires et honoraires enregistrés avec succès pour le mois ${mName} ${y} selon pointage!`
    );
  };

  const currentMonthLabel = useMemo(() => {
    const [year, month] = viewMonth.split('-');
    const mIndex = parseInt(month, 10) - 1;
    if (lang === 'ar') {
      return `${ARABIC_MONTH_NAMES[mIndex] || month} ${year}`;
    }
    return `${FRENCH_MONTH_NAMES[mIndex] || month} ${year}`;
  }, [viewMonth, lang]);

  const handleOpenEditEmpExp = (emp: Employee, exp: Expense) => {
    if (isOwner) return;
    setEditingExpenseForEmp({ emp, expense: exp });
    setEditEmpExpAmount(exp.amount);
    setEditEmpExpDate(exp.date || new Date().toISOString().slice(0, 10));
    setEditEmpExpMethod(exp.paymentMethod || 'cash');
    setEditEmpExpNotes(exp.title || '');
  };

  const handleSaveEditEmpExp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingExpenseForEmp || isOwner) return;
    const { emp, expense } = editingExpenseForEmp;

    updateExpense(expense.id, {
      amount: Number(editEmpExpAmount),
      date: editEmpExpDate,
      paymentMethod: editEmpExpMethod,
      title: editEmpExpNotes.trim() || expense.title,
    });

    setEditingExpenseForEmp(null);
  };

  const handleConfirmDeleteEmpExp = () => {
    if (!deletingExpenseForEmp || isOwner) return;
    deleteExpense(deletingExpenseForEmp.expense.id);
    setDeletingExpenseForEmp(null);
  };

  const handleConfirmDeleteEmployee = () => {
    if (!deletingEmployee || isOwner) return;
    deleteEmployee(deletingEmployee.id);
    setDeletingEmployee(null);
  };

  const getRoleIcon = (role: EmployeeRole) => {
    switch (role) {
      case 'security': return <Shield className="w-4 h-4 text-indigo-600" />;
      case 'supervisor': return <Eye className="w-4 h-4 text-cyan-600" />;
      case 'cleaning': return <Sparkles className="w-4 h-4 text-emerald-600" />;
      case 'gardener': return <Flower2 className="w-4 h-4 text-teal-600" />;
      case 'technician': return <Wrench className="w-4 h-4 text-amber-600" />;
      case 'syndic': return <Briefcase className="w-4 h-4 text-purple-600" />;
      case 'deputy_syndic': return <Briefcase className="w-4 h-4 text-amber-600" />;
      case 'collector': return <Wallet className="w-4 h-4 text-blue-600" />;
      case 'sweeper': return <Brush className="w-4 h-4 text-lime-600" />;
      default: return <Briefcase className="w-4 h-4 text-slate-600" />;
    }
  };

  const getMethodLabel = (m?: string) => {
    switch (m) {
      case 'cash': return t.payments.methodCash;
      case 'bank_transfer': return t.payments.methodTransfer;
      case 'check': return t.payments.methodCheck;
      case 'online': return t.payments.methodOnline;
      default: return m || t.payments.methodCash;
    }
  };

  const getRoleLabel = (role: EmployeeRole) => {
    switch (role) {
      case 'security': return t.employees.roleSecurity;
      case 'supervisor': return t.employees.roleSupervisor;
      case 'cleaning': return t.employees.roleCleaning;
      case 'gardener': return t.employees.roleGardener;
      case 'technician': return t.employees.roleTechnician;
      case 'syndic': return t.employees.roleSyndic || (lang === 'ar' ? 'وكيل الاتحاد (السانديك)' : 'Agent Syndic');
      case 'deputy_syndic': return t.employees.roleDeputySyndic || (lang === 'ar' ? 'نائب وكيل الاتحاد' : 'Adjoint au Syndic');
      case 'collector': return t.employees.roleCollector || (lang === 'ar' ? 'القابض (أمين المال)' : 'Caissier / Trésorier');
      case 'sweeper': return t.employees.roleSweeper || (lang === 'ar' ? 'الكناس' : 'Balayeur');
      default: return t.employees.roleAdmin;
    }
  };

  const filteredEmployees = useMemo(() => {
    return employees.filter(emp => {
      const matchesSearch = 
        emp.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        emp.phone.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (emp.cin && emp.cin.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (emp.assignedBuilding && emp.assignedBuilding.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchesRole = filterRole === 'ALL' || emp.role === filterRole;

      // CRITICAL RULE: Workers registered in later months (e.g. September) CANNOT be added to or shown in earlier months (e.g. August)!
      const matchesMonth = filterScope === 'all' || isEmployeeActiveInMonth(emp, viewMonth);

      return matchesSearch && matchesRole && matchesMonth;
    });
  }, [employees, searchTerm, filterRole, filterScope, viewMonth]);

  // Count of workers registered in later months than viewMonth (e.g. hired in September while viewing August)
  const workersRegisteredLaterCount = useMemo(() => {
    return employees.filter(emp => !isEmployeeActiveInMonth(emp, viewMonth)).length;
  }, [employees, viewMonth]);

  // Active employees in viewMonth for accurate payroll summary
  const activeInViewMonthEmployees = useMemo(() => {
    return employees.filter(e => e.status === 'active' && (filterScope === 'all' || isEmployeeActiveInMonth(e, viewMonth)));
  }, [employees, filterScope, viewMonth]);

  const totalMonthlyPayroll = activeInViewMonthEmployees
    .reduce((sum, e) => sum + (Number(e.salary) || 0), 0);

  const totalWorkersPayroll = activeInViewMonthEmployees
    .filter(e => e.role !== 'syndic' && e.role !== 'deputy_syndic')
    .reduce((sum, e) => sum + (Number(e.salary) || 0), 0);

  const totalSyndicFees = activeInViewMonthEmployees
    .filter(e => e.role === 'syndic' || e.role === 'deputy_syndic')
    .reduce((sum, e) => sum + (Number(e.salary) || 0), 0);

  return (
    <div className="space-y-6">
      {/* Top Tab Switcher: Pointage vs Directory */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
        <button
          type="button"
          onClick={() => setActiveTab('pointage')}
          className={`flex items-center gap-2 px-5 py-3 rounded-2xl font-black text-xs sm:text-sm transition-all cursor-pointer ${
            activeTab === 'pointage'
              ? 'bg-[#0a8591] text-white shadow-md'
              : 'bg-white hover:bg-slate-50 text-slate-700 border border-slate-200'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>{lang === 'ar' ? '📋 جدول التنقيط اليومي للعمال وحساب الأجور (Pointage)' : 'Pointage Journalier & Calcul de Paie'}</span>
          <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
            activeTab === 'pointage' ? 'bg-white/20 text-white border border-white/20' : 'bg-[#e9fbf8] text-[#0a8591]'
          }`}>
            26j + 4j
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('directory')}
          className={`flex items-center gap-2 px-5 py-3 rounded-2xl font-black text-xs sm:text-sm transition-all cursor-pointer ${
            activeTab === 'directory'
              ? 'bg-[#0a8591] text-white shadow-md'
              : 'bg-white hover:bg-slate-50 text-slate-700 border border-slate-200'
          }`}
        >
          <UserCheck className="w-4 h-4" />
          <span>{lang === 'ar' ? '👷 بطاقات العمال ومسؤولي التسيير' : 'Fiches du Personnel'}</span>
          <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
            activeTab === 'directory' ? 'bg-white/20 text-white border border-white/20' : 'bg-slate-100 text-slate-700'
          }`}>
            {employees.length}
          </span>
        </button>
      </div>

      {activeTab === 'pointage' ? (
        <PointageView initialMonth={viewMonth} />
      ) : (
        <>
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-5 rounded-2xl border-2 border-[#92e8dd] shadow-xs">
            <div>
              <div className="flex items-center gap-3"><span className="icon-wiggle anim-bob w-10 h-10 rounded-2xl bg-gradient-to-br from-yellow-400 to-orange-500 text-white flex items-center justify-center shadow-md shrink-0"><HeaderIcon className="w-5 h-5" /></span><h1 className="text-xl sm:text-2xl font-bold text-slate-900">{t.employees.title}</h1></div>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                {lang === 'ar' 
                  ? 'إدارة أجور عمال الحراسة، النظافة، البستنة، وأجرة وكيل الاتحاد ونائبه'
                  : 'Gestion des salaires des travailleurs, agents de sécurité, et honoraires du syndic & adjoint'}
              </p>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              {!isOwner && (
                <>
                  {/* Batch Salary Expense Entry Button */}
                  <button
                    type="button"
                    id="btn-open-payroll-modal"
                    onClick={handleOpenPayrollModal}
                    className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                  >
                    <CreditCard className="w-4 h-4 text-emerald-400" />
                    <span>{lang === 'ar' ? 'صرف أجور الشهر في المصاريف' : 'Imputer les salaires du mois'}</span>
                  </button>

                  <button
                    type="button"
                    id="btn-open-add-employee"
                    onClick={handleOpenNew}
                    className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#0a8591] hover:bg-[#0b6a78] text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>{t.employees.addBtn}</span>
                  </button>
                </>
              )}

              {isOwner && (
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 border border-slate-200 text-slate-600 text-xs font-semibold">
                  <Lock className="w-3.5 h-3.5 text-slate-400" />
                  <span>{lang === 'ar' ? 'فريق العمل والحراسة (اطلاع فقط)' : 'Personnel & Gardiens'}</span>
                </div>
              )}
            </div>
          </div>

          {/* Instant Success Banner */}
          {empSuccessMsg && (
            <div className="bg-emerald-500 text-white p-4 rounded-2xl shadow-md border-2 border-emerald-400 flex items-center justify-between gap-3 animate-in fade-in slide-in-from-top-2">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-white/20 text-white font-bold">
                  <CheckCircle2 className="w-5 h-5" />
                </span>
                <span className="text-xs sm:text-sm font-black">{empSuccessMsg}</span>
              </div>
              <button
                type="button"
                onClick={() => setEmpSuccessMsg(null)}
                className="p-1 rounded-lg hover:bg-white/20 text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

      {/* Quick Payroll Overview Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white p-5 rounded-2xl border border-slate-700 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="p-1.5 rounded-lg bg-emerald-600/30 text-emerald-300">
                <Receipt className="w-4 h-4" />
              </span>
              <h2 className="text-sm sm:text-base font-black">
                {lang === 'ar' ? 'الكتلة الأجرية الشهرية: أجور العمال وأجرة الوكيل ونائبه' : 'Masse Salariale Mensuelle: Ouvriers & Syndic'}
              </h2>
            </div>
            <p className="text-xs text-slate-300">
              {lang === 'ar' 
                ? 'يتم إدراج هذه المستحقات آلياً في الباب الأول (أجور العمال) والباب الثاني (أجرة وكيل ونائبه) من المصاريف الشهرية.'
                : 'Ces montants sont imputés directement dans les catégories 1 (Salaires) et 2 (Honoraires Syndic).'}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setActiveSection('expenses')}
              className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-all border border-white/10 flex items-center gap-1.5 cursor-pointer"
            >
              <span>{lang === 'ar' ? 'سجل المصاريف والفواتير' : 'Voir les dépenses'}</span>
              <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180" />
            </button>
          </div>
        </div>

        {/* 3 Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4">
          <div className="bg-white/10 backdrop-blur-xs p-3.5 rounded-xl border border-white/10">
            <span className="text-xs text-sky-300 font-bold block mb-0.5">
              {lang === 'ar' ? '👷 أجور العمال (حراسة، نظافة، بستنة)' : 'Salaires Ouvriers & Gardiens'}
            </span>
            <div className="text-xl font-black text-sky-200 font-mono">
              {totalWorkersPayroll.toLocaleString()} <span className="text-xs">DH / {lang === 'ar' ? 'شهر' : 'mois'}</span>
            </div>
            <span className="text-[11px] text-slate-300">
              {employees.filter(e => e.status === 'active' && e.role !== 'syndic' && e.role !== 'deputy_syndic').length} {lang === 'ar' ? 'عمال مباشرين' : 'agents'}
            </span>
          </div>

          <div className="bg-white/10 backdrop-blur-xs p-3.5 rounded-xl border border-white/10">
            <span className="text-xs text-amber-300 font-bold block mb-0.5">
              {lang === 'ar' ? '👔 أجرة وكيل الاتحاد ونائبه' : 'Honoraires Syndic & Adjoint'}
            </span>
            <div className="text-xl font-black text-amber-200 font-mono">
              {totalSyndicFees.toLocaleString()} <span className="text-xs">DH / {lang === 'ar' ? 'شهر' : 'mois'}</span>
            </div>
            <span className="text-[11px] text-slate-300">
              {employees.filter(e => e.status === 'active' && (e.role === 'syndic' || e.role === 'deputy_syndic')).length} {lang === 'ar' ? 'مسؤولين عن التسيير' : 'gestionnaires'}
            </span>
          </div>

          <div className="bg-emerald-600/20 backdrop-blur-xs p-3.5 rounded-xl border border-emerald-500/30">
            <span className="text-xs text-emerald-300 font-bold block mb-0.5">
              {lang === 'ar' ? '💰 إجمالي الأجور الشهرية' : 'Total Masse Salariale'}
            </span>
            <div className="text-xl font-black text-emerald-200 font-mono">
              {totalMonthlyPayroll.toLocaleString()} <span className="text-xs">DH</span>
            </div>
            <span className="text-[11px] text-emerald-100">
              {lang === 'ar' ? 'المبلغ المطلوب إدراجه شهرياً في المصاريف' : 'À imputer chaque mois'}
            </span>
          </div>
        </div>
      </div>

      {/* Add / Edit Employee Form Modal */}
      {!isOwner && isFormOpen && (
        <div className="bg-white p-6 rounded-2xl border-2 border-emerald-600 shadow-lg animate-in fade-in zoom-in-98 duration-200">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
            <h2 className="text-base font-bold text-emerald-900 flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-emerald-700" />
              <span>{editingId ? t.common.edit : t.employees.addBtn}</span>
            </h2>
            <button 
              onClick={() => setIsFormOpen(false)}
              className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.employees.name} *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="علي المريني / ذ. فلان"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.employees.role} *</label>
                <select
                  value={role}
                  onChange={e => setRole(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none bg-white font-medium"
                >
                  <optgroup label="المكتب الإداري والتسيير">
                    <option value="syndic">{lang === 'ar' ? '👔 وكيل الاتحاد (السانديك)' : 'Agent Syndic'}</option>
                    <option value="deputy_syndic">{lang === 'ar' ? '🤝 نائب وكيل الاتحاد' : 'Adjoint au Syndic'}</option>
                    <option value="collector">💰 {t.employees.roleCollector || (lang === 'ar' ? 'القابض (أمين المال)' : 'Caissier')}</option>
                    <option value="admin">{t.employees.roleAdmin}</option>
                  </optgroup>
                  <optgroup label="عمال الإقامة والمرافق">
                    <option value="security">👮 {t.employees.roleSecurity}</option>
                    <option value="cleaning">🧹 {t.employees.roleCleaning}</option>
                    <option value="sweeper">🗑️ {t.employees.roleSweeper || (lang === 'ar' ? 'الكناس' : 'Balayeur')}</option>
                    <option value="gardener">🌿 {t.employees.roleGardener}</option>
                    <option value="technician">🛠️ {t.employees.roleTechnician}</option>
                    <option value="supervisor">👀 {t.employees.roleSupervisor}</option>
                  </optgroup>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.employees.phone} *</label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="+212 650-112233"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.employees.salary} (DH) *</label>
                <input
                  type="number"
                  min="0"
                  required
                  value={salary}
                  onChange={e => setSalary(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.employees.shift}</label>
                <input
                  type="text"
                  value={shift}
                  onChange={e => setShift(e.target.value)}
                  placeholder="08:00 - 18:00"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">رقم ب.ت.و (CIN)</label>
                <input
                  type="text"
                  value={cin}
                  onChange={e => setCin(e.target.value)}
                  placeholder="EE123456"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none uppercase"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'ar' ? 'تاريخ التسجيل وبداية العمل الفعلي *' : 'Date d\'embauche & début de travail *'}
                </label>
                <input
                  type="date"
                  value={startDate}
                  onChange={e => setStartDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none font-mono font-bold"
                />
                <span className="text-[10px] text-emerald-800 mt-1 block leading-tight font-medium bg-emerald-50 p-2 rounded-lg border border-emerald-200">
                  {lang === 'ar' 
                    ? '📌 قاعدة نظام الأشهر: يعتبر تاريخ التسجيل هو بداية عمل العامل، فلا يُضاف العامل المسجل في شتنبر 2026 إلى عمال شهر ماي 2026، بل يبدأ ظهوره واحتساب أجره من شتنبر 2026 فصاعداً.' 
                    : '📌 Règle: L\'agent apparaît dans les listes et le pointage à partir de son mois d\'embauche.'}
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.employees.building}</label>
                <input
                  type="text"
                  value={assignedBuilding}
                  onChange={e => setAssignedBuilding(e.target.value)}
                  placeholder="كامل الإقامة / عمارة"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{t.employees.status}</label>
                <select
                  value={status}
                  onChange={e => setStatus(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-600 focus:outline-none bg-white"
                >
                  <option value="active">{t.employees.active}</option>
                  <option value="leave">{t.employees.leave}</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsFormOpen(false)}
                className="px-4 py-2 rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-bold transition-all cursor-pointer"
              >
                {t.common.cancel}
              </button>
              <button
                type="submit"
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>{t.common.save}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Batch Payroll Modal: صرف أجور الشهر وتسجيلها في المصاريف */}
      {!isOwner && isPayrollModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8">
            {/* Modal Header */}
            <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-emerald-600/30 text-emerald-400">
                  <CreditCard className="w-5 h-5" />
                </span>
                <div>
                  <h2 className="text-base sm:text-lg font-bold">
                    {lang === 'ar' ? 'صرف أجور ومستحقات الشهر وتسجيلها في المصاريف' : 'Imputer les salaires et honoraires du mois'}
                  </h2>
                  <p className="text-xs text-slate-300">
                    {lang === 'ar' 
                      ? 'توليد قيود المصاريف تلقائياً لأجور العمال وأجرة وكيل الاتحاد ونائبه' 
                      : 'Génération automatique des écritures de dépenses pour les salaires et honoraires'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsPayrollModalOpen(false)}
                className="p-1.5 rounded-xl hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-5">
              {paySuccessMsg && (
                <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    <span>{paySuccessMsg}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setIsPayrollModalOpen(false);
                      setActiveSection('expenses');
                    }}
                    className="px-3 py-1.5 rounded-lg bg-emerald-700 text-white text-xs hover:bg-emerald-800 transition-colors cursor-pointer"
                  >
                    {lang === 'ar' ? 'عرض المصاريف' : 'Voir les dépenses'}
                  </button>
                </div>
              )}

              {/* Month and Payment Parameters */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 bg-slate-50 rounded-xl border border-slate-200">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'ar' ? 'شهر الصرف والمحاسبة *' : 'Mois concerné *'}
                  </label>
                  <select
                    value={payMonth}
                    onChange={(e) => {
                      setPayMonth(e.target.value);
                      setPayDate(`${e.target.value}-30`);
                    }}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-bold focus:ring-2 focus:ring-emerald-600"
                  >
                    {availableMonths.map(opt => (
                      <option key={opt.key} value={opt.key}>
                        {lang === 'ar' ? opt.labelAr : opt.labelFr}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'ar' ? 'تاريخ أداء الأجور *' : 'Date de versement *'}
                  </label>
                  <input
                    type="date"
                    value={payDate}
                    onChange={(e) => setPayDate(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-mono focus:ring-2 focus:ring-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {lang === 'ar' ? 'طريقة الأداء *' : 'Mode de paiement *'}
                  </label>
                  <select
                    value={payMethod}
                    onChange={(e) => setPayMethod(e.target.value as PaymentMethod)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white font-medium focus:ring-2 focus:ring-emerald-600"
                  >
                    <option value="cash">{t.payments.methodCash}</option>
                    <option value="bank_transfer">{t.payments.methodTransfer}</option>
                    <option value="check">{t.payments.methodCheck}</option>
                  </select>
                </div>
              </div>

              {/* Staff List to Pay */}
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="p-3 bg-slate-100 text-slate-700 text-xs font-bold flex items-center justify-between border-b border-slate-200">
                  <span>{lang === 'ar' ? 'حدد العمال والمسؤولين المراد تسجيل أجورهم في هذا الشهر:' : 'Sélectionnez le personnel à payer :'}</span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const all: Record<string, boolean> = {};
                        employees.filter(e => isEmployeeActiveInMonth(e, payMonth)).forEach(e => all[e.id] = true);
                        setSelectedToPay(all);
                      }}
                      className="text-emerald-700 hover:underline text-[11px] font-bold cursor-pointer"
                    >
                      {lang === 'ar' ? 'تحديد الكل' : 'Tout sélectionner'}
                    </button>
                    <span>|</span>
                    <button
                      type="button"
                      onClick={() => setSelectedToPay({})}
                      className="text-slate-500 hover:underline text-[11px] cursor-pointer"
                    >
                      {lang === 'ar' ? 'إلغاء التحديد' : 'Désélectionner'}
                    </button>
                  </div>
                </div>

                <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
                  {employees.filter(e => isEmployeeActiveInMonth(e, payMonth)).map(emp => {
                    const existingExp = getEmployeePaymentExpense(emp, payMonth);
                    const isSelected = !!selectedToPay[emp.id];

                    return (
                      <div 
                        key={emp.id}
                        className={`p-3.5 flex items-center justify-between gap-3 text-xs transition-colors ${
                          existingExp ? 'bg-slate-50/70' : isSelected ? 'bg-emerald-50/40' : 'bg-white'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={(e) => setSelectedToPay(prev => ({ ...prev, [emp.id]: e.target.checked }))}
                            className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-slate-300 cursor-pointer"
                          />
                          <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center border border-slate-200">
                            {getRoleIcon(emp.role)}
                          </div>
                          <div>
                            <div className="font-bold text-slate-900 flex items-center gap-2">
                              <span>{emp.name}</span>
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-semibold">
                                {getRoleLabel(emp.role)}
                              </span>
                            </div>
                            <div className="text-[11px] text-slate-500">
                              {emp.role === 'syndic' || emp.role === 'deputy_syndic'
                                ? (lang === 'ar' ? 'الباب 2: أجرة وكيل و نائبه' : 'Cat. 2: Honoraires Syndic & Adjoint')
                                : (lang === 'ar' ? 'الباب 1: أجور العمال' : 'Cat. 1: Salaires des travailleurs')}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          {existingExp ? (
                            <div className="text-end">
                              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold inline-flex items-center gap-1">
                                <Check className="w-3 h-3" />
                                {lang === 'ar' ? 'تم الصرف والتسجيل مسبقاً' : 'Déjà imputé'}
                              </span>
                              <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                                {existingExp.amount.toLocaleString()} DH ({existingExp.invoiceRef || existingExp.date})
                              </div>
                            </div>
                          ) : (
                            (() => {
                              const isWorker = emp.role !== 'syndic' && emp.role !== 'deputy_syndic';
                              const calc = isWorker 
                                ? calculateEmployeeSalary(emp, payMonth, pointageRecords, pointageAdvances[`${emp.id}_${payMonth}`] || 0, pointageBonuses[`${emp.id}_${payMonth}`] || 0)
                                : null;
                              return (
                                <div className="text-end font-mono">
                                  <span className="font-black text-slate-900 text-sm">
                                    {(calc ? calc.netSalary : emp.salary).toLocaleString()} DH
                                  </span>
                                  {calc && calc.absentDays > 0 ? (
                                    <span className="block text-[10px] text-rose-600 font-bold">
                                      {lang === 'ar' ? `غياب: ${calc.absentDays}j (-${calc.totalAbsenceDeduction}DH)` : `${calc.absentDays}j abs (-${calc.totalAbsenceDeduction}DH)`}
                                    </span>
                                  ) : (
                                    <span className="block text-[10px] text-slate-400">{lang === 'ar' ? 'الراتب المستحق' : 'Salaire dû'}</span>
                                  )}
                                </div>
                              );
                            })()
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Total Calculation */}
              <div className="p-4 rounded-xl bg-slate-900 text-white flex flex-col sm:flex-row items-center justify-between gap-3">
                <div>
                  <span className="text-xs text-slate-300 block">
                    {lang === 'ar' ? 'المبلغ الإجمالي للأجور المحددة للتسجيل في المصاريف:' : 'Total des salaires sélectionnés à imputer :'}
                  </span>
                  <div className="text-2xl font-black text-emerald-400 font-mono mt-0.5">
                    {employees
                      .filter(e => selectedToPay[e.id])
                      .reduce((sum, emp) => {
                        if (emp.role !== 'syndic' && emp.role !== 'deputy_syndic') {
                          const adv = pointageAdvances[`${emp.id}_${payMonth}`] || 0;
                          const bon = pointageBonuses[`${emp.id}_${payMonth}`] || 0;
                          const calc = calculateEmployeeSalary(emp, payMonth, pointageRecords, adv, bon);
                          return sum + calc.netSalary;
                        }
                        return sum + (Number(emp.salary) || 0);
                      }, 0)
                      .toLocaleString()} <span className="text-sm text-slate-300">DH</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsPayrollModalOpen(false)}
                    className="px-4 py-2.5 rounded-xl border border-slate-700 hover:bg-white/10 text-white text-xs font-bold transition-all cursor-pointer"
                  >
                    {t.common.cancel}
                  </button>
                  <button
                    type="button"
                    onClick={handleConfirmBatchPayroll}
                    disabled={Object.values(selectedToPay).filter(Boolean).length === 0}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold transition-all shadow-md cursor-pointer"
                  >
                    <Check className="w-4 h-4" />
                    <span>{lang === 'ar' ? 'تأكيد التسجيل في المصاريف الشهرية' : 'Confirmer l\'imputation'}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Single Employee Pay Modal */}
      {singlePayEmp && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="bg-slate-900 text-white p-4 flex items-center justify-between">
              <h3 className="font-bold text-sm flex items-center gap-2">
                <Receipt className="w-4 h-4 text-emerald-400" />
                <span>{lang === 'ar' ? `صرف أجرة: ${singlePayEmp.name}` : `Paiement: ${singlePayEmp.name}`}</span>
              </h3>
              <button
                type="button"
                onClick={() => setSinglePayEmp(null)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleConfirmSinglePay} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{lang === 'ar' ? 'الشهر المعني' : 'Mois'}</label>
                <select
                  value={singleMonth}
                  onChange={e => {
                    const newMonth = e.target.value;
                    setSingleMonth(newMonth);
                    setSingleDate(`${newMonth}-30`);
                    if (singlePayEmp && singlePayEmp.role !== 'syndic' && singlePayEmp.role !== 'deputy_syndic') {
                      const adv = pointageAdvances[`${singlePayEmp.id}_${newMonth}`] || 0;
                      const bon = pointageBonuses[`${singlePayEmp.id}_${newMonth}`] || 0;
                      const calc = calculateEmployeeSalary(singlePayEmp, newMonth, pointageRecords, adv, bon);
                      setSingleAmount(calc.netSalary);
                    }
                  }}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 font-bold"
                >
                  {availableMonths.map(opt => {
                    const isActive = singlePayEmp ? isEmployeeActiveInMonth(singlePayEmp, opt.key) : true;
                    return (
                      <option key={opt.key} value={opt.key} disabled={!isActive}>
                        {lang === 'ar' ? opt.labelAr : opt.labelFr} {!isActive ? (lang === 'ar' ? '⚠️ (لم يكن مسجلاً في هذا الشهر)' : '⚠️ (Non encore recruté)') : ''}
                      </option>
                    );
                  })}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{lang === 'ar' ? 'المبلغ (DH)' : 'Montant (DH)'}</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={singleAmount}
                    onChange={e => setSingleAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">{lang === 'ar' ? 'طريقة الأداء' : 'Mode'}</label>
                  <select
                    value={singleMethod}
                    onChange={e => setSingleMethod(e.target.value as PaymentMethod)}
                    className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                  >
                    <option value="cash">{t.payments.methodCash}</option>
                    <option value="bank_transfer">{t.payments.methodTransfer}</option>
                    <option value="check">{t.payments.methodCheck}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{lang === 'ar' ? 'تاريخ الأداء' : 'Date'}</label>
                <input
                  type="date"
                  value={singleDate}
                  onChange={e => setSingleDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{lang === 'ar' ? 'ملاحظات وتفاصيل' : 'Notes'}</label>
                <input
                  type="text"
                  value={singleNotes}
                  onChange={e => setSingleNotes(e.target.value)}
                  placeholder={lang === 'ar' ? 'رقم وصل الاستلام، رقم الشيك...' : 'N° chèque ou reçu...'}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSinglePayEmp(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 text-xs font-bold"
                >
                  {t.common.cancel}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>{lang === 'ar' ? 'تسجيل في المصاريف' : 'Imputer'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Filters Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute start-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder={t.employees.searchPlaceholder}
            className="w-full ps-9 pe-3 py-2 text-xs bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-600"
          />
        </div>

        <div>
          <select
            value={filterRole}
            onChange={e => setFilterRole(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-600 font-medium"
          >
            <option value="ALL">{lang === 'ar' ? 'جميع المهام والمسؤوليات' : 'Toutes les fonctions'}</option>
            <optgroup label="المكتب والتسيير">
              <option value="syndic">{lang === 'ar' ? '👔 وكيل الاتحاد (السانديك)' : 'Agent Syndic'}</option>
              <option value="deputy_syndic">{lang === 'ar' ? '🤝 نائب وكيل الاتحاد' : 'Adjoint au Syndic'}</option>
              <option value="collector">💰 {t.employees.roleCollector || (lang === 'ar' ? 'القابض (أمين المال)' : 'Caissier')}</option>
            </optgroup>
            <optgroup label="عمال الإقامة">
              <option value="security">👮 {t.employees.roleSecurity}</option>
              <option value="cleaning">🧹 {t.employees.roleCleaning}</option>
              <option value="sweeper">🗑️ {t.employees.roleSweeper || (lang === 'ar' ? 'الكناس' : 'Balayeur')}</option>
              <option value="gardener">🌿 {t.employees.roleGardener}</option>
              <option value="technician">🛠️ {t.employees.roleTechnician}</option>
              <option value="supervisor">👀 {t.employees.roleSupervisor}</option>
            </optgroup>
          </select>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={viewMonth}
            onChange={e => setViewMonth(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-600 font-bold text-slate-800"
          >
            {availableMonths.map(opt => (
              <option key={opt.key} value={opt.key}>
                {lang === 'ar' ? `📅 أجور شهر ${opt.labelAr}` : `📅 Salaires ${opt.labelFr}`}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Quick Month Switchers & Cohort Isolation Controls */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 bg-slate-100/70 p-2.5 rounded-2xl border border-slate-200 text-xs">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-bold text-slate-600 text-[11px] ms-1">
            {lang === 'ar' ? 'المعاينة حسب الشهر:' : 'Affichage par mois:'}
          </span>
          <button
            type="button"
            onClick={() => setViewMonth('2026-05')}
            className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
              viewMonth === '2026-05'                ? 'bg-emerald-700 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            {lang === 'ar' ? '📅 عمال ماي 2026' : 'Mai 2026'}
          </button>
          <button
            type="button"
            onClick={() => setViewMonth('2026-09')}
            className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
              viewMonth === '2026-09'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200'
            }`}
          >
            {lang === 'ar' ? '📅 عمال شتنبر 2026' : 'Septembre 2026'}
          </button>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => setFilterScope('month_active')}
            className={`px-2.5 py-1.5 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
              filterScope === 'month_active'
                ? 'bg-slate-800 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-200 border border-slate-200'
            }`}
            title={lang === 'ar' ? 'عرض عمال هذا الشهر فقط واستثناء من سجل لاحقاً' : 'Ouvriers actifs ce mois uniquement'}
          >
            {lang === 'ar' ? '🔒 عمال هذا الشهر فقط' : 'Actifs ce mois'}
          </button>
          <button
            type="button"
            onClick={() => setFilterScope('all')}
            className={`px-2.5 py-1.5 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
              filterScope === 'all'
                ? 'bg-slate-800 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-200 border border-slate-200'
            }`}
            title={lang === 'ar' ? 'عرض كافة العمال المسجلين في كل الفترات' : 'Tous les ouvriers enregistrés'}
          >
            {lang === 'ar' ? '🌐 كافة المسجلين' : 'Tous'}
          </button>
        </div>
      </div>

      {/* Notice Banner when workers from later months are excluded from earlier months */}
      {filterScope === 'month_active' && workersRegisteredLaterCount > 0 && (
        <div className="p-3.5 bg-sky-50 border border-sky-200 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-sky-950">
          <div className="flex items-start sm:items-center gap-2.5">
            <span className="p-1.5 rounded-xl bg-sky-100 text-sky-700 font-bold shrink-0">🛡️</span>
            <div>
              <span className="font-bold block sm:inline">
                {lang === 'ar' 
                  ? `يتم عرض عمال شهر ${viewMonth === '2026-05' ? 'ماي 2026' : viewMonth} فقط (${filteredEmployees.length} عمال).` 
                  : `Affichage des agents du mois ${viewMonth} uniquement.`}
              </span>
              <span className="text-[11px] text-sky-800 mt-0.5 block">
                {lang === 'ar'
                  ? `تم استبعاد (${workersRegisteredLaterCount}) عامل مسجلين في شهر شتنبر 2026؛ لأنهم لم يكونوا موجودين بعد في هذا الشهر وتاريخ تسجيلهم هو شتنبر.`
                  : `${workersRegisteredLaterCount} agent(s) recruté(s) en septembre ne sont pas inclus dans ce mois.`}
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setViewMonth('2026-09')}
            className="self-end sm:self-auto px-3.5 py-1.5 rounded-xl bg-sky-700 hover:bg-sky-800 text-white font-black text-xs shrink-0 cursor-pointer transition-all shadow-xs"
          >
            {lang === 'ar' ? 'عرض عمال شتنبر 2026 ➜' : 'Voir Septembre 2026 ➜'}
          </button>
        </div>
      )}

      {/* Grid Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredEmployees.map((emp) => {
          const existingExp = getEmployeePaymentExpense(emp, viewMonth);

          return (
            <div 
              key={emp.id}
              className="bg-white rounded-2xl border border-slate-200 shadow-xs hover:border-emerald-400 transition-all p-5 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center border border-slate-200">
                      {getRoleIcon(emp.role)}
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-slate-900">{emp.name}</h3>
                      <div className="text-xs text-emerald-800 font-semibold">{getRoleLabel(emp.role)}</div>
                    </div>
                  </div>

                  {!isOwner && (
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        id={`btn-edit-emp-${emp.id}`}
                        onClick={() => handleOpenEdit(emp)}
                        className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-emerald-700 cursor-pointer"
                        title={lang === 'ar' ? 'تعديل بيانات العامل' : t.common.edit}
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        id={`btn-delete-emp-${emp.id}`}
                        onClick={() => setDeletingEmployee(emp)}
                        className="p-1.5 rounded-lg hover:bg-red-50 text-slate-400 hover:text-red-600 cursor-pointer"
                        title={lang === 'ar' ? 'مسح العامل إذا سجل عن طريق الخطأ' : t.common.delete}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>

                {/* Details box */}
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 space-y-1.5 text-xs mb-3">
                  <div className="flex items-center justify-between text-slate-600">
                    <span>{t.employees.shift}:</span>
                    <span className="font-medium text-slate-900 font-mono">{emp.shift}</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-600">
                    <span>{t.employees.building}:</span>
                    <span className="font-medium text-slate-900">{emp.assignedBuilding || '-'}</span>
                  </div>
                  {emp.cin && (
                    <div className="flex items-center justify-between text-slate-600">
                      <span>CIN:</span>
                      <span className="font-medium text-slate-900 font-mono">{emp.cin}</span>
                    </div>
                  )}
                  {getEmployeeEffectiveStartDate(emp) && (
                    <div className="flex items-center justify-between text-slate-600">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-emerald-600" />
                        <span>{lang === 'ar' ? 'تاريخ بدء العمل:' : 'Début:'}</span>
                      </span>
                      <span className="font-semibold text-emerald-800 font-mono text-xs">{getEmployeeEffectiveStartDate(emp)}</span>
                    </div>
                  )}
                  {!isOwner && (
                    <div className="flex items-center justify-between text-slate-600 pt-1 border-t border-slate-200/60">
                      <span>{t.employees.salary}:</span>
                      <span className="font-bold text-emerald-800 font-mono text-sm">{emp.salary.toLocaleString()} DH</span>
                    </div>
                  )}
                </div>

                {/* Monthly Expense Imputation Status Box (خانة العامل: عرض وتعديل ومسح الأجرة) */}
                <div className={`mb-3 p-3 rounded-xl border text-xs transition-all ${
                  existingExp 
                    ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950' 
                    : 'bg-amber-50/40 border-amber-200 text-amber-900'
                }`}>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-semibold text-slate-700 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-slate-500" />
                      <span>{currentMonthLabel}:</span>
                    </span>
                    {!isEmployeeActiveInMonth(emp, viewMonth) ? (
                      <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-500 font-medium text-[10px]">
                        {lang === 'ar' ? `التحق في ${getEmployeeEffectiveStartDate(emp).slice(0, 7)}` : 'Non recruté'}
                      </span>
                    ) : existingExp ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                        <Check className="w-3 h-3 text-emerald-700" />
                        {lang === 'ar' ? 'مسجل في المصاريف' : 'Imputé'}
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 font-medium text-[10px]">
                        {lang === 'ar' ? 'غير مسجل بعد' : 'Non imputé'}
                      </span>
                    )}
                  </div>

                  {existingExp ? (
                    <div className="mt-2 pt-2 border-t border-emerald-200/60 flex items-center justify-between gap-2">
                      <div>
                        <div className="font-extrabold text-emerald-900 font-mono text-xs">
                          {Number(existingExp.amount).toLocaleString()} DH
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono">
                          {existingExp.date} • {getMethodLabel(existingExp.paymentMethod)}
                        </div>
                      </div>

                      {!isOwner && (
                        <div className="flex items-center gap-1">
                          {/* زر تغيير الأجرة المسجلة بالخطأ في خانة هذا العامل */}
                          <button
                            type="button"
                            id={`btn-edit-salary-${emp.id}`}
                            onClick={() => handleOpenEditEmpExp(emp, existingExp)}
                            className="px-2 py-1 rounded-lg bg-white hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold text-[10px] flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                            title={lang === 'ar' ? 'تعديل وتغيير الأجرة المسجلة بالخطأ لهذا العامل' : 'Modifier le salaire'}
                          >
                            <Edit2 className="w-3 h-3" />
                            <span>{lang === 'ar' ? 'تغيير' : 'Modifier'}</span>
                          </button>

                          {/* زر مسح الأجرة المسجلة بالخطأ في خانة هذا العامل */}
                          <button
                            type="button"
                            id={`btn-delete-salary-${emp.id}`}
                            onClick={() => setDeletingExpenseForEmp({ emp, expense: existingExp })}
                            className="p-1 rounded-lg bg-white hover:bg-rose-50 text-rose-600 hover:text-rose-700 border border-rose-200 font-bold text-[10px] flex items-center justify-center cursor-pointer transition-colors shadow-2xs"
                            title={lang === 'ar' ? 'مسح الأجرة المسجلة بالخطأ لهذا العامل' : 'Supprimer'}
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-[10px] text-slate-500 mt-1">
                      {lang === 'ar' ? 'لم يتم تسجيل صرف الأجرة لهذا الشهر حتى الآن' : 'Aucun salaire imputé pour ce mois'}
                    </div>
                  )}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    emp.status === 'active' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'
                  }`}>
                    {emp.status === 'active' ? t.employees.active : t.employees.leave}
                  </span>

                  <a
                    href={`tel:${emp.phone}`}
                    className="py-1 px-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold flex items-center gap-1"
                    title={emp.phone}
                  >
                    <Phone className="w-3.5 h-3.5 text-slate-600" />
                    <span dir="ltr">{emp.phone}</span>
                  </a>
                </div>

                <div className="flex items-center gap-1.5">
                  {emp.role !== 'syndic' && emp.role !== 'deputy_syndic' && (
                    <button
                      type="button"
                      onClick={() => setActiveTab('pointage')}
                      className="px-2 py-1 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 text-[10px] font-bold transition-all cursor-pointer flex items-center gap-1"
                      title={lang === 'ar' ? 'عرض جدول التنقيط وحساب الأجر' : 'Voir le pointage'}
                    >
                      <Calendar className="w-3 h-3 text-sky-600" />
                      <span>{lang === 'ar' ? 'التنقيط' : 'Pointage'}</span>
                    </button>
                  )}

                  {!isOwner && !existingExp && isEmployeeActiveInMonth(emp, viewMonth) && (
                    <button
                      type="button"
                      onClick={() => handleOpenSinglePay(emp)}
                      className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-[11px] font-bold transition-all cursor-pointer flex items-center gap-1"
                      title={lang === 'ar' ? 'تسجيل الأجرة في المصاريف' : 'Imputer salaire'}
                    >
                      <DollarSign className="w-3 h-3" />
                      <span>{lang === 'ar' ? 'صرف الأجرة' : 'Payer'}</span>
                    </button>
                  )}

                  {!isOwner && existingExp && (
                    <span className="inline-flex items-center gap-1 text-[11px] text-emerald-700 font-bold">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{lang === 'ar' ? 'تم الصرف' : 'Payé'}</span>
                    </span>
                  )}
                </div>
              </div>

            </div>
          );
        })}
      </div>

      {/* Edit Worker Salary Modal (تعديل وتغيير أجرة العامل المسجلة بالخطأ) */}
      {!isOwner && editingExpenseForEmp && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-8">
            <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-emerald-600/30 text-emerald-400">
                  <Edit2 className="w-5 h-5" />
                </span>
                <div>
                  <h2 className="text-base font-bold">
                    {lang === 'ar' ? 'تعديل وتغيير أجرة العامل المسجلة بالخطأ' : 'Modifier le salaire enregistré'}
                  </h2>
                  <p className="text-xs text-slate-300">
                    {editingExpenseForEmp.emp.name} ({getRoleLabel(editingExpenseForEmp.emp.role)})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingExpenseForEmp(null)}
                className="p-1.5 rounded-xl hover:bg-white/10 text-slate-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEditEmpExp} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'ar' ? 'مبلغ الأجرة المصروفة (DH) *' : 'Montant du salaire (DH) *'}
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  value={editEmpExpAmount}
                  onChange={e => setEditEmpExpAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 font-mono font-bold focus:ring-2 focus:ring-slate-800 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'ar' ? 'تاريخ صرف الأداء (يوم المحاسبة) *' : 'Date de versement *'}
                </label>
                <input
                  type="date"
                  required
                  value={editEmpExpDate}
                  onChange={e => setEditEmpExpDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 font-mono focus:ring-2 focus:ring-slate-800 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'ar' ? 'طريقة الأداء' : 'Mode de paiement'}
                </label>
                <select
                  value={editEmpExpMethod}
                  onChange={e => setEditEmpExpMethod(e.target.value as PaymentMethod)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-slate-800 focus:outline-none bg-white"
                >
                  <option value="cash">{t.payments.methodCash}</option>
                  <option value="bank_transfer">{t.payments.methodTransfer}</option>
                  <option value="check">{t.payments.methodCheck}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'ar' ? 'بيان وقيد المصروف / ملاحظات' : 'Libellé / Notes'}
                </label>
                <input
                  type="text"
                  value={editEmpExpNotes}
                  onChange={e => setEditEmpExpNotes(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-slate-800 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingExpenseForEmp(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 text-xs font-bold hover:bg-slate-50 transition-all cursor-pointer"
                >
                  {t.common.cancel}
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>{lang === 'ar' ? 'حفظ التعديل والتصحيح' : t.common.save}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Worker Salary Confirmation Modal (مسح أجرة العامل المسجلة بالخطأ) */}
      {!isOwner && deletingExpenseForEmp && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-rose-200 overflow-hidden my-8">
            <div className="bg-rose-600 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-white/20 text-white">
                  <AlertTriangle className="w-5 h-5" />
                </span>
                <div>
                  <h2 className="text-base font-bold">
                    {lang === 'ar' ? 'مسح أجرة العامل المسجلة بالخطأ' : 'Suppression du salaire'}
                  </h2>
                  <p className="text-xs text-rose-100">
                    {lang === 'ar' ? 'حذف قيد المصروف من حسابات الإقامة' : 'Confirmation de suppression'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setDeletingExpenseForEmp(null)}
                className="p-1.5 rounded-xl hover:bg-white/10 text-white/80 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <p className="text-xs text-slate-600 leading-relaxed">
                {lang === 'ar'
                  ? `هل أنت متأكد من مسح أجرة العامل (${deletingExpenseForEmp.emp.name}) المسجلة عن طريق الخطأ؟ سيتم حذف قيد المصروف نهائياً وإرجاع وضعية العامل لهذا الشهر إلى "غير مسجل".`
                  : 'Êtes-vous sûr de vouloir supprimer cette écriture de salaire ?'}
              </p>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">{lang === 'ar' ? 'العامل:' : 'Employé:'}</span>
                  <span className="font-bold text-slate-900">{deletingExpenseForEmp.emp.name}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">{lang === 'ar' ? 'المبلغ المحذوف:' : 'Montant:'}</span>
                  <span className="font-extrabold text-red-700 font-mono text-sm">
                    {Number(deletingExpenseForEmp.expense.amount).toLocaleString()} DH
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">{lang === 'ar' ? 'التاريخ المسجل:' : 'Date:'}</span>
                  <span className="font-mono text-slate-700">{deletingExpenseForEmp.expense.date}</span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setDeletingExpenseForEmp(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-bold transition-all cursor-pointer"
                >
                  {lang === 'ar' ? 'إلغاء التراجع' : t.common.cancel}
                </button>
                <button
                  type="button"
                  id="btn-confirm-delete-worker-salary"
                  onClick={handleConfirmDeleteEmpExp}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>{lang === 'ar' ? 'تأكيد مسح الأجرة بالخطأ' : t.common.delete}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Employee Confirmation Modal (مسح عامل مسجل بالخطأ) */}
      {!isOwner && deletingEmployee && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-rose-200 overflow-hidden my-8">
            <div className="bg-rose-600 text-white p-5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-white/20 text-white">
                  <AlertTriangle className="w-5 h-5" />
                </span>
                <div>
                  <h2 className="text-base font-bold">
                    {lang === 'ar' ? 'مسح العامل المسجل بالخطأ' : 'Supprimer l\'employé'}
                  </h2>
                  <p className="text-xs text-rose-100">
                    {lang === 'ar' ? 'حذف بطاقة العامل من سجلات الفريق' : 'Confirmation de suppression'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setDeletingEmployee(null)}
                className="p-1.5 rounded-xl hover:bg-white/10 text-white/80 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <p className="text-xs text-slate-600 leading-relaxed">
                {lang === 'ar'
                  ? `هل أنت متأكد من مسح العامل (${deletingEmployee.name}) من بطاقات المستخدمين وعمال الإقامة؟`
                  : 'Êtes-vous sûr de vouloir supprimer cet employé ?'}
              </p>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">{lang === 'ar' ? 'الاسم الكامل:' : 'Nom:'}</span>
                  <span className="font-bold text-slate-900">{deletingEmployee.name}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">{lang === 'ar' ? 'المهمة / الوظيفة:' : 'Rôle:'}</span>
                  <span className="font-semibold text-emerald-800">{getRoleLabel(deletingEmployee.role)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">{lang === 'ar' ? 'الأجر المعتاد:' : 'Salaire:'}</span>
                  <span className="font-bold text-slate-900 font-mono">{deletingEmployee.salary} DH</span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setDeletingEmployee(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs font-bold transition-all cursor-pointer"
                >
                  {lang === 'ar' ? 'إلغاء التراجع' : t.common.cancel}
                </button>
                <button
                  type="button"
                  id="btn-confirm-delete-employee"
                  onClick={handleConfirmDeleteEmployee}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>{lang === 'ar' ? 'تأكيد مسح العامل' : t.common.delete}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Worker Salary Payment Receipt Modal (وصل أداء وصرف أجرة العامل) */}
      {workerReceiptData && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl border-2 border-emerald-400 overflow-hidden my-6">
            <div className="bg-gradient-to-r from-slate-900 to-emerald-950 text-white p-5 flex items-center justify-between border-b border-emerald-500/30">
              <div className="flex items-center gap-2.5">
                <span className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  <Receipt className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="font-black text-base text-white">
                    {lang === 'ar' ? 'وصل أداء وصرف الأجرة الشهرية' : 'Reçu de Paiement de Salaire'}
                  </h3>
                  <p className="text-xs text-emerald-300">
                    {lang === 'ar' ? 'إثبات صرف وتسجيل الأجر في حسابات السانديك' : 'Justificatif officiel d\'encaissement'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setWorkerReceiptData(null)}
                className="p-1.5 rounded-xl hover:bg-white/10 text-white/70 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-5" id="printable-worker-salary-receipt">
              {/* Header Info */}
              <div className="flex items-center justify-between border-b pb-3">
                <div>
                  <h4 className="font-extrabold text-sm text-slate-900">
                    {lang === 'ar' ? 'الإقامة - مكتب السانديك' : 'Résidence - Syndic'}
                  </h4>
                  <p className="text-[11px] text-slate-500 font-mono">
                    {lang === 'ar' ? '' : ', '}
                  </p>
                </div>
                <div className="text-end font-mono">
                  <span className="text-[10px] text-slate-500 uppercase block">{lang === 'ar' ? 'رقم الوصل' : 'N° Reçu'}</span>
                  <span className="text-xs font-black text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    {workerReceiptData.invoiceRef || workerReceiptData.expense.id}
                  </span>
                </div>
              </div>

              {/* Amount Badge */}
              <div className="bg-gradient-to-br from-emerald-50 to-teal-50 border-2 border-emerald-300 p-4 rounded-2xl text-center space-y-1">
                <span className="text-[11px] font-bold text-emerald-800">
                  {lang === 'ar' ? 'المبلغ المؤدى والصافي المستلم' : 'Montant Net Réglé'}
                </span>
                <div className="text-3xl font-black text-emerald-700 font-mono">
                  {workerReceiptData.amount} <span className="text-base font-bold">DH</span>
                </div>
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-600 text-white text-[10px] font-bold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{lang === 'ar' ? 'خالص ومسجل في المصاريف' : 'Payé et Comptabilisé'}</span>
                </div>
              </div>

              {/* Grid Details */}
              <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <div>
                  <span className="text-slate-500 block text-[10px]">{lang === 'ar' ? 'اسم المستفيد / العامل:' : 'Bénéficiaire :'}</span>
                  <span className="font-bold text-slate-900">{workerReceiptData.employee.name}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">{lang === 'ar' ? 'المهمة / الصفة:' : 'Fonction :'}</span>
                  <span className="font-semibold text-slate-700">{getRoleLabel(workerReceiptData.employee.role)}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">{lang === 'ar' ? 'الشهر المؤدى عنه:' : 'Période :'}</span>
                  <span className="font-bold text-emerald-800">{workerReceiptData.monthName} {workerReceiptData.year}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">{lang === 'ar' ? 'تاريخ الصرف والتسجيل:' : 'Date de paiement :'}</span>
                  <span className="font-mono font-bold text-slate-800">{workerReceiptData.date}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">{lang === 'ar' ? 'طريقة الأداء:' : 'Mode de règlement :'}</span>
                  <span className="font-bold text-slate-800">
                    {workerReceiptData.method === 'cash' ? (lang === 'ar' ? 'نقداً (سيولة)' : 'Espèces') : (lang === 'ar' ? 'تحويل بنكي' : 'Virement')}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">{lang === 'ar' ? 'رقم ب.ت.و (CIN):' : 'N° CIN :'}</span>
                  <span className="font-mono text-slate-700">{workerReceiptData.employee.cin || '---'}</span>
                </div>
              </div>

              {workerReceiptData.notes && (
                <div className="text-[11px] p-2.5 rounded-xl bg-slate-100 text-slate-600 border border-slate-200">
                  <span className="font-bold block mb-0.5">{lang === 'ar' ? 'ملاحظات وتفاصيل التنقيط:' : 'Notes :'}</span>
                  <p>{workerReceiptData.notes}</p>
                </div>
              )}

              {/* Signatures */}
              <div className="grid grid-cols-2 gap-4 pt-4 border-t text-center text-[10px] text-slate-500">
                <div className="border border-dashed border-slate-300 rounded-xl p-3 bg-slate-50">
                  <span className="font-bold block mb-4">{lang === 'ar' ? 'توقيع وخاتم السانديك' : 'Signature & Cachet Syndic'}</span>
                  <span className="text-slate-400">مكتب السانديك</span>
                </div>
                <div className="border border-dashed border-slate-300 rounded-xl p-3 bg-slate-50">
                  <span className="font-bold block mb-4">{lang === 'ar' ? 'توقيع المستفيد (العامل)' : 'Signature Bénéficiaire'}</span>
                  <span className="text-slate-400">{workerReceiptData.employee.name}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>{lang === 'ar' ? 'طباعة الوصل' : 'Imprimer le reçu'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setWorkerReceiptData(null)}
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black transition-all shadow-xs cursor-pointer"
                >
                  <span>{lang === 'ar' ? 'إغلاق ومتابعة' : 'Fermer'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
        </>
      )}
    </div>
  );
};
