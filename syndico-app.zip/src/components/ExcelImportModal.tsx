import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { 
  FileSpreadsheet, Upload, Download, CheckCircle2, AlertCircle, 
  HelpCircle, ArrowRight, ArrowLeft, RefreshCw, Eye, X, Filter,
  FileCheck, Shield, Phone, Mail, Building, Home, MapPin, Hash, Sparkles
} from 'lucide-react';
import { 
  generateOwnersExcelTemplate, 
  readExcelFile, 
  autoDetectFieldMapping, 
  processImportData,
  ExcelImportFieldMapping,
  ImportSummary,
  ParsedOwnerRow
} from '../utils/excelImportUtils';
import { ApartmentStatus } from '../types';

interface ExcelImportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type Step = 'upload' | 'mapping' | 'preview' | 'success';

export const ExcelImportModal: React.FC<ExcelImportModalProps> = ({ isOpen, onClose }) => {
  const { 
    lang, t, apartments, buildings, residents, importOwnersFromExcelData 
  } = useApp();
  const isAr = lang === 'ar';

  const [step, setStep] = useState<Step>('upload');
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Sheets data
  const [sheetNames, setSheetNames] = useState<string[]>([]);
  const [selectedSheet, setSelectedSheet] = useState<string>('');
  const [sheetsRawData, setSheetsRawData] = useState<Record<string, { headers: string[]; rows: any[][] }>>({});

  // Column mapping
  const [headers, setHeaders] = useState<string[]>([]);
  const [mapping, setMapping] = useState<ExcelImportFieldMapping>({
    buildingCode: '',
    apartmentNumber: '',
    ownerName: '',
    ownerPhone: '',
    ownerCin: '',
    ownerEmail: '',
    addressOrNotes: '',
    floor: '',
    monthlyFee: '',
    status: '',
    residentName: '',
    residentPhone: '',
    unpaidMonthsCount: '',
    balanceDue: ''
  });

  // Processed Import Data
  const [summary, setSummary] = useState<ImportSummary | null>(null);
  const [previewFilter, setPreviewFilter] = useState<'ALL' | 'existing' | 'new' | 'invalid'>('ALL');
  const [previewSearch, setPreviewSearch] = useState('');

  // Import options
  const [updateApartments, setUpdateApartments] = useState(true);
  const [syncResidents, setSyncResidents] = useState(true);
  const [createMissingApartments, setCreateMissingApartments] = useState(true);
  const [overwriteExistingPhones, setOverwriteExistingPhones] = useState(true);

  // Success stats
  const [resultStats, setResultStats] = useState<{
    apartmentsUpdated: number;
    residentsUpdated: number;
    apartmentsCreated: number;
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleReset = () => {
    setStep('upload');
    setFile(null);
    setErrorMessage(null);
    setSummary(null);
    setResultStats(null);
    setPreviewSearch('');
  };

  const handleFileProcess = async (selectedFile: File) => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const parsed = await readExcelFile(selectedFile);
      if (parsed.sheetNames.length === 0) {
        throw new Error(isAr ? 'الملف فارغ أو غير مدعوم' : 'Le fichier est vide ou non pris en charge');
      }

      setFile(selectedFile);
      setSheetNames(parsed.sheetNames);
      setSheetsRawData(parsed.sheetsData);

      const firstSheet = parsed.sheetNames[0];
      setSelectedSheet(firstSheet);

      const sheetData = parsed.sheetsData[firstSheet];
      setHeaders(sheetData.headers);

      const autoMap = autoDetectFieldMapping(sheetData.headers);
      setMapping(autoMap);

      // Auto-check if basic required columns are found
      const hasReq = autoMap.buildingCode && autoMap.apartmentNumber && autoMap.ownerName;
      if (hasReq) {
        // Pre-calculate summary
        const resSummary = processImportData(
          sheetData.headers, 
          sheetData.rows, 
          autoMap, 
          apartments, 
          buildings
        );
        setSummary(resSummary);
        setStep('preview');
      } else {
        setStep('mapping');
      }
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err?.message || (isAr ? 'حدث خطأ أثناء قراءة ملف Excel' : 'Erreur lors de la lecture du fichier Excel'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleSheetChange = (sheetName: string) => {
    setSelectedSheet(sheetName);
    const sheetData = sheetsRawData[sheetName];
    if (sheetData) {
      setHeaders(sheetData.headers);
      const autoMap = autoDetectFieldMapping(sheetData.headers);
      setMapping(autoMap);
    }
  };

  const handleProceedToPreview = () => {
    if (!mapping.buildingCode || !mapping.apartmentNumber || !mapping.ownerName) {
      setErrorMessage(
        isAr 
          ? 'يرجى تحديد الأعمدة الإلزامية: رمز العمارة، رقم الشقة، واسم المالك.' 
          : 'Veuillez mapper les colonnes obligatoires : Bâtiment, N° Appartement et Nom Propriétaire.'
      );
      return;
    }
    setErrorMessage(null);
    const sheetData = sheetsRawData[selectedSheet];
    if (!sheetData) return;

    const resSummary = processImportData(
      sheetData.headers,
      sheetData.rows,
      mapping,
      apartments,
      buildings
    );
    setSummary(resSummary);
    setStep('preview');
  };

  const handleExecuteImport = () => {
    if (!summary || summary.validRows === 0) {
      setErrorMessage(isAr ? 'لا توجد بيانات صالحة للاستيراد' : 'Aucune donnée valide à importer');
      return;
    }

    setIsLoading(true);
    try {
      const validRowsToImport = summary.parsedData
        .filter(r => r.matchType === 'existing' || (r.matchType === 'new' && createMissingApartments))
        .map(r => ({
          buildingCode: r.buildingCode,
          apartmentNumber: r.apartmentNumber,
          ownerName: r.ownerName,
          ownerPhone: r.ownerPhone,
          ownerCin: r.ownerCin,
          ownerEmail: r.ownerEmail,
          addressOrNotes: r.addressOrNotes,
          floor: r.floor,
          monthlyFee: r.monthlyFee,
          status: r.status,
          residentName: r.residentName,
          residentPhone: r.residentPhone
        }));

      const results = importOwnersFromExcelData(validRowsToImport, {
        updateApartments,
        syncResidents,
        createMissingApartments,
        overwriteExistingPhones
      });

      setResultStats(results);
      setStep('success');
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err?.message || (isAr ? 'فشل تنفيذ الاستيراد' : 'Échec de l\'importation'));
    } finally {
      setIsLoading(false);
    }
  };

  const filteredPreviewData = summary?.parsedData.filter(r => {
    const matchesFilter = 
      previewFilter === 'ALL' || 
      r.matchType === previewFilter;

    const searchLower = previewSearch.toLowerCase();
    const matchesSearch = 
      !previewSearch ||
      r.ownerName.toLowerCase().includes(searchLower) ||
      r.buildingCode.toLowerCase().includes(searchLower) ||
      r.apartmentNumber.toLowerCase().includes(searchLower) ||
      r.ownerPhone.toLowerCase().includes(searchLower) ||
      r.ownerCin.toLowerCase().includes(searchLower) ||
      r.addressOrNotes.toLowerCase().includes(searchLower);

    return matchesFilter && matchesSearch;
  }) || [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto animate-in fade-in duration-200">
      <div 
        className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden my-6 max-h-[92vh]"
        dir={isAr ? 'rtl' : 'ltr'}
      >
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-emerald-50 via-teal-50 to-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-md shadow-emerald-600/20">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                {isAr ? 'استيراد وإدخال بيانات الملاك عبر Excel' : 'Importation des données propriétaires via Excel'}
                <span className="px-2 py-0.5 text-[11px] font-semibold bg-emerald-100 text-emerald-800 rounded-full border border-emerald-200">
                  .xlsx / .csv
                </span>
              </h2>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                {isAr 
                  ? 'إدخال جماعي وتحديث لأسماء الملاك، أرقام الهواتف، بطاقات التعريف CIN، والعناوين الشخصية'
                  : 'Mise à jour groupée des noms, téléphones, CIN et adresses personnelles des copropriétaires'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Indicator */}
        <div className="px-6 py-3 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-xs font-semibold text-slate-600">
          <div className="flex items-center gap-2 sm:gap-4 flex-wrap">
            <span className={`flex items-center gap-1.5 px-3 py-1 rounded-full ${step === 'upload' ? 'bg-emerald-600 text-white shadow-xs' : 'bg-slate-200 text-slate-600'}`}>
              <span>1</span> {isAr ? 'اختيار الملف أو النموذج' : 'Fichier / Modèle'}
            </span>
            <span className={`flex items-center gap-1.5 px-3 py-1 rounded-full ${step === 'mapping' ? 'bg-emerald-600 text-white shadow-xs' : 'bg-slate-200 text-slate-600'}`}>
              <span>2</span> {isAr ? 'مطابقة الأعمدة' : 'Mappage'}
            </span>
            <span className={`flex items-center gap-1.5 px-3 py-1 rounded-full ${step === 'preview' ? 'bg-emerald-600 text-white shadow-xs' : 'bg-slate-200 text-slate-600'}`}>
              <span>3</span> {isAr ? 'المعاينة والتأكيد' : 'Aperçu'}
            </span>
            <span className={`flex items-center gap-1.5 px-3 py-1 rounded-full ${step === 'success' ? 'bg-emerald-600 text-white shadow-xs' : 'bg-slate-200 text-slate-600'}`}>
              <span>4</span> {isAr ? 'اكتمال التحديث' : 'Terminé'}
            </span>
          </div>

          {file && step !== 'success' && (
            <button
              onClick={handleReset}
              className="text-xs text-slate-500 hover:text-slate-800 underline cursor-pointer"
            >
              {isAr ? 'تغيير الملف' : 'Changer fichier'}
            </button>
          )}
        </div>

        {/* Error Alert */}
        {errorMessage && (
          <div className="mx-6 mt-4 p-3.5 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">

          {/* STEP 1: UPLOAD & TEMPLATE DOWNLOAD */}
          {step === 'upload' && (
            <div className="space-y-6">
              {/* Template Download Section */}
              <div className="p-5 bg-gradient-to-br from-emerald-50/70 to-teal-50/70 border border-emerald-200 rounded-2xl">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <h3 className="text-sm font-bold text-emerald-950 flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-emerald-600" />
                      {isAr ? 'هل تحتاج إلى نموذج Excel جاهز ومنظم؟' : 'Besoin d\'un modèle Excel prêt à l\'emploi ?'}
                    </h3>
                    <p className="text-xs text-emerald-800 font-medium leading-relaxed">
                      {isAr 
                        ? 'يمكنك تحميل ملف Excel جاهز يحتوي على قائمة كافة الشقق (جميع الشقق) أو نموذج فارغ لإدخال الأسماء والعناوين والهواتف ثم رفعه مباشرة.'
                        : 'Téléchargez un modèle Excel pré-rempli avec les tous les lots ou un modèle vierge pour saisir vos données.'}
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => generateOwnersExcelTemplate(apartments, buildings, lang, true)}
                      className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-2 transition-all cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                      <span>{isAr ? 'تحميل جدول كافة شقق الإقامة (جميع الشقق)' : 'Télécharger modèle complet (tous les lots)'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => generateOwnersExcelTemplate(apartments, buildings, lang, false)}
                      className="px-3.5 py-2.5 bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300 font-bold text-xs rounded-xl transition-all cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                      <span>{isAr ? 'نموذج فارغ بأمثلة' : 'Modèle vierge avec exemples'}</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Drag and Drop Zone */}
              <div>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      handleFileProcess(e.target.files[0]);
                    }
                  }}
                  accept=".xlsx, .xls, .csv"
                  className="hidden"
                />

                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsDragging(true);
                  }}
                  onDragLeave={() => setIsDragging(false)}
                  onDrop={(e) => {
                    e.preventDefault();
                    setIsDragging(false);
                    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                      handleFileProcess(e.dataTransfer.files[0]);
                    }
                  }}
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-3xl p-10 text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-3 ${
                    isDragging 
                      ? 'border-emerald-500 bg-emerald-50/80 ring-4 ring-emerald-500/10 scale-[1.01]' 
                      : 'border-slate-300 hover:border-emerald-500 hover:bg-slate-50/80 bg-white'
                  }`}
                >
                  <div className="w-16 h-16 rounded-2xl bg-emerald-100/70 text-emerald-700 flex items-center justify-center shadow-xs">
                    {isLoading ? (
                      <RefreshCw className="w-8 h-8 animate-spin text-emerald-600" />
                    ) : (
                      <Upload className="w-8 h-8 text-emerald-600" />
                    )}
                  </div>

                  <div>
                    <p className="text-sm font-bold text-slate-800">
                      {isAr ? 'اضغط لاختيار ملف Excel أو قم بسحبه وإسقاطه هنا' : 'Cliquez pour choisir un fichier Excel ou glissez-déposez le ici'}
                    </p>
                    <p className="text-xs text-slate-400 font-medium mt-1">
                      {isAr ? 'يدعم صيغ Microsoft Excel (.xlsx, .xls) وجداول البيانات (.csv)' : 'Prend en charge les formats .xlsx, .xls et .csv'}
                    </p>
                  </div>

                  <div className="mt-2 flex items-center gap-2 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{isAr ? 'التعرف التلقائي الذكي على أسماء الأعمدة باللغتين العربية والفرنسية' : 'Détection automatique intelligente des colonnes en Arabe et Français'}</span>
                  </div>
                </div>
              </div>

              {/* Guidance Box */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-xs text-slate-600 space-y-2">
                <div className="font-bold text-slate-800 flex items-center gap-1.5">
                  <HelpCircle className="w-4 h-4 text-slate-500" />
                  <span>{isAr ? 'نصائح لضمان استيراد دقيق وسريع:' : 'Conseils pour un import sans erreur :'}</span>
                </div>
                <ul className="list-disc list-inside space-y-1 text-slate-500 pr-2 leading-relaxed">
                  <li>{isAr ? 'الحقول الضرورية الأساسية: رمز العمارة (مثل )، رقم الشقة (01 إلى 16)، واسم المالك.' : 'Champs obligatoires : Code bâtiment (ex: ), N° appartement (01 à 16) et nom propriétaire.'}</li>
                  <li>{isAr ? 'يمكنك إدخال العنوان الشخصي، رقم الهاتف، رقم بطاقة التعريف CIN، والبريد الإلكتروني.' : 'Vous pouvez inclure l\'adresse personnelle, le téléphone, le CIN et l\'email.'}</li>
                  <li>{isAr ? 'سيقوم التطبيق تلقائياً بتحديث سجل الشقق وسجل السكان ومطابقة الملاك مع شققهم.' : 'L\'application synchronisera automatiquement les appartements et le registre des résidents.'}</li>
                </ul>
              </div>
            </div>
          )}

          {/* STEP 2: COLUMN MAPPING */}
          {step === 'mapping' && (
            <div className="space-y-5">
              <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-xs text-amber-900 flex items-start gap-3">
                <AlertCircle className="w-5 h-5 shrink-0 text-amber-600 mt-0.5" />
                <div>
                  <p className="font-bold">{isAr ? 'يرجى مراجعة مطابقة أعمدة ملف Excel:' : 'Veuillez vérifier la correspondance des colonnes :'}</p>
                  <p className="mt-0.5 text-amber-800">
                    {isAr 
                      ? 'حدد العمود المقابل لكل معلومة من ملفك لضمان قراءة وتوزيع البيانات في أماكنها الصحيحة.' 
                      : 'Associez chaque champ à la colonne correspondante de votre fichier Excel.'}
                  </p>
                </div>
              </div>

              {/* Sheet selector if multiple */}
              {sheetNames.length > 1 && (
                <div className="flex items-center gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                  <span className="text-xs font-bold text-slate-700">{isAr ? 'ورقة العمل (Sheet):' : 'Feuille (Sheet) :'}</span>
                  <select
                    value={selectedSheet}
                    onChange={(e) => handleSheetChange(e.target.value)}
                    className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  >
                    {sheetNames.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              )}

              {/* Mapping Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Required Fields */}
                <div className="p-4 bg-emerald-50/50 border border-emerald-200 rounded-2xl space-y-3">
                  <h4 className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    {isAr ? 'الحقول الأساسية (إلزامية)' : 'Champs Obligatoires'}
                  </h4>

                  {/* Building Code */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 flex items-center justify-between">
                      <span>{isAr ? 'رمز العمارة *' : 'Code Bâtiment *'}</span>
                      <span className="text-[10px] text-slate-400 font-normal">Ex: </span>
                    </label>
                    <select
                      value={mapping.buildingCode}
                      onChange={(e) => setMapping({ ...mapping, buildingCode: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-800 focus:border-emerald-500 focus:outline-hidden"
                    >
                      <option value="">{isAr ? '-- اختر عمود العمارة --' : '-- Choisir colonne --'}</option>
                      {headers.map(h => <option key={h} value={h}>{h}</option>)}
                    </select>
                  </div>

                  {/* Apartment Number */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 flex items-center justify-between">
                      <span>{isAr ? 'رقم الشقة *' : 'N° Appartement *'}</span>
                      <span className="text-[10px] text-slate-400 font-normal">Ex: 01, 02...</span>
                    </label>
                    <select
                      value={mapping.apartmentNumber}
                      onChange={(e) => setMapping({ ...mapping, apartmentNumber: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-800 focus:border-emerald-500 focus:outline-hidden"
                    >
                      <option value="">{isAr ? '-- اختر عمود رقم الشقة --' : '-- Choisir colonne --'}</option>
                      {headers.map(h => <option key={h} value={h}>{h}</option>)}
                    </select>
                  </div>

                  {/* Owner Name */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 flex items-center justify-between">
                      <span>{isAr ? 'اسم المالك الكامل *' : 'Nom Complet du Propriétaire *'}</span>
                      <span className="text-[10px] text-slate-400 font-normal">Ex: محمد العلمي</span>
                    </label>
                    <select
                      value={mapping.ownerName}
                      onChange={(e) => setMapping({ ...mapping, ownerName: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-800 focus:border-emerald-500 focus:outline-hidden"
                    >
                      <option value="">{isAr ? '-- اختر عمود اسم المالك --' : '-- Choisir colonne --'}</option>
                      {headers.map(h => <option key={h} value={h}>{h}</option>)}
                    </select>
                  </div>
                </div>

                {/* Optional Details */}
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                  <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    <Phone className="w-4 h-4 text-slate-500" />
                    {isAr ? 'بيانات الاتصال والعنوان (اختيارية)' : 'Coordonnées & Informations'}
                  </h4>

                  {/* Owner Phone */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700">{isAr ? 'رقم الهاتف' : 'Téléphone'}</label>
                    <select
                      value={mapping.ownerPhone}
                      onChange={(e) => setMapping({ ...mapping, ownerPhone: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-800 focus:border-emerald-500 focus:outline-hidden"
                    >
                      <option value="">{isAr ? '-- غير محدد / اختياري --' : '-- Non défini --'}</option>
                      {headers.map(h => <option key={h} value={h}>{h}</option>)}
                    </select>
                  </div>

                  {/* CIN */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700">{isAr ? 'بطاقة التعريف الوطنية (CIN)' : 'N° CIN'}</label>
                    <select
                      value={mapping.ownerCin}
                      onChange={(e) => setMapping({ ...mapping, ownerCin: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-800 focus:border-emerald-500 focus:outline-hidden"
                    >
                      <option value="">{isAr ? '-- غير محدد / اختياري --' : '-- Non défini --'}</option>
                      {headers.map(h => <option key={h} value={h}>{h}</option>)}
                    </select>
                  </div>

                  {/* Address or Notes */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700">{isAr ? 'العنوان الشخصي / الملاحظات' : 'Adresse / Notes'}</label>
                    <select
                      value={mapping.addressOrNotes}
                      onChange={(e) => setMapping({ ...mapping, addressOrNotes: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-800 focus:border-emerald-500 focus:outline-hidden"
                    >
                      <option value="">{isAr ? '-- غير محدد / اختياري --' : '-- Non défini --'}</option>
                      {headers.map(h => <option key={h} value={h}>{h}</option>)}
                    </select>
                  </div>

                  {/* Email */}
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700">{isAr ? 'البريد الإلكتروني' : 'Email'}</label>
                    <select
                      value={mapping.ownerEmail}
                      onChange={(e) => setMapping({ ...mapping, ownerEmail: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium text-slate-800 focus:border-emerald-500 focus:outline-hidden"
                    >
                      <option value="">{isAr ? '-- غير محدد / اختياري --' : '-- Non défini --'}</option>
                      {headers.map(h => <option key={h} value={h}>{h}</option>)}
                    </select>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: PREVIEW & VALIDATION */}
          {step === 'preview' && summary && (
            <div className="space-y-5">
              {/* Top Stats Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-center">
                  <p className="text-xs font-semibold text-slate-500">{isAr ? 'إجمالي الأسطر' : 'Lignes trouvées'}</p>
                  <p className="text-lg font-bold text-slate-900 mt-1">{summary.totalRows}</p>
                </div>
                <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl text-center">
                  <p className="text-xs font-semibold text-emerald-700">{isAr ? 'مطابقة لشقق موجودة' : 'Lots correspondants'}</p>
                  <p className="text-lg font-bold text-emerald-900 mt-1">{summary.matchingApartments}</p>
                </div>
                <div className="p-3.5 bg-blue-50 border border-blue-200 rounded-2xl text-center">
                  <p className="text-xs font-semibold text-blue-700">{isAr ? 'شقق جديدة ستضاف' : 'Nouveaux lots'}</p>
                  <p className="text-lg font-bold text-blue-900 mt-1">{summary.newApartments}</p>
                </div>
                <div className="p-3.5 bg-red-50 border border-red-200 rounded-2xl text-center">
                  <p className="text-xs font-semibold text-red-700">{isAr ? 'أسطر بها أخطاء' : 'Lignes avec erreurs'}</p>
                  <p className="text-lg font-bold text-red-900 mt-1">{summary.invalidRows}</p>
                </div>
              </div>

              {/* Sync Options Checkboxes */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2.5">
                <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-emerald-600" />
                  {isAr ? 'خيارات تطبيق وتحديث البيانات:' : 'Options d\'application :'}
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <label className="flex items-center gap-2 cursor-pointer text-slate-700 font-medium">
                    <input
                      type="checkbox"
                      checked={updateApartments}
                      onChange={(e) => setUpdateApartments(e.target.checked)}
                      className="rounded-md border-slate-300 text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
                    />
                    <span>{isAr ? 'تحديث أسماء الملاك وبياناتهم في سجل الشقق' : 'Mettre à jour le registre des appartements'}</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-slate-700 font-medium">
                    <input
                      type="checkbox"
                      checked={syncResidents}
                      onChange={(e) => setSyncResidents(e.target.checked)}
                      className="rounded-md border-slate-300 text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
                    />
                    <span>{isAr ? 'مزامنة دليل السكان (إضافة وتحديث الملاك)' : 'Synchroniser le répertoire des résidents'}</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-slate-700 font-medium">
                    <input
                      type="checkbox"
                      checked={createMissingApartments}
                      onChange={(e) => setCreateMissingApartments(e.target.checked)}
                      className="rounded-md border-slate-300 text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
                    />
                    <span>{isAr ? 'إنشاء الشقق الجديدة تلقائياً إن لم تكن مسجلة' : 'Créer automatiquement les lots non existants'}</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-slate-700 font-medium">
                    <input
                      type="checkbox"
                      checked={overwriteExistingPhones}
                      onChange={(e) => setOverwriteExistingPhones(e.target.checked)}
                      className="rounded-md border-slate-300 text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
                    />
                    <span>{isAr ? 'تحيين أرقام الهواتف والعناوين الشخصية' : 'Mettre à jour les téléphones et adresses'}</span>
                  </label>
                </div>
              </div>

              {/* Filter and Search Bar for preview */}
              <div className="flex flex-col sm:flex-row gap-2 items-center justify-between">
                <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={() => setPreviewFilter('ALL')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      previewFilter === 'ALL' ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {isAr ? 'الكل' : 'Tous'} ({summary.totalRows})
                  </button>
                  <button
                    type="button"
                    onClick={() => setPreviewFilter('existing')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      previewFilter === 'existing' ? 'bg-emerald-600 text-white' : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                    }`}
                  >
                    {isAr ? 'المتطابقة' : 'Valides'} ({summary.matchingApartments})
                  </button>
                  {summary.newApartments > 0 && (
                    <button
                      type="button"
                      onClick={() => setPreviewFilter('new')}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        previewFilter === 'new' ? 'bg-blue-600 text-white' : 'bg-blue-50 text-blue-700 hover:bg-blue-100'
                      }`}
                    >
                      {isAr ? 'جديدة' : 'Nouveaux'} ({summary.newApartments})
                    </button>
                  )}
                  {summary.invalidRows > 0 && (
                    <button
                      type="button"
                      onClick={() => setPreviewFilter('invalid')}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        previewFilter === 'invalid' ? 'bg-red-600 text-white' : 'bg-red-50 text-red-700 hover:bg-red-100'
                      }`}
                    >
                      {isAr ? 'أخطاء' : 'Erreurs'} ({summary.invalidRows})
                    </button>
                  )}
                </div>

                <input
                  type="text"
                  value={previewSearch}
                  onChange={(e) => setPreviewSearch(e.target.value)}
                  placeholder={isAr ? 'بحث سريع في المعاينة...' : 'Recherche dans l\'aperçu...'}
                  className="w-full sm:w-64 px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:bg-white focus:border-emerald-500"
                />
              </div>

              {/* Data Table */}
              <div className="border border-slate-200 rounded-2xl overflow-hidden max-h-72 overflow-y-auto overflow-x-auto">
                <table className="w-full whitespace-nowrap text-start text-xs border-collapse">
                  <thead className="bg-slate-100/90 text-slate-700 sticky top-0 font-bold border-b border-slate-200 z-10">
                    <tr>
                      <th className="p-2.5 text-start">{isAr ? 'السطر' : 'N°'}</th>
                      <th className="p-2.5 text-start">{isAr ? 'العمارة' : 'Bâtiment'}</th>
                      <th className="p-2.5 text-start">{isAr ? 'الشقة' : 'Apt'}</th>
                      <th className="p-2.5 text-start">{isAr ? 'اسم المالك' : 'Propriétaire'}</th>
                      <th className="p-2.5 text-start">{isAr ? 'الهاتف' : 'Téléphone'}</th>
                      <th className="p-2.5 text-start">{isAr ? 'CIN' : 'CIN'}</th>
                      <th className="p-2.5 text-start">{isAr ? 'العنوان الشخصي / ملاحظات' : 'Adresse / Notes'}</th>
                      <th className="p-2.5 text-start">{isAr ? 'الحالة' : 'État'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 bg-white">
                    {filteredPreviewData.map((row, idx) => (
                      <tr 
                        key={idx} 
                        className={`hover:bg-slate-50/80 transition-colors ${
                          row.matchType === 'invalid' ? 'bg-red-50/40' : row.matchType === 'new' ? 'bg-blue-50/30' : ''
                        }`}
                      >
                        <td className="p-2.5 font-mono text-slate-400">{row.rowNumber}</td>
                        <td className="p-2.5 font-bold text-slate-800">{row.buildingCode || '-'}</td>
                        <td className="p-2.5 font-bold text-emerald-800">{row.apartmentNumber || '-'}</td>
                        <td className="p-2.5 font-semibold text-slate-900">{row.ownerName || '-'}</td>
                        <td className="p-2.5 text-slate-600 font-mono" dir="ltr">{row.ownerPhone || '-'}</td>
                        <td className="p-2.5 font-mono text-slate-700 font-bold">{row.ownerCin || '-'}</td>
                        <td className="p-2.5 text-slate-600 truncate max-w-[140px]">{row.addressOrNotes || '-'}</td>
                        <td className="p-2.5">
                          {row.matchType === 'existing' && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                              {isAr ? 'تحديث شقة' : 'Mise à jour'}
                            </span>
                          )}
                          {row.matchType === 'new' && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-200">
                              {isAr ? 'شقة جديدة' : 'Nouveau lot'}
                            </span>
                          )}
                          {row.matchType === 'invalid' && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-100 text-red-800 border border-red-200" title={row.validationErrors.join(', ')}>
                              {isAr ? 'بيانات ناقصة' : 'Invalide'}
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                    {filteredPreviewData.length === 0 && (
                      <tr>
                        <td colSpan={8} className="p-8 text-center text-slate-400 font-medium">
                          {isAr ? 'لا توجد سجلات تطابق الفلتر' : 'Aucun enregistrement ne correspond'}
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* STEP 4: SUCCESS SUMMARY */}
          {step === 'success' && resultStats && (
            <div className="py-6 text-center space-y-6 animate-in zoom-in-95 duration-300">
              <div className="w-20 h-20 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-md shadow-emerald-500/10">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  {isAr ? 'تم استيراد وتحديث بيانات الملاك بنجاح!' : 'Données propriétaires importées avec succès !'}
                </h3>
                <p className="text-xs text-slate-500 font-medium mt-1">
                  {isAr 
                    ? 'تم تحيين سجل الشقق ودليل السكان، وتحديث أرقام الهواتف والـ CIN والعناوين وحفظها بالكامل.'
                    : 'Le registre des copropriétaires a été synchronisé et sauvegardé avec succès.'}
                </p>
              </div>

              {/* Stats overview */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 max-w-lg mx-auto">
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-center">
                  <p className="text-xs font-semibold text-emerald-700">{isAr ? 'شقق تم تحديث ملاكها' : 'Appartements mis à jour'}</p>
                  <p className="text-xl font-bold text-emerald-900 mt-1">{resultStats.apartmentsUpdated}</p>
                </div>
                <div className="p-4 bg-teal-50 border border-teal-200 rounded-2xl text-center">
                  <p className="text-xs font-semibold text-teal-700">{isAr ? 'سجلات سكان تمت مزامنتها' : 'Résidents synchronisés'}</p>
                  <p className="text-xl font-bold text-teal-900 mt-1">{resultStats.residentsUpdated}</p>
                </div>
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-2xl text-center">
                  <p className="text-xs font-semibold text-blue-700">{isAr ? 'شقق جديدة مضافة' : 'Nouveaux lots créés'}</p>
                  <p className="text-xl font-bold text-blue-900 mt-1">{resultStats.apartmentsCreated}</p>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
          {step === 'upload' && (
            <div className="flex items-center justify-between w-full">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 rounded-xl transition-all cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Annuler'}
              </button>
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-2 transition-all cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>{isAr ? 'اختيار ملف من الجهاز' : 'Choisir un fichier'}</span>
              </button>
            </div>
          )}

          {step === 'mapping' && (
            <div className="flex items-center justify-between w-full">
              <button
                type="button"
                onClick={() => setStep('upload')}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 rounded-xl flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <ArrowRight className="w-4 h-4 rtl:rotate-180" />
                <span>{isAr ? 'رجوع' : 'Retour'}</span>
              </button>
              <button
                type="button"
                onClick={handleProceedToPreview}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center gap-2 transition-all cursor-pointer"
              >
                <span>{isAr ? 'المتابعة إلى المعاينة' : 'Suivant : Aperçu'}</span>
                <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
              </button>
            </div>
          )}

          {step === 'preview' && (
            <div className="flex items-center justify-between w-full">
              <button
                type="button"
                onClick={() => setStep('mapping')}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 rounded-xl flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <ArrowRight className="w-4 h-4 rtl:rotate-180" />
                <span>{isAr ? 'تعديل مطابقة الأعمدة' : 'Modifier mappage'}</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 rounded-xl transition-all cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Annuler'}
                </button>
                <button
                  type="button"
                  onClick={handleExecuteImport}
                  disabled={isLoading || !summary || summary.validRows === 0}
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-md shadow-emerald-600/20 flex items-center gap-2 transition-all cursor-pointer"
                >
                  {isLoading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4" />
                  )}
                  <span>{isAr ? `تأكيد واستيراد (${summary?.validRows || 0}) مالك` : `Confirmer l'importation (${summary?.validRows || 0})`}</span>
                </button>
              </div>
            </div>
          )}

          {step === 'success' && (
            <div className="flex items-center justify-end w-full">
              <button
                type="button"
                onClick={onClose}
                className="px-6 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer"
              >
                {isAr ? 'إغلاق وعرض البيانات المحدثة' : 'Fermer et voir les résultats'}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
