import { RES } from '../config/residence';
import React, { useState, useMemo, useEffect } from 'react';
import { 
  X, 
  Printer, 
  Download, 
  Calendar, 
  Building2, 
  TrendingUp, 
  TrendingDown, 
  Wallet, 
  Percent, 
  FileText, 
  Receipt, 
  CheckCircle2, 
  AlertCircle, 
  PieChart as PieIcon, 
  BarChart3, 
  Layers, 
  ShieldCheck, 
  Sparkles,
  Info,
  CreditCard,
  Building,
  Check,
  ChevronDown,
  ChevronUp,
  Table as TableIcon,
  FileSpreadsheet,
  Activity,
  ArrowUpRight,
  Users,
  UserCheck,
  Briefcase,
  CalendarDays,
  Edit3,
  Clock,
  Coins,
  Shield,
  Award,
  RotateCcw,
  Plus,
  Zap,
  Droplets,
  Hammer,
  Wrench,
  Scale,
  Gavel,
  Package,
  ArrowRightLeft,
  ArrowRight,
  ArrowLeft,
  History
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid, 
  PieChart, 
  Pie, 
  Cell, 
  Legend,
  AreaChart,
  Area,
  Line,
  ComposedChart
} from 'recharts';
import { useApp } from '../context/AppContext';
import { exportMonthlyFinancialReportToPdf, exportFinancialReportToCSV } from '../utils/monthlyPdfReportUtils';
import { 
  getCarriedForwardBalance, 
  getMonthlyCarryoverChain, 
  getPreviousMonthKey, 
  getNextMonthKey, 
  MonthlyCarryoverItem,
  ARABIC_MONTH_NAMES,
  FRENCH_MONTH_NAMES, splitExpensePillars } from '../utils/monthlyFinanceUtils';
import { Payment, Expense, ExpenseCategory, PaymentMethod } from '../types';

export interface FinancialReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'monthly' | 'annual' | 'custom_period';
  initialYear?: string;
  initialMonth?: string;
  initialStartYear?: string;
  initialStartMonth?: string;
  initialEndYear?: string;
  initialEndMonth?: string;
}

const MONTHS_LIST = [
  { value: '01', labelAr: 'يناير', labelFr: 'Janvier' },
  { value: '02', labelAr: 'فبراير', labelFr: 'Février' },
  { value: '03', labelAr: 'مارس', labelFr: 'Mars' },
  { value: '04', labelAr: 'أبريل', labelFr: 'Avril' },
  { value: '05', labelAr: 'مايو', labelFr: 'Mai' },
  { value: '06', labelAr: 'يونيو', labelFr: 'Juin' },
  { value: '07', labelAr: 'يوليوز', labelFr: 'Juillet' },
  { value: '08', labelAr: 'غشت / أغسطس', labelFr: 'Août' },
  { value: '09', labelAr: 'شتنبر / سبتمبر', labelFr: 'Septembre' },
  { value: '10', labelAr: 'أكتوبر', labelFr: 'Octobre' },
  { value: '11', labelAr: 'نونبر / نوفمبر', labelFr: 'Novembre' },
  { value: '12', labelAr: 'دجنبر / ديسمبر', labelFr: 'Décembre' },
];

const PIE_COLORS = ['#059669', '#0284c7', '#d97706', '#dc2626', '#7c3aed', '#db2777', '#4b5563', '#0d9488', '#f97316'];

export const MonthlyFinancialReportModal: React.FC<FinancialReportModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'monthly',
  initialYear,
  initialMonth,
  initialStartYear,
  initialStartMonth,
  initialEndYear,
  initialEndMonth
}) => {
  const { 
    buildings, apartments, payments, expenses, employees, lang, currentUser,
    manualMonthlyRecords, upsertManualMonthlyRecord, deleteManualMonthlyRecord, showToast
  } = useApp();
  const isAr = lang === 'ar';

  const today = new Date();
  const currentYearStr = initialYear || String(today.getFullYear());
  const currentMonthStr = initialMonth || String(today.getMonth() + 1).padStart(2, '0');

  // Mode: 'monthly' (التقرير المالي الشهري) | 'annual' (التقرير المالي السنوي) | 'custom_period' (تقرير موحد لفترة مخصصة / دمج سنتين)
  const [reportMode, setReportMode] = useState<'monthly' | 'annual' | 'custom_period'>(initialMode);
  const [selectedYear, setSelectedYear] = useState<string>(currentYearStr);
  const [selectedMonth, setSelectedMonth] = useState<string>(currentMonthStr);
  const [selectedBuilding, setSelectedBuilding] = useState<string>('ALL');

  // Custom period interval state - Default to 2 full years (2025-01 to 2026-12) as requested for 2-year balance sheet
  const [startYear, setStartYear] = useState<string>(initialStartYear || '2025');
  const [startMonth, setStartMonth] = useState<string>(initialStartMonth || '01');
  const [endYear, setEndYear] = useState<string>(initialEndYear || '2026');
  const [endMonth, setEndMonth] = useState<string>(initialEndMonth || '12');

  // Manual override for starting carryover balance in custom period mode
  const [customOpeningOverride, setCustomOpeningOverride] = useState<string>(() => {
    try {
      return localStorage.getItem('syndico_custom_period_opening') || '';
    } catch {
      return '';
    }
  });
  const [isEditingCustomOpening, setIsEditingCustomOpening] = useState<boolean>(false);
  const [tempCustomOpening, setTempCustomOpening] = useState<string>('');

  // =========================================================================
  // UN SEUL BILAN DE 2ANS (FAIT MANUEL) - DEDICATED MANUAL DATA STORAGE & STATE
  // 1. Report • 2. Recettes • 3. Salaires • 4. Syndic • 5. Avocat • 6. Huissier • 7. Droguerie
  // Auto: 8. Total Disponible • 9. Dépenses • 10. Solde Restant
  // =========================================================================
  const getBilanManualStorageKey = (sY: string, sM: string, eY: string, eM: string) => 
    `syndico_bilan_manual_${sY}_${sM}_${eY}_${eM}`;

  const [manualBilan, setManualBilan] = useState<{
    isManualActive: boolean;
    report: number;
    recettes: number;
    salaires: number;
    syndic: number;
    avocat: number;
    huissier: number;
    droguerie: number;
    notes?: string;
    savedAt?: string;
  }>(() => {
    try {
      const sY = initialStartYear || '2025';
      const sM = initialStartMonth || '01';
      const eY = initialEndYear || '2026';
      const eM = initialEndMonth || '12';
      const key = `syndico_bilan_manual_${sY}_${sM}_${eY}_${eM}`;
      const saved = localStorage.getItem(key) || localStorage.getItem('syndico_bilan_2ans_manual_data');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return {
      isManualActive: false,
      report: 0,
      recettes: 0,
      salaires: 0,
      syndic: 0,
      avocat: 0,
      huissier: 0,
      droguerie: 0
    };
  });

  const [isManualPanelOpen, setIsManualPanelOpen] = useState<boolean>(true);
  const [tempManualReport, setTempManualReport] = useState<string>(String(manualBilan.report || 0));
  const [tempManualRecettes, setTempManualRecettes] = useState<string>(String(manualBilan.recettes || 0));
  const [tempManualSalaires, setTempManualSalaires] = useState<string>(String(manualBilan.salaires || 0));
  const [tempManualSyndic, setTempManualSyndic] = useState<string>(String(manualBilan.syndic || 0));
  const [tempManualAvocat, setTempManualAvocat] = useState<string>(String(manualBilan.avocat || 0));
  const [tempManualHuissier, setTempManualHuissier] = useState<string>(String(manualBilan.huissier || 0));
  const [tempManualDroguerie, setTempManualDroguerie] = useState<string>(String(manualBilan.droguerie || 0));

  // Sync manual state when start/end dates change
  useEffect(() => {
    try {
      const key = getBilanManualStorageKey(startYear, startMonth, endYear, endMonth);
      const saved = localStorage.getItem(key);
      if (saved) {
        const parsed = JSON.parse(saved);
        setManualBilan(parsed);
        setTempManualReport(String(parsed.report ?? 0));
        setTempManualRecettes(String(parsed.recettes ?? 0));
        setTempManualSalaires(String(parsed.salaires ?? 0));
        setTempManualSyndic(String(parsed.syndic ?? 0));
        setTempManualAvocat(String(parsed.avocat ?? 0));
        setTempManualHuissier(String(parsed.huissier ?? 0));
        setTempManualDroguerie(String(parsed.droguerie ?? 0));
      } else {
        // No saved manual data for this specific period; default to auto calculation
        setManualBilan(prev => ({ ...prev, isManualActive: false }));
      }
    } catch (e) {
      console.error(e);
    }
  }, [startYear, startMonth, endYear, endMonth]);

  useEffect(() => {
    if (isOpen) {
      if (initialMode) setReportMode(initialMode);
      if (initialYear) setSelectedYear(initialYear);
      if (initialMonth) setSelectedMonth(initialMonth);
      if (initialStartYear) setStartYear(initialStartYear);
      if (initialStartMonth) setStartMonth(initialStartMonth);
      if (initialEndYear) setEndYear(initialEndYear);
      if (initialEndMonth) setEndMonth(initialEndMonth);
    }
  }, [isOpen, initialMode, initialYear, initialMonth, initialStartYear, initialStartMonth, initialEndYear, initialEndMonth]);

  // Visual toggles
  const [showCharts, setShowCharts] = useState<boolean>(true);
  const [showSyndicFees, setShowSyndicFees] = useState<boolean>(true);
  const [showExpensesDetail, setShowExpensesDetail] = useState<boolean>(true);
  const [showCarryoverTable, setShowCarryoverTable] = useState<boolean>(true);

  // Syndic Management Fee (Editable & Persisted - 4,000 DH/month as requested)
  const [syndicMonthlyFee, setSyndicMonthlyFee] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('syndico_syndic_monthly_fee');
      if (!saved || saved === '3500' || saved === '2000') {
        localStorage.setItem('syndico_syndic_monthly_fee', '4000');
        return 4000;
      }
      return Number(saved) || 4000;
    } catch {
      return 4000;
    }
  });
  const [isEditingSyndicFee, setIsEditingSyndicFee] = useState<boolean>(false);
  const [tempSyndicFee, setTempSyndicFee] = useState<string>(String(syndicMonthlyFee));

  const handleSaveSyndicFee = () => {
    const val = Number(tempSyndicFee);
    if (!isNaN(val) && val >= 0) {
      setSyndicMonthlyFee(val);
      try {
        localStorage.setItem('syndico_syndic_monthly_fee', String(val));
      } catch (e) {
        console.error(e);
      }
    }
    setIsEditingSyndicFee(false);
  };

  // Default residence workers if none configured in employees
  const defaultResidenceWorkers = useMemo(() => [] as { id: string; name: string; role: string; baseSalary: number }[], [isAr]);

  // Active workers list
  const activeWorkers = useMemo(() => {
    if (employees && employees.length > 0) {
      return employees.map((emp, idx) => ({
        id: emp.id || `emp-${idx}`,
        name: emp.name,
        role: emp.role === 'security' ? (isAr ? 'حراسة وأمن' : 'Sécurité') :
              emp.role === 'cleaning' ? (isAr ? 'نظافة ومرافق' : 'Nettoyage') :
              emp.role === 'gardener' ? (isAr ? 'بستنة ومساحات خضراء' : 'Jardinage') :
              emp.role === 'technician' ? (isAr ? 'تقني وصيانة' : 'Maintenance') :
              emp.role === 'supervisor' ? (isAr ? 'مشرف ميداني' : 'Superviseur') :
              (isAr ? 'إدارة ومكتب' : 'Administration'),
        baseSalary: Number(emp.salary) || 0,
      }));
    }
    return defaultResidenceWorkers;
  }, [employees, defaultResidenceWorkers, isAr]);

  // Days in selected month
  const daysInSelectedMonth = useMemo(() => {
    const y = parseInt(selectedYear, 10) || 2026;
    const m = parseInt(selectedMonth, 10) || 8;
    return new Date(y, m, 0).getDate();
  }, [selectedYear, selectedMonth]);

  // Pointage Map: workerId -> { dailyStatus: { [day]: 'P'|'R'|'A'|'C' }, bonus: number }
  const [pointageMap, setPointageMap] = useState<Record<string, { dailyStatus: Record<number, 'P'|'R'|'A'|'C'>; bonus: number }>>(() => {
    try {
      const saved = localStorage.getItem(`syndico_pointage_${currentYearStr}_${currentMonthStr}`);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return {};
  });

  useEffect(() => {
    try {
      const saved = localStorage.getItem(`syndico_pointage_${selectedYear}_${selectedMonth}`);
      if (saved) {
        setPointageMap(JSON.parse(saved));
      } else {
        setPointageMap({});
      }
    } catch (e) {
      console.error(e);
    }
  }, [selectedYear, selectedMonth]);

  const savePointage = (newMap: Record<string, { dailyStatus: Record<number, 'P'|'R'|'A'|'C'>; bonus: number }>) => {
    setPointageMap(newMap);
    try {
      localStorage.setItem(`syndico_pointage_${selectedYear}_${selectedMonth}`, JSON.stringify(newMap));
    } catch (e) {
      console.error(e);
    }
  };

  // Toggle Day Status in Pointage: P -> R -> A -> C -> P
  const handleToggleDayStatus = (workerId: string, day: number) => {
    const currentWorkerData = pointageMap[workerId] || { dailyStatus: {}, bonus: 0 };
    const y = parseInt(selectedYear, 10) || 2026;
    const m = parseInt(selectedMonth, 10) || 8;
    const isSun = new Date(y, m - 1, day).getDay() === 0;
    const currentStatus = currentWorkerData.dailyStatus[day] || (isSun ? 'R' : 'P');

    const nextStatusMap: Record<string, 'P' | 'R' | 'A' | 'C'> = {
      'P': 'R',
      'R': 'A',
      'A': 'C',
      'C': 'P',
    };
    const nextStatus = nextStatusMap[currentStatus] || 'P';

    const newMap = {
      ...pointageMap,
      [workerId]: {
        ...currentWorkerData,
        dailyStatus: {
          ...currentWorkerData.dailyStatus,
          [day]: nextStatus
        }
      }
    };
    savePointage(newMap);
  };

  // Set all workers present for normal working days
  const handleSetAllPresent = () => {
    const y = parseInt(selectedYear, 10) || 2026;
    const m = parseInt(selectedMonth, 10) || 8;
    const newMap: typeof pointageMap = {};

    activeWorkers.forEach(w => {
      const dailyStatus: Record<number, 'P' | 'R' | 'A' | 'C'> = {};
      for (let d = 1; d <= daysInSelectedMonth; d++) {
        const isSun = new Date(y, m - 1, d).getDay() === 0;
        dailyStatus[d] = isSun ? 'R' : 'P';
      }
      newMap[w.id] = {
        dailyStatus,
        bonus: pointageMap[w.id]?.bonus || 0
      };
    });
    savePointage(newMap);
  };

  // Reset Pointage for Month
  const handleResetPointage = () => {
    savePointage({});
  };

  // Comprehensive Worker Dues & Pointage calculation
  const workersPointageReport = useMemo(() => {
    const y = parseInt(selectedYear, 10) || 2026;
    const m = parseInt(selectedMonth, 10) || 8;

    let totalBaseSalary = 0;
    let totalDeductions = 0;
    let totalBonuses = 0;
    let totalNetDues = 0;
    let totalPresentDays = 0;
    let totalAbsentDays = 0;

    const list = activeWorkers.map(w => {
      const workerData = pointageMap[w.id];
      const dailyStatus = workerData?.dailyStatus || {};
      const bonus = workerData?.bonus || 0;

      let present = 0;
      let rest = 0;
      let absent = 0;
      let conge = 0;

      for (let d = 1; d <= daysInSelectedMonth; d++) {
        const status = dailyStatus[d];
        const isSun = new Date(y, m - 1, d).getDay() === 0;

        if (status) {
          if (status === 'P') present++;
          else if (status === 'R') rest++;
          else if (status === 'A') absent++;
          else if (status === 'C') conge++;
        } else {
          if (isSun) rest++;
          else present++;
        }
      }

      // Standard 26 working days base in Moroccan collective payroll
      const standardWorkingDays = 26;
      const dailyRate = Math.round(w.baseSalary / standardWorkingDays);
      const deduction = absent * dailyRate;
      const netDue = Math.max(0, w.baseSalary - deduction + bonus);

      totalBaseSalary += w.baseSalary;
      totalDeductions += deduction;
      totalBonuses += bonus;
      totalNetDues += netDue;
      totalPresentDays += present;
      totalAbsentDays += absent;

      return {
        ...w,
        presentDays: present,
        restDays: rest,
        absentDays: absent,
        congeDays: conge,
        dailyRate,
        deduction,
        bonus,
        netDue,
        dailyStatus
      };
    });

    const attendanceRate = (totalPresentDays + totalAbsentDays) > 0
      ? Math.round((totalPresentDays / (totalPresentDays + totalAbsentDays)) * 100)
      : 100;

    return {
      workers: list,
      totalBaseSalary,
      totalDeductions,
      totalBonuses,
      totalNetDues,
      totalPresentDays,
      totalAbsentDays,
      attendanceRate
    };
  }, [activeWorkers, pointageMap, daysInSelectedMonth, selectedYear, selectedMonth]);

  // Chronological list of month keys ('YYYY-MM') for the active report mode
  const periodMonthKeys = useMemo(() => {
    if (reportMode === 'monthly') {
      return [`${selectedYear}-${selectedMonth}`];
    }
    if (reportMode === 'annual') {
      const list: string[] = [];
      for (let m = 1; m <= 12; m++) {
        list.push(`${selectedYear}-${String(m).padStart(2, '0')}`);
      }
      return list;
    }
    // custom_period: range from startKey to endKey inclusive
    let sKey = `${startYear}-${startMonth}`;
    let eKey = `${endYear}-${endMonth}`;
    if (sKey > eKey) {
      const temp = sKey;
      sKey = eKey;
      eKey = temp;
    }
    const result: string[] = [];
    let cur = sKey;
    while (cur <= eKey) {
      result.push(cur);
      cur = getNextMonthKey(cur);
      if (result.length > 120) break;
    }
    return result;
  }, [reportMode, selectedYear, selectedMonth, startYear, startMonth, endYear, endMonth]);

  // Current Syndic Dues (Monthly vs Annual vs Custom Period)
  const currentSyndicDues = reportMode === 'annual' 
    ? syndicMonthlyFee * 12 
    : reportMode === 'custom_period'
      ? syndicMonthlyFee * periodMonthKeys.length
      : syndicMonthlyFee;
  const currentWorkersDues = reportMode === 'annual' 
    ? workersPointageReport.totalNetDues * 12 
    : reportMode === 'custom_period'
      ? workersPointageReport.totalNetDues * periodMonthKeys.length
      : workersPointageReport.totalNetDues;

  // Export State
  const [isGeneratingPdf, setIsGeneratingPdf] = useState<boolean>(false);
  const [exportSuccessMsg, setExportSuccessMsg] = useState<string | null>(null);

  // Period Titles
  const selectedMonthObj = MONTHS_LIST.find(m => m.value === selectedMonth);
  const monthName = isAr ? selectedMonthObj?.labelAr || selectedMonth : selectedMonthObj?.labelFr || selectedMonth;

  const startMonthObj = MONTHS_LIST.find(m => m.value === startMonth);
  const endMonthObj = MONTHS_LIST.find(m => m.value === endMonth);
  const startMonthName = isAr ? startMonthObj?.labelAr || startMonth : startMonthObj?.labelFr || startMonth;
  const endMonthName = isAr ? endMonthObj?.labelAr || endMonth : endMonthObj?.labelFr || endMonth;

  const periodTitle = useMemo(() => {
    if (reportMode === 'annual') {
      return isAr 
        ? `الحصيلة والتقرير المالي السنوي الشامل لسنة ${selectedYear}` 
        : `Bilan et Rapport Financier Annuel ${selectedYear}`;
    }
    if (reportMode === 'custom_period') {
      const is2025_2026 = (startYear === '2025' && endYear === '2026');
      const isTwoYears = is2025_2026 || (periodMonthKeys.length >= 22 && periodMonthKeys.length <= 26);
      const baseLabel = is2025_2026
        ? (isAr ? 'تقرير وحصيلة السنتين الأخيرتين الموحدة (2025 و 2026)' : 'UN SEUL BILAN DES 2 DERNIÈRES ANNÉES (2025 ET 2026)')
        : isTwoYears
          ? (isAr ? 'حصيلة السنتين الموحدة (سجل يدوي معتمد)' : 'UN SEUL BILAN DE 2 ANS (FAIT MANUEL)')
          : (isAr ? 'التقرير والحصيلة المالية الموحدة للفترة' : 'Bilan Financier Synthétique Période Début - Fin');

      if (startYear === endYear) {
        return `${baseLabel} • ${isAr ? `من ${startMonthName} إلى ${endMonthName} ${startYear} (${periodMonthKeys.length} أشهر)` : `Du ${startMonthName} au ${endMonthName} ${startYear} (${periodMonthKeys.length} mois)`}`;
      } else {
        return `${baseLabel} • ${isAr ? `من ${startMonthName} ${startYear} إلى غاية ${endMonthName} ${endYear} (${periodMonthKeys.length} شهراً)` : `Du ${startMonthName} ${startYear} au ${endMonthName} ${endYear} (${periodMonthKeys.length} mois)`}`;
      }
    }
    return isAr 
      ? `التقرير المالي لشهر ${monthName} ${selectedYear}` 
      : `Rapport Financier Mensuel - ${monthName} ${selectedYear}`;
  }, [reportMode, selectedYear, monthName, startYear, endYear, startMonthName, endMonthName, periodMonthKeys.length, isAr]);

  const periodCode = useMemo(() => {
    if (reportMode === 'annual') return `${selectedYear}_Annuel`;
    if (reportMode === 'custom_period') return `Bilan_2Ans_${startYear}_${startMonth}_a_${endYear}_${endMonth}`;
    return `${selectedYear}_${selectedMonth}`;
  }, [reportMode, selectedYear, selectedMonth, startYear, startMonth, endYear, endMonth]);

  // Filtered Payments based on reportMode (Monthly, Annual, Custom Period) and Building
  // Accrual / cash basis: income belongs strictly to the month/year of paymentDate
  const filteredPayments = useMemo(() => {
    return payments.filter(p => {
      const pDate = p.paymentDate || '';
      const pPeriod = p.periodMonth || '';
      const pMonthKey = (pDate && pDate.length >= 7) ? pDate.slice(0, 7) : (pPeriod && pPeriod.length >= 7 ? pPeriod.slice(0, 7) : '');

      if (reportMode === 'monthly') {
        const targetMonthPrefix = `${selectedYear}-${selectedMonth}`;
        const inMonth = pDate ? pDate.startsWith(targetMonthPrefix) : pPeriod.startsWith(targetMonthPrefix);
        if (!inMonth) return false;
      } else if (reportMode === 'annual') {
        const inYear = pDate ? pDate.startsWith(selectedYear) : pPeriod.includes(selectedYear);
        if (!inYear) return false;
      } else {
        // custom_period
        if (!pMonthKey || !periodMonthKeys.includes(pMonthKey)) return false;
      }

      if (selectedBuilding !== 'ALL') {
        const cleanBld = selectedBuilding.replace(/\s+/g, '').toUpperCase();
        const pClean = p.buildingCode.replace(/\s+/g, '').toUpperCase();
        if (cleanBld !== pClean) return false;
      }

      return true;
    });
  }, [payments, selectedYear, selectedMonth, selectedBuilding, reportMode, periodMonthKeys]);

  // Filtered Expenses based on reportMode and Building
  const filteredExpenses = useMemo(() => {
    return expenses.filter(e => {
      const eDate = e.date || '';
      const eMonthKey = (eDate && eDate.length >= 7) ? eDate.slice(0, 7) : '';

      if (reportMode === 'monthly') {
        if (!eDate.startsWith(`${selectedYear}-${selectedMonth}`)) return false;
      } else if (reportMode === 'annual') {
        if (!eDate.startsWith(selectedYear)) return false;
      } else {
        // custom_period
        if (!eMonthKey || !periodMonthKeys.includes(eMonthKey)) return false;
      }

      if (selectedBuilding !== 'ALL') {
        const cleanBld = selectedBuilding.replace(/\s+/g, '').toUpperCase();
        const eClean = (e.buildingCode || 'ALL').replace(/\s+/g, '').toUpperCase();
        if (eClean !== 'ALL' && eClean !== cleanBld) return false;
      }

      return true;
    });
  }, [expenses, selectedYear, selectedMonth, selectedBuilding, reportMode, periodMonthKeys]);

  // Summary Metrics
  const totalIncome = useMemo(() => {
    return filteredPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
  }, [filteredPayments]);

  const totalExpenses = useMemo(() => {
    return filteredExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  }, [filteredExpenses]);

  const netBalance = totalIncome - totalExpenses;

  // Expected Revenue: Monthly (1 month) vs Annual (12 months) vs Custom Period (N months)
  const expectedRevenue = useMemo(() => {
    const monthsMultiplier = reportMode === 'annual' 
      ? 12 
      : reportMode === 'custom_period' 
        ? periodMonthKeys.length 
        : 1;
    if (selectedBuilding === 'ALL') {
      return apartments
        .filter(a => !a.isSyndicOffice && !(false))
        .reduce((sum, a) => sum + ((Number(a.monthlyFee) || 150) * monthsMultiplier), 0);
    } else {
      const cleanBld = selectedBuilding.replace(/\s+/g, '').toUpperCase();
      return apartments
        .filter(a => a.buildingCode.replace(/\s+/g, '').toUpperCase() === cleanBld && !a.isSyndicOffice && !(false))
        .reduce((sum, a) => sum + ((Number(a.monthlyFee) || 150) * monthsMultiplier), 0);
    }
  }, [apartments, selectedBuilding, reportMode, periodMonthKeys]);

  const collectionRate = expectedRevenue > 0 
    ? Math.min(100, Math.round((totalIncome / expectedRevenue) * 100))
    : (totalIncome > 0 ? 100 : 0);

  // Category Translation Helper
  const getCategoryName = (cat: ExpenseCategory | string) => {
    switch (cat) {
      case 'worker_salaries': return isAr ? 'أجور العمال' : 'Salaires des travailleurs';
      case 'syndic_fees': return isAr ? 'أجرة وكيل و نائبه' : 'Honoraires agent syndic & adjoint';
      case 'cleaning_supplies': return isAr ? 'مواد النظافة' : 'Matériel et produits de nettoyage';
      case 'electrical_supplies': return isAr ? 'مواد الكهربائية' : 'Matériel & fournitures électriques';
      case 'hardware_droguerie': return isAr ? 'العقاقير بمختلفها' : 'Droguerie & quincaillerie diverses';
      case 'building_materials': return isAr ? 'مواد البناء' : 'Matériaux de construction';
      case 'irrigation_tools': return isAr ? 'أدوات السقي' : 'Outils et matériel d\'arrosage';
      case 'office_stationery': return isAr ? 'مكتبيات' : 'Papeterie & fournitures de bureau';
      case 'lawyer_fees': return isAr ? 'أتعاب المحامي' : 'Honoraires de l\'avocat';
      case 'bailiff_fees': return isAr ? 'أتعاب مفوض قضائي' : 'Honoraires d\'huissier de justice';
      case 'electricity': return isAr ? 'إنارة السلالم والمرافق المشتركة' : 'Électricité des Communs';
      case 'water': return isAr ? 'استهلاك الماء ومضخات الآبار' : 'Eau & Pompage';
      case 'cleaning_company': return isAr ? 'شركة النظافة والتعقيم' : 'Nettoyage & Hygiène';
      case 'security_company': return isAr ? 'حراسة وأمن الإقامة' : 'Sécurité & Gardiennage';
      case 'emergency_repairs': return isAr ? 'إصلاحات وأعطال طارئة' : 'Réparations Urgentes';
      case 'supplies': return isAr ? 'مقتنيات ومعدات الصيانة' : 'Fournitures & Équipements';
      default: return isAr ? 'مصاريف ونفقات عامة' : 'Divers & Maintenance';
    }
  };

  // 10 Official Expense Categories Breakdown as requested by the user
  const official10ExpenseCategories = useMemo(() => {
    const categoriesConfig = [
      {
        id: 'worker_salaries',
        categoryKeys: ['worker_salaries', 'security_company'],
        titleAr: 'أجور العمال',
        titleFr: 'Salaires des travailleurs / ouvriers',
        descAr: 'مستحقات ورواتب أعوان الحراسة والنظافة والبستنة والصيانة',
        descFr: 'Salaires et émoluments des agents et ouvriers',
        iconType: 'users',
        badgeColor: 'bg-sky-50 text-sky-800 border-sky-200'
      },
      {
        id: 'syndic_fees',
        categoryKeys: ['syndic_fees'],
        titleAr: 'أجرة وكيل و نائبه',
        titleFr: 'Honoraires agent syndic & adjoint',
        descAr: 'أتعاب التسيير والإشراف الإداري والمالي والقانوني للسانديك ونائبه',
        descFr: 'Honoraires de gestion et administration du syndic et adjoint',
        iconType: 'briefcase',
        badgeColor: 'bg-amber-50 text-amber-800 border-amber-200'
      },
      {
        id: 'cleaning_supplies',
        categoryKeys: ['cleaning_supplies', 'cleaning_company'],
        titleAr: 'مواد النظافة',
        titleFr: 'Matériel & produits de nettoyage',
        descAr: 'سوائل التنظيف، المعقمات، أكياس القمامة ومعدات نظافة العمارات',
        descFr: 'Produits d\'entretien, détergents, sacs poubelles et balais',
        iconType: 'sparkles',
        badgeColor: 'bg-emerald-50 text-emerald-800 border-emerald-200'
      },
      {
        id: 'electrical_supplies',
        categoryKeys: ['electrical_supplies', 'electricity'],
        titleAr: 'مواد الكهربائية',
        titleFr: 'Fournitures & matériel électrique',
        descAr: 'المصابيح الموفرة للطاقة، الكابلات، مؤقتات السلالم ومستلزمات الإنارة',
        descFr: 'Lampes LED, câbles, minuteries et appareillage électrique',
        iconType: 'zap',
        badgeColor: 'bg-amber-50 text-amber-800 border-amber-200'
      },
      {
        id: 'hardware_droguerie',
        categoryKeys: ['hardware_droguerie', 'supplies', 'emergency_repairs'],
        titleAr: 'العقاقير بمختلفها',
        titleFr: 'Droguerie & quincaillerie diverses',
        descAr: 'الأقفال، المفصلات، الصباغة، الغراء، المسامير، أدوات الصيانة السريعة',
        descFr: 'Serrures, peintures, quincaillerie, colles et visserie',
        iconType: 'wrench',
        badgeColor: 'bg-orange-50 text-orange-800 border-orange-200'
      },
      {
        id: 'building_materials',
        categoryKeys: ['building_materials'],
        titleAr: 'مواد البناء',
        titleFr: 'Matériaux de construction & maçonnerie',
        descAr: 'الإسمنت، الرمل، الجبس، الزليج، مواد العزل وترميم التشققات والجدران',
        descFr: 'Ciment, sable, plâtre, carrelage et réparations des murs',
        iconType: 'hammer',
        badgeColor: 'bg-stone-50 text-stone-800 border-stone-200'
      },
      {
        id: 'irrigation_tools',
        categoryKeys: ['irrigation_tools', 'water'],
        titleAr: 'أدوات السقي',
        titleFr: 'Outils & matériel d\'arrosage',
        descAr: 'خراطيم المياه، فوهات الرش، مضخات الري ومستلزمات الحدائق',
        descFr: 'Tuyaux d\'arrosage, arroseurs, raccords et pompes',
        iconType: 'droplets',
        badgeColor: 'bg-teal-50 text-teal-800 border-teal-200'
      },
      {
        id: 'office_stationery',
        categoryKeys: ['office_stationery'],
        titleAr: 'مكتبيات',
        titleFr: 'Papeterie & fournitures de bureau',
        descAr: 'أوراق الطباعة، الدفاتر، وصولات الأداء، الطوابع ومستلزمات التوثيق',
        descFr: 'Papier, carnets de reçus, registres et fournitures',
        iconType: 'fileText',
        badgeColor: 'bg-blue-50 text-blue-800 border-blue-200'
      },
      {
        id: 'lawyer_fees',
        categoryKeys: ['lawyer_fees'],
        titleAr: 'أتعاب المحامي',
        titleFr: 'Honoraires de l\'avocat',
        descAr: 'الاستشارات القانونية، ملفات النزاع والمتابعة القضائية لتحصيل المتأخرات',
        descFr: 'Conseil juridique, contentieux et procédures judiciaires',
        iconType: 'scale',
        badgeColor: 'bg-purple-50 text-purple-800 border-purple-200'
      },
      {
        id: 'bailiff_fees',
        categoryKeys: ['bailiff_fees'],
        titleAr: 'أتعاب مفوض قضائي',
        titleFr: 'Honoraires d\'huissier de justice',
        descAr: 'الإنذارات المباشرة، المعاينات الرسمية، المحاضر وتبليغ الممتنعين عن الأداء',
        descFr: 'Sommations, procès-verbaux de constat et notifications',
        iconType: 'gavel',
        badgeColor: 'bg-rose-50 text-rose-800 border-rose-200'
      }
    ];

    return categoriesConfig.map((item, index) => {
      const matched = filteredExpenses.filter(e => item.categoryKeys.includes(e.category as any));
      const amount = matched.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
      const percentage = totalExpenses > 0 ? Math.round((amount / totalExpenses) * 100) : 0;

      return {
        number: index + 1,
        id: item.id,
        title: isAr ? item.titleAr : item.titleFr,
        titleAr: item.titleAr,
        titleFr: item.titleFr,
        description: isAr ? item.descAr : item.descFr,
        iconType: item.iconType,
        badgeColor: item.badgeColor,
        amount,
        percentage,
        invoicesCount: matched.length,
        invoices: matched
      };
    });
  }, [filteredExpenses, totalExpenses, isAr]);

  const renderOfficialIcon = (iconType: string) => {
    switch (iconType) {
      case 'users': return <Users className="w-4 h-4 text-sky-600" />;
      case 'briefcase': return <Briefcase className="w-4 h-4 text-amber-600" />;
      case 'sparkles': return <Sparkles className="w-4 h-4 text-emerald-600" />;
      case 'zap': return <Zap className="w-4 h-4 text-amber-500" />;
      case 'wrench': return <Wrench className="w-4 h-4 text-orange-600" />;
      case 'hammer': return <Hammer className="w-4 h-4 text-stone-600" />;
      case 'droplets': return <Droplets className="w-4 h-4 text-teal-600" />;
      case 'fileText': return <FileText className="w-4 h-4 text-blue-600" />;
      case 'scale': return <Scale className="w-4 h-4 text-purple-600" />;
      case 'gavel': return <Gavel className="w-4 h-4 text-rose-600" />;
      default: return <Package className="w-4 h-4 text-slate-600" />;
    }
  };

  const getMethodName = (method: PaymentMethod | string) => {
    switch (method) {
      case 'cash': return isAr ? 'نقداً (Espèces)' : 'Espèces';
      case 'bank_transfer': return isAr ? 'تحويل بنكي (Virement)' : 'Virement';
      case 'check': return isAr ? 'شيك بنكي (Chèque)' : 'Chèque';
      case 'online': return isAr ? 'أداء إلكتروني (En ligne)' : 'En ligne';
      default: return method;
    }
  };

  // Chart Data 1: Category Expenses Breakdown
  const expensesByCategoryData = useMemo(() => {
    const map: Record<string, number> = {};
    filteredExpenses.forEach(e => {
      const cat = e.category || 'other';
      map[cat] = (map[cat] || 0) + (Number(e.amount) || 0);
    });

    return Object.entries(map).map(([key, value]) => ({
      key,
      name: getCategoryName(key),
      amount: value,
      percentage: totalExpenses > 0 ? Math.round((value / totalExpenses) * 100) : 0
    })).sort((a, b) => b.amount - a.amount);
  }, [filteredExpenses, totalExpenses, isAr]);

  // Chart Data 2: Payment Methods Distribution
  const paymentMethodsData = useMemo(() => {
    const map: Record<string, number> = {};
    filteredPayments.forEach(p => {
      const m = p.paymentMethod || 'cash';
      map[m] = (map[m] || 0) + (Number(p.amount) || 0);
    });

    return Object.entries(map).map(([key, value]) => ({
      key,
      name: getMethodName(key),
      amount: value,
      percentage: totalIncome > 0 ? Math.round((value / totalIncome) * 100) : 0
    }));
  }, [filteredPayments, totalIncome, isAr]);

  // Current active month key
  const currentMonthKey = `${selectedYear}-${selectedMonth}`;

  // Prior carryover before the selected period (الفائض أو الناقص المنقول)
  const carryoverData = useMemo(() => {
    if (reportMode === 'monthly') {
      return getCarriedForwardBalance(payments, expenses, currentMonthKey, selectedBuilding, manualMonthlyRecords);
    } else if (reportMode === 'annual') {
      // Annual mode: calculate balance strictly before selectedYear-01
      const yearStartMonthKey = `${selectedYear}-01`;
      const res = getCarriedForwardBalance(payments, expenses, yearStartMonthKey, selectedBuilding, manualMonthlyRecords);
      return {
        ...res,
        prevMonthKey: `${Number(selectedYear) - 1}`,
        prevMonthNameAr: `نهاية سنة ${Number(selectedYear) - 1}`,
        prevMonthNameFr: `Fin d'année ${Number(selectedYear) - 1}`
      };
    } else {
      // Custom period mode: calculate balance strictly before the first month of the range
      const startKey = periodMonthKeys[0] || `${startYear}-${startMonth}`;
      const res = getCarriedForwardBalance(payments, expenses, startKey, selectedBuilding, manualMonthlyRecords);
      const prevKey = getPreviousMonthKey(startKey);
      const [pY, pM] = prevKey ? prevKey.split('-') : ['', ''];
      return {
        ...res,
        prevMonthKey: prevKey,
        prevMonthNameAr: prevKey ? `${ARABIC_MONTH_NAMES[pM] || pM} ${pY}` : '',
        prevMonthNameFr: prevKey ? `${FRENCH_MONTH_NAMES[pM] || pM} ${pY}` : ''
      };
    }
  }, [payments, expenses, reportMode, selectedYear, selectedMonth, selectedBuilding, manualMonthlyRecords, currentMonthKey, periodMonthKeys, startYear, startMonth]);

  // Check if manual monthly record exists for this selected month
  const currentManualRecord = useMemo(() => {
    return manualMonthlyRecords?.find(r => r.monthKey === currentMonthKey);
  }, [manualMonthlyRecords, currentMonthKey]);

  // Editing state for the 3 missing monthly data fields:
  // 1. الرصيد المنقول سابقاً
  // 2. مقبوضات الشهرية
  // 3. مصاريف الشهر
  const [isEditingMonthData, setIsEditingMonthData] = useState<boolean>(false);
  const [inputOpeningBalance, setInputOpeningBalance] = useState<string>('');
  const [inputIncome, setInputIncome] = useState<string>('');
  const [inputExpenses, setInputExpenses] = useState<string>('');

  // Effective values considering manual entries and custom period overrides
  const effectiveCarriedBalance = useMemo(() => {
    if (reportMode === 'custom_period' && customOpeningOverride !== '') {
      return Number(customOpeningOverride) || 0;
    }
    if (reportMode === 'monthly' && currentManualRecord && typeof currentManualRecord.openingBalance === 'number') {
      return currentManualRecord.openingBalance;
    }
    return carryoverData.carriedBalance;
  }, [reportMode, customOpeningOverride, currentManualRecord, carryoverData.carriedBalance]);

  const effectiveIncome = useMemo(() => {
    if (currentManualRecord && typeof currentManualRecord.totalIncome === 'number') {
      return currentManualRecord.totalIncome;
    }
    return totalIncome;
  }, [currentManualRecord, totalIncome]);

  const effectiveExpenses = useMemo(() => {
    if (currentManualRecord && typeof currentManualRecord.totalExpenses === 'number') {
      return currentManualRecord.totalExpenses;
    }
    return totalExpenses;
  }, [currentManualRecord, totalExpenses]);

  // Sync inputs whenever selected month/year changes or currentManualRecord changes
  useEffect(() => {
    if (currentManualRecord) {
      setInputOpeningBalance(String(currentManualRecord.openingBalance ?? 0));
      setInputIncome(String(currentManualRecord.totalIncome ?? 0));
      setInputExpenses(String(currentManualRecord.totalExpenses ?? 0));
    } else {
      setInputOpeningBalance(String(carryoverData.carriedBalance || 0));
      setInputIncome(String(totalIncome || 0));
      setInputExpenses(String(totalExpenses || 0));
    }
  }, [currentMonthKey, currentManualRecord, carryoverData.carriedBalance, totalIncome, totalExpenses]);

  // Live display values during editing
  const displayCarriedBalance = isEditingMonthData && inputOpeningBalance !== ''
    ? (Number(inputOpeningBalance) || 0)
    : effectiveCarriedBalance;

  const displayIncome = isEditingMonthData && inputIncome !== ''
    ? (Number(inputIncome) || 0)
    : effectiveIncome;

  const displayExpenses = isEditingMonthData && inputExpenses !== ''
    ? (Number(inputExpenses) || 0)
    : effectiveExpenses;

  const displayNetBalance = displayIncome - displayExpenses;
  const displayFinalClosingBalance = displayCarriedBalance + displayNetBalance;

  // Final Closing Balance at the end of period carried forward to subsequent period
  const finalClosingBalance = displayFinalClosingBalance;

  // Save manual month data
  const handleSaveMonthData = () => {
    const opening = Number(inputOpeningBalance) || 0;
    const inc = Number(inputIncome) || 0;
    const exp = Number(inputExpenses) || 0;
    const net = inc - exp;
    const closing = opening + net;

    upsertManualMonthlyRecord({
      monthKey: currentMonthKey,
      totalIncome: inc,
      totalExpenses: exp,
      openingBalance: opening,
      closingBalance: closing,
      isUserModified: true,
      notes: isAr ? `بيانات مدخلة يدوياً لشهر ${selectedMonth}/${selectedYear}` : `Données saisies pour ${selectedMonth}/${selectedYear}`,
      recordedBy: currentUser?.name || currentUser?.username || 'Syndic',
    });

    setIsEditingMonthData(false);
    if (showToast) {
      showToast(isAr ? `تم حفظ البيانات لشهر ${selectedMonth}/${selectedYear} بنجاح` : `Données enregistrées avec succès`, { type: 'success' });
    }
  };

  // Revert back to system auto calculation
  const handleResetToAuto = () => {
    if (currentManualRecord) {
      deleteManualMonthlyRecord(currentManualRecord.id);
    }
    setIsEditingMonthData(false);
    setInputOpeningBalance(String(carryoverData.carriedBalance || 0));
    setInputIncome(String(totalIncome || 0));
    setInputExpenses(String(totalExpenses || 0));
    if (showToast) {
      showToast(isAr ? `تمت استعادة الحساب التلقائي للنظام` : `Calcul automatique rétabli`, { type: 'info' });
    }
  };

  // Next month info
  const nextMonthInfo = useMemo(() => {
    if (reportMode === 'monthly') {
      const mKey = `${selectedYear}-${selectedMonth}`;
      const nKey = getNextMonthKey(mKey);
      const [nY, nM] = nKey.split('-');
      return {
        key: nKey,
        nameAr: `${ARABIC_MONTH_NAMES[nM] || nM} ${nY}`,
        nameFr: `${FRENCH_MONTH_NAMES[nM] || nM} ${nY}`
      };
    } else {
      const nextY = `${Number(selectedYear) + 1}`;
      return {
        key: `${nextY}-01`,
        nameAr: `سنة ${nextY}`,
        nameFr: `Année ${nextY}`
      };
    }
  }, [reportMode, selectedYear, selectedMonth]);

  // Full chronological monthly chain for the selected year
  const monthlyCarryoverChain = useMemo(() => {
    return getMonthlyCarryoverChain(payments, expenses, selectedBuilding, selectedYear, manualMonthlyRecords);
  }, [payments, expenses, selectedBuilding, selectedYear, manualMonthlyRecords]);

  // Annual Evolution: Month-by-Month data (Jan to Dec) for Annual Mode
  const annualMonthlyTrendData = useMemo(() => {
    if (reportMode !== 'annual') return [];

    return monthlyCarryoverChain.map(item => ({
      month: isAr ? item.labelAr.split(' ')[0] : item.labelFr.split(' ')[0],
      fullMonth: isAr ? item.labelAr : item.labelFr,
      shortMonth: item.month,
      openingBalance: item.openingBalance,
      income: item.income,
      expenses: item.expenses,
      balance: item.monthNet,
      closingBalance: item.closingBalance
    }));
  }, [reportMode, monthlyCarryoverChain, isAr]);

  // Custom Period Evolution: Month-by-Month data across the unified date range
  const customPeriodMonthlyTrendData = useMemo(() => {
    if (reportMode !== 'custom_period' && reportMode !== 'annual') return [];

    let runningBalance = effectiveCarriedBalance;

    return periodMonthKeys.map(mKey => {
      const [y, m] = mKey.split('-');
      const mNameAr = `${ARABIC_MONTH_NAMES[m] || m} ${y}`;
      const mNameFr = `${FRENCH_MONTH_NAMES[m] || m} ${y}`;

      const manual = manualMonthlyRecords?.find(r => r.monthKey === mKey);
      let mInc = 0;
      let mExp = 0;

      if (manual) {
        mInc = manual.totalIncome ?? 0;
        mExp = manual.totalExpenses ?? 0;
      } else {
        mInc = payments
          .filter(p => {
            const d = p.paymentDate || p.periodMonth || '';
            const matchM = d.startsWith(mKey);
            if (!matchM) return false;
            if (selectedBuilding !== 'ALL') {
              return p.buildingCode.replace(/\s+/g, '').toUpperCase() === selectedBuilding.replace(/\s+/g, '').toUpperCase();
            }
            return true;
          })
          .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);

        mExp = expenses
          .filter(e => {
            const d = e.date || '';
            const matchM = d.startsWith(mKey);
            if (!matchM) return false;
            if (selectedBuilding !== 'ALL') {
              const b = (e.buildingCode || 'ALL').replace(/\s+/g, '').toUpperCase();
              return b === 'ALL' || b === selectedBuilding.replace(/\s+/g, '').toUpperCase();
            }
            return true;
          })
          .reduce((sum, e) => sum + (Number(e.amount) || 0), 0);

        if (mExp === 0 && mInc > 0) {
          mExp = syndicMonthlyFee;
        }
      }

      const mNet = mInc - mExp;
      const closing = runningBalance + mNet;
      const item = {
        monthKey: mKey,
        month: isAr ? (ARABIC_MONTH_NAMES[m] || m) : (FRENCH_MONTH_NAMES[m] || m),
        fullMonth: isAr ? mNameAr : mNameFr,
        year: y,
        shortMonth: m,
        openingBalance: runningBalance,
        income: mInc,
        expenses: mExp,
        balance: mNet,
        monthNet: mNet,
        closingBalance: closing,
        isClosingSurplus: closing >= 0
      };

      runningBalance = closing;
      return item;
    });
  }, [reportMode, periodMonthKeys, effectiveCarriedBalance, manualMonthlyRecords, payments, expenses, selectedBuilding, syndicMonthlyFee, isAr]);

  // Buildings Breakdown Analytics (All 20 Buildings)
  const buildingsSummaryList = useMemo(() => {
    const monthsMultiplier = reportMode === 'annual' 
      ? 12 
      : reportMode === 'custom_period' 
        ? periodMonthKeys.length 
        : 1;
    return buildings.map(bld => {
      const cleanCode = bld.code.replace(/\s+/g, '').toUpperCase();
      const bldApts = apartments.filter(a => a.buildingCode.replace(/\s+/g, '').toUpperCase() === cleanCode && !a.isSyndicOffice && !(false));
      
      const expectedRevenue = bldApts.reduce((sum, a) => sum + ((Number(a.monthlyFee) || 150) * monthsMultiplier), 0);

      const collectedIncome = filteredPayments
        .filter(p => p.buildingCode.replace(/\s+/g, '').toUpperCase() === cleanCode)
        .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);

      const directExpenses = filteredExpenses
        .filter(e => e.buildingCode && e.buildingCode.replace(/\s+/g, '').toUpperCase() === cleanCode)
        .reduce((sum, e) => sum + (Number(e.amount) || 0), 0);

      const bldCollectionRate = expectedRevenue > 0 
        ? Math.min(100, Math.round((collectedIncome / expectedRevenue) * 100))
        : (collectedIncome > 0 ? 100 : 0);

      return {
        id: bld.id,
        code: bld.code,
        name: bld.name,
        apartmentsCount: bldApts.length || 16,
        expectedRevenue,
        collectedIncome,
        expenses: directExpenses,
        netBalance: collectedIncome - directExpenses,
        collectionRate: bldCollectionRate
      };
    });
  }, [buildings, apartments, filteredPayments, filteredExpenses, reportMode, periodMonthKeys]);

  // =========================================================================
  // SYSTEM PERIOD PILLARS (Calculated automatically from database transactions)
  // Used as default for Custom Period / 2-Year Bilan, or when Auto-fill is clicked
  // =========================================================================
  const systemPeriodPillars = useMemo(() => {
    let rep = effectiveCarriedBalance;
    let rec = 0;
    let sal = 0;
    let syn = 0;
    let avo = 0;
    let hui = 0;
    let dro = 0;

    const periodManualRecords = (manualMonthlyRecords || []).filter(r => periodMonthKeys.includes(r.monthKey));
    const recordedKeys = new Set(periodManualRecords.map(r => r.monthKey));

    periodManualRecords.forEach(r => {
      rec += (r.totalIncome || 0);
      const bExp = r.breakdownExpenses || {};
      const pil = splitExpensePillars(r);
          const w = pil.workers; const s = pil.syndic; const l = pil.lawyer; const b = pil.bailiff; const d = pil.diverse;

      sal += w;
      syn += s;
      avo += l;
      hui += b;
      dro += d;
    });

    filteredPayments.forEach(p => {
      const pDate = p.paymentDate || '';
      const pPeriod = p.periodMonth || '';
      const m = (pDate && pDate.length >= 7) ? pDate.slice(0, 7) : (pPeriod && pPeriod.length >= 7 ? pPeriod.slice(0, 7) : '');
      if (m && !recordedKeys.has(m) && periodMonthKeys.includes(m)) {
        rec += (Number(p.amount) || 0);
      }
    });

    filteredExpenses.forEach(exp => {
      const m = (exp.date && exp.date.length >= 7) ? exp.date.slice(0, 7) : '';
      if (m && !recordedKeys.has(m) && periodMonthKeys.includes(m)) {
        const amt = Number(exp.amount) || 0;
        const cat = exp.category;
        const title = (exp.title || '').toLowerCase();

        if (cat === 'worker_salaries' || cat === 'security_company' || title.includes('حراس') || title.includes('أجر') || title.includes('راتب')) {
          sal += amt;
        } else if (cat === 'syndic_fees' || title.includes('سانديك') || title.includes('syndic')) {
          syn += amt;
        } else if (cat === 'lawyer_fees' || title.includes('محام') || title.includes('avocat')) {
          avo += amt;
        } else if (cat === 'bailiff_fees' || title.includes('مفوض') || title.includes('huissier')) {
          hui += amt;
        } else {
          dro += amt;
        }
      }
    });

    const unrecordedMonthsCount = periodMonthKeys.filter(k => !recordedKeys.has(k)).length;
    if (unrecordedMonthsCount > 0 && syn === 0) {
      syn += syndicMonthlyFee * unrecordedMonthsCount;
    }

    const totalDisp = rep + rec;
    const totalExp = sal + syn + avo + hui + dro;
    const solde = totalDisp - totalExp;

    return {
      report: rep,
      recettes: rec,
      salaires: sal,
      syndic: syn,
      avocat: avo,
      huissier: hui,
      droguerie: dro,
      totalDisponible: totalDisp,
      depenses: totalExp,
      soldeRestant: solde
    };
  }, [effectiveCarriedBalance, manualMonthlyRecords, periodMonthKeys, filteredPayments, filteredExpenses, syndicMonthlyFee]);

  // Fill manual inputs from system calculation
  const handlePopulateFromSystem = () => {
    setTempManualReport(String(systemPeriodPillars.report));
    setTempManualRecettes(String(systemPeriodPillars.recettes));
    setTempManualSalaires(String(systemPeriodPillars.salaires));
    setTempManualSyndic(String(systemPeriodPillars.syndic));
    setTempManualAvocat(String(systemPeriodPillars.avocat));
    setTempManualHuissier(String(systemPeriodPillars.huissier));
    setTempManualDroguerie(String(systemPeriodPillars.droguerie));
    if (showToast) {
      showToast(isAr ? 'تم استيراد أرقام النظام بنجاح إلى النموذج اليدوي' : 'Chiffres calculés importés dans le formulaire manuel', { type: 'info' });
    }
  };

  // Save manual bilan figures to state and localStorage
  const handleSaveManualBilan = () => {
    const rep = Number(tempManualReport) || 0;
    const rec = Number(tempManualRecettes) || 0;
    const sal = Number(tempManualSalaires) || 0;
    const syn = Number(tempManualSyndic) || 0;
    const avo = Number(tempManualAvocat) || 0;
    const hui = Number(tempManualHuissier) || 0;
    const dro = Number(tempManualDroguerie) || 0;

    const data = {
      isManualActive: true,
      report: rep,
      recettes: rec,
      salaires: sal,
      syndic: syn,
      avocat: avo,
      huissier: hui,
      droguerie: dro,
      savedAt: new Date().toISOString()
    };

    setManualBilan(data);
    const key = getBilanManualStorageKey(startYear, startMonth, endYear, endMonth);
    try {
      localStorage.setItem(key, JSON.stringify(data));
      localStorage.setItem('syndico_bilan_2ans_manual_data', JSON.stringify(data));
    } catch (e) {
      console.error(e);
    }

    if (showToast) {
      showToast(isAr ? 'تم حفظ أرقام حصيلة السنتين (سجل يدوي) بنجاح وتطبيقها على التقرير' : 'Bilan manuel de 2 ans enregistré avec succès', { type: 'success' });
    }
  };

  // Reset manual bilan to auto-calculated system
  const handleResetManualBilanToAuto = () => {
    const data = {
      isManualActive: false,
      report: systemPeriodPillars.report,
      recettes: systemPeriodPillars.recettes,
      salaires: systemPeriodPillars.salaires,
      syndic: systemPeriodPillars.syndic,
      avocat: systemPeriodPillars.avocat,
      huissier: systemPeriodPillars.huissier,
      droguerie: systemPeriodPillars.droguerie
    };
    setManualBilan(data);
    const key = getBilanManualStorageKey(startYear, startMonth, endYear, endMonth);
    try {
      localStorage.removeItem(key);
    } catch (e) {
      console.error(e);
    }
    if (showToast) {
      showToast(isAr ? 'تمت استعادة الحساب التلقائي من النظام' : 'Calcul automatique rétabli', { type: 'info' });
    }
  };

  // Live computed indicators for the manual form
  const liveFormTotalDisponible = (Number(tempManualReport) || 0) + (Number(tempManualRecettes) || 0);
  const liveFormDepenses = (Number(tempManualSalaires) || 0) + 
                           (Number(tempManualSyndic) || 0) + 
                           (Number(tempManualAvocat) || 0) + 
                           (Number(tempManualHuissier) || 0) + 
                           (Number(tempManualDroguerie) || 0);
  const liveFormSoldeRestant = liveFormTotalDisponible - liveFormDepenses;

  // =========================================================================
  // MASTER FINANCIAL STATEMENT (البيان المالي والمحاسباتي الرسمي الموحد)
  // Exact 10 rows requested:
  // 1. المرحل من الشهر السابق (أو السنة السابقة)
  // 2. المداخيل
  // 3. أجور العمال (% من المصاريف)
  // 4. أجرة الوكيل ونائبه (% من المصاريف)
  // 5. أتعاب المحامي (% من المصاريف)
  // 6. أتعاب مفوض قضائي (% من المصاريف)
  // 7. مصاريف مختلفة (عقاقير، إسمنت، أدوات السقي... إلى آخره) (% من المصاريف)
  // 8. مجموع المداخيل مع إضافة المنقول
  // 9. مجموع المصاريف (100%)
  // 10. الباقي (الرصيد النهائي المرحل)
  // =========================================================================
  const masterFinancialStatement = useMemo(() => {
    let carriedBalance = 0;
    let income = 0;
    let workerSalaries = 0;
    let syndicFees = 0;
    let lawyerFees = 0;
    let bailiffFees = 0;
    let diverseExpenses = 0;

    if (reportMode === 'monthly') {
      carriedBalance = displayCarriedBalance;
      income = displayIncome;

      if (currentManualRecord) {
        const bExp = currentManualRecord.breakdownExpenses || {};
        const pil = splitExpensePillars(currentManualRecord);
        workerSalaries = pil.workers; syndicFees = pil.syndic; lawyerFees = pil.lawyer; bailiffFees = pil.bailiff; diverseExpenses = pil.diverse;
      } else {
        filteredExpenses.forEach(exp => {
          const amt = Number(exp.amount) || 0;
          const cat = exp.category;
          const title = (exp.title || '').toLowerCase();

          if (cat === 'worker_salaries' || cat === 'security_company' || title.includes('حراس') || title.includes('أجر') || title.includes('راتب') || title.includes('نظاف') || title.includes('ouvrier')) {
            workerSalaries += amt;
          } else if (cat === 'syndic_fees' || title.includes('سانديك') || title.includes('syndic') || title.includes('أجرة الوكيل')) {
            syndicFees += amt;
          } else if (cat === 'lawyer_fees' || title.includes('محام') || title.includes('avocat')) {
            lawyerFees += amt;
          } else if (cat === 'bailiff_fees' || title.includes('مفوض') || title.includes('huissier')) {
            bailiffFees += amt;
          } else {
            diverseExpenses += amt;
          }
        });

        if (syndicFees === 0 && displayExpenses > 0) syndicFees = syndicMonthlyFee;
        const currentSum = workerSalaries + syndicFees + lawyerFees + bailiffFees;
        if (displayExpenses > currentSum) {
          diverseExpenses = displayExpenses - currentSum;
        }
      }
    } else if (reportMode === 'annual') {
      // Annual Mode:
      carriedBalance = carryoverData.carriedBalance;
      income = displayIncome;

      const yearManualRecords = (manualMonthlyRecords || []).filter(r => r.monthKey.startsWith(selectedYear));
      if (yearManualRecords.length > 0) {
        yearManualRecords.forEach(r => {
          const bExp = r.breakdownExpenses || {};
          const pil = splitExpensePillars(r);
          const w = pil.workers; const s = pil.syndic; const l = pil.lawyer; const b = pil.bailiff; const d = pil.diverse;

          workerSalaries += w;
          syndicFees += s;
          lawyerFees += l;
          bailiffFees += b;
          diverseExpenses += d;
        });

        // Add any non-manual system expenses not covered in recorded months
        const recordedKeys = new Set(yearManualRecords.map(r => r.monthKey));
        filteredExpenses.forEach(exp => {
          const m = (exp.date && exp.date.length >= 7) ? exp.date.slice(0, 7) : '';
          if (m && !recordedKeys.has(m)) {
            const amt = Number(exp.amount) || 0;
            const cat = exp.category;
            const title = (exp.title || '').toLowerCase();

            if (cat === 'worker_salaries' || cat === 'security_company' || title.includes('حراس') || title.includes('أجر') || title.includes('راتب')) {
              workerSalaries += amt;
            } else if (cat === 'syndic_fees' || title.includes('سانديك') || title.includes('syndic')) {
              syndicFees += amt;
            } else if (cat === 'lawyer_fees' || title.includes('محام') || title.includes('avocat')) {
              lawyerFees += amt;
            } else if (cat === 'bailiff_fees' || title.includes('مفوض') || title.includes('huissier')) {
              bailiffFees += amt;
            } else {
              diverseExpenses += amt;
            }
          }
        });
      } else {
        filteredExpenses.forEach(exp => {
          const amt = Number(exp.amount) || 0;
          const cat = exp.category;
          const title = (exp.title || '').toLowerCase();

          if (cat === 'worker_salaries' || cat === 'security_company' || title.includes('حراس') || title.includes('أجر') || title.includes('راتب')) {
            workerSalaries += amt;
          } else if (cat === 'syndic_fees' || title.includes('سانديك') || title.includes('syndic')) {
            syndicFees += amt;
          } else if (cat === 'lawyer_fees' || title.includes('محام') || title.includes('avocat')) {
            lawyerFees += amt;
          } else if (cat === 'bailiff_fees' || title.includes('مفوض') || title.includes('huissier')) {
            bailiffFees += amt;
          } else {
            diverseExpenses += amt;
          }
        });

        if (syndicFees === 0 && displayExpenses > 0) {
          syndicFees = syndicMonthlyFee * 12;
        }
      }
    } else {
      // Custom Period Mode (UN SEUL BILAN DE 2ANS - FAIT MANUEL ou CALCUL SYSTÈME)
      if (manualBilan.isManualActive) {
        carriedBalance = manualBilan.report;
        income = manualBilan.recettes;
        workerSalaries = manualBilan.salaires;
        syndicFees = manualBilan.syndic;
        lawyerFees = manualBilan.avocat;
        bailiffFees = manualBilan.huissier;
        diverseExpenses = manualBilan.droguerie;
      } else {
        carriedBalance = systemPeriodPillars.report;
        income = systemPeriodPillars.recettes;
        workerSalaries = systemPeriodPillars.salaires;
        syndicFees = systemPeriodPillars.syndic;
        lawyerFees = systemPeriodPillars.avocat;
        bailiffFees = systemPeriodPillars.huissier;
        diverseExpenses = systemPeriodPillars.droguerie;
      }
    }

    const totalExpenses = workerSalaries + syndicFees + lawyerFees + bailiffFees + diverseExpenses;
    const totalIncomeWithCarried = carriedBalance + income;
    const netPeriodSurplus = income - totalExpenses;
    const remainingBalance = totalIncomeWithCarried - totalExpenses;

    const calcPct = (v: number) => {
      if (!totalExpenses || totalExpenses <= 0) return 0;
      return Number(((v / totalExpenses) * 100).toFixed(1));
    };

    return {
      carriedBalance,
      income,
      workerSalaries,
      syndicFees,
      lawyerFees,
      bailiffFees,
      diverseExpenses,
      totalIncomeWithCarried,
      totalExpenses,
      netPeriodSurplus,
      remainingBalance,
      workerSalariesPct: calcPct(workerSalaries),
      syndicFeesPct: calcPct(syndicFees),
      lawyerFeesPct: calcPct(lawyerFees),
      bailiffFeesPct: calcPct(bailiffFees),
      diverseExpensesPct: calcPct(diverseExpenses)
    };
  }, [
    reportMode, displayCarriedBalance, effectiveCarriedBalance, carryoverData.carriedBalance,
    displayIncome, displayExpenses, totalIncome, currentManualRecord, filteredExpenses,
    filteredPayments, syndicMonthlyFee, selectedYear, manualMonthlyRecords, periodMonthKeys,
    manualBilan, systemPeriodPillars
  ]);

  // Chart 1: Donut of the 5 expense pillars with percentages
  const expensePillarsChartData = useMemo(() => [
    { name: isAr ? 'أجور العمال' : 'Salaires ouvriers', value: masterFinancialStatement.workerSalaries, pct: masterFinancialStatement.workerSalariesPct, fill: '#0284c7' },
    { name: isAr ? 'أجرة الوكيل ونائبه' : 'Honoraires Syndic', value: masterFinancialStatement.syndicFees, pct: masterFinancialStatement.syndicFeesPct, fill: '#d97706' },
    { name: isAr ? 'أتعاب المحامي' : 'Avocat', value: masterFinancialStatement.lawyerFees, pct: masterFinancialStatement.lawyerFeesPct, fill: '#7c3aed' },
    { name: isAr ? 'أتعاب مفوض قضائي' : 'Huissier', value: masterFinancialStatement.bailiffFees, pct: masterFinancialStatement.bailiffFeesPct, fill: '#db2777' },
    { name: isAr ? 'مصاريف مختلفة (عقاقير، إسمنت، سقي...)' : 'Dépenses diverses', value: masterFinancialStatement.diverseExpenses, pct: masterFinancialStatement.diverseExpensesPct, fill: '#ea580c' },
  ].filter(d => d.value > 0), [masterFinancialStatement, isAr]);

  // Chart 2: Cashflow Comparison
  const cashflowComparisonData = useMemo(() => [
    { name: isAr ? 'المنقول السابق' : 'Report', amount: masterFinancialStatement.carriedBalance, fill: '#6366f1' },
    { name: isAr ? 'المداخيل' : 'Recettes', amount: masterFinancialStatement.income, fill: '#059669' },
    { name: isAr ? 'إجمالي السيولة (1+2)' : 'Disponible', amount: masterFinancialStatement.totalIncomeWithCarried, fill: '#0891b2' },
    { name: isAr ? 'مجموع المصاريف' : 'Dépenses', amount: masterFinancialStatement.totalExpenses, fill: '#dc2626' },
    { name: isAr ? 'الباقي النهائي' : 'Solde Restant', amount: masterFinancialStatement.remainingBalance, fill: masterFinancialStatement.remainingBalance >= 0 ? '#10b981' : '#f43f5e' },
  ], [masterFinancialStatement, isAr]);

  // Dedicated Two Years (2025 ET 2026) Comparative Breakdown & Analytics
  const twoYearsComparison = useMemo(() => {
    const isTwoYearsSpan = (startYear === '2025' && endYear === '2026') || 
      (reportMode === 'custom_period' && periodMonthKeys.some(k => k.startsWith('2025')) && periodMonthKeys.some(k => k.startsWith('2026')));

    if (!isTwoYearsSpan) {
      return null;
    }

    const months2025 = periodMonthKeys.filter(k => k.startsWith('2025'));
    const months2026 = periodMonthKeys.filter(k => k.startsWith('2026'));

    const calcYearPillars = (monthKeys: string[], startingReport: number) => {
      let rec = 0;
      let sal = 0;
      let syn = 0;
      let avo = 0;
      let hui = 0;
      let dro = 0;

      if (manualBilan.isManualActive) {
        const ratio = (monthKeys.length || 12) / (periodMonthKeys.length || 24);
        rec = Math.round(manualBilan.recettes * ratio);
        sal = Math.round(manualBilan.salaires * ratio);
        syn = Math.round(manualBilan.syndic * ratio);
        avo = Math.round(manualBilan.avocat * ratio);
        hui = Math.round(manualBilan.huissier * ratio);
        dro = Math.round(manualBilan.droguerie * ratio);
        const exp = sal + syn + avo + hui + dro;
        const disp = startingReport + rec;
        const solde = disp - exp;
        return {
          report: startingReport,
          recettes: rec,
          salaires: sal,
          syndic: syn,
          avocat: avo,
          huissier: hui,
          droguerie: dro,
          totalDisponible: disp,
          totalExpenses: exp,
          soldeRestant: solde,
          netSurplus: rec - exp,
          monthsCount: monthKeys.length
        };
      }

      const keysSet = new Set(monthKeys);
      const manualRecs = (manualMonthlyRecords || []).filter(r => keysSet.has(r.monthKey));
      const manualKeysSet = new Set(manualRecs.map(r => r.monthKey));

      manualRecs.forEach(r => {
        rec += (r.totalIncome || 0);
        const b = r.breakdownExpenses || {};
        const pil = splitExpensePillars(r);
          const w = pil.workers; const s = pil.syndic; const l = pil.lawyer; const bh = pil.bailiff; const d = pil.diverse;
        sal += w;
        syn += s;
        avo += l;
        hui += bh;
        dro += d;
      });

      filteredPayments.forEach(p => {
        const pDate = p.paymentDate || '';
        const pPeriod = p.periodMonth || '';
        const m = (pDate && pDate.length >= 7) ? pDate.slice(0, 7) : (pPeriod && pPeriod.length >= 7 ? pPeriod.slice(0, 7) : '');
        if (m && keysSet.has(m) && !manualKeysSet.has(m)) {
          rec += (Number(p.amount) || 0);
        }
      });

      filteredExpenses.forEach(exp => {
        const m = (exp.date && exp.date.length >= 7) ? exp.date.slice(0, 7) : '';
        if (m && keysSet.has(m) && !manualKeysSet.has(m)) {
          const amt = Number(exp.amount) || 0;
          const cat = exp.category;
          const title = (exp.title || '').toLowerCase();
          if (cat === 'worker_salaries' || cat === 'security_company' || title.includes('حراس') || title.includes('أجر') || title.includes('راتب')) {
            sal += amt;
          } else if (cat === 'syndic_fees' || title.includes('سانديك') || title.includes('syndic')) {
            syn += amt;
          } else if (cat === 'lawyer_fees' || title.includes('محام') || title.includes('avocat')) {
            avo += amt;
          } else if (cat === 'bailiff_fees' || title.includes('مفوض') || title.includes('huissier')) {
            hui += amt;
          } else {
            dro += amt;
          }
        }
      });

      const unrec = monthKeys.filter(k => !manualKeysSet.has(k)).length;
      if (unrec > 0 && syn === 0) syn += syndicMonthlyFee * unrec;

      const totalDisp = startingReport + rec;
      const totalExp = sal + syn + avo + hui + dro;
      const soldeRestant = totalDisp - totalExp;

      return {
        report: startingReport,
        recettes: rec,
        salaires: sal,
        syndic: syn,
        avocat: avo,
        huissier: hui,
        droguerie: dro,
        totalDisponible: totalDisp,
        totalExpenses: totalExp,
        netSurplus: rec - totalExp,
        soldeRestant: soldeRestant,
        monthsCount: monthKeys.length
      };
    };

    const y2025 = calcYearPillars(months2025, masterFinancialStatement.carriedBalance);
    const y2026 = calcYearPillars(months2026, y2025.soldeRestant);

    const comparativeBarData = [
      {
        year: isAr ? 'سنة 2025' : 'Année 2025',
        recettes: y2025.recettes,
        depenses: y2025.totalExpenses,
        solde: y2025.soldeRestant,
        disponible: y2025.totalDisponible
      },
      {
        year: isAr ? 'سنة 2026' : 'Année 2026',
        recettes: y2026.recettes,
        depenses: y2026.totalExpenses,
        solde: y2026.soldeRestant,
        disponible: y2026.totalDisponible
      }
    ];

    const calcPct = (val: number, tot: number) => tot > 0 ? Number(((val / tot) * 100).toFixed(1)) : 0;

    const y2025Enhanced = {
      ...y2025,
      salairesPct: calcPct(y2025.salaires, y2025.totalExpenses),
      syndicPct: calcPct(y2025.syndic, y2025.totalExpenses),
      avocatPct: calcPct(y2025.avocat, y2025.totalExpenses),
      huissierPct: calcPct(y2025.huissier, y2025.totalExpenses),
      drogueriePct: calcPct(y2025.droguerie, y2025.totalExpenses),
    };

    const y2026Enhanced = {
      ...y2026,
      salairesPct: calcPct(y2026.salaires, y2026.totalExpenses),
      syndicPct: calcPct(y2026.syndic, y2026.totalExpenses),
      avocatPct: calcPct(y2026.avocat, y2026.totalExpenses),
      huissierPct: calcPct(y2026.huissier, y2026.totalExpenses),
      drogueriePct: calcPct(y2026.droguerie, y2026.totalExpenses),
    };

    const pillarsComparativeBarData = [
      {
        poste: isAr ? 'أجور العمال' : 'Salaires ouvriers',
        y2025: y2025.salaires,
        y2026: y2026.salaires,
      },
      {
        poste: isAr ? 'أجرة الوكيل' : 'Honoraires Syndic',
        y2025: y2025.syndic,
        y2026: y2026.syndic,
      },
      {
        poste: isAr ? 'أتعاب المحامي' : 'Avocat',
        y2025: y2025.avocat,
        y2026: y2026.avocat,
      },
      {
        poste: isAr ? 'مفوض قضائي' : 'Huissier',
        y2025: y2025.huissier,
        y2026: y2026.huissier,
      },
      {
        poste: isAr ? 'عقاقير ومختلفة' : 'Droguerie & Divers',
        y2025: y2025.droguerie,
        y2026: y2026.droguerie,
      },
    ];

    const growthRecettes = y2025.recettes > 0 ? Number((((y2026.recettes - y2025.recettes) / y2025.recettes) * 100).toFixed(1)) : 0;
    const growthDepenses = y2025.totalExpenses > 0 ? Number((((y2026.totalExpenses - y2025.totalExpenses) / y2025.totalExpenses) * 100).toFixed(1)) : 0;
    const growthSolde = y2025.soldeRestant !== 0 ? Number((((y2026.soldeRestant - y2025.soldeRestant) / Math.abs(y2025.soldeRestant)) * 100).toFixed(1)) : 0;

    return {
      hasTwoYears: true,
      months2025Count: months2025.length,
      months2026Count: months2026.length,
      y2025: y2025Enhanced,
      y2026: y2026Enhanced,
      comparativeBarData,
      pillarsComparativeBarData,
      growthRecettes,
      growthDepenses,
      growthSolde
    };
  }, [
    startYear, endYear, periodMonthKeys, reportMode, manualBilan, manualMonthlyRecords,
    filteredPayments, filteredExpenses, syndicMonthlyFee, masterFinancialStatement.carriedBalance, isAr
  ]);

  // Handle PDF Export
  const handleDownloadPdf = async () => {
    setIsGeneratingPdf(true);
    setExportSuccessMsg(null);
    try {
      const success = await exportMonthlyFinancialReportToPdf(
        'financial-report-print-container',
        periodCode,
        reportMode
      );
      if (success) {
        setExportSuccessMsg(isAr ? 'تم تحميل ملف PDF بنجاح!' : 'Fichier PDF généré avec succès !');
        setTimeout(() => setExportSuccessMsg(null), 4000);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // Handle CSV / Excel Export
  const handleDownloadCSV = () => {
    exportFinancialReportToCSV({
      residenceName: RES.fullNameAr,
      reportType: reportMode === 'annual' ? 'التقرير والحصيلة المالية السنوية' : 'التقرير المالي والمحاسباتي الشهري',
      period: periodTitle,
      totalIncome: displayIncome,
      totalExpenses: displayExpenses,
      netBalance: displayNetBalance,
      collectionRate,
      previousCarriedBalance: displayCarriedBalance,
      finalClosingBalance: displayFinalClosingBalance,
      previousMonthName: carryoverData.prevMonthNameAr,
      nextMonthName: nextMonthInfo.nameAr,
      monthlyCarryoverChain: monthlyCarryoverChain.map(item => ({
        month: isAr ? item.labelAr : item.labelFr,
        openingBalance: item.openingBalance,
        income: item.income,
        expenses: item.expenses,
        monthNet: item.monthNet,
        closingBalance: item.closingBalance,
        status: item.isClosingSurplus ? (isAr ? 'فائض مرحل 🟢' : 'Excédent reporté') : (isAr ? 'عجز مرحل 🔴' : 'Déficit reporté')
      })),
      syndicDues: currentSyndicDues,
      officialCategories: official10ExpenseCategories.map(c => ({
        number: c.number,
        title: c.title,
        description: c.description,
        amount: c.amount,
        percentage: c.percentage,
        invoicesCount: c.invoicesCount
      })),
      expensesByCategory: expensesByCategoryData,
      expenses: filteredExpenses.map(e => ({
        date: e.date,
        title: e.title,
        category: getCategoryName(e.category),
        supplier: e.supplier || '-',
        buildingCode: e.buildingCode || 'ALL',
        amount: Number(e.amount) || 0
      }))
    });
    setExportSuccessMsg(isAr ? 'تم تصدير كشف الإكسيل (CSV) بنجاح!' : 'Fichier Excel (CSV) exporté avec succès !');
    setTimeout(() => setExportSuccessMsg(null), 4000);
  };

  // Quick Presets Handler for Custom Period
  const handleApplyPreset = (preset: 'last_2_years' | 'two_years_25_26' | 'example_user' | 'year_2025' | 'year_2024' | 'last_6_months' | 'last_12_months') => {
    if (preset === 'last_2_years') {
      setStartYear('2024');
      setStartMonth('01');
      setEndYear('2025');
      setEndMonth('12');
    } else if (preset === 'two_years_25_26') {
      setStartYear('2025');
      setStartMonth('01');
      setEndYear('2026');
      setEndMonth('12');
    } else if (preset === 'example_user') {
      setStartYear('2025');
      setStartMonth('04');
      setEndYear('2025');
      setEndMonth('10');
    } else if (preset === 'year_2025') {
      setStartYear('2025');
      setStartMonth('01');
      setEndYear('2025');
      setEndMonth('12');
    } else if (preset === 'year_2024') {
      setStartYear('2024');
      setStartMonth('01');
      setEndYear('2024');
      setEndMonth('12');
    } else if (preset === 'last_6_months') {
      const now = new Date();
      const eY = now.getFullYear();
      const eM = now.getMonth() + 1;
      let sM = eM - 5;
      let sY = eY;
      if (sM <= 0) {
        sM += 12;
        sY -= 1;
      }
      setStartYear(String(sY));
      setStartMonth(String(sM).padStart(2, '0'));
      setEndYear(String(eY));
      setEndMonth(String(eM).padStart(2, '0'));
    } else if (preset === 'last_12_months') {
      const now = new Date();
      const eY = now.getFullYear();
      const eM = now.getMonth() + 1;
      let sM = eM - 11;
      let sY = eY;
      if (sM <= 0) {
        sM += 12;
        sY -= 1;
      }
      setStartYear(String(sY));
      setStartMonth(String(sM).padStart(2, '0'));
      setEndYear(String(eY));
      setEndMonth(String(eM).padStart(2, '0'));
    }
  };

  const handleSaveCustomOpening = () => {
    const val = Number(tempCustomOpening);
    if (!isNaN(val)) {
      setCustomOpeningOverride(String(val));
      try {
        localStorage.setItem('syndico_custom_period_opening', String(val));
      } catch (e) {
        console.error(e);
      }
      if (showToast) {
        showToast(isAr ? 'تم تعديل الرصيد المنقول لبداية الفترة يدوياً بنجاح' : 'Solde initial de la période enregistré', { type: 'success' });
      }
    }
    setIsEditingCustomOpening(false);
  };

  const handleResetCustomOpening = () => {
    setCustomOpeningOverride('');
    try {
      localStorage.removeItem('syndico_custom_period_opening');
    } catch (e) {
      console.error(e);
    }
    setIsEditingCustomOpening(false);
    if (showToast) {
      showToast(isAr ? 'تمت استعادة الحساب التلقائي للرصيد المنقول' : 'Calcul automatique rétabli', { type: 'info' });
    }
  };

  // Handle Native Browser Print
  const handlePrint = () => {
    window.print();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-in fade-in">
      <div className="bg-white w-full max-w-5xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[94vh]">
        
        {/* TOP CONTROL BAR (Hidden during Print) */}
        <div className="no-print p-4 sm:p-5 bg-gradient-to-r from-[#0f172a] via-[#0a8591] to-[#1e3a8a] text-white flex flex-wrap items-center justify-between gap-4 border-b border-[#0d5262]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/15 border border-white/20 flex items-center justify-center text-white shadow-inner shrink-0">
              <FileText className="w-5 h-5 text-rose-200" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black tracking-tight text-white">
                  {reportMode === 'annual' 
                    ? (isAr ? 'الحصيلة والتقرير المالي السنوي الشامل' : 'Bilan & Rapport Financier Annuel')
                    : reportMode === 'custom_period'
                      ? (isAr ? 'حصيلة السنتين الموحدة (سجل يدوي معتمد)' : 'UN SEUL BILAN DE 2 ANS (FAIT MANUEL)')
                      : (isAr ? 'التقرير المالي والمحاسباتي الشهري' : 'Rapport Financier Mensuel')}
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[10px] font-extrabold border border-amber-300">
                  {reportMode === 'annual' 
                    ? (isAr ? 'سنوي' : 'Annuel') 
                    : reportMode === 'custom_period' 
                      ? (isAr ? 'حصيلة سنتين ⚖️' : 'Bilan 2 Ans ⚖️') 
                      : (isAr ? 'شهري' : 'Mensuel')}
                </span>
              </div>
              <p className="text-xs text-rose-200 mt-0.5 font-medium">
                {RES.fullNameAr}
              </p>
            </div>
          </div>

          {/* Action Buttons: Mode Switch, Print, PDF, CSV, Close */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* Mode Switcher Buttons */}
            <div className="bg-black/30 p-1 rounded-xl border border-white/20 flex items-center gap-1">
              <button
                type="button"
                onClick={() => setReportMode('monthly')}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all cursor-pointer ${
                  reportMode === 'monthly'
                    ? 'bg-white text-slate-950 shadow-xs'
                    : 'text-rose-100 hover:text-white hover:bg-white/10'
                }`}
              >
                {isAr ? 'التقرير الشهري 📅' : 'Mensuel 📅'}
              </button>
              <button
                type="button"
                onClick={() => setReportMode('annual')}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all cursor-pointer ${
                  reportMode === 'annual'
                    ? 'bg-white text-slate-950 shadow-xs'
                    : 'text-rose-100 hover:text-white hover:bg-white/10'
                }`}
              >
                {isAr ? 'التقرير السنوي 📑' : 'Annuel 📑'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setReportMode('custom_period');
                  setStartYear('2025');
                  setStartMonth('01');
                  setEndYear('2026');
                  setEndMonth('12');
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all cursor-pointer ${
                  reportMode === 'custom_period'
                    ? 'bg-amber-400 text-slate-950 shadow-xs ring-2 ring-amber-300/50'
                    : 'text-rose-100 hover:text-white hover:bg-white/10'
                }`}
              >
                {isAr ? 'حصيلة السنتين (2025 و 2026) ⚖️' : 'Bilan 2 Ans (2025 et 2026) ⚖️'}
              </button>
            </div>

            <button
              onClick={handlePrint}
              type="button"
              id="btn-financial-report-print"
              className="px-3.5 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer border border-white/20 shadow-2xs"
              title={isAr ? 'طباعة مباشرة A4' : 'Imprimer'}
            >
              <Printer className="w-4 h-4 text-amber-300" />
              <span className="hidden sm:inline">{isAr ? 'طباعة' : 'Imprimer'}</span>
            </button>

            <button
              onClick={handleDownloadCSV}
              type="button"
              id="btn-financial-report-csv"
              className="px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer border border-emerald-500/40 shadow-2xs"
              title={isAr ? 'تحميل جدول Excel / CSV' : 'Export CSV'}
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
              <span className="hidden md:inline">{isAr ? 'إكسيل CSV' : 'CSV'}</span>
            </button>

            <button
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              type="button"
              id="btn-financial-report-download-pdf"
              className="px-4 py-2 rounded-xl bg-amber-400 hover:bg-amber-500 active:bg-amber-600 disabled:opacity-50 text-slate-950 text-xs font-black flex items-center gap-2 transition-all shadow-md cursor-pointer border border-amber-300"
            >
              <Download className="w-4 h-4" />
              <span>
                {isGeneratingPdf 
                  ? (isAr ? 'جاري تجهيز PDF...' : 'Génération...') 
                  : (isAr ? 'تحميل PDF 📄' : 'Télécharger PDF')}
              </span>
            </button>

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center text-sm font-bold transition-all cursor-pointer ms-1"
            >
              ✕
            </button>
          </div>
        </div>

        {/* FILTER & CONFIGURATION TOOLBAR (Hidden during Print) */}
        <div className="no-print p-3.5 bg-slate-50 border-b border-slate-200 flex flex-col gap-3 text-xs">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 flex-wrap">
              
              {/* Year & Month Selector for Standard Monthly & Annual Modes */}
              {reportMode !== 'custom_period' && (
                <>
                  <div className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-xl border border-slate-200 shadow-2xs">
                    <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                    <span className="font-bold text-slate-700">{isAr ? 'السنة:' : 'Année:'}</span>
                    <select
                      value={selectedYear}
                      onChange={(e) => setSelectedYear(e.target.value)}
                      className="bg-transparent font-black text-emerald-900 focus:outline-none cursor-pointer text-xs"
                    >
                      <option value="2026">2026</option>
                      <option value="2025">2025</option>
                      <option value="2024">2024</option>
                      <option value="2027">2027</option>
                    </select>
                  </div>

                  {reportMode === 'monthly' && (
                    <div className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-xl border border-slate-200 shadow-2xs">
                      <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                      <span className="font-bold text-slate-700">{isAr ? 'الشهر:' : 'Mois:'}</span>
                      <select
                        value={selectedMonth}
                        onChange={(e) => setSelectedMonth(e.target.value)}
                        className="bg-transparent font-black text-emerald-900 focus:outline-none cursor-pointer text-xs"
                      >
                        {MONTHS_LIST.map(m => (
                          <option key={m.value} value={m.value}>
                            {m.value} - {isAr ? m.labelAr : m.labelFr}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}
                </>
              )}

              {/* CUSTOM PERIOD MANUAL DATE PICKERS (تحديد بداية ونهاية العملية المحاسباتية يدوياً) */}
              {reportMode === 'custom_period' && (
                <div className="flex items-center gap-2 flex-wrap bg-emerald-50/70 p-1.5 rounded-2xl border border-emerald-200">
                  {/* Start Date */}
                  <div className="flex items-center gap-1.5 bg-white px-2.5 py-1.5 rounded-xl border border-emerald-300 shadow-2xs">
                    <span className="font-black text-emerald-900">{isAr ? 'من تاريخ:' : 'Du:'}</span>
                    <select
                      value={startMonth}
                      onChange={(e) => setStartMonth(e.target.value)}
                      className="bg-transparent font-bold text-slate-800 focus:outline-none cursor-pointer text-xs"
                    >
                      {MONTHS_LIST.map(m => (
                        <option key={`sm-${m.value}`} value={m.value}>{m.value} - {isAr ? m.labelAr : m.labelFr}</option>
                      ))}
                    </select>
                    <span className="text-slate-300">/</span>
                    <select
                      value={startYear}
                      onChange={(e) => setStartYear(e.target.value)}
                      className="bg-transparent font-black text-emerald-900 focus:outline-none cursor-pointer text-xs"
                    >
                      <option value="2024">2024</option>
                      <option value="2025">2025</option>
                      <option value="2026">2026</option>
                      <option value="2027">2027</option>
                    </select>
                  </div>

                  <ArrowLeft className={`w-4 h-4 text-emerald-600 hidden sm:inline ${!isAr ? 'rotate-180' : ''}`} />

                  {/* End Date */}
                  <div className="flex items-center gap-1.5 bg-white px-2.5 py-1.5 rounded-xl border border-emerald-300 shadow-2xs">
                    <span className="font-black text-emerald-900">{isAr ? 'إلى غاية شهر:' : 'Au:'}</span>
                    <select
                      value={endMonth}
                      onChange={(e) => setEndMonth(e.target.value)}
                      className="bg-transparent font-bold text-slate-800 focus:outline-none cursor-pointer text-xs"
                    >
                      {MONTHS_LIST.map(m => (
                        <option key={`em-${m.value}`} value={m.value}>{m.value} - {isAr ? m.labelAr : m.labelFr}</option>
                      ))}
                    </select>
                    <span className="text-slate-300">/</span>
                    <select
                      value={endYear}
                      onChange={(e) => setEndYear(e.target.value)}
                      className="bg-transparent font-black text-emerald-900 focus:outline-none cursor-pointer text-xs"
                    >
                      <option value="2024">2024</option>
                      <option value="2025">2025</option>
                      <option value="2026">2026</option>
                      <option value="2027">2027</option>
                    </select>
                  </div>

                  {/* Range count pill */}
                  <span className="px-2.5 py-1 rounded-xl bg-emerald-700 text-white text-xs font-black shadow-xs">
                    {periodMonthKeys.length} {isAr ? 'أشهر مدمجة' : 'mois'}
                  </span>
                </div>
              )}

              {/* Building Filter */}
              <div className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-xl border border-slate-200 shadow-2xs">
                <Building2 className="w-3.5 h-3.5 text-emerald-700" />
                <span className="font-bold text-slate-700">{isAr ? 'العمارة:' : 'Immeuble:'}</span>
                <select
                  value={selectedBuilding}
                  onChange={(e) => setSelectedBuilding(e.target.value)}
                  className="bg-transparent font-black text-emerald-900 focus:outline-none cursor-pointer text-xs max-w-[200px]"
                >
                  <option value="ALL">{isAr ? '🏢 كافة الإقامة (جميع العمارات / جميع الشقق)' : 'tous les immeubles'}</option>
                  {buildings.map(b => (
                    <option key={b.code} value={b.code}>{b.code} - {b.name}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Section Toggles */}
            <div className="flex items-center gap-2 flex-wrap">
              <label className="flex items-center gap-1.5 cursor-pointer select-none text-[11px] text-slate-700 font-bold bg-white px-2.5 py-1.5 rounded-xl border border-slate-200 shadow-2xs">
                <input 
                  type="checkbox" 
                  checked={showCharts} 
                  onChange={(e) => setShowCharts(e.target.checked)} 
                  className="rounded text-emerald-600"
                />
                <BarChart3 className="w-3.5 h-3.5 text-emerald-700" />
                <span>{isAr ? 'الرسوم البيانية' : 'Graphiques'}</span>
              </label>

              <label className="flex items-center gap-1.5 cursor-pointer select-none text-[11px] text-slate-700 font-bold bg-white px-2.5 py-1.5 rounded-xl border border-slate-200 shadow-2xs">
                <input 
                  type="checkbox" 
                  checked={showSyndicFees} 
                  onChange={(e) => setShowSyndicFees(e.target.checked)} 
                  className="rounded text-emerald-600"
                />
                <Briefcase className="w-3.5 h-3.5 text-amber-700" />
                <span>{isAr ? 'أتعاب إدارة السانديك' : 'Honoraires Syndic'}</span>
              </label>

              <label className="flex items-center gap-1.5 cursor-pointer select-none text-[11px] text-slate-700 font-bold bg-white px-2.5 py-1.5 rounded-xl border border-slate-200 shadow-2xs">
                <input 
                  type="checkbox" 
                  checked={showExpensesDetail} 
                  onChange={(e) => setShowExpensesDetail(e.target.checked)} 
                  className="rounded text-emerald-600"
                />
                <TrendingDown className="w-3.5 h-3.5 text-rose-600" />
                <span>{isAr ? 'المصاريف' : 'Dépenses'}</span>
              </label>

              <label className="flex items-center gap-1.5 cursor-pointer select-none text-[11px] text-slate-700 font-bold bg-white px-2.5 py-1.5 rounded-xl border border-slate-200 shadow-2xs">
                <input 
                  type="checkbox" 
                  checked={showCarryoverTable} 
                  onChange={(e) => setShowCarryoverTable(e.target.checked)} 
                  className="rounded text-emerald-600"
                />
                <ArrowRightLeft className="w-3.5 h-3.5 text-blue-600" />
                <span>{isAr ? 'جدول ترحيل الفائض/الناقص' : 'Report à Nouveau'}</span>
              </label>
            </div>
          </div>

          {/* QUICK PRESETS ROW WHEN IN CUSTOM PERIOD MODE */}
          {reportMode === 'custom_period' && (
            <div className="pt-2 border-t border-slate-200 flex items-center justify-between gap-2 flex-wrap">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[11px] font-black text-slate-600 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>{isAr ? 'نماذج دمج سريعة:' : 'Raccourcis de Fusion:'}</span>
                </span>
                
                {/* 1. دمج السنتين الأخيرتين (2025 - 2026) - الخيار الرئيسي المطلوب */}
                <button
                  type="button"
                  onClick={() => handleApplyPreset('two_years_25_26')}
                  className={`px-3 py-1.5 rounded-xl font-black text-xs transition-all cursor-pointer shadow-xs border ${
                    startYear === '2025' && endYear === '2026'
                      ? 'bg-amber-400 text-slate-950 border-amber-500 ring-2 ring-amber-300'
                      : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-950 border-indigo-200'
                  }`}
                  title="دمج السنتين الأخيرتين 2025 و 2026 كاملتين (24 شهراً)"
                >
                  ⭐ {isAr ? 'حصيلة السنتين الأخيرتين (2025 و 2026)' : 'Bilan 2 Dernières Années (2025 & 2026)'}
                </button>

                {/* 2. دمج العامين السابقين (2024 - 2025) */}
                <button
                  type="button"
                  onClick={() => handleApplyPreset('last_2_years')}
                  className="px-2.5 py-1 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 font-bold text-[11px] transition-all cursor-pointer shadow-2xs"
                  title="دمج السنتين 2024 و 2025 كاملتين (24 شهراً)"
                >
                  {isAr ? 'دمج العامين (2024 - 2025)' : 'Fusion 2024 - 2025'}
                </button>

                {/* 3. سنة 2026 كاملة */}
                <button
                  type="button"
                  onClick={() => {
                    setStartYear('2026');
                    setStartMonth('01');
                    setEndYear('2026');
                    setEndMonth('12');
                  }}
                  className="px-2.5 py-1 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-950 border border-sky-300 font-bold text-[11px] transition-all cursor-pointer shadow-2xs"
                  title="سنة 2026 كاملة (12 شهراً)"
                >
                  {isAr ? 'سنة 2026 كاملة' : 'Année 2026'}
                </button>

                {/* 4. سنة 2025 كاملة */}
                <button
                  type="button"
                  onClick={() => handleApplyPreset('year_2025')}
                  className="px-2 py-1 rounded-xl bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 font-bold text-[11px] transition-all cursor-pointer shadow-2xs"
                  title="سنة 2025 كاملة (12 شهراً)"
                >
                  {isAr ? 'سنة 2025 كاملة' : 'Année 2025'}
                </button>

                {/* 5. آخر 6 أشهر */}
                <button
                  type="button"
                  onClick={() => handleApplyPreset('last_6_months')}
                  className="px-2 py-1 rounded-xl bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 font-bold text-[11px] transition-all cursor-pointer shadow-2xs"
                >
                  {isAr ? 'آخر 6 أشهر' : '6 derniers mois'}
                </button>
              </div>

              {/* Editable starting opening balance in custom period */}
              <div className="flex items-center gap-1.5 text-[11px]">
                <span className="text-slate-600 font-bold">
                  {isAr ? 'المنقول ببداية الفترة:' : 'Report initial:'}
                </span>
                {!isEditingCustomOpening ? (
                  <div className="flex items-center gap-1.5 bg-white px-2.5 py-1 rounded-xl border border-slate-200">
                    <span className="font-mono font-black text-indigo-950">
                      {effectiveCarriedBalance >= 0 ? '+' : ''}{effectiveCarriedBalance.toLocaleString()} DH
                    </span>
                    {customOpeningOverride !== '' && (
                      <span className="px-1.5 py-0.2 rounded bg-amber-100 text-amber-900 text-[9px] font-black">
                        {isAr ? 'يدوي' : 'Manuel'}
                      </span>
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        setTempCustomOpening(String(effectiveCarriedBalance));
                        setIsEditingCustomOpening(true);
                      }}
                      className="p-1 rounded hover:bg-slate-100 text-slate-600 hover:text-indigo-600 cursor-pointer"
                      title={isAr ? 'تعديل الرصيد المنقول لبداية الفترة يدوياً' : 'Modifier le solde initial'}
                    >
                      <Edit3 className="w-3 h-3" />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-indigo-400">
                    <input
                      type="number"
                      value={tempCustomOpening}
                      onChange={(e) => setTempCustomOpening(e.target.value)}
                      placeholder="0"
                      className="w-20 px-1 py-0.5 text-xs font-mono font-black border border-slate-200 rounded text-end"
                      autoFocus
                    />
                    <button
                      type="button"
                      onClick={handleSaveCustomOpening}
                      className="px-2 py-0.5 rounded bg-indigo-700 text-white font-bold text-[10px] cursor-pointer"
                    >
                      {isAr ? 'حفظ' : 'OK'}
                    </button>
                    <button
                      type="button"
                      onClick={handleResetCustomOpening}
                      className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-bold text-[10px] cursor-pointer"
                      title={isAr ? 'استعادة الحساب التلقائي' : 'Rétablir auto'}
                    >
                      ↺
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Section Toggles */}
          <div className="flex items-center gap-2 flex-wrap">
            <label className="flex items-center gap-1.5 cursor-pointer select-none text-[11px] text-slate-700 font-bold bg-white px-2.5 py-1.5 rounded-xl border border-slate-200 shadow-2xs">
              <input 
                type="checkbox" 
                checked={showCharts} 
                onChange={(e) => setShowCharts(e.target.checked)} 
                className="rounded text-emerald-600"
              />
              <BarChart3 className="w-3.5 h-3.5 text-emerald-700" />
              <span>{isAr ? 'الرسوم البيانية' : 'Graphiques'}</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer select-none text-[11px] text-slate-700 font-bold bg-white px-2.5 py-1.5 rounded-xl border border-slate-200 shadow-2xs">
              <input 
                type="checkbox" 
                checked={showSyndicFees} 
                onChange={(e) => setShowSyndicFees(e.target.checked)} 
                className="rounded text-emerald-600"
              />
              <Briefcase className="w-3.5 h-3.5 text-amber-700" />
              <span>{isAr ? 'أتعاب إدارة السانديك' : 'Honoraires Syndic'}</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer select-none text-[11px] text-slate-700 font-bold bg-white px-2.5 py-1.5 rounded-xl border border-slate-200 shadow-2xs">
              <input 
                type="checkbox" 
                checked={showExpensesDetail} 
                onChange={(e) => setShowExpensesDetail(e.target.checked)} 
                className="rounded text-emerald-600"
              />
              <TrendingDown className="w-3.5 h-3.5 text-rose-600" />
              <span>{isAr ? 'المصاريف' : 'Dépenses'}</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer select-none text-[11px] text-slate-700 font-bold bg-white px-2.5 py-1.5 rounded-xl border border-slate-200 shadow-2xs">
              <input 
                type="checkbox" 
                checked={showCarryoverTable} 
                onChange={(e) => setShowCarryoverTable(e.target.checked)} 
                className="rounded text-emerald-600"
              />
              <ArrowRightLeft className="w-3.5 h-3.5 text-blue-600" />
              <span>{isAr ? 'جدول ترحيل الفائض/الناقص' : 'Report à Nouveau'}</span>
            </label>
          </div>
        </div>

        {/* Success / Alert Banner */}
        {exportSuccessMsg && (
          <div className="no-print bg-emerald-600 text-white px-4 py-2.5 text-xs font-bold flex items-center justify-between animate-in fade-in">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-200" />
              <span>{exportSuccessMsg}</span>
            </div>
            <button onClick={() => setExportSuccessMsg(null)} className="cursor-pointer">✕</button>
          </div>
        )}

        {/* ========================================================================= */}
        {/* SCROLLABLE OFFICIAL REPORT CONTAINER (Captured by PDF & Printed cleanly)  */}
        {/* ========================================================================= */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-100/70 space-y-6">

          {/* DEDICATED INTERACTIVE 2-YEAR MANUAL ADJUSTMENT PANEL (UN SEUL BILAN DE 2ANS - FAIT MANUEL) */}
          {reportMode === 'custom_period' && (
            <div 
              data-html2canvas-ignore 
              className="no-print max-w-5xl mx-auto bg-gradient-to-br from-amber-50 via-orange-50/60 to-amber-100/80 rounded-2xl border-2 border-amber-300 p-4 sm:p-5 shadow-sm space-y-4"
            >
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-amber-200 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-xs shrink-0">
                    <Edit3 className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm sm:text-base font-black text-amber-950">
                        {isAr ? 'لوحة إدخال وتعديل حصيلة السنتين يدوياً (Fait Manuel)' : 'Panneau de Saisie Manuelle du Bilan de 2 Ans (Fait Manuel)'}
                      </h3>
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black border ${
                        manualBilan.isManualActive 
                          ? 'bg-emerald-600 text-white border-emerald-500 shadow-2xs' 
                          : 'bg-amber-200 text-amber-900 border-amber-300'
                      }`}>
                        {manualBilan.isManualActive 
                          ? (isAr ? '✍️ الوضع اليدوي مفعل' : '✍️ Mode Manuel Actif') 
                          : (isAr ? '⚡ حساب تلقائي من النظام' : '⚡ Calcul Système')}
                      </span>
                    </div>
                    <p className="text-xs text-amber-800 font-medium mt-0.5">
                      {isAr 
                        ? 'تحديد التاريخ (بداية ونهاية) • المنقول • المداخيل • أجور العمال • السانديك • المحامي • المفوض • العقاقير • السيولة • المصاريف • الباقي' 
                        : 'Détermination de la date (début - fin) • Report • Recettes • Salaires • Syndic • Avocat • Huissier • Droguerie • Total Disponible • Dépenses • Solde Restant'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    type="button"
                    onClick={handlePopulateFromSystem}
                    className="px-3 py-1.5 rounded-xl bg-white hover:bg-amber-100 text-amber-950 font-black text-xs border border-amber-300 shadow-2xs transition-all flex items-center gap-1.5 cursor-pointer"
                    title={isAr ? 'استيراد الأرقام المحسوبة من معاملات النظام وملء الخانات بها للتعديل الفوري' : 'Pré-remplir les champs avec les chiffres calculés'}
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-amber-700" />
                    <span>{isAr ? '🔄 استيراد أرقام النظام' : '🔄 Remplir depuis système'}</span>
                  </button>

                  {manualBilan.isManualActive && (
                    <button
                      type="button"
                      onClick={handleResetManualBilanToAuto}
                      className="px-3 py-1.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs transition-all flex items-center gap-1 cursor-pointer"
                      title={isAr ? 'إلغاء الإدخال اليدوي والعودة للحساب التلقائي من قاعدة البيانات' : 'Rétablir le calcul automatique'}
                    >
                      <span>{isAr ? '↺ استعادة التلقائي' : '↺ Rétablir auto'}</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => setIsManualPanelOpen(!isManualPanelOpen)}
                    className="p-1.5 rounded-xl bg-white/80 hover:bg-white text-amber-900 border border-amber-300 text-xs font-bold cursor-pointer"
                    title={isManualPanelOpen ? (isAr ? 'طي النموذج' : 'Réduire') : (isAr ? 'فتح النموذج' : 'Déplier')}
                  >
                    {isManualPanelOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {isManualPanelOpen && (
                <div className="space-y-4">
                  {/* 7 Core Requested Items Input Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                    
                    {/* 1. Report */}
                    <div className="p-3 bg-white rounded-xl border border-indigo-200 shadow-2xs space-y-1">
                      <label className="text-[11px] font-black text-indigo-950 flex items-center justify-between">
                        <span>1. {isAr ? 'المنقول (Report)' : 'Report'}</span>
                        <History className="w-3.5 h-3.5 text-indigo-600" />
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          value={tempManualReport}
                          onChange={e => setTempManualReport(e.target.value)}
                          placeholder="0"
                          className="w-full pe-9 ps-2 py-1.5 font-mono font-black text-sm text-indigo-950 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-slate-50/50"
                        />
                        <span className="absolute end-2 top-1/2 -translate-y-1/2 text-[10px] font-bold text-slate-400">DH</span>
                      </div>
                      <p className="text-[10px] text-slate-500">{isAr ? 'الرصيد المنقول ما قبل الفترة' : 'Solde antérieur'}</p>
                    </div>

                    {/* 2. Recettes */}
                    <div className="p-3 bg-white rounded-xl border border-emerald-200 shadow-2xs space-y-1">
                      <label className="text-[11px] font-black text-emerald-950 flex items-center justify-between">
                        <span>2. {isAr ? 'المداخيل (Recettes)' : 'Recettes'}</span>
                        <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          value={tempManualRecettes}
                          onChange={e => setTempManualRecettes(e.target.value)}
                          placeholder="0"
                          className="w-full pe-9 ps-2 py-1.5 font-mono font-black text-sm text-emerald-950 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-slate-50/50"
                        />
                        <span className="absolute end-2 top-1/2 -translate-y-1/2 text-[10px] font-bold text-slate-400">DH</span>
                      </div>
                      <p className="text-[10px] text-slate-500">{isAr ? 'مقبوضات واشتراكات الفترة' : 'Cotisations encaissées'}</p>
                    </div>

                    {/* 3. Salaires */}
                    <div className="p-3 bg-white rounded-xl border border-sky-200 shadow-2xs space-y-1">
                      <label className="text-[11px] font-black text-sky-950 flex items-center justify-between">
                        <span>3. {isAr ? 'أجور العمال (Salaires)' : 'Salaires'}</span>
                        <Users className="w-3.5 h-3.5 text-sky-600" />
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          value={tempManualSalaires}
                          onChange={e => setTempManualSalaires(e.target.value)}
                          placeholder="0"
                          className="w-full pe-9 ps-2 py-1.5 font-mono font-black text-sm text-sky-950 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500 bg-slate-50/50"
                        />
                        <span className="absolute end-2 top-1/2 -translate-y-1/2 text-[10px] font-bold text-slate-400">DH</span>
                      </div>
                      <p className="text-[10px] text-slate-500">{isAr ? 'حراس الأمن، النظافة، البستاني' : 'Agents de garde et ouvriers'}</p>
                    </div>

                    {/* 4. Syndic */}
                    <div className="p-3 bg-white rounded-xl border border-amber-200 shadow-2xs space-y-1">
                      <label className="text-[11px] font-black text-amber-950 flex items-center justify-between">
                        <span>4. {isAr ? 'أجرة الوكيل (Syndic)' : 'Syndic'}</span>
                        <Briefcase className="w-3.5 h-3.5 text-amber-600" />
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          value={tempManualSyndic}
                          onChange={e => setTempManualSyndic(e.target.value)}
                          placeholder="0"
                          className="w-full pe-9 ps-2 py-1.5 font-mono font-black text-sm text-amber-950 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 bg-slate-50/50"
                        />
                        <span className="absolute end-2 top-1/2 -translate-y-1/2 text-[10px] font-bold text-slate-400">DH</span>
                      </div>
                      <p className="text-[10px] text-slate-500">{isAr ? 'أتعاب الوكيل ونائبه' : 'Honoraires syndic & adjoint'}</p>
                    </div>

                    {/* 5. Avocat */}
                    <div className="p-3 bg-white rounded-xl border border-purple-200 shadow-2xs space-y-1">
                      <label className="text-[11px] font-black text-purple-950 flex items-center justify-between">
                        <span>5. {isAr ? 'أتعاب المحامي (Avocat)' : 'Avocat'}</span>
                        <Scale className="w-3.5 h-3.5 text-purple-600" />
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          value={tempManualAvocat}
                          onChange={e => setTempManualAvocat(e.target.value)}
                          placeholder="0"
                          className="w-full pe-9 ps-2 py-1.5 font-mono font-black text-sm text-purple-950 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-purple-500 bg-slate-50/50"
                        />
                        <span className="absolute end-2 top-1/2 -translate-y-1/2 text-[10px] font-bold text-slate-400">DH</span>
                      </div>
                      <p className="text-[10px] text-slate-500">{isAr ? 'ملفات ونزاعات المحاكم' : 'Honoraires avocat'}</p>
                    </div>

                    {/* 6. Huissier */}
                    <div className="p-3 bg-white rounded-xl border border-rose-200 shadow-2xs space-y-1">
                      <label className="text-[11px] font-black text-rose-950 flex items-center justify-between">
                        <span>6. {isAr ? 'أتعاب المفوض (Huissier)' : 'Huissier'}</span>
                        <Gavel className="w-3.5 h-3.5 text-rose-600" />
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          value={tempManualHuissier}
                          onChange={e => setTempManualHuissier(e.target.value)}
                          placeholder="0"
                          className="w-full pe-9 ps-2 py-1.5 font-mono font-black text-sm text-rose-950 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-rose-500 bg-slate-50/50"
                        />
                        <span className="absolute end-2 top-1/2 -translate-y-1/2 text-[10px] font-bold text-slate-400">DH</span>
                      </div>
                      <p className="text-[10px] text-slate-500">{isAr ? 'إنذارات وتبليغات قضائية' : 'Frais huissier de justice'}</p>
                    </div>

                    {/* 7. Droguerie & Divers */}
                    <div className="p-3 bg-white rounded-xl border border-orange-200 shadow-2xs space-y-1 lg:col-span-2">
                      <label className="text-[11px] font-black text-orange-950 flex items-center justify-between">
                        <span>7. {isAr ? 'العقاقير ومصاريف مختلفة (Droguerie)' : 'Droguerie & Divers'}</span>
                        <Wrench className="w-3.5 h-3.5 text-orange-600" />
                      </label>
                      <div className="relative">
                        <input
                          type="number"
                          value={tempManualDroguerie}
                          onChange={e => setTempManualDroguerie(e.target.value)}
                          placeholder="0"
                          className="w-full pe-9 ps-2 py-1.5 font-mono font-black text-sm text-orange-950 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-orange-500 bg-slate-50/50"
                        />
                        <span className="absolute end-2 top-1/2 -translate-y-1/2 text-[10px] font-bold text-slate-400">DH</span>
                      </div>
                      <p className="text-[10px] text-slate-500">{isAr ? 'عقاقير، إسمنت، مضخات سقي، إنارة، سباكة، صيانة' : 'Droguerie, quincaillerie, ciment, arrosage...'}</p>
                    </div>

                  </div>

                  {/* Real-time Live Computed Totals: 8. Total Disponible • 9. Dépenses • 10. Solde Restant */}
                  <div className="p-3.5 rounded-xl bg-white/95 border-2 border-amber-300 grid grid-cols-1 sm:grid-cols-3 gap-3 shadow-2xs">
                    {/* 8. Total Disponible */}
                    <div className="p-2.5 rounded-xl bg-cyan-50/90 border border-cyan-200 text-center">
                      <div className="text-[10px] font-extrabold text-cyan-900">
                        8. {isAr ? 'مجموع المداخيل مع المنقول' : 'Total Disponible'} (1 + 2)
                      </div>
                      <div className="text-base sm:text-lg font-black font-mono text-cyan-950 mt-1">
                        {liveFormTotalDisponible.toLocaleString()} <span className="text-xs font-normal">DH</span>
                      </div>
                      <div className="text-[9px] text-cyan-700 font-medium mt-0.5">
                        {isAr ? 'السيولة الإجمالية المتاحة' : 'Disponibilités en caisse'}
                      </div>
                    </div>

                    {/* 9. Dépenses */}
                    <div className="p-2.5 rounded-xl bg-rose-50/90 border border-rose-200 text-center">
                      <div className="text-[10px] font-extrabold text-rose-900">
                        9. {isAr ? 'مجموع المصاريف' : 'Total Dépenses'} (3+4+5+6+7)
                      </div>
                      <div className="text-base sm:text-lg font-black font-mono text-rose-950 mt-1">
                        -{liveFormDepenses.toLocaleString()} <span className="text-xs font-normal">DH</span>
                      </div>
                      <div className="text-[9px] text-rose-700 font-medium mt-0.5">
                        {isAr ? 'كافة النفقات (100%)' : 'Total des charges'}
                      </div>
                    </div>

                    {/* 10. Solde Restant */}
                    <div className={`p-2.5 rounded-xl border-2 text-center ${
                      liveFormSoldeRestant >= 0 ? 'bg-emerald-100/80 border-emerald-400' : 'bg-rose-100/80 border-rose-400'
                    }`}>
                      <div className="text-[10px] font-black text-slate-800">
                        10. {isAr ? 'الباقي النهائي الصافي' : 'Solde Restant'} (8 - 9)
                      </div>
                      <div className={`text-base sm:text-lg font-black font-mono mt-1 ${liveFormSoldeRestant >= 0 ? 'text-emerald-950' : 'text-rose-950'}`}>
                        {liveFormSoldeRestant >= 0 ? '+' : ''}{liveFormSoldeRestant.toLocaleString()} <span className="text-xs font-normal">DH</span>
                      </div>
                      <div className="text-[9px] font-black text-slate-700 mt-0.5">
                        {liveFormSoldeRestant >= 0 ? (isAr ? '🟢 فائض مرحّل' : '🟢 Excédent') : (isAr ? '🔴 عجز مرحّل' : '🔴 Déficit')}
                      </div>
                    </div>
                  </div>

                  {/* Save button and status */}
                  <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                    <div className="text-[11px] text-slate-600 font-bold flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-600" />
                      <span>
                        {manualBilan.savedAt 
                          ? (isAr ? `آخر حفظ مثبت: ${new Date(manualBilan.savedAt).toLocaleDateString()} ${new Date(manualBilan.savedAt).toLocaleTimeString()}` : `Dernier enregistrement: ${new Date(manualBilan.savedAt).toLocaleString()}`)
                          : (isAr ? 'لم يتم حفظ بيانات يدوية لهذه الفترة بعد' : 'Aucune donnée manuelle enregistrée')}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={handleSaveManualBilan}
                      className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-700 to-teal-800 hover:from-emerald-600 hover:to-teal-700 text-white font-black text-xs shadow-md transition-all flex items-center gap-2 cursor-pointer border border-emerald-500"
                    >
                      <CheckCircle2 className="w-4 h-4 text-emerald-200" />
                      <span>{isAr ? '💾 حفظ وتثبيت أرقام الحصيلة اليدوية' : '💾 Enregistrer et Valider le Bilan Manuel'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          <div 
            id="financial-report-print-container"
            className="bg-transparent max-w-5xl mx-auto space-y-6 text-slate-900 font-sans print:p-0 print:border-none print:shadow-none"
          >
            {/* ========================================================================= */}
            {/* PAGE BLOCK 1: MASTER FINANCIAL STATEMENT, PERCENTAGES & VISUAL CHARTS     */}
            {/* Exactly fits 1 A4 page with zero cut-off / uninterrupted print            */}
            {/* ========================================================================= */}
            <div className="pdf-page-block print-avoid-break bg-white p-6 sm:p-8 rounded-2xl border-2 border-slate-300 shadow-sm space-y-5">
              
              {/* OFFICIAL HEADER WITH EXACT RESIDENCE NAME */}
              <div className="border-b-2 border-[#0a8591] pb-4">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-start">
                  <div className="space-y-1">
                    <div className="text-[11px] font-extrabold text-slate-600 uppercase tracking-wider flex items-center justify-center sm:justify-start gap-1.5">
                      <span>المملكة المغربية</span>
                      <span>•</span>
                      <span></span>
                      <span>•</span>
                      <span>اتحاد الملاك المشتركين</span>
                    </div>
                    
                    <h1 className="text-xl sm:text-2xl font-black text-[#0a8591] tracking-tight leading-tight">
                      {RES.fullNameAr}
                    </h1>
                    
                    <div className="text-xs font-bold text-slate-700 flex items-center justify-center sm:justify-start gap-1.5">
                      <span>{RES.fullNameFr}</span>
                    </div>
                    <div className="text-[11px] text-slate-600 font-semibold">
                      {isAr ? 'جميع العمارات • جميع الشقق' : 'tous les immeubles • tous les lots'}
                    </div>
                  </div>

                  <div className="p-3 sm:p-3.5 rounded-2xl bg-[#e9fbf8] border-2 border-[#0d5262] text-center sm:text-end shrink-0 shadow-2xs">
                    <div className="text-[10px] font-extrabold text-[#0a8591] uppercase tracking-wider flex items-center justify-center sm:justify-end gap-1.5">
                      <span>
                        {reportMode === 'annual' 
                          ? (isAr ? 'الحصيلة والتقرير المالي السنوي المعتمد' : 'Bilan Financier Annuel') 
                          : reportMode === 'custom_period'
                            ? (isAr ? 'حصيلة السنتين الموحدة (سجل يدوي معتمد)' : 'UN SEUL BILAN DE 2 ANS (FAIT MANUEL)')
                            : (isAr ? 'التقرير المالي والمحاسباتي الشهري' : 'Rapport Financier Mensuel')}
                      </span>
                      {reportMode === 'custom_period' && (
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-black border ${
                          manualBilan.isManualActive 
                            ? 'bg-emerald-600 text-white border-emerald-500' 
                            : 'bg-amber-400 text-slate-950 border-amber-300'
                        }`}>
                          {manualBilan.isManualActive 
                            ? (isAr ? 'سجل يدوي ✍️' : 'Fait Manuel ✍️') 
                            : (isAr ? 'تلقائي ⚡' : 'Auto ⚡')}
                        </span>
                      )}
                    </div>
                    <div className="text-base sm:text-lg font-black text-[#0f172a] mt-0.5 font-mono">
                      {periodTitle}
                    </div>
                    <div className="text-[10px] text-slate-600 mt-0.5 font-semibold">
                      {isAr ? `تاريخ الإصدار: ${today.toISOString().slice(0, 10)}` : `Émis le: ${today.toISOString().slice(0, 10)}`}
                    </div>
                  </div>
                </div>

                {selectedBuilding !== 'ALL' && (
                  <div className="mt-2.5 px-3 py-1 rounded-xl bg-slate-100 text-xs font-bold text-slate-800 inline-flex items-center gap-1.5 border border-slate-200">
                    <Building2 className="w-3.5 h-3.5 text-[#0a8591]" />
                    <span>{isAr ? `نطاق التقرير المحدد: عمارة ${selectedBuilding}` : `Périmètre : Immeuble ${selectedBuilding}`}</span>
                  </div>
                )}
              </div>

              {/* 5 MAIN FINANCIAL KPI CARDS */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-xs">
                {/* 1. المنقول */}
                <div className="p-2.5 rounded-xl bg-indigo-50/80 border border-indigo-200">
                  <div className="text-[10px] text-indigo-900 font-bold flex items-center justify-between">
                    <span>{reportMode === 'annual' ? (isAr ? '1. منقول السنة السابقة' : '1. Report Année') : reportMode === 'custom_period' ? (isAr ? '1. المنقول (Report)' : '1. Report') : (isAr ? '1. منقول الشهر السابق' : '1. Report Mois')}</span>
                    <History className="w-3.5 h-3.5 text-indigo-600" />
                  </div>
                  <div className={`text-base sm:text-lg font-black font-mono mt-1 ${masterFinancialStatement.carriedBalance >= 0 ? 'text-indigo-950' : 'text-rose-700'}`}>
                    {masterFinancialStatement.carriedBalance >= 0 ? '+' : ''}{masterFinancialStatement.carriedBalance.toLocaleString()} <span className="text-[10px] font-sans font-normal">DH</span>
                  </div>
                  <div className="text-[9px] text-indigo-700 font-medium truncate mt-0.5">
                    {isAr ? 'الرصيد الافتتاحي المرحل' : 'Solde antérieur'}
                  </div>
                </div>

                {/* 2. المداخيل */}
                <div className="p-2.5 rounded-xl bg-emerald-50/80 border border-emerald-200">
                  <div className="text-[10px] text-emerald-900 font-bold flex items-center justify-between">
                    <span>{isAr ? '2. المداخيل (Recettes)' : '2. Recettes'}</span>
                    <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
                  </div>
                  <div className="text-base sm:text-lg font-black font-mono mt-1 text-emerald-950">
                    +{masterFinancialStatement.income.toLocaleString()} <span className="text-[10px] font-sans font-normal">DH</span>
                  </div>
                  <div className="text-[9px] text-emerald-700 font-medium truncate mt-0.5">
                    {isAr ? 'مقبوضات واجبات السانديك' : 'Cotisations perçues'}
                  </div>
                </div>

                {/* 3. إجمالي السيولة */}
                <div className="p-2.5 rounded-xl bg-cyan-50/80 border border-cyan-200">
                  <div className="text-[10px] text-cyan-900 font-bold flex items-center justify-between">
                    <span>{isAr ? '3. المداخيل مع المنقول (Total Disponible)' : '3. Total Disponible'}</span>
                    <Sparkles className="w-3.5 h-3.5 text-cyan-600" />
                  </div>
                  <div className="text-base sm:text-lg font-black font-mono mt-1 text-cyan-950">
                    {masterFinancialStatement.totalIncomeWithCarried.toLocaleString()} <span className="text-[10px] font-sans font-normal">DH</span>
                  </div>
                  <div className="text-[9px] text-cyan-700 font-medium truncate mt-0.5">
                    {isAr ? 'الخانة 1 + الخانة 2' : 'Case 1 + 2'}
                  </div>
                </div>

                {/* 4. مجموع المصاريف */}
                <div className="p-2.5 rounded-xl bg-rose-50/80 border border-rose-200">
                  <div className="text-[10px] text-rose-900 font-bold flex items-center justify-between">
                    <span>{isAr ? '4. مجموع المصاريف (Dépenses)' : '4. Dépenses'}</span>
                    <TrendingDown className="w-3.5 h-3.5 text-rose-600" />
                  </div>
                  <div className="text-base sm:text-lg font-black font-mono mt-1 text-rose-950">
                    -{masterFinancialStatement.totalExpenses.toLocaleString()} <span className="text-[10px] font-sans font-normal">DH</span>
                  </div>
                  <div className="text-[9px] text-rose-700 font-medium truncate mt-0.5">
                    {isAr ? 'كافة النفقات المؤداة (100%)' : 'Charges décaissées'}
                  </div>
                </div>

                {/* 5. الباقي النهائي */}
                <div className={`p-2.5 rounded-xl border-2 ${
                  masterFinancialStatement.remainingBalance >= 0 
                    ? 'bg-emerald-100/70 border-emerald-400' 
                    : 'bg-rose-100/70 border-rose-400'
                }`}>
                  <div className="text-[10px] font-bold text-slate-800 flex items-center justify-between">
                    <span>{isAr ? '5. الباقي النهائي الصافي (Solde Restant)' : '5. Solde Restant'}</span>
                    <Wallet className={`w-3.5 h-3.5 ${masterFinancialStatement.remainingBalance >= 0 ? 'text-emerald-700' : 'text-rose-700'}`} />
                  </div>
                  <div className={`text-base sm:text-lg font-black font-mono mt-1 ${masterFinancialStatement.remainingBalance >= 0 ? 'text-emerald-950' : 'text-rose-950'}`}>
                    {masterFinancialStatement.remainingBalance >= 0 ? '+' : ''}{masterFinancialStatement.remainingBalance.toLocaleString()} <span className="text-[10px] font-sans font-normal">DH</span>
                  </div>
                  <div className="text-[9px] font-bold text-slate-700 truncate mt-0.5">
                    {masterFinancialStatement.remainingBalance >= 0 ? (isAr ? '🟢 فائض مرحّل' : '🟢 Excédent') : (isAr ? '🔴 عجز مرحّل' : '🔴 Déficit')}
                  </div>
                </div>
              </div>

              {/* ========================================================================= */}
              {/* THE EXACT 10-ITEM MASTER FINANCIAL STATEMENT TABLE AS REQUESTED           */}
              {/* ========================================================================= */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg bg-[#0a8591] text-white flex items-center justify-center text-xs font-bold shadow-xs">
                      <TableIcon className="w-3.5 h-3.5" />
                    </div>
                    <h2 className="text-sm sm:text-base font-black text-slate-900">
                      {isAr 
                        ? 'الجدول المالي والمحاسباتي الرسمي المعتمد (الخانات العشر المحددة)' 
                        : 'Tableau Financier Officiel de Synthèse (Les 10 Postes)'}
                    </h2>
                  </div>
                  <span className="text-[11px] font-mono font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-lg border border-slate-200">
                    {reportMode === 'annual' ? (isAr ? 'حصيلة سنوية كاملة' : 'Exercice Annuel') : (isAr ? `شهر ${selectedMonth}/${selectedYear}` : `Mois ${selectedMonth}/${selectedYear}`)}
                  </span>
                </div>

                <div className="overflow-x-auto rounded-xl border-2 border-slate-300 shadow-xs bg-white">
                  <table className="w-full text-xs text-start border-collapse">
                    <thead className="bg-slate-900 text-white font-black text-xs">
                      <tr>
                        <th className="p-2.5 text-center w-12 border-e border-slate-700">{isAr ? 'الرقم' : 'N°'}</th>
                        <th className="p-2.5 text-start min-w-[200px] border-e border-slate-700">{isAr ? 'البيان المحاسبي المعتمد' : 'Poste Budgétaire'}</th>
                        <th className="p-2.5 text-start min-w-[220px] hidden md:table-cell border-e border-slate-700">{isAr ? 'التفصيل والتوضيح' : 'Détails & Nature'}</th>
                        <th className="p-2.5 text-center min-w-[90px] border-e border-slate-700">{isAr ? 'النسبة (%)' : 'Part (%)'}</th>
                        <th className="p-2.5 text-end min-w-[130px]">{isAr ? 'المبلغ (درهم)' : 'Montant (DH)'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 font-mono">
                      {/* 1. المرحل من الشهر السابق أو بداية الفترة */}
                      <tr className="bg-indigo-50/60 hover:bg-indigo-50 transition-colors">
                        <td className="p-2.5 text-center font-black text-indigo-900 border-e border-slate-200">1</td>
                        <td className="p-2.5 font-sans font-black text-indigo-950 border-e border-slate-200 flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <History className="w-4 h-4 text-indigo-700" />
                            <span>
                              {reportMode === 'annual' 
                                ? (isAr ? 'المرحل من السنة السابقة (Report)' : 'Report de l\'Année Précédente') 
                                : reportMode === 'custom_period'
                                  ? (isAr ? 'المنقول الافتتاحي السابق (Report)' : 'Report au Début de la Période')
                                  : (isAr ? 'المرحل من الشهر السابق (Report)' : 'Report du Mois Précédent')}
                            </span>
                          </div>
                          {reportMode === 'custom_period' && (
                            <button
                              type="button"
                              onClick={() => {
                                setIsManualPanelOpen(true);
                              }}
                              className="no-print p-1 rounded-md bg-white border border-indigo-200 text-indigo-700 hover:bg-indigo-50 text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                              title={isAr ? 'تعديل المنقول يدوياً' : 'Modifier'}
                            >
                              <Edit3 className="w-3 h-3" />
                              <span>{isAr ? 'تعديل يدوي' : 'Modifier'}</span>
                            </button>
                          )}
                        </td>
                        <td className="p-2.5 font-sans text-indigo-900 text-[11px] hidden md:table-cell border-e border-slate-200">
                          {isAr ? 'الفائض الإجمالي المحاسبي المنقول من إقفال ما قبل بداية الفترة' : 'Solde antérieur reporté'}
                        </td>
                        <td className="p-2.5 text-center font-sans text-slate-400 border-e border-slate-200">-</td>
                        <td className="p-2.5 text-end font-black text-indigo-950 text-sm">
                          {masterFinancialStatement.carriedBalance >= 0 ? '+' : ''}{masterFinancialStatement.carriedBalance.toLocaleString()} <span className="text-xs font-normal">DH</span>
                        </td>
                      </tr>

                      {/* 2. المداخيل */}
                      <tr className="bg-emerald-50/60 hover:bg-emerald-50 transition-colors">
                        <td className="p-2.5 text-center font-black text-emerald-900 border-e border-slate-200">2</td>
                        <td className="p-2.5 font-sans font-black text-emerald-950 border-e border-slate-200 flex items-center gap-2">
                          <TrendingUp className="w-4 h-4 text-emerald-700" />
                          <span>{isAr ? 'المداخيل ومقبوضات الاشتراكات (Recettes)' : 'Recettes (Cotisations Encaissées)'}</span>
                        </td>
                        <td className="p-2.5 font-sans text-emerald-900 text-[11px] hidden md:table-cell border-e border-slate-200">
                          {isAr ? 'واجبات الاشتراك الشهرية والمستخلصات من ملاك الشقق والمحلات' : 'Cotisations et paiements encaissés'}
                        </td>
                        <td className="p-2.5 text-center font-sans text-slate-400 border-e border-slate-200">-</td>
                        <td className="p-2.5 text-end font-black text-emerald-800 text-sm">
                          +{masterFinancialStatement.income.toLocaleString()} <span className="text-xs font-normal">DH</span>
                        </td>
                      </tr>

                      {/* 3. أجور العمال */}
                      <tr className="hover:bg-slate-50 transition-colors">
                        <td className="p-2.5 text-center font-bold text-slate-700 border-e border-slate-200">3</td>
                        <td className="p-2.5 font-sans font-bold text-slate-900 border-e border-slate-200 flex items-center gap-2">
                          <Users className="w-4 h-4 text-sky-600" />
                          <span>{isAr ? 'أجور العمال والحراس (Salaires)' : 'Salaires des Ouvriers & Gardiens'}</span>
                        </td>
                        <td className="p-2.5 font-sans text-slate-600 text-[11px] hidden md:table-cell border-e border-slate-200">
                          {isAr ? 'رواتب ومستحقات حراس الأمن النهاري والليلي، عمال النظافة والبستاني' : 'Sécurité, propreté, jardinage'}
                        </td>
                        <td className="p-2.5 text-center border-e border-slate-200">
                          <span className="px-2 py-0.5 rounded-md text-xs font-black bg-sky-100 text-sky-800 border border-sky-300">
                            {masterFinancialStatement.workerSalariesPct}%
                          </span>
                        </td>
                        <td className="p-2.5 text-end font-black text-rose-700 text-sm">
                          -{masterFinancialStatement.workerSalaries.toLocaleString()} <span className="text-xs font-normal">DH</span>
                        </td>
                      </tr>

                      {/* 4. أجرة الوكيل ونائبه */}
                      <tr className="hover:bg-slate-50 transition-colors">
                        <td className="p-2.5 text-center font-bold text-slate-700 border-e border-slate-200">4</td>
                        <td className="p-2.5 font-sans font-bold text-slate-900 border-e border-slate-200 flex items-center gap-2">
                          <Briefcase className="w-4 h-4 text-amber-600" />
                          <span>{isAr ? 'أجرة الوكيل ونائبه (Syndic)' : 'Rémunération Syndic & Adjoint'}</span>
                        </td>
                        <td className="p-2.5 font-sans text-slate-600 text-[11px] hidden md:table-cell border-e border-slate-200">
                          {isAr ? 'أتعاب التسيير والإشراف الإداري والمالي والقانوني المعتمدة للسانديك' : 'Honoraires de gestion administrative et financière'}
                        </td>
                        <td className="p-2.5 text-center border-e border-slate-200">
                          <span className="px-2 py-0.5 rounded-md text-xs font-black bg-amber-100 text-amber-800 border border-amber-300">
                            {masterFinancialStatement.syndicFeesPct}%
                          </span>
                        </td>
                        <td className="p-2.5 text-end font-black text-rose-700 text-sm">
                          -{masterFinancialStatement.syndicFees.toLocaleString()} <span className="text-xs font-normal">DH</span>
                        </td>
                      </tr>

                      {/* 5. أتعاب المحامي */}
                      <tr className="hover:bg-slate-50 transition-colors">
                        <td className="p-2.5 text-center font-bold text-slate-700 border-e border-slate-200">5</td>
                        <td className="p-2.5 font-sans font-bold text-slate-900 border-e border-slate-200 flex items-center gap-2">
                          <Scale className="w-4 h-4 text-purple-600" />
                          <span>{isAr ? 'أتعاب المحامي (Avocat)' : 'Honoraires Avocat'}</span>
                        </td>
                        <td className="p-2.5 font-sans text-slate-600 text-[11px] hidden md:table-cell border-e border-slate-200">
                          {isAr ? 'الملفات القضائية، الاستشارات القانونية ومتابعة دعاوى تحصيل الديون' : 'Contentieux et recouvrement judiciaire'}
                        </td>
                        <td className="p-2.5 text-center border-e border-slate-200">
                          <span className="px-2 py-0.5 rounded-md text-xs font-black bg-purple-100 text-purple-800 border border-purple-300">
                            {masterFinancialStatement.lawyerFeesPct}%
                          </span>
                        </td>
                        <td className="p-2.5 text-end font-black text-rose-700 text-sm">
                          -{masterFinancialStatement.lawyerFees.toLocaleString()} <span className="text-xs font-normal">DH</span>
                        </td>
                      </tr>

                      {/* 6. أتعاب مفوض قضائي */}
                      <tr className="hover:bg-slate-50 transition-colors">
                        <td className="p-2.5 text-center font-bold text-slate-700 border-e border-slate-200">6</td>
                        <td className="p-2.5 font-sans font-bold text-slate-900 border-e border-slate-200 flex items-center gap-2">
                          <Gavel className="w-4 h-4 text-rose-600" />
                          <span>{isAr ? 'أتعاب مفوض قضائي (Huissier)' : 'Frais Huissier de Justice'}</span>
                        </td>
                        <td className="p-2.5 font-sans text-slate-600 text-[11px] hidden md:table-cell border-e border-slate-200">
                          {isAr ? 'تبليغ الإنذارات الرسمية، المحاضر القانونية والمعاينات الميدانية' : 'Sommations et significations'}
                        </td>
                        <td className="p-2.5 text-center border-e border-slate-200">
                          <span className="px-2 py-0.5 rounded-md text-xs font-black bg-rose-100 text-rose-800 border border-rose-300">
                            {masterFinancialStatement.bailiffFeesPct}%
                          </span>
                        </td>
                        <td className="p-2.5 text-end font-black text-rose-700 text-sm">
                          -{masterFinancialStatement.bailiffFees.toLocaleString()} <span className="text-xs font-normal">DH</span>
                        </td>
                      </tr>

                      {/* 7. العقاقير بمختلفها والمصاريف المتنوعة */}
                      <tr className="hover:bg-slate-50 transition-colors">
                        <td className="p-2.5 text-center font-bold text-slate-700 border-e border-slate-200">7</td>
                        <td className="p-2.5 font-sans font-bold text-slate-900 border-e border-slate-200 flex items-center gap-2">
                          <Wrench className="w-4 h-4 text-orange-600" />
                          <span>{isAr ? 'العقاقير بمختلفها ومصاريف متنوعة (Droguerie & Divers)' : 'Droguerie, Matériel & Divers (Ciment, Arrosage...)'}</span>
                        </td>
                        <td className="p-2.5 font-sans text-slate-600 text-[11px] hidden md:table-cell border-e border-slate-200">
                          {isAr ? 'عقاقير، إسمنت، مضخات الري، مواد النظافة، الكهرباء، والسباكة والصيانة العامة' : 'Droguerie, quincaillerie, ciment, arrosage, entretien'}
                        </td>
                        <td className="p-2.5 text-center border-e border-slate-200">
                          <span className="px-2 py-0.5 rounded-md text-xs font-black bg-orange-100 text-orange-800 border border-orange-300">
                            {masterFinancialStatement.diverseExpensesPct}%
                          </span>
                        </td>
                        <td className="p-2.5 text-end font-black text-rose-700 text-sm">
                          -{masterFinancialStatement.diverseExpenses.toLocaleString()} <span className="text-xs font-normal">DH</span>
                        </td>
                      </tr>

                      {/* 8. مجموع المداخيل مع إضافة المنقول */}
                      <tr className="bg-cyan-900 text-white font-black">
                        <td className="p-2.5 text-center border-e border-cyan-800">8</td>
                        <td className="p-2.5 font-sans border-e border-cyan-800 flex items-center gap-2 text-cyan-200">
                          <Sparkles className="w-4 h-4 text-amber-300" />
                          <span>{isAr ? 'مجموع المداخيل مع إضافة المنقول (Total Disponible)' : 'Total Disponible (Report + Recettes)'}</span>
                        </td>
                        <td className="p-2.5 font-sans text-cyan-100 text-[11px] hidden md:table-cell border-e border-cyan-800">
                          {isAr ? 'إجمالي السيولة المالية الإجمالية المتوفرة بالصندوق (الخانة 1 + الخانة 2)' : 'Total des disponibilités en caisse'}
                        </td>
                        <td className="p-2.5 text-center border-e border-cyan-800 font-sans text-cyan-300 text-xs">(1 + 2)</td>
                        <td className="p-2.5 text-end font-black text-cyan-200 text-base">
                          {masterFinancialStatement.totalIncomeWithCarried.toLocaleString()} <span className="text-xs font-normal text-white">DH</span>
                        </td>
                      </tr>

                      {/* 9. مجموع المصاريف */}
                      <tr className="bg-rose-900 text-white font-black">
                        <td className="p-2.5 text-center border-e border-rose-800">9</td>
                        <td className="p-2.5 font-sans border-e border-rose-800 flex items-center gap-2 text-rose-200">
                          <TrendingDown className="w-4 h-4 text-rose-300" />
                          <span>{isAr ? 'مجموع المصاريف (Dépenses)' : 'Total Général des Dépenses'}</span>
                        </td>
                        <td className="p-2.5 font-sans text-rose-100 text-[11px] hidden md:table-cell border-e border-rose-800">
                          {isAr ? 'إجمالي كافة النفقات المؤداة (مجموع البنود من 3 إلى 7)' : 'Somme totale des charges décaissées (3 à 7)'}
                        </td>
                        <td className="p-2.5 text-center border-e border-rose-800 font-sans text-rose-200 text-xs">100%</td>
                        <td className="p-2.5 text-end font-black text-rose-200 text-base">
                          -{masterFinancialStatement.totalExpenses.toLocaleString()} <span className="text-xs font-normal text-white">DH</span>
                        </td>
                      </tr>

                      {/* 10. الباقي */}
                      <tr className={`${
                        masterFinancialStatement.remainingBalance >= 0 
                          ? 'bg-gradient-to-r from-emerald-800 via-teal-900 to-emerald-950 text-white' 
                          : 'bg-gradient-to-r from-rose-900 to-red-950 text-white'
                      } font-black`}>
                        <td className="p-3 text-center border-e border-emerald-700 text-amber-300 text-sm"></td>
                        <td className="p-3 font-sans border-e border-emerald-700 flex items-center gap-2 text-white text-sm">
                          <Wallet className="w-5 h-5 text-amber-300" />
                          <span>{isAr ? 'الباقي النهائي الصافي (Solde Restant)' : 'Solde Restant Final (Reporté)'}</span>
                        </td>
                        <td className="p-3 font-sans text-emerald-100 text-[11px] hidden md:table-cell border-e border-emerald-700">
                          {isAr ? 'المعادلة: مجموع المداخيل مع المنقول (8) - مجموع المصاريف (9) = التحفة المرحّلة' : 'Solde net final reporté: Total Disponible (8) - Dépenses (9)'}
                        </td>
                        <td className="p-3 text-center border-e border-emerald-700 font-sans">
                          <span className="px-2.5 py-1 rounded-full bg-white/20 text-white text-[11px] font-black">
                            {masterFinancialStatement.remainingBalance >= 0 ? (isAr ? 'فائض 🟢' : 'Excédent') : (isAr ? 'عجز 🔴' : 'Déficit')}
                          </span>
                        </td>
                        <td className="p-3 text-end font-black text-amber-300 text-lg">
                          {masterFinancialStatement.remainingBalance >= 0 ? '+' : ''}{masterFinancialStatement.remainingBalance.toLocaleString()} <span className="text-xs font-normal text-white">DH</span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* VISUAL EXPENSE PERCENTAGES DISTRIBUTION BAR & SUMMARY BADGES */}
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-800">
                    <span className="flex items-center gap-1.5">
                      <Percent className="w-3.5 h-3.5 text-indigo-600" />
                      <span>{isAr ? 'توزيع نسب النفقات كم في المئة (%) من مجموع المصاريف:' : 'Ventilation en Pourcentage (%) des Dépenses:'}</span>
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">100% = {masterFinancialStatement.totalExpenses.toLocaleString()} DH</span>
                  </div>

                  {/* Multi-colored proportional bar */}
                  <div className="w-full bg-slate-200 rounded-full h-3.5 overflow-hidden flex shadow-inner">
                    <div style={{ width: `${masterFinancialStatement.workerSalariesPct}%` }} className="bg-sky-500 h-full transition-all" title={`أجور العمال: ${masterFinancialStatement.workerSalariesPct}%`} />
                    <div style={{ width: `${masterFinancialStatement.syndicFeesPct}%` }} className="bg-amber-500 h-full transition-all" title={`أجرة الوكيل ونائبه: ${masterFinancialStatement.syndicFeesPct}%`} />
                    <div style={{ width: `${masterFinancialStatement.lawyerFeesPct}%` }} className="bg-purple-500 h-full transition-all" title={`أتعاب المحامي: ${masterFinancialStatement.lawyerFeesPct}%`} />
                    <div style={{ width: `${masterFinancialStatement.bailiffFeesPct}%` }} className="bg-rose-500 h-full transition-all" title={`أتعاب مفوض قضائي: ${masterFinancialStatement.bailiffFeesPct}%`} />
                    <div style={{ width: `${masterFinancialStatement.diverseExpensesPct}%` }} className="bg-orange-500 h-full transition-all" title={`مصاريف مختلفة: ${masterFinancialStatement.diverseExpensesPct}%`} />
                  </div>

                  {/* 5 Percent Badges Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-1 text-[11px]">
                    <div className="p-2 rounded-lg bg-sky-50 border border-sky-200 flex flex-col justify-between">
                      <span className="text-slate-600 font-semibold text-[10px]">{isAr ? 'أجور العمال' : 'Salaires'}</span>
                      <span className="font-mono font-black text-sky-900 text-xs mt-0.5">{masterFinancialStatement.workerSalariesPct}%</span>
                      <span className="text-[9px] text-slate-500 font-mono">{masterFinancialStatement.workerSalaries.toLocaleString()} DH</span>
                    </div>

                    <div className="p-2 rounded-lg bg-amber-50 border border-amber-200 flex flex-col justify-between">
                      <span className="text-slate-600 font-semibold text-[10px]">{isAr ? 'أجرة الوكيل ونائبه' : 'Syndic'}</span>
                      <span className="font-mono font-black text-amber-900 text-xs mt-0.5">{masterFinancialStatement.syndicFeesPct}%</span>
                      <span className="text-[9px] text-slate-500 font-mono">{masterFinancialStatement.syndicFees.toLocaleString()} DH</span>
                    </div>

                    <div className="p-2 rounded-lg bg-purple-50 border border-purple-200 flex flex-col justify-between">
                      <span className="text-slate-600 font-semibold text-[10px]">{isAr ? 'أتعاب المحامي' : 'Avocat'}</span>
                      <span className="font-mono font-black text-purple-900 text-xs mt-0.5">{masterFinancialStatement.lawyerFeesPct}%</span>
                      <span className="text-[9px] text-slate-500 font-mono">{masterFinancialStatement.lawyerFees.toLocaleString()} DH</span>
                    </div>

                    <div className="p-2 rounded-lg bg-rose-50 border border-rose-200 flex flex-col justify-between">
                      <span className="text-slate-600 font-semibold text-[10px]">{isAr ? 'أتعاب مفوض قضائي' : 'Huissier'}</span>
                      <span className="font-mono font-black text-rose-900 text-xs mt-0.5">{masterFinancialStatement.bailiffFeesPct}%</span>
                      <span className="text-[9px] text-slate-500 font-mono">{masterFinancialStatement.bailiffFees.toLocaleString()} DH</span>
                    </div>

                    <div className="p-2 rounded-lg bg-orange-50 border border-orange-200 flex flex-col justify-between">
                      <span className="text-slate-600 font-semibold text-[10px]">{isAr ? 'مصاريف مختلفة' : 'Divers'}</span>
                      <span className="font-mono font-black text-orange-900 text-xs mt-0.5">{masterFinancialStatement.diverseExpensesPct}%</span>
                      <span className="text-[9px] text-slate-500 font-mono">{masterFinancialStatement.diverseExpenses.toLocaleString()} DH</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* ========================================================================= */}
              {/* VISUAL CHARTS SECTION (DONUT CHART OF 5 EXPENSES + CASHFLOW COMPARISON)    */}
              {/* ========================================================================= */}
              {showCharts && (
                <div className="space-y-3 pt-1">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-1.5">
                    <h3 className="text-xs font-black text-slate-900 flex items-center gap-2">
                      <BarChart3 className="w-4 h-4 text-emerald-700" />
                      <span>{isAr ? 'المخططات البيانية التوضيحية للمصاريف والموازنة' : 'Graphiques et Schémas Explicatifs'}</span>
                    </h3>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {/* Chart 1: Donut of the 5 Expense Shares (%) */}
                    <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/60">
                      <div className="text-xs font-bold text-slate-800 mb-1.5 flex items-center justify-between">
                        <span>{isAr ? 'مخطط توزيع نسب المصاريف الخمسة (%)' : 'Répartition des 5 Postes de Dépenses (%)'}</span>
                        <span className="text-[10px] font-mono font-bold text-rose-800">{masterFinancialStatement.totalExpenses.toLocaleString()} DH</span>
                      </div>

                      <div className="h-52">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={expensePillarsChartData}
                              dataKey="value"
                              nameKey="name"
                              cx="50%"
                              cy="50%"
                              outerRadius={65}
                              innerRadius={32}
                              paddingAngle={3}
                            >
                              {expensePillarsChartData.map((entry, index) => (
                                <Cell key={`pillar-cell-${index}`} fill={entry.fill} />
                              ))}
                            </Pie>
                            <Tooltip formatter={(val: any) => [`${Number(val).toLocaleString()} DH`, isAr ? 'المبلغ' : 'Montant']} />
                            <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontSize: '10px', fontWeight: 'bold' }} />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    {/* Chart 2: Cashflow Comparison Bar Chart */}
                    <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/60">
                      <div className="text-xs font-bold text-slate-800 mb-1.5 flex items-center justify-between">
                        <span>{isAr ? 'مخطط الموازنة العامة والسيولة (درهم)' : 'Comparatif Global des Flux Financiers (DH)'}</span>
                        <span className={`text-[10px] font-mono font-bold ${masterFinancialStatement.remainingBalance >= 0 ? 'text-emerald-800' : 'text-rose-800'}`}>
                          {isAr ? 'الباقي:' : 'Reste:'} {masterFinancialStatement.remainingBalance >= 0 ? '+' : ''}{masterFinancialStatement.remainingBalance.toLocaleString()} DH
                        </span>
                      </div>

                      <div className="h-52">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={cashflowComparisonData}
                            margin={{ top: 10, right: 10, left: -15, bottom: 0 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                            <XAxis dataKey="name" tick={{ fontSize: 9, fontWeight: 'bold' }} stroke="#64748b" />
                            <YAxis tick={{ fontSize: 9 }} stroke="#64748b" />
                            <Tooltip formatter={(val: any) => [`${Number(val).toLocaleString()} DH`, isAr ? 'المبلغ' : 'Montant']} />
                            <Bar dataKey="amount" radius={[6, 6, 0, 0]} barSize={32}>
                              {cashflowComparisonData.map((entry, idx) => (
                                <Cell key={`cf-cell-${idx}`} fill={entry.fill} />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* ANNUAL & CUSTOM PERIOD EVOLUTION: Month-by-Month Trend ComposedChart */}
              {(reportMode === 'annual' || reportMode === 'custom_period') && showCharts && (customPeriodMonthlyTrendData.length > 0 || annualMonthlyTrendData.length > 0) && (
                <div className="space-y-2 pt-1">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-1">
                    <h3 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                      <Activity className="w-4 h-4 text-emerald-700" />
                      <span>
                        {reportMode === 'annual' 
                          ? (isAr ? `تطور المداخيل والمصاريف شهراً بشهر خلال سنة ${selectedYear}` : `Évolution Mensuelle Recettes / Dépenses ${selectedYear}`)
                          : (isAr ? `تطور المداخيل والمصاريف شهراً بشهر للفترة المحددة (${periodMonthKeys.length} أشهر)` : `Évolution Mensuelle Recettes / Dépenses (${periodMonthKeys.length} mois)`)}
                      </span>
                    </h3>
                    <span className="text-[10px] font-mono font-bold text-emerald-800">
                      {reportMode === 'annual' ? 12 : periodMonthKeys.length} {isAr ? 'شهراً' : 'mois'}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl border border-slate-200 bg-slate-50/50">
                    <div className="h-52">
                      <ResponsiveContainer width="100%" height="100%">
                        <ComposedChart 
                          data={reportMode === 'annual' ? annualMonthlyTrendData : customPeriodMonthlyTrendData} 
                          margin={{ top: 10, right: 10, left: -10, bottom: 0 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                          <XAxis dataKey="month" tick={{ fontSize: 9, fontWeight: 'bold' }} stroke="#64748b" />
                          <YAxis tick={{ fontSize: 9 }} stroke="#64748b" />
                          <Tooltip formatter={(val: any) => [`${Number(val).toLocaleString()} DH`, '']} />
                          <Legend verticalAlign="top" height={32} wrapperStyle={{ fontSize: '10px', fontWeight: 'bold' }} />
                          <Bar dataKey="income" name={isAr ? 'المداخيل المحصلة' : 'Recettes'} fill="#059669" radius={[4, 4, 0, 0]} barSize={reportMode === 'custom_period' && periodMonthKeys.length > 12 ? 8 : 14} />
                          <Bar dataKey="expenses" name={isAr ? 'المصاريف والنفقات' : 'Dépenses'} fill="#dc2626" radius={[4, 4, 0, 0]} barSize={reportMode === 'custom_period' && periodMonthKeys.length > 12 ? 8 : 14} />
                          <Line type="monotone" dataKey="balance" name={isAr ? 'صافي الشهر' : 'Solde Net'} stroke="#0284c7" strokeWidth={2} dot={{ r: 2 }} />
                          <Line type="monotone" dataKey="closingBalance" name={isAr ? 'الرصيد المرحّل' : 'Report'} stroke="#d97706" strokeWidth={2.5} strokeDasharray="4 4" dot={{ r: 3, fill: '#d97706' }} />
                        </ComposedChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* ========================================================================= */}
            {/* DEDICATED PAGE BLOCK: BILAN 2 ANS (2025 ET 2026) DÉTAILLÉ AVEC GRAPHIQUES */}
            {/* ========================================================================= */}
            {twoYearsComparison && twoYearsComparison.hasTwoYears && (
              <>
                <div className="pdf-page-break print:block hidden" />
                <div className="pdf-page-block print-avoid-break bg-white p-6 sm:p-8 rounded-2xl border-2 border-slate-300 shadow-sm space-y-5">
                  {/* Header */}
                  <div className="border-b-2 border-indigo-600 pb-3 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-start">
                    <div>
                      <div className="flex items-center justify-center sm:justify-start gap-2">
                        <div className="p-1.5 rounded-lg bg-indigo-600 text-white shadow-xs">
                          <Scale className="w-4 h-4" />
                        </div>
                        <h2 className="text-base sm:text-lg font-black text-indigo-950">
                          {isAr ? 'التحليل المقارن والرسوم البيانية للسنتين الأخيرتين (2025 و 2026)' : 'Analyse Détaillée et Graphiques Comparatifs des 2 Dernières Années (2025 et 2026)'}
                        </h2>
                      </div>
                      <p className="text-xs text-slate-600 mt-0.5">
                        {isAr ? 'مقارنة تفصيلية للخانات العشر المعتمدة بين سنتي 2025 و 2026 مع الرسوم البيانية ونسب التطور' : 'Comparatif poste par poste des 10 rubriques entre 2025 et 2026 avec graphiques et taux d\'évolution'}
                      </p>
                    </div>
                    <div className="text-xs font-mono font-bold text-indigo-900 bg-indigo-50 border border-indigo-200 px-3 py-1 rounded-xl">
                      2025 ({twoYearsComparison.months2025Count} {isAr ? 'أشهر' : 'mois'}) ➔ 2026 ({twoYearsComparison.months2026Count} {isAr ? 'أشهر' : 'mois'})
                    </div>
                  </div>

                  {/* 3 Comparative KPI Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {/* Recettes */}
                    <div className="p-3 rounded-xl bg-emerald-50/90 border border-emerald-200 space-y-1.5">
                      <div className="flex items-center justify-between text-xs font-bold text-emerald-950">
                        <span className="flex items-center gap-1.5">
                          <TrendingUp className="w-4 h-4 text-emerald-600" />
                          <span>{isAr ? 'مداخيل 2025 مقابل 2026' : 'Recettes 2025 vs 2026'}</span>
                        </span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-black ${twoYearsComparison.growthRecettes >= 0 ? 'bg-emerald-200 text-emerald-900' : 'bg-rose-200 text-rose-900'}`}>
                          {twoYearsComparison.growthRecettes >= 0 ? '+' : ''}{twoYearsComparison.growthRecettes}%
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-1">
                        <div>
                          <span className="text-[10px] text-slate-500 font-sans block">{isAr ? 'سنة 2025' : 'Année 2025'}</span>
                          <span className="font-bold text-emerald-900">{twoYearsComparison.y2025.recettes.toLocaleString()} DH</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-500 font-sans block">{isAr ? 'سنة 2026' : 'Année 2026'}</span>
                          <span className="font-bold text-emerald-900">{twoYearsComparison.y2026.recettes.toLocaleString()} DH</span>
                        </div>
                      </div>
                      <div className="text-[10px] text-emerald-800 font-sans pt-1 border-t border-emerald-200/80 flex items-center justify-between">
                        <span>{isAr ? 'المجموع الموحد لسنتين:' : 'Total consolidé :'}</span>
                        <span className="font-mono font-black">{masterFinancialStatement.income.toLocaleString()} DH</span>
                      </div>
                    </div>

                    {/* Dépenses */}
                    <div className="p-3 rounded-xl bg-rose-50/90 border border-rose-200 space-y-1.5">
                      <div className="flex items-center justify-between text-xs font-bold text-rose-950">
                        <span className="flex items-center gap-1.5">
                          <TrendingDown className="w-4 h-4 text-rose-600" />
                          <span>{isAr ? 'مصاريف 2025 مقابل 2026' : 'Dépenses 2025 vs 2026'}</span>
                        </span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-black ${twoYearsComparison.growthDepenses <= 0 ? 'bg-emerald-200 text-emerald-900' : 'bg-rose-200 text-rose-900'}`}>
                          {twoYearsComparison.growthDepenses >= 0 ? '+' : ''}{twoYearsComparison.growthDepenses}%
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-1">
                        <div>
                          <span className="text-[10px] text-slate-500 font-sans block">{isAr ? 'سنة 2025' : 'Année 2025'}</span>
                          <span className="font-bold text-rose-900">{twoYearsComparison.y2025.totalExpenses.toLocaleString()} DH</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-500 font-sans block">{isAr ? 'سنة 2026' : 'Année 2026'}</span>
                          <span className="font-bold text-rose-900">{twoYearsComparison.y2026.totalExpenses.toLocaleString()} DH</span>
                        </div>
                      </div>
                      <div className="text-[10px] text-rose-800 font-sans pt-1 border-t border-rose-200/80 flex items-center justify-between">
                        <span>{isAr ? 'المجموع الموحد لسنتين:' : 'Total consolidé :'}</span>
                        <span className="font-mono font-black">{masterFinancialStatement.totalExpenses.toLocaleString()} DH</span>
                      </div>
                    </div>

                    {/* Solde */}
                    <div className="p-3 rounded-xl bg-indigo-50/90 border border-indigo-200 space-y-1.5">
                      <div className="flex items-center justify-between text-xs font-bold text-indigo-950">
                        <span className="flex items-center gap-1.5">
                          <Wallet className="w-4 h-4 text-indigo-600" />
                          <span>{isAr ? 'الباقي الصافي 2025 و 2026' : 'Solde 2025 vs 2026'}</span>
                        </span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-black ${twoYearsComparison.growthSolde >= 0 ? 'bg-emerald-200 text-emerald-900' : 'bg-rose-200 text-rose-900'}`}>
                          {twoYearsComparison.growthSolde >= 0 ? '+' : ''}{twoYearsComparison.growthSolde}%
                        </span>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-1">
                        <div>
                          <span className="text-[10px] text-slate-500 font-sans block">{isAr ? 'رصيد نهاية 2025' : 'Fin 2025'}</span>
                          <span className={`font-bold ${twoYearsComparison.y2025.soldeRestant >= 0 ? 'text-emerald-900' : 'text-rose-900'}`}>
                            {twoYearsComparison.y2025.soldeRestant >= 0 ? '+' : ''}{twoYearsComparison.y2025.soldeRestant.toLocaleString()} DH
                          </span>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-500 font-sans block">{isAr ? 'رصيد نهاية 2026' : 'Fin 2026'}</span>
                          <span className={`font-bold ${twoYearsComparison.y2026.soldeRestant >= 0 ? 'text-emerald-900' : 'text-rose-900'}`}>
                            {twoYearsComparison.y2026.soldeRestant >= 0 ? '+' : ''}{twoYearsComparison.y2026.soldeRestant.toLocaleString()} DH
                          </span>
                        </div>
                      </div>
                      <div className="text-[10px] text-indigo-800 font-sans pt-1 border-t border-indigo-200/80 flex items-center justify-between">
                        <span>{isAr ? 'الرصيد النهائي المرحل:' : 'Solde restant final :'}</span>
                        <span className={`font-mono font-black ${masterFinancialStatement.remainingBalance >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                          {masterFinancialStatement.remainingBalance >= 0 ? '+' : ''}{masterFinancialStatement.remainingBalance.toLocaleString()} DH
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* 2 Visual Charts for 2025 vs 2026 */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                    {/* Chart 1: Grouped Bar Chart (Recettes, Dépenses, Solde 2025 vs 2026) */}
                    <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/60">
                      <div className="text-xs font-bold text-slate-800 mb-2 flex items-center justify-between">
                        <span className="flex items-center gap-1.5">
                          <BarChart3 className="w-4 h-4 text-indigo-600" />
                          <span>{isAr ? 'مقارنة المداخيل والمصاريف والسيولة (2025 مقابل 2026)' : 'Comparatif Global : Recettes, Dépenses et Solde (2025 vs 2026)'}</span>
                        </span>
                      </div>
                      <div className="h-56">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={twoYearsComparison.comparativeBarData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                            <XAxis dataKey="year" tick={{ fontSize: 10, fontWeight: 'bold' }} stroke="#64748b" />
                            <YAxis tick={{ fontSize: 9 }} stroke="#64748b" />
                            <Tooltip formatter={(val: any) => [`${Number(val).toLocaleString()} DH`, '']} />
                            <Legend verticalAlign="top" height={32} wrapperStyle={{ fontSize: '10px', fontWeight: 'bold' }} />
                            <Bar dataKey="recettes" name={isAr ? 'المداخيل' : 'Recettes'} fill="#059669" radius={[4, 4, 0, 0]} />
                            <Bar dataKey="depenses" name={isAr ? 'المصاريف' : 'Dépenses'} fill="#dc2626" radius={[4, 4, 0, 0]} />
                            <Bar dataKey="disponible" name={isAr ? 'إجمالي السيولة (1+2)' : 'Disponible'} fill="#0891b2" radius={[4, 4, 0, 0]} />
                            <Bar dataKey="solde" name={isAr ? 'الباقي الصافي' : 'Solde'} fill="#6366f1" radius={[4, 4, 0, 0]} />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    {/* Chart 2: Comparative 5 Expense Pillars Bar Chart (2025 vs 2026) */}
                    <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/60">
                      <div className="text-xs font-bold text-slate-800 mb-2 flex items-center justify-between">
                        <span className="flex items-center gap-1.5">
                          <Activity className="w-4 h-4 text-amber-600" />
                          <span>{isAr ? 'مقارنة أبواب المصاريف الخمسة (2025 مقابل 2026)' : 'Comparatif des 5 Postes de Dépenses (2025 vs 2026)'}</span>
                        </span>
                      </div>
                      <div className="h-56">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={twoYearsComparison.pillarsComparativeBarData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                            <XAxis dataKey="poste" tick={{ fontSize: 9, fontWeight: 'bold' }} stroke="#64748b" />
                            <YAxis tick={{ fontSize: 9 }} stroke="#64748b" />
                            <Tooltip formatter={(val: any) => [`${Number(val).toLocaleString()} DH`, '']} />
                            <Legend verticalAlign="top" height={32} wrapperStyle={{ fontSize: '10px', fontWeight: 'bold' }} />
                            <Bar dataKey="y2025" name={isAr ? 'سنة 2025' : 'Année 2025'} fill="#3b82f6" radius={[4, 4, 0, 0]} />
                            <Bar dataKey="y2026" name={isAr ? 'سنة 2026' : 'Année 2026'} fill="#f59e0b" radius={[4, 4, 0, 0]} />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  </div>

                  {/* Side-by-side 10-Line Master Statement Table for 2025 vs 2026 */}
                  <div className="space-y-2 pt-1">
                    <div className="flex items-center justify-between">
                      <h3 className="text-xs sm:text-sm font-black text-slate-900 flex items-center gap-1.5">
                        <TableIcon className="w-4 h-4 text-indigo-700" />
                        <span>{isAr ? 'جدول مقارنة الخانات العشر بالتفصيل (2025 و 2026 والمجموع الموحد)' : 'Tableau Comparatif Détaillé des 10 Rubriques (2025 vs 2026 & Consolidé)'}</span>
                      </h3>
                      <span className="text-[10px] font-mono text-slate-500 font-bold">
                        {isAr ? 'سنتين متكاملتين (2025 و 2026)' : '2 Ans complets (2025 et 2026)'}
                      </span>
                    </div>

                    <div className="overflow-x-auto rounded-xl border-2 border-slate-300 shadow-2xs bg-white">
                      <table className="w-full text-xs text-start border-collapse">
                        <thead className="bg-slate-900 text-white font-black text-xs">
                          <tr>
                            <th className="p-2.5 text-center w-10 border-e border-slate-700">{isAr ? 'الرقم' : 'N°'}</th>
                            <th className="p-2.5 text-start min-w-[200px] border-e border-slate-700">{isAr ? 'البيان المحاسبي المعتمد' : 'Poste Budgétaire'}</th>
                            <th className="p-2.5 text-end min-w-[110px] border-e border-slate-700 text-sky-300">{isAr ? 'سنة 2025' : 'Année 2025'}</th>
                            <th className="p-2.5 text-end min-w-[110px] border-e border-slate-700 text-amber-300">{isAr ? 'سنة 2026' : 'Année 2026'}</th>
                            <th className="p-2.5 text-end min-w-[130px] border-e border-slate-700 text-emerald-300">{isAr ? 'المجموع الموحد (2 سنتين)' : 'Total Consolidé 2 Ans'}</th>
                            <th className="p-2.5 text-center min-w-[90px]">{isAr ? 'التطور / النسبة' : 'Évolution / Part'}</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200 font-mono">
                          {/* 1. Report */}
                          <tr className="bg-indigo-50/50 hover:bg-indigo-50">
                            <td className="p-2 text-center font-black text-indigo-900 border-e border-slate-200">1</td>
                            <td className="p-2 font-sans font-bold text-slate-900 border-e border-slate-200">
                              {isAr ? 'المنقول الافتتاحي (Report)' : 'Report initial'}
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 font-bold text-indigo-950">
                              {twoYearsComparison.y2025.report.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 font-bold text-indigo-950">
                              {twoYearsComparison.y2026.report.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 font-black text-indigo-950">
                              {masterFinancialStatement.carriedBalance.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-center font-sans text-[10px] text-slate-500">
                              {isAr ? 'مرحل سابق' : 'Solde antérieur'}
                            </td>
                          </tr>

                          {/* 2. Recettes */}
                          <tr className="bg-emerald-50/40 hover:bg-emerald-50">
                            <td className="p-2 text-center font-black text-emerald-900 border-e border-slate-200">2</td>
                            <td className="p-2 font-sans font-bold text-slate-900 border-e border-slate-200">
                              {isAr ? 'المداخيل (Recettes)' : 'Recettes perçues'}
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 font-bold text-emerald-900">
                              +{twoYearsComparison.y2025.recettes.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 font-bold text-emerald-900">
                              +{twoYearsComparison.y2026.recettes.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 font-black text-emerald-950">
                              +{masterFinancialStatement.income.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-center">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-black ${twoYearsComparison.growthRecettes >= 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>
                                {twoYearsComparison.growthRecettes >= 0 ? '+' : ''}{twoYearsComparison.growthRecettes}%
                              </span>
                            </td>
                          </tr>

                          {/* 3. Salaires */}
                          <tr className="hover:bg-slate-50">
                            <td className="p-2 text-center font-bold text-slate-700 border-e border-slate-200">3</td>
                            <td className="p-2 font-sans font-medium text-slate-800 border-e border-slate-200">
                              {isAr ? 'أجور العمال (Salaires)' : 'Salaires ouvriers'}
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 text-rose-700 font-semibold">
                              -{twoYearsComparison.y2025.salaires.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 text-rose-700 font-semibold">
                              -{twoYearsComparison.y2026.salaires.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 text-rose-800 font-black">
                              -{masterFinancialStatement.workerSalaries.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-center">
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-800">
                                {masterFinancialStatement.workerSalariesPct}%
                              </span>
                            </td>
                          </tr>

                          {/* 4. Syndic */}
                          <tr className="hover:bg-slate-50">
                            <td className="p-2 text-center font-bold text-slate-700 border-e border-slate-200">4</td>
                            <td className="p-2 font-sans font-medium text-slate-800 border-e border-slate-200">
                              {isAr ? 'أجرة الوكيل ونائبه (Syndic)' : 'Honoraires Syndic & adjoint'}
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 text-rose-700 font-semibold">
                              -{twoYearsComparison.y2025.syndic.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 text-rose-700 font-semibold">
                              -{twoYearsComparison.y2026.syndic.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 text-rose-800 font-black">
                              -{masterFinancialStatement.syndicFees.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-center">
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800">
                                {masterFinancialStatement.syndicFeesPct}%
                              </span>
                            </td>
                          </tr>

                          {/* 5. Avocat */}
                          <tr className="hover:bg-slate-50">
                            <td className="p-2 text-center font-bold text-slate-700 border-e border-slate-200">5</td>
                            <td className="p-2 font-sans font-medium text-slate-800 border-e border-slate-200">
                              {isAr ? 'أتعاب المحامي (Avocat)' : 'Honoraires Avocat'}
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 text-rose-700 font-semibold">
                              -{twoYearsComparison.y2025.avocat.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 text-rose-700 font-semibold">
                              -{twoYearsComparison.y2026.avocat.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 text-rose-800 font-black">
                              -{masterFinancialStatement.lawyerFees.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-center">
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-800">
                                {masterFinancialStatement.lawyerFeesPct}%
                              </span>
                            </td>
                          </tr>

                          {/* 6. Huissier */}
                          <tr className="hover:bg-slate-50">
                            <td className="p-2 text-center font-bold text-slate-700 border-e border-slate-200">6</td>
                            <td className="p-2 font-sans font-medium text-slate-800 border-e border-slate-200">
                              {isAr ? 'أتعاب مفوض قضائي (Huissier)' : 'Huissier de Justice'}
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 text-rose-700 font-semibold">
                              -{twoYearsComparison.y2025.huissier.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 text-rose-700 font-semibold">
                              -{twoYearsComparison.y2026.huissier.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 text-rose-800 font-black">
                              -{masterFinancialStatement.bailiffFees.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-center">
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800">
                                {masterFinancialStatement.bailiffFeesPct}%
                              </span>
                            </td>
                          </tr>

                          {/* 7. Droguerie */}
                          <tr className="hover:bg-slate-50">
                            <td className="p-2 text-center font-bold text-slate-700 border-e border-slate-200">7</td>
                            <td className="p-2 font-sans font-medium text-slate-800 border-e border-slate-200">
                              {isAr ? 'العقاقير ومصاريف متنوعة (Droguerie & Divers)' : 'Droguerie, Matériel & Divers'}
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 text-rose-700 font-semibold">
                              -{twoYearsComparison.y2025.droguerie.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 text-rose-700 font-semibold">
                              -{twoYearsComparison.y2026.droguerie.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-end border-e border-slate-200 text-rose-800 font-black">
                              -{masterFinancialStatement.diverseExpenses.toLocaleString()} DH
                            </td>
                            <td className="p-2 text-center">
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-orange-100 text-orange-800">
                                {masterFinancialStatement.diverseExpensesPct}%
                              </span>
                            </td>
                          </tr>

                          {/* 8. Total Disponible */}
                          <tr className="bg-cyan-900 text-white font-black">
                            <td className="p-2.5 text-center border-e border-cyan-800">8</td>
                            <td className="p-2.5 font-sans border-e border-cyan-800 text-cyan-200">
                              {isAr ? 'مجموع المداخيل مع المنقول (Total Disponible)' : 'Total Disponible (1 + 2)'}
                            </td>
                            <td className="p-2.5 text-end border-e border-cyan-800 text-cyan-200">
                              {twoYearsComparison.y2025.totalDisponible.toLocaleString()} DH
                            </td>
                            <td className="p-2.5 text-end border-e border-cyan-800 text-cyan-200">
                              {twoYearsComparison.y2026.totalDisponible.toLocaleString()} DH
                            </td>
                            <td className="p-2.5 text-end border-e border-cyan-800 text-cyan-200 text-sm">
                              {masterFinancialStatement.totalIncomeWithCarried.toLocaleString()} DH
                            </td>
                            <td className="p-2.5 text-center text-[10px] text-cyan-300 font-sans">
                              (1 + 2)
                            </td>
                          </tr>

                          {/* 9. Dépenses */}
                          <tr className="bg-rose-900 text-white font-black">
                            <td className="p-2.5 text-center border-e border-rose-800">9</td>
                            <td className="p-2.5 font-sans border-e border-rose-800 text-rose-200">
                              {isAr ? 'مجموع المصاريف (Dépenses)' : 'Total Dépenses (3 à 7)'}
                            </td>
                            <td className="p-2.5 text-end border-e border-rose-800 text-rose-200">
                              -{twoYearsComparison.y2025.totalExpenses.toLocaleString()} DH
                            </td>
                            <td className="p-2.5 text-end border-e border-rose-800 text-rose-200">
                              -{twoYearsComparison.y2026.totalExpenses.toLocaleString()} DH
                            </td>
                            <td className="p-2.5 text-end border-e border-rose-800 text-rose-200 text-sm">
                              -{masterFinancialStatement.totalExpenses.toLocaleString()} DH
                            </td>
                            <td className="p-2.5 text-center">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-black ${twoYearsComparison.growthDepenses <= 0 ? 'bg-emerald-200 text-emerald-900' : 'bg-rose-200 text-rose-900'}`}>
                                {twoYearsComparison.growthDepenses >= 0 ? '+' : ''}{twoYearsComparison.growthDepenses}%
                              </span>
                            </td>
                          </tr>

                          {/* 10. Solde Restant */}
                          <tr className={`${masterFinancialStatement.remainingBalance >= 0 ? 'bg-emerald-950 text-white' : 'bg-rose-950 text-white'} font-black`}>
                            <td className="p-2.5 text-center border-e border-emerald-800 text-amber-300"></td>
                            <td className="p-2.5 font-sans border-e border-emerald-800 text-white">
                              {isAr ? 'الباقي النهائي الصافي (Solde Restant)' : 'Solde Restant (8 - 9)'}
                            </td>
                            <td className="p-2.5 text-end border-e border-emerald-800 text-amber-300">
                              {twoYearsComparison.y2025.soldeRestant >= 0 ? '+' : ''}{twoYearsComparison.y2025.soldeRestant.toLocaleString()} DH
                            </td>
                            <td className="p-2.5 text-end border-e border-emerald-800 text-amber-300">
                              {twoYearsComparison.y2026.soldeRestant >= 0 ? '+' : ''}{twoYearsComparison.y2026.soldeRestant.toLocaleString()} DH
                            </td>
                            <td className="p-2.5 text-end border-e border-emerald-800 text-amber-300 text-sm">
                              {masterFinancialStatement.remainingBalance >= 0 ? '+' : ''}{masterFinancialStatement.remainingBalance.toLocaleString()} DH
                            </td>
                            <td className="p-2.5 text-center">
                              <span className="px-2 py-0.5 rounded-full bg-white/20 text-white text-[10px] font-black">
                                {masterFinancialStatement.remainingBalance >= 0 ? (isAr ? 'فائض 🟢' : 'Excédent') : (isAr ? 'عجز 🔴' : 'Déficit')}
                              </span>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* SEPARATOR FOR PRINT / MULTI-PAGE SLICE (Without cutting through tables) */}
            <div className="pdf-page-break print:block hidden" />

            {/* ========================================================================= */}
            {/* PAGE BLOCK 2 / 3: ACCOUNTING ANNEXES, SYNDIC DUES & OFFICIAL SIGNATURES   */}
            {/* Exactly fits 1 A4 page with zero cut-off / uninterrupted print            */}
            {/* ========================================================================= */}
            <div className="pdf-page-block print-avoid-break bg-white p-6 sm:p-8 rounded-2xl border-2 border-slate-300 shadow-sm space-y-5">
              
              {/* Page 2 / 3 Header */}
              <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                <div className="text-xs font-black text-slate-800">
                  {isAr ? 'ملحق الكشوفات المحاسبية والتوقيعات الرسمية للإقامة' : 'Annexes Comptables & Signatures Officielles'}
                </div>
                <div className="text-[10px] text-slate-500 font-mono">
                  {periodTitle} • {isAr ? (twoYearsComparison?.hasTwoYears ? 'الصفحة 3 من 3' : 'الصفحة 2 من 2') : (twoYearsComparison?.hasTwoYears ? 'Page 3 sur 3' : 'Page 2 sur 2')}
                </div>
              </div>

              {/* TABLE 1: OFFICIAL 10 EXPENSE CATEGORIES BREAKDOWN TABLE */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs sm:text-sm font-black text-slate-900 flex items-center gap-1.5">
                    <TrendingDown className="w-4 h-4 text-rose-600" />
                    <span>{isAr ? 'جدول تبويب المصاريف حسب الأبواب المحاسبية العشرة المعتمدة' : 'Tableau Récapitulatif des 10 Postes de Dépenses'}</span>
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-lg bg-rose-50 text-rose-900 border border-rose-200 font-mono font-bold text-xs">
                    {masterFinancialStatement.totalExpenses.toLocaleString()} DH
                  </span>
                </div>

                <div className="overflow-x-auto rounded-xl border border-slate-200 shadow-2xs">
                  <table className="w-full whitespace-nowrap text-start text-xs border-collapse">
                    <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                      <tr>
                        <th className="p-2 text-center w-10">{isAr ? 'الرقم' : 'N°'}</th>
                        <th className="p-2 text-start min-w-[170px]">{isAr ? 'باب المصروف المعتمد' : 'Poste de Dépense'}</th>
                        <th className="p-2 text-start min-w-[200px] hidden md:table-cell">{isAr ? 'البيان والتفصيل' : 'Détail'}</th>
                        <th className="p-2 text-center min-w-[70px]">{isAr ? 'العمليات' : 'Op.'}</th>
                        <th className="p-2 text-center min-w-[80px]">{isAr ? 'النسبة (%)' : 'Part (%)'}</th>
                        <th className="p-2 text-end min-w-[110px]">{isAr ? 'المبلغ المؤدى' : 'Montant'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-mono">
                      {official10ExpenseCategories.map((item) => (
                        <tr key={item.id} className="hover:bg-slate-50">
                          <td className="p-2 text-center text-slate-500 font-bold">{item.number}</td>
                          <td className="p-2 font-sans font-bold text-slate-900">
                            <div className="flex items-center gap-1.5">
                              {renderOfficialIcon(item.iconType)}
                              <span>{item.title}</span>
                            </div>
                          </td>
                          <td className="p-2 font-sans text-slate-600 text-[11px] hidden md:table-cell">{item.description}</td>
                          <td className="p-2 text-center font-sans text-slate-600 text-[10px]">
                            {item.invoicesCount > 0 ? `${item.invoicesCount} ${isAr ? 'فاتورة' : 'fact.'}` : '-'}
                          </td>
                          <td className="p-2 text-center">
                            <span className="font-bold text-slate-700">{item.percentage}%</span>
                          </td>
                          <td className="p-2 text-end font-bold text-rose-700">
                            {item.amount.toLocaleString()} <span className="text-[10px] font-normal text-slate-500">DH</span>
                          </td>
                        </tr>
                      ))}
                      <tr className="bg-slate-100 font-black text-slate-950 border-t-2 border-slate-300">
                        <td className="p-2 text-center">∑</td>
                        <td className="p-2 font-sans">{isAr ? 'المجموع الإجمالي لكافة المصاريف' : 'Total Dépenses'}</td>
                        <td className="p-2 font-sans text-[11px] text-slate-600 hidden md:table-cell">{isAr ? '10 أبواب محاسبية معتمدة' : '10 postes'}</td>
                        <td className="p-2 text-center font-sans">{filteredExpenses.length}</td>
                        <td className="p-2 text-center text-rose-800">100%</td>
                        <td className="p-2 text-end text-rose-800 text-sm">{masterFinancialStatement.totalExpenses.toLocaleString()} DH</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* SYNDIC MANAGEMENT DUES AND LEGAL REFERENCE */}
              {showSyndicFees && (
                <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Briefcase className="w-4 h-4 text-amber-700" />
                      <h4 className="text-xs font-black text-amber-950">
                        {isAr ? 'مستحقات وأتعاب إدارة السانديك ونائبه:' : 'Honoraires Gestion Syndic & Adjoint:'}
                      </h4>
                    </div>
                    <span className="font-mono font-black text-amber-950 text-xs bg-white px-2 py-0.5 rounded border border-amber-300">
                      {currentSyndicDues.toLocaleString()} DH
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-700 flex flex-wrap items-center justify-between gap-2">
                    <span>{isAr ? 'الأتعاب المعتمدة: 4,000 درهم شهرياً نظير الإشراف الإداري والمالي والقانوني على جميع العمارات (جميع الشقق).' : 'Honoraires mensuels 4.000 DH/mois pour tous les immeubles (tous les lots).'}</span>
                    <span className="text-[10px] font-bold text-amber-900 bg-amber-100 px-2 py-0.5 rounded">
                      ⚖️ {isAr ? 'المادة 18 من القانون رقم 18.00 المتعلق بالملكية المشتركة' : 'Loi 18.00 Art. 18'}
                    </span>
                  </div>
                </div>
              )}

              {/* MONTHLY PROGRESSION & CARRYOVER TABLE (if enabled) */}
              {showCarryoverTable && (
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                      <ArrowRightLeft className="w-3.5 h-3.5 text-blue-600" />
                      <span>
                        {reportMode === 'custom_period'
                          ? (isAr ? `جدول التطور الشهري والتفصيل المحاسبي للفترة المحددة (${periodMonthKeys.length} أشهر):` : `Suivi Mensuel de la Période (${periodMonthKeys.length} mois):`)
                          : (isAr ? `تسلسل ترحيل الأرصدة (الفائض / العجز) لسنة ${selectedYear}:` : `Suivi du Report à Nouveau ${selectedYear}:`)}
                      </span>
                    </h4>
                  </div>
                  <div className="overflow-x-auto rounded-xl border border-slate-200">
                    <table className="w-full text-start text-[11px] border-collapse font-mono">
                      <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                        <tr>
                          <th className="p-1.5 text-start font-sans">{isAr ? 'الشهر والسنة' : 'Mois'}</th>
                          <th className="p-1.5 text-end">{isAr ? 'المنقول الافتتاحي' : 'Début'}</th>
                          <th className="p-1.5 text-end text-emerald-800">{isAr ? '(+) المداخيل' : '(+) Recettes'}</th>
                          <th className="p-1.5 text-end text-rose-800">{isAr ? '(-) المصاريف' : '(-) Dépenses'}</th>
                          <th className="p-1.5 text-end font-black">{isAr ? '(=) المرحّل' : '(=) Report'}</th>
                          <th className="p-1.5 text-center font-sans">{isAr ? 'الوضعية' : 'Statut'}</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {(reportMode === 'custom_period' ? customPeriodMonthlyTrendData : monthlyCarryoverChain).map((item: any) => (
                          <tr key={item.monthKey} className="hover:bg-slate-50">
                            <td className="p-1.5 font-sans font-bold">{isAr ? (item.labelAr || item.fullMonth) : (item.labelFr || item.fullMonth)}</td>
                            <td className="p-1.5 text-end text-slate-600">{item.openingBalance.toLocaleString()}</td>
                            <td className="p-1.5 text-end text-emerald-700 font-bold">+{item.income.toLocaleString()}</td>
                            <td className="p-1.5 text-end text-rose-700 font-bold">-{item.expenses.toLocaleString()}</td>
                            <td className="p-1.5 text-end font-black text-slate-900">{item.closingBalance.toLocaleString()} DH</td>
                            <td className="p-1.5 text-center font-sans text-[10px]">
                              {item.isClosingSurplus ? (isAr ? 'فائض 🟢' : 'Excédent') : (isAr ? 'عجز 🔴' : 'Déficit')}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* OFFICIAL SIGNATURE & STAMP BLOCK */}
              <div className="pt-4 border-t-2 border-slate-300 space-y-3">
                <div className="max-w-md mx-auto text-center text-xs">
                  {/* Syndic Stamp */}
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-6 shadow-xs">
                    <div className="font-bold text-slate-900 text-sm">
                      {isAr ? 'خاتم وتوقيع وكيل السانديك' : 'Cachet & Signature du Syndic'}
                    </div>
                    <div className="text-xs text-emerald-950 font-black">
                      مكتب السانديك - الإقامة
                    </div>
                  </div>
                </div>

                <div className="text-[10px] text-slate-500 text-center pt-1">
                  {isAr 
                    ? 'تم استخراج هذا التقرير المحاسباتي الرسمي طبقاً لمقتضيات القانون رقم 18.00 المتعلق بنظام الملكية المشتركة للعقارات المبنية بالمملكة المغربية.'
                    : 'Document financier conforme aux dispositions de la loi n° 18.00 régissant la copropriété au Royaume du Maroc.'}
                </div>
              </div>

            </div>
          </div>
        </div>

        {/* MODAL BOTTOM BAR (Hidden during Print) */}
        <div className="no-print p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs">
          <div className="text-slate-600 flex items-center gap-1.5 font-bold">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>{RES.fullNameAr}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadCSV}
              type="button"
              className="px-3.5 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 font-bold text-slate-800 cursor-pointer flex items-center gap-1.5"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-teal-700" />
              <span>{isAr ? 'تصدير إكسيل CSV' : 'Export CSV'}</span>
            </button>
            <button
              onClick={handlePrint}
              type="button"
              className="px-3.5 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 font-bold text-slate-800 cursor-pointer flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5 text-slate-700" />
              <span>{isAr ? 'طباعة A4' : 'Imprimer'}</span>
            </button>
            <button
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              type="button"
              className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold cursor-pointer flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isGeneratingPdf ? (isAr ? 'جاري التحميل...' : 'Téléchargement...') : (isAr ? 'تحميل تقرير PDF' : 'Télécharger PDF')}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
