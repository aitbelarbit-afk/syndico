import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { MaintenanceTicket, MaintenanceCategory, MaintenancePriority, MaintenanceStatus } from '../types';
import { 
  Camera, Upload, Trash2, X, AlertCircle, CheckCircle2, Clock, 
  MapPin, Phone, User, FileText, Send, Sparkles, Image as ImageIcon, 
  Eye, RefreshCw, Volume2, VolumeX, ShieldAlert, Wrench, Building2,
  Maximize2, MessageSquare, ArrowRight, ArrowLeft, Check, BellRing
} from 'lucide-react';

interface Props {
  onSuccess?: () => void;
}

export const ResidentMaintenanceReportForm: React.FC<Props> = ({ onSuccess }) => {
  const { 
    lang, currentUser, buildings, apartments, residents, 
    addMaintenanceTicket, updateMaintenanceTicket, maintenanceTickets,
    showToast, logActivity 
  } = useApp();

  const isAr = lang === 'ar';
  const isOwner = currentUser?.role === 'resident';

  // Form State
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<MaintenanceCategory>('plumbing');
  const [priority, setPriority] = useState<MaintenancePriority>('medium');
  const [buildingCode, setBuildingCode] = useState(() => currentUser?.building || '');
  const [apartmentOrArea, setApartmentOrArea] = useState(() => currentUser?.apartment ? `${lang === 'ar' ? 'شقة' : 'Appt'} ${currentUser.apartment}` : '');
  const [reportedBy, setReportedBy] = useState(() => currentUser?.name || '');
  const [ownerPhone, setOwnerPhone] = useState(() => currentUser?.phone || '');
  const [description, setDescription] = useState('');
  const [photos, setPhotos] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // Camera WebRTC Modal State
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [cameraFacingMode, setCameraFacingMode] = useState<'environment' | 'user'>('environment');
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isTakingSnapshot, setIsTakingSnapshot] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Zoomed Image Modal State
  const [zoomedPhoto, setZoomedPhoto] = useState<string | null>(null);

  // Admin Notification / Filter Tab for Syndic
  const [adminViewTab, setAdminViewTab] = useState<'create' | 'incoming_alerts'>(isOwner ? 'create' : 'incoming_alerts');
  const [adminFilter, setAdminFilter] = useState<'all' | 'urgent' | 'with_photos' | 'open'>('all');
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Syndic reply inline state
  const [replyTicketId, setReplyTicketId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');

  // Quick preset issue chips
  const quickIssues = isAr ? [
    { title: 'تسرب مياه في الدرج أو الأنبوب', cat: 'plumbing' as MaintenanceCategory, prio: 'urgent' as MaintenancePriority },
    { title: 'انقطاع إضاءة مدخل العمارة أو الممرات', cat: 'lighting' as MaintenanceCategory, prio: 'medium' as MaintenancePriority },
    { title: 'عطل في قفل الباب الرئيسي أو الإنترفون', cat: 'security' as MaintenanceCategory, prio: 'high' as MaintenancePriority },
    { title: 'تراكم نفايات أو حاجة لتنظيف عاجل', cat: 'cleaning' as MaintenanceCategory, prio: 'medium' as MaintenancePriority },
    { title: 'عطل بمضخة المياه أو ضغط ضعيف', cat: 'plumbing' as MaintenanceCategory, prio: 'urgent' as MaintenancePriority },
    { title: 'كسر أو تلف في مرافق مشتركة', cat: 'general' as MaintenanceCategory, prio: 'high' as MaintenancePriority }
  ] : [
    { title: 'Fuite d\'eau dans les escaliers ou gaine', cat: 'plumbing' as MaintenanceCategory, prio: 'urgent' as MaintenancePriority },
    { title: 'Éclairage des couloirs défaillant', cat: 'lighting' as MaintenanceCategory, prio: 'medium' as MaintenancePriority },
    { title: 'Panne de l\'interphone ou porte d\'entrée', cat: 'security' as MaintenanceCategory, prio: 'high' as MaintenancePriority },
    { title: 'Besoin de nettoyage urgent des parties communes', cat: 'cleaning' as MaintenanceCategory, prio: 'medium' as MaintenancePriority },
    { title: 'Panne de surpresseur d\'eau', cat: 'plumbing' as MaintenanceCategory, prio: 'urgent' as MaintenancePriority },
    { title: 'Dégradation ou vitre cassée', cat: 'general' as MaintenanceCategory, prio: 'high' as MaintenancePriority }
  ];

  // Play audio chime for alert
  const playAlertChime = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
      osc.frequency.setValueAtTime(880, audioCtx.currentTime + 0.1); // A5
      gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.5);
      
      osc.start();
      osc.stop(audioCtx.currentTime + 0.5);
    } catch {
      // AudioContext not allowed or unsupported
    }
  };

  // Start Camera Stream
  const startCamera = async (facing: 'environment' | 'user' = 'environment') => {
    setCameraError(null);
    try {
      if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: facing,
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        audio: false
      });

      setCameraStream(stream);
      setIsCameraOpen(true);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.warn('Camera access error, fallback to file input:', err);
      setCameraError(
        isAr 
          ? 'تعذر الوصول المباشر لكاميرا الويب. يمكنك استخدام الكاميرا عبر زر إرفاق ملف من هاتفك.'
          : 'Accès caméra refusé. Utilisez le sélecteur de fichier pour ouvrir votre appareil photo.'
      );
      // Trigger native input as fallback
      if (fileInputRef.current) {
        fileInputRef.current.click();
      }
    }
  };

  // Stop Camera Stream
  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
      setCameraStream(null);
    }
    setIsCameraOpen(false);
  };

  useEffect(() => {
    if (isCameraOpen && cameraStream && videoRef.current) {
      videoRef.current.srcObject = cameraStream;
    }
  }, [isCameraOpen, cameraStream]);

  // Cleanup camera when unmounting
  useEffect(() => {
    return () => {
      if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
      }
    };
  }, [cameraStream]);

  // Capture Photo from Live Camera
  const captureSnapshot = () => {
    if (!videoRef.current) return;
    setIsTakingSnapshot(true);

    try {
      const video = videoRef.current;
      const canvas = document.createElement('canvas');
      const width = video.videoWidth || 640;
      const height = video.videoHeight || 480;

      // Max dimension 1200px for storage efficiency
      const maxDim = 1200;
      let targetW = width;
      let targetH = height;
      if (width > maxDim || height > maxDim) {
        if (width > height) {
          targetW = maxDim;
          targetH = Math.round((height * maxDim) / width);
        } else {
          targetH = maxDim;
          targetW = Math.round((width * maxDim) / height);
        }
      }

      canvas.width = targetW;
      canvas.height = targetH;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, targetW, targetH);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.82);
        setPhotos(prev => [...prev, dataUrl]);
        showToast(isAr ? 'تم التقاط الصورة بنجاح 📸' : 'Photo capturée avec succès 📸');
      }
    } catch (e) {
      console.error('Error capturing snapshot:', e);
    } finally {
      setTimeout(() => {
        setIsTakingSnapshot(false);
        stopCamera();
      }, 300);
    }
  };

  // Switch between front & back camera
  const toggleCameraFacing = () => {
    const nextMode = cameraFacingMode === 'environment' ? 'user' : 'environment';
    setCameraFacingMode(nextMode);
    startCamera(nextMode);
  };

  // Handle File Input (Camera or Gallery)
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach(file => {
      if (!file.type.startsWith('image/')) return;
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const maxDim = 1200;
          let w = img.width;
          let h = img.height;
          if (w > maxDim || h > maxDim) {
            if (w > h) {
              w = maxDim;
              h = Math.round((img.height * maxDim) / img.width);
            } else {
              h = maxDim;
              w = Math.round((img.width * maxDim) / img.height);
            }
          }
          canvas.width = w;
          canvas.height = h;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, w, h);
            const compressed = canvas.toDataURL('image/jpeg', 0.82);
            setPhotos(prev => [...prev, compressed]);
          }
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    });

    e.target.value = '';
    showToast(isAr ? 'تم إرفاق الصورة بنجاح 📷' : 'Photo ajoutée');
  };

  // Remove Photo
  const handleRemovePhoto = (indexToRemove: number) => {
    setPhotos(prev => prev.filter((_, idx) => idx !== indexToRemove));
  };

  // Submit Complaint to App & Trigger Admin Notification System
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      showToast(isAr ? 'يرجى إدخال عنوان أو موضوع العطل' : 'Veuillez saisir un sujet', { type: 'warning' });
      return;
    }
    if (!buildingCode) {
      showToast(isAr ? 'يرجى تحديد العمارة المعنية' : 'Veuillez sélectionner l\'immeuble', { type: 'warning' });
      return;
    }

    setIsSubmitting(true);

    try {
      // 1. Add Maintenance Ticket
      addMaintenanceTicket({
        title: title.trim(),
        description: description.trim(),
        buildingCode,
        apartmentOrArea: apartmentOrArea.trim() || (isAr ? 'المرافق المشتركة' : 'Parties communes'),
        category,
        priority,
        status: 'open',
        reportedBy: reportedBy.trim() || currentUser?.name || (isAr ? 'ساكن العمارة' : 'Copropriétaire'),
        ownerPhone: ownerPhone.trim() || currentUser?.phone || '',
        photos: photos.length > 0 ? photos : undefined,
        photoUrl: photos.length > 0 ? photos[0] : undefined
      });

      // 2. Play Audio Alert Chime
      if (soundEnabled) {
        playAlertChime();
      }

      // 3. Register in Administrative Notifications System
      try {
        const existingAlertsRaw = localStorage.getItem('syndic_maintenance_alerts');
        const existingAlerts = existingAlertsRaw ? JSON.parse(existingAlertsRaw) : [];
        const newAlert = {
          id: 'alt-' + Date.now(),
          title: title.trim(),
          buildingCode,
          apartmentOrArea: apartmentOrArea.trim(),
          reportedBy: reportedBy.trim(),
          phone: ownerPhone.trim(),
          priority,
          hasPhotos: photos.length > 0,
          photosCount: photos.length,
          timestamp: new Date().toISOString(),
          isRead: false
        };
        localStorage.setItem('syndic_maintenance_alerts', JSON.stringify([newAlert, ...existingAlerts.slice(0, 50)]));
        window.dispatchEvent(new CustomEvent('syndic-new-maintenance-alert', { detail: newAlert }));
      } catch (err) {
        console.error('Failed to store alert:', err);
      }

      // 4. Log Administrative Activity
      logActivity(
        'CREATE',
        'maintenance',
        'm-' + Date.now(),
        `بلاغ صيانة جديد من ${reportedBy || 'ساكن'} (${buildingCode}) بخصوص ${title.trim()} مرفق بـ ${photos.length} صورة كاميرا`,
        `Nouveau signalement par ${reportedBy} (${buildingCode}) : ${title.trim()} avec ${photos.length} photo(s)`
      );

      // 5. Toast & Success UI
      showToast(
        isAr 
          ? 'تم إرسال بلاغ الصيانة مع الصور وإشعار مكتب السانديك في الحال! 🚀📸' 
          : 'Signalement de maintenance envoyé avec succès au bureau du Syndic !',
        { type: 'success' }
      );

      setSubmitSuccess(true);
      if (onSuccess) onSuccess();

      // Reset form fields
      setTitle('');
      setDescription('');
      setPhotos([]);
      setApartmentOrArea(currentUser?.apartment ? `${lang === 'ar' ? 'شقة' : 'Appt'} ${currentUser.apartment}` : '');

    } catch (err) {
      console.error(err);
      showToast(isAr ? 'حدث خطأ أثناء إرسال البلاغ' : 'Erreur lors de l\'envoi', { type: 'error' });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Syndic Quick Reply Handler
  const handleSendSyndicReply = (ticket: MaintenanceTicket) => {
    if (!replyText.trim()) return;
    const now = new Date();
    const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    updateMaintenanceTicket(ticket.id, {
      syndicResponse: replyText.trim(),
      syndicResponseDate: dateStr,
      syndicResponderName: currentUser?.name || (isAr ? 'مكتب السانديك' : 'Bureau du Syndic'),
      status: ticket.status === 'open' ? 'in_progress' : ticket.status
    });

    showToast(isAr ? 'تم توثيق رد السانديك وإرسال الإشعار للساكن بنجاح! 📨' : 'Réponse envoyée au copropriétaire !');
    setReplyTicketId(null);
    setReplyText('');
  };

  // Filtered Tickets for Admin Center
  const incomingTickets = maintenanceTickets.filter(t => {
    if (adminFilter === 'urgent') return t.priority === 'urgent' || t.priority === 'high';
    if (adminFilter === 'with_photos') return t.photos && t.photos.length > 0;
    if (adminFilter === 'open') return t.status === 'open';
    return true;
  });

  const urgentCount = maintenanceTickets.filter(t => (t.priority === 'urgent' || t.priority === 'high') && t.status === 'open').length;
  const withPhotosCount = maintenanceTickets.filter(t => t.photos && t.photos.length > 0).length;

  return (
    <div className="space-y-6">
      
      {/* Syndic Office Sub-Bar (Switch between Report Form & Admin Alert Center) */}
      {!isOwner && (
        <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-[#072535] rounded-2xl border border-[#0e7490]/50 shadow-md">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setAdminViewTab('incoming_alerts')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                adminViewTab === 'incoming_alerts'
                  ? 'bg-teal-600 text-white shadow-md shadow-teal-500/30'
                  : 'text-teal-200 hover:bg-[#0b3347] hover:text-white'
              }`}
            >
              <BellRing className="w-4 h-4 text-cyan-300" />
              <span>{isAr ? 'نظام التنبيهات الإداري للبلاغات الواردة' : 'Centre d\'Alertes Administratives'}</span>
              {urgentCount > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-black animate-pulse">
                  {urgentCount} {isAr ? 'عاجل' : 'Urgent'}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setAdminViewTab('create')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                adminViewTab === 'create'
                  ? 'bg-teal-600 text-white shadow-md shadow-teal-500/30'
                  : 'text-teal-200 hover:bg-[#0b3347] hover:text-white'
              }`}
            >
              <Camera className="w-4 h-4 text-cyan-300" />
              <span>{isAr ? 'تسجيل بلاغ صيانة جديد بالكاميرا' : 'Nouveau Signalement'}</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setSoundEnabled(!soundEnabled)}
              className={`p-2 rounded-xl border text-xs flex items-center gap-1.5 transition-colors cursor-pointer ${
                soundEnabled 
                  ? 'bg-teal-950/80 border-teal-500/50 text-teal-200' 
                  : 'bg-slate-900 border-slate-700 text-slate-400'
              }`}
              title={soundEnabled ? (isAr ? 'تنبيه صوتي مفعل' : 'Son activé') : (isAr ? 'تنبيه صوتي معطل' : 'Son désactivé')}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-cyan-400" /> : <VolumeX className="w-4 h-4" />}
              <span className="text-[11px] font-bold hidden sm:inline">
                {soundEnabled ? (isAr ? 'صوت التنبيه' : 'Alerte sonore') : (isAr ? 'صامت' : 'Muet')}
              </span>
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 1. RESIDENT MAINTENANCE REPORT FORM (FORMULAIRE AVEC CAPTURE CAMÉRA)      */}
      {/* ========================================================================= */}
      {(isOwner || adminViewTab === 'create') && (
        <div className="bg-[#05212e] text-white rounded-3xl p-5 sm:p-7 border border-[#0e7490]/50 shadow-2xl relative overflow-hidden backdrop-blur-xl">
          
          {/* Header Banner */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 mb-6 border-b border-[#0e7490]/40">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-teal-500 to-cyan-600 flex items-center justify-center text-white shadow-lg shadow-teal-500/30 shrink-0">
                <Camera className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                  <span>{isAr ? 'إرسال بلاغ صيانة وعطل مع إرفاق صور الكاميرا' : 'Signaler une panne avec photos en direct'}</span>
                </h3>
                <p className="text-xs text-teal-200/80 mt-0.5">
                  {isAr 
                    ? 'التقط صوراً فورية للعطل بهاتفك ليتم إشعار مكتب السانديك وتوجيه التقني المختص في الحال.'
                    : 'Prenez des photos de la panne pour notifier le Syndic et planifier l\'intervention.'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-start sm:self-auto">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-teal-950/80 text-teal-300 border border-teal-700/60 flex items-center gap-1.5">
                <BellRing className="w-3.5 h-3.5 text-cyan-400 animate-bounce" />
                <span>{isAr ? 'تنبيه إداري فوري للسانديك' : 'Alerte administrative directe'}</span>
              </span>
            </div>
          </div>

          {/* Quick Issue Chips */}
          <div className="mb-6 space-y-2">
            <span className="text-xs font-bold text-teal-200 block">
              {isAr ? 'اختر مشكلة شائعة بسرعة أو اكتب تفاصيل البلاغ:' : 'Sélection rapide ou personnalisée :'}
            </span>
            <div className="flex flex-wrap gap-2">
              {quickIssues.map((item, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setTitle(item.title);
                    setCategory(item.cat);
                    setPriority(item.prio);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-[#072535] hover:bg-[#0a2f42] active:bg-[#031822] text-xs text-teal-100 border border-[#0e7490]/50 hover:border-cyan-400/60 transition-all cursor-pointer font-medium"
                >
                  {item.title}
                </button>
              ))}
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            
            {/* Title & Category Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              {/* Issue Title */}
              <div className="space-y-1.5 text-start">
                <label className="text-xs font-bold text-teal-200 flex items-center gap-1">
                  <FileText className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{isAr ? 'عنوان البلاغ أو موضوع العطل *' : 'Objet de la panne *'}</span>
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder={isAr ? 'مثال: تسرب ماء في المدخل الرئيسي...' : 'Ex: Fuite d\'eau au palier...'}
                  className="w-full px-4 py-2.5 rounded-2xl bg-[#031822] border border-[#0e7490]/50 text-white placeholder-slate-400 text-sm font-semibold focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400"
                  required
                />
              </div>

              {/* Category */}
              <div className="space-y-1.5 text-start">
                <label className="text-xs font-bold text-teal-200 flex items-center gap-1">
                  <Wrench className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{isAr ? 'نوع وتصنيف العطل' : 'Catégorie'}</span>
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as MaintenanceCategory)}
                  className="w-full px-4 py-2.5 rounded-2xl bg-[#031822] border border-[#0e7490]/50 text-white text-sm font-bold focus:outline-none focus:border-cyan-400"
                >
                  <option value="plumbing" className="bg-[#031822] text-white">{isAr ? 'ترصيص وسباكة ومياه 🚰' : 'Plomberie & Eau'}</option>
                  <option value="lighting" className="bg-[#031822] text-white">{isAr ? 'إنارة وكهرباء 💡' : 'Électricité & Éclairage'}</option>
                  <option value="cleaning" className="bg-[#031822] text-white">{isAr ? 'نظافة وعناية بالمرافق 🧹' : 'Nettoyage & Hygiène'}</option>
                  <option value="security" className="bg-[#031822] text-white">{isAr ? 'أمن، كاميرات، أقفال، إنترفون 🚪' : 'Sécurité & Interphone'}</option>
                  <option value="general" className="bg-[#031822] text-white">{isAr ? 'صيانة عامة وأخرى 🛠️' : 'Maintenance générale'}</option>
                </select>
              </div>

            </div>

            {/* Building, Area & Urgency Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              
              {/* Building Code */}
              <div className="space-y-1.5 text-start">
                <label className="text-xs font-bold text-teal-200 flex items-center gap-1">
                  <Building2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{isAr ? 'العمارة المعنية' : 'Immeuble'}</span>
                </label>
                <select
                  value={buildingCode}
                  onChange={(e) => setBuildingCode(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-2xl bg-[#031822] border border-[#0e7490]/50 text-white text-sm font-bold focus:outline-none focus:border-cyan-400"
                >
                  {buildings.map(b => (
                    <option key={b.id} value={b.code} className="bg-[#031822] text-white">
                      {b.code} ({b.name})
                    </option>
                  ))}
                </select>
              </div>

              {/* Apartment or Area */}
              <div className="space-y-1.5 text-start">
                <label className="text-xs font-bold text-teal-200 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{isAr ? 'مكان العطل (شقة أو مرفق)' : 'Lieu / N° Appt'}</span>
                </label>
                <input
                  type="text"
                  value={apartmentOrArea}
                  onChange={(e) => setApartmentOrArea(e.target.value)}
                  placeholder={isAr ? 'مثال: شقة 12 أو مدخل الدرج...' : 'Ex: Appt 12 ou palier 2ème...'}
                  className="w-full px-4 py-2.5 rounded-2xl bg-[#031822] border border-[#0e7490]/50 text-white placeholder-slate-400 text-sm font-semibold focus:outline-none focus:border-cyan-400"
                />
              </div>

              {/* Priority */}
              <div className="space-y-1.5 text-start">
                <label className="text-xs font-bold text-teal-200 flex items-center gap-1">
                  <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                  <span>{isAr ? 'مستوى الاستعجال والأهمية' : 'Niveau d\'urgence'}</span>
                </label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as MaintenancePriority)}
                  className="w-full px-4 py-2.5 rounded-2xl bg-[#031822] border border-[#0e7490]/50 text-white text-sm font-bold focus:outline-none focus:border-cyan-400"
                >
                  <option value="low" className="bg-[#031822] text-white">{isAr ? 'عادي (Low)' : 'Faible'}</option>
                  <option value="medium" className="bg-[#031822] text-white">{isAr ? 'متوسط (Medium)' : 'Moyen'}</option>
                  <option value="high" className="bg-[#031822] text-white">{isAr ? 'مهم ومستعجل (High) ⚠️' : 'Élevé ⚠️'}</option>
                  <option value="urgent" className="bg-[#031822] text-white">{isAr ? 'طارئ جداً وخطر (Urgent) 🚨' : 'Très urgent 🚨'}</option>
                </select>
              </div>

            </div>

            {/* Reporter Name & Phone */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              <div className="space-y-1.5 text-start">
                <label className="text-xs font-bold text-teal-200 flex items-center gap-1">
                  <User className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{isAr ? 'اسم الساكن أو المبلّغ' : 'Nom du déclarant'}</span>
                </label>
                <input
                  type="text"
                  value={reportedBy}
                  onChange={(e) => setReportedBy(e.target.value)}
                  placeholder={isAr ? 'اسم الساكن' : 'Nom complet'}
                  className="w-full px-4 py-2.5 rounded-2xl bg-[#031822] border border-[#0e7490]/50 text-white placeholder-slate-400 text-sm font-semibold focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="space-y-1.5 text-start">
                <label className="text-xs font-bold text-teal-200 flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{isAr ? 'رقم الهاتف للتواصل والمتابعة' : 'Numéro de téléphone'}</span>
                </label>
                <input
                  type="tel"
                  value={ownerPhone}
                  onChange={(e) => setOwnerPhone(e.target.value)}
                  placeholder="06XXXXXXXX"
                  className="w-full px-4 py-2.5 rounded-2xl bg-[#031822] border border-[#0e7490]/50 text-white placeholder-slate-400 text-sm font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>

            </div>

            {/* Detailed Description */}
            <div className="space-y-1.5 text-start">
              <label className="text-xs font-bold text-teal-200 block">
                {isAr ? 'وصف دقيق للمشكلة وتفاصيل العطل' : 'Description détaillée'}
              </label>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder={isAr ? 'اذكر تفاصيل إضافية لتسهيل مهمة التقني ومكتب السانديك...' : 'Détails complémentaires sur la panne...'}
                className="w-full px-4 py-2.5 rounded-2xl bg-[#031822] border border-[#0e7490]/50 text-white placeholder-slate-400 text-sm focus:outline-none focus:border-cyan-400 leading-relaxed"
              />
            </div>

            {/* ===================================================================== */}
            {/* CAMERA CAPTURE & PHOTO ATTACHMENT SECTION                             */}
            {/* ===================================================================== */}
            <div className="p-4 rounded-2xl bg-[#072535] border-2 border-dashed border-[#0e7490]/70 space-y-4">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h4 className="text-sm font-black text-white flex items-center gap-2">
                    <Camera className="w-4 h-4 text-cyan-400" />
                    <span>{isAr ? 'إرفاق صور العطل (كاميرا حية أو ألبوم الصور)' : 'Photos de la panne (Caméra / Galerie)'}</span>
                  </h4>
                  <p className="text-xs text-teal-200/80 mt-0.5">
                    {isAr 
                      ? 'يمكنك التقاط صورة فورية بالكاميرا لتوثيق مكان العطل والضرر.'
                      : 'Prenez une photo en direct ou choisissez depuis votre galerie.'}
                  </p>
                </div>

                {/* Camera & Upload Action Buttons */}
                <div className="flex items-center gap-2">
                  
                  {/* Direct Camera Capture Button */}
                  <button
                    type="button"
                    id="btn-open-camera-capture"
                    onClick={() => startCamera('environment')}
                    className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-teal-500 to-cyan-600 hover:from-teal-400 hover:to-cyan-500 text-white text-xs font-black transition-all shadow-md shadow-teal-500/30 cursor-pointer hover:scale-[1.02] active:scale-95"
                  >
                    <Camera className="w-4 h-4" />
                    <span>{isAr ? 'التقاط صورة بالكاميرا 📸' : 'Ouvrir la caméra'}</span>
                  </button>

                  {/* File Picker Button (Fallback & Gallery) */}
                  <button
                    type="button"
                    id="btn-upload-photo-gallery"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#0b3347] hover:bg-[#0f415c] text-teal-100 text-xs font-bold border border-[#0e7490]/60 transition-all cursor-pointer shadow-xs"
                  >
                    <Upload className="w-4 h-4 text-cyan-300" />
                    <span>{isAr ? 'ألبوم الصور' : 'Galerie'}</span>
                  </button>

                  {/* Hidden Native File Input with camera capture option */}
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    capture="environment"
                    multiple
                    className="hidden"
                    onChange={handleFileChange}
                  />
                </div>
              </div>

              {/* Photo Thumbnails Preview Strip */}
              {photos.length > 0 ? (
                <div className="pt-2">
                  <div className="flex items-center justify-between text-xs text-teal-200 font-bold mb-2">
                    <span>{isAr ? `الصور المرفقة (${photos.length})` : `Photos jointes (${photos.length})`}</span>
                    <button
                      type="button"
                      onClick={() => setPhotos([])}
                      className="text-rose-400 hover:text-rose-300 cursor-pointer text-[11px]"
                    >
                      {isAr ? 'مسح كل الصور' : 'Effacer tout'}
                    </button>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {photos.map((photo, idx) => (
                      <div 
                        key={idx} 
                        className="group relative rounded-xl overflow-hidden border border-[#0e7490] aspect-video bg-black/60 shadow-md"
                      >
                        <img 
                          src={photo} 
                          alt={`Captured ${idx + 1}`} 
                          className="w-full h-full object-cover cursor-pointer group-hover:scale-105 transition-transform duration-300"
                          onClick={() => setZoomedPhoto(photo)}
                        />
                        
                        {/* Zoom overlay badge */}
                        <div 
                          onClick={() => setZoomedPhoto(photo)}
                          className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer"
                        >
                          <Maximize2 className="w-5 h-5 text-white" />
                        </div>

                        {/* Delete button */}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleRemovePhoto(idx);
                          }}
                          className="absolute top-1.5 end-1.5 p-1 rounded-lg bg-rose-600/90 text-white hover:bg-rose-600 shadow-md cursor-pointer transition-colors"
                          title={isAr ? 'حذف الصورة' : 'Supprimer'}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>

                        <span className="absolute bottom-1 start-1.5 px-1.5 py-0.5 rounded bg-black/70 text-white font-mono text-[9px]">
                          #{idx + 1}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="py-4 text-center text-xs text-teal-200/60 flex flex-col items-center gap-1.5">
                  <ImageIcon className="w-8 h-8 text-teal-500/40" />
                  <span>{isAr ? 'لم يتم إرفاق صور بعد. انقر على «التقاط صورة بالكاميرا» لإضافة صور العطل.' : 'Aucune photo jointe. Cliquez pour capturer en direct.'}</span>
                </div>
              )}

            </div>

            {/* Submit Action Row */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-[#0e7490]/40">
              
              <div className="flex items-center gap-2 text-xs text-teal-200/80">
                <CheckCircle2 className="w-4 h-4 text-teal-400 shrink-0" />
                <span>
                  {isAr 
                    ? 'سيتم تسجيل البلاغ في سجل مكتب السانديك وإرسال تنبيه مباشر للإدارة'
                    : 'Le rapport sera transmis instantanément au bureau du Syndic.'}
                </span>
              </div>

              <button
                type="submit"
                id="btn-submit-maintenance-report"
                disabled={isSubmitting}
                className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-gradient-to-r from-teal-500 via-cyan-600 to-teal-600 hover:from-teal-400 hover:to-cyan-500 active:from-teal-600 active:to-cyan-700 text-white font-black text-sm shadow-xl shadow-teal-500/30 flex items-center justify-center gap-2 cursor-pointer transition-all hover:scale-[1.02] active:scale-95"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>{isAr ? 'جاري الإرسال...' : 'Envoi en cours...'}</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>{isAr ? 'إرسال البلاغ الآن وإشعار السانديك 🚀' : 'Envoyer le signalement'}</span>
                  </>
                )}
              </button>

            </div>

          </form>

        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. ADMIN MAINTENANCE ALERT NOTIFICATION CENTER (POUR LE SYNDIC)           */}
      {/* ========================================================================= */}
      {!isOwner && adminViewTab === 'incoming_alerts' && (
        <div className="bg-[#05212e] text-white rounded-3xl p-5 sm:p-7 border border-[#0e7490]/50 shadow-2xl space-y-6">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#0e7490]/40">
            <div>
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-teal-500/20 border border-teal-400/40 flex items-center justify-center text-teal-300">
                  <BellRing className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">
                    {isAr ? 'لوحة التنبيهات الإدارية لبلاغات وأعطال السكان' : 'Centre d\'Alertes et Signalements des Résidents'}
                  </h3>
                  <p className="text-xs text-teal-200/80 mt-0.5">
                    {isAr 
                      ? 'متابعة حية للبلاغات الواردة من الملاك المشتركين مع الصور الملتقطة عبر الكاميرا والرد الفوري عليها.'
                      : 'Suivi en direct des signalements avec photos caméra et réponses officielles.'}
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Stats Badges */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-3 py-1 rounded-xl bg-[#072535] border border-[#0e7490]/60 text-xs font-bold text-teal-200">
                {isAr ? 'المجموع:' : 'Total :'} {maintenanceTickets.length}
              </span>
              <span className="px-3 py-1 rounded-xl bg-rose-950/80 border border-rose-500/50 text-xs font-bold text-rose-200">
                {isAr ? 'عاجل:' : 'Urgents :'} {urgentCount}
              </span>
              <span className="px-3 py-1 rounded-xl bg-cyan-950/80 border border-cyan-500/50 text-xs font-bold text-cyan-200">
                {isAr ? 'مع صور:' : 'Avec photos :'} {withPhotosCount}
              </span>
            </div>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            <button
              type="button"
              onClick={() => setAdminFilter('all')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                adminFilter === 'all'
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'bg-[#072535] text-teal-200 hover:text-white'
              }`}
            >
              {isAr ? 'كافة البلاغات' : 'Tous'} ({maintenanceTickets.length})
            </button>
            <button
              type="button"
              onClick={() => setAdminFilter('urgent')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                adminFilter === 'urgent'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'bg-[#072535] text-rose-300 hover:text-white'
              }`}
            >
              {isAr ? 'الحالات العاجلة 🚨' : 'Urgents 🚨'} ({urgentCount})
            </button>
            <button
              type="button"
              onClick={() => setAdminFilter('with_photos')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                adminFilter === 'with_photos'
                  ? 'bg-cyan-600 text-white shadow-xs'
                  : 'bg-[#072535] text-cyan-300 hover:text-white'
              }`}
            >
              {isAr ? 'مرفق بصور الكاميرا 📸' : 'Avec photos 📸'} ({withPhotosCount})
            </button>
            <button
              type="button"
              onClick={() => setAdminFilter('open')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                adminFilter === 'open'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-[#072535] text-amber-300 hover:text-white'
              }`}
            >
              {isAr ? 'جديد قيد الانتظار ⏳' : 'En attente ⏳'} ({maintenanceTickets.filter(t => t.status === 'open').length})
            </button>
          </div>

          {/* Tickets Cards List */}
          {incomingTickets.length > 0 ? (
            <div className="space-y-4">
              {incomingTickets.map((ticket) => {
                const hasPhotos = ticket.photos && ticket.photos.length > 0;
                const isReplying = replyTicketId === ticket.id;

                return (
                  <div 
                    key={ticket.id}
                    className={`p-4 sm:p-5 rounded-2xl border transition-all ${
                      ticket.priority === 'urgent'
                        ? 'bg-[#181e28] border-rose-500/60 shadow-lg shadow-rose-950/20'
                        : 'bg-[#072535]/80 border-[#0e7490]/50 hover:border-cyan-400/50'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                      
                      {/* Ticket Info */}
                      <div className="space-y-1.5 flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                            ticket.priority === 'urgent'
                              ? 'bg-rose-600 text-white animate-pulse'
                              : ticket.priority === 'high'
                              ? 'bg-amber-500 text-slate-950'
                              : 'bg-teal-950 text-teal-300 border border-teal-800'
                          }`}>
                            {ticket.priority === 'urgent' ? (isAr ? '🚨 طارئ جداً' : 'Urgent') : ticket.priority}
                          </span>

                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#031822] text-cyan-300 border border-[#0e7490]/50">
                            {ticket.buildingCode} - {ticket.apartmentOrArea}
                          </span>

                          <span className="text-[10px] text-teal-200/60 font-mono">
                            {ticket.createdAt}
                          </span>

                          {hasPhotos && (
                            <span className="px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-200 text-[10px] font-bold border border-cyan-500/40 flex items-center gap-1">
                              <Camera className="w-3 h-3 text-cyan-300" />
                              <span>{ticket.photos!.length} {isAr ? 'صور' : 'photos'}</span>
                            </span>
                          )}
                        </div>

                        <h4 className="text-sm sm:text-base font-black text-white">
                          {ticket.title}
                        </h4>

                        {ticket.description && (
                          <p className="text-xs text-teal-100/90 leading-relaxed bg-[#031822]/60 p-2.5 rounded-xl border border-[#0e7490]/30">
                            {ticket.description}
                          </p>
                        )}

                        <div className="flex items-center gap-3 text-xs text-teal-200/80 pt-1">
                          <span className="font-bold flex items-center gap-1">
                            <User className="w-3.5 h-3.5 text-cyan-400" />
                            <span>{ticket.reportedBy}</span>
                          </span>
                          {ticket.ownerPhone && (
                            <a 
                              href={`tel:${ticket.ownerPhone}`}
                              className="font-mono text-cyan-300 hover:underline flex items-center gap-1"
                            >
                              <Phone className="w-3.5 h-3.5" />
                              <span>{ticket.ownerPhone}</span>
                            </a>
                          )}
                        </div>
                      </div>

                      {/* Status & Quick Actions */}
                      <div className="flex flex-col sm:items-end gap-2 shrink-0">
                        <span className={`px-3 py-1 rounded-xl text-xs font-black text-center ${
                          ticket.status === 'resolved'
                            ? 'bg-emerald-600 text-white'
                            : ticket.status === 'in_progress'
                            ? 'bg-blue-600 text-white'
                            : 'bg-amber-500 text-slate-950'
                        }`}>
                          {ticket.status === 'resolved' 
                            ? (isAr ? 'تم الإصلاح بنجاح ✅' : 'Résolu') 
                            : ticket.status === 'in_progress'
                            ? (isAr ? 'جاري التدخل 🛠️' : 'En cours')
                            : (isAr ? 'قيد الانتظار ⏳' : 'En attente')}
                        </span>

                        {/* Status Toggle Buttons */}
                        <div className="flex items-center gap-1 pt-1">
                          {ticket.status !== 'resolved' && (
                            <button
                              type="button"
                              onClick={() => {
                                updateMaintenanceTicket(ticket.id, { 
                                  status: 'resolved', 
                                  resolvedAt: new Date().toISOString() 
                                });
                                showToast(isAr ? 'تم تعيين العطل كمصلح بنجاح ✅' : 'Marqué comme résolu');
                              }}
                              className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold transition-colors cursor-pointer"
                            >
                              {isAr ? 'إتمام الإصلاح' : 'Résoudre'}
                            </button>
                          )}

                          {ticket.status === 'open' && (
                            <button
                              type="button"
                              onClick={() => {
                                updateMaintenanceTicket(ticket.id, { status: 'in_progress' });
                                showToast(isAr ? 'تم تحويل الحالة إلى جاري التدخل 🛠️' : 'Statut en cours');
                              }}
                              className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-bold transition-colors cursor-pointer"
                            >
                              {isAr ? 'بدء التدخل' : 'En cours'}
                            </button>
                          )}

                          <button
                            type="button"
                            onClick={() => {
                              if (isReplying) {
                                setReplyTicketId(null);
                              } else {
                                setReplyTicketId(ticket.id);
                                setReplyText(ticket.syndicResponse || '');
                              }
                            }}
                            className="px-2.5 py-1 rounded-lg bg-[#0b3347] hover:bg-[#0f415c] text-teal-200 text-[11px] font-bold border border-[#0e7490]/60 transition-colors cursor-pointer"
                          >
                            <MessageSquare className="w-3 h-3 inline-block me-1" />
                            <span>{ticket.syndicResponse ? (isAr ? 'تعديل الرد' : 'Modifier réponse') : (isAr ? 'رد السانديك' : 'Répondre')}</span>
                          </button>
                        </div>
                      </div>

                    </div>

                    {/* Camera Photos Strip for this Ticket */}
                    {hasPhotos && (
                      <div className="mt-3 pt-3 border-t border-[#0e7490]/40">
                        <div className="text-[11px] font-bold text-teal-200 mb-2 flex items-center gap-1.5">
                          <Camera className="w-3.5 h-3.5 text-cyan-400" />
                          <span>{isAr ? 'الصور الملتقطة والمرفقة من طرف الساكن عبر الكاميرا:' : 'Photos de la panne :'}</span>
                        </div>
                        <div className="flex flex-wrap gap-2.5">
                          {ticket.photos!.map((p, pIdx) => (
                            <div 
                              key={pIdx}
                              onClick={() => setZoomedPhoto(p)}
                              className="relative w-20 h-16 sm:w-24 sm:h-20 rounded-xl overflow-hidden border border-[#0e7490] cursor-pointer hover:scale-105 transition-transform shadow-md group"
                            >
                              <img src={p} alt={`panne-${pIdx}`} className="w-full h-full object-cover" />
                              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                <Maximize2 className="w-4 h-4 text-white" />
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Syndic Existing Response Display */}
                    {ticket.syndicResponse && !isReplying && (
                      <div className="mt-3 p-3 rounded-xl bg-teal-950/60 border border-teal-600/40 text-xs text-teal-100 space-y-1">
                        <div className="font-bold flex items-center justify-between text-teal-300 text-[11px]">
                          <span>{isAr ? 'رد وملاحظات مكتب السانديك 🏢:' : 'Réponse officielle du Syndic :'}</span>
                          <span className="font-mono text-[10px] text-teal-400/80">{ticket.syndicResponseDate}</span>
                        </div>
                        <p className="leading-relaxed">{ticket.syndicResponse}</p>
                      </div>
                    )}

                    {/* Inline Syndic Reply Input Box */}
                    {isReplying && (
                      <div className="mt-3 p-3.5 rounded-xl bg-[#031822] border border-cyan-500/50 space-y-2.5 animate-in fade-in">
                        <label className="text-xs font-bold text-cyan-300 block">
                          {isAr ? 'صياغة رد رسمي من مكتب السانديك على الساكن:' : 'Rédiger une réponse du Syndic :'}
                        </label>
                        <textarea
                          rows={2}
                          value={replyText}
                          onChange={(e) => setReplyText(e.target.value)}
                          placeholder={isAr ? 'مثال: تم إبلاغ التقني المختص وسيحضر لمعاينة العطل اليوم على الساعة 16:00...' : 'Ex: Le technicien a été mandaté pour intervenir...'}
                          className="w-full px-3 py-2 rounded-xl bg-[#072535] border border-[#0e7490]/60 text-white placeholder-slate-400 text-xs focus:outline-none focus:border-cyan-400"
                        />
                        <div className="flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => setReplyTicketId(null)}
                            className="px-3 py-1.5 rounded-lg text-xs text-slate-400 hover:text-white cursor-pointer"
                          >
                            {isAr ? 'إلغاء' : 'Annuler'}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleSendSyndicReply(ticket)}
                            className="px-4 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold transition-colors cursor-pointer shadow-xs"
                          >
                            {isAr ? 'حفظ وإرسال الرد للساكن 📨' : 'Enregistrer la réponse'}
                          </button>
                        </div>
                      </div>
                    )}

                  </div>
                );
              })}
            </div>
          ) : (
            <div className="py-12 text-center text-teal-200/60 space-y-2">
              <CheckCircle2 className="w-10 h-10 mx-auto text-teal-400" />
              <p className="font-bold text-sm text-white">
                {isAr ? 'لا توجد بلاغات معلقة مطابقة للتصفية المحددة' : 'Aucun signalement en attente'}
              </p>
              <p className="text-xs">
                {isAr ? 'كافة المرافق تعمل بصورة جيدة.' : 'Toutes les installations fonctionnent.'}
              </p>
            </div>
          )}

        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. RESIDENT PERSONAL REPORTS HISTORY (HISTORIQUE DES SIGNALEMENTS)        */}
      {/* ========================================================================= */}
      {isOwner && (
        <div className="bg-[#05212e] text-white rounded-3xl p-5 sm:p-6 border border-[#0e7490]/50 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-black text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-cyan-400" />
              <span>{isAr ? 'سجل بلاغاتي السابقة ومتابعة الإصلاح' : 'Mes signalements & Suivi des réparations'}</span>
            </h4>
            <span className="text-xs font-mono text-teal-300 bg-[#072535] px-2.5 py-0.5 rounded-full border border-[#0e7490]/60">
              {maintenanceTickets.filter(t => t.reportedBy === currentUser?.name || t.apartmentOrArea?.includes(currentUser?.apartment || '')).length} {isAr ? 'بلاغات' : 'tickets'}
            </span>
          </div>

          <div className="space-y-3">
            {maintenanceTickets
              .filter(t => t.reportedBy === currentUser?.name || t.apartmentOrArea?.includes(currentUser?.apartment || ''))
              .slice(0, 5)
              .map((ticket) => (
                <div 
                  key={ticket.id}
                  className="p-3.5 rounded-2xl bg-[#072535] border border-[#0e7490]/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-black text-white text-sm">{ticket.title}</span>
                      <span className="text-[10px] text-teal-300 font-mono">({ticket.createdAt})</span>
                    </div>
                    {ticket.description && (
                      <p className="text-teal-200/80 text-[11px] line-clamp-1">{ticket.description}</p>
                    )}
                    {ticket.syndicResponse && (
                      <div className="text-[11px] text-cyan-300 bg-[#031822] p-2 rounded-xl border border-cyan-500/30">
                        <strong>{isAr ? 'رد السانديك:' : 'Réponse du syndic :'}</strong> {ticket.syndicResponse}
                      </div>
                    )}
                  </div>

                  <span className={`px-3 py-1 rounded-xl text-xs font-black self-start sm:self-auto ${
                    ticket.status === 'resolved'
                      ? 'bg-emerald-600 text-white'
                      : ticket.status === 'in_progress'
                      ? 'bg-blue-600 text-white'
                      : 'bg-amber-500 text-slate-950'
                  }`}>
                    {ticket.status === 'resolved' 
                      ? (isAr ? 'تم الإصلاح بنجاح ✅' : 'Résolu') 
                      : ticket.status === 'in_progress'
                      ? (isAr ? 'جاري التدخل 🛠️' : 'En cours')
                      : (isAr ? 'قيد الانتظار ⏳' : 'En attente')}
                  </span>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. LIVE WEBRTC CAMERA STREAM MODAL (VIEWFINDER & SNAPSHOT)                 */}
      {/* ========================================================================= */}
      {isCameraOpen && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
          <div className="relative w-full max-w-xl bg-slate-950 rounded-3xl overflow-hidden border-2 border-teal-500/70 shadow-2xl flex flex-col">
            
            {/* Camera Header */}
            <div className="flex items-center justify-between p-3.5 bg-black/80 border-b border-teal-500/30 text-white z-10">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
                <span className="text-xs font-black tracking-wide">
                  {isAr ? 'كاميرا بلاغات الصيانة الحية' : 'Caméra de signalement'}
                </span>
              </div>

              <div className="flex items-center gap-2">
                {/* Switch Camera Button (Front / Back) */}
                <button
                  type="button"
                  onClick={toggleCameraFacing}
                  className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                  title={isAr ? 'تبديل الكاميرا (أمامية / خلفية)' : 'Changer de caméra'}
                >
                  <RefreshCw className="w-4 h-4" />
                </button>

                {/* Close Button */}
                <button
                  type="button"
                  onClick={stopCamera}
                  className="p-1.5 rounded-xl bg-rose-600/80 hover:bg-rose-600 text-white cursor-pointer transition-colors"
                  title={isAr ? 'إغلاق الكاميرا' : 'Fermer'}
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Video Viewfinder Area */}
            <div className="relative aspect-video sm:aspect-[4/3] bg-black flex items-center justify-center overflow-hidden">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />

              {/* Viewfinder Target Guidelines */}
              <div className="absolute inset-8 border border-white/25 rounded-2xl pointer-events-none flex flex-col justify-between p-2">
                <div className="flex justify-between">
                  <div className="w-4 h-4 border-t-2 border-s-2 border-teal-400" />
                  <div className="w-4 h-4 border-t-2 border-e-2 border-teal-400" />
                </div>
                <div className="text-center text-[10px] text-white/70 font-mono tracking-widest bg-black/40 px-2 py-0.5 rounded-full mx-auto">
                  {isAr ? 'وجّه الكاميرا نحو مكان العطل أو الضرر' : 'Cadrez la panne à photographier'}
                </div>
                <div className="flex justify-between">
                  <div className="w-4 h-4 border-b-2 border-s-2 border-teal-400" />
                  <div className="w-4 h-4 border-b-2 border-e-2 border-teal-400" />
                </div>
              </div>

              {/* Shutter Flash Animation Effect */}
              {isTakingSnapshot && (
                <div className="absolute inset-0 bg-white animate-out fade-out duration-300" />
              )}
            </div>

            {/* Camera Control Footer */}
            <div className="p-4 bg-black/90 border-t border-teal-500/30 flex items-center justify-center gap-4 z-10">
              <button
                type="button"
                id="btn-take-snapshot"
                onClick={captureSnapshot}
                disabled={isTakingSnapshot}
                className="group relative flex items-center justify-center w-16 h-16 rounded-full bg-white hover:bg-teal-100 active:scale-90 transition-all shadow-2xl cursor-pointer ring-4 ring-teal-500/60"
                title={isAr ? 'التقاط الصورة' : 'Capturer'}
              >
                <div className="w-12 h-12 rounded-full bg-teal-600 group-hover:bg-teal-500 flex items-center justify-center text-white transition-colors">
                  <Camera className="w-6 h-6" />
                </div>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. FULL-SCREEN ZOOMED PHOTO MODAL                                         */}
      {/* ========================================================================= */}
      {zoomedPhoto && (
        <div 
          onClick={() => setZoomedPhoto(null)}
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in"
        >
          <div className="relative max-w-4xl max-h-[90vh] w-full flex flex-col items-center">
            <button
              type="button"
              onClick={() => setZoomedPhoto(null)}
              className="absolute -top-10 end-0 p-2 text-white hover:text-rose-400 cursor-pointer text-sm font-bold flex items-center gap-1"
            >
              <X className="w-5 h-5" />
              <span>{isAr ? 'إغلاق' : 'Fermer'}</span>
            </button>
            <img 
              src={zoomedPhoto} 
              alt="Zoomed preview" 
              className="max-w-full max-h-[85vh] object-contain rounded-2xl border-2 border-teal-500/50 shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            />
          </div>
        </div>
      )}

    </div>
  );
};
