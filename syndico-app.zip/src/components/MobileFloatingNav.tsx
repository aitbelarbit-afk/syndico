import React from 'react';
import { motion } from 'motion/react';
import { LayoutDashboard, HandCoins, ReceiptText, Building2, KeyRound, Landmark } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface MobileFloatingNavProps {
  onOpenMenu: () => void;
  isMenuOpen: boolean;
}

export const MobileFloatingNav: React.FC<MobileFloatingNavProps> = ({ onOpenMenu, isMenuOpen }) => {
  const { activeSection, setActiveSection, lang, currentUser } = useApp();
  const isAr = lang === 'ar';
  const isOwner = currentUser?.role === 'resident';

  const navItems = isOwner ? [
    { id: 'dashboard', label: isAr ? 'الرئيسية' : 'Accueil', icon: LayoutDashboard },
    { id: 'apartments', label: isAr ? 'شقتي' : 'Mon Appt', icon: KeyRound },
    { id: 'payments', label: isAr ? 'وصلاتي' : 'Reçus', icon: HandCoins },
    { id: 'expenses', label: isAr ? 'المصاريف' : 'Dépenses', icon: ReceiptText },
    { id: 'two-years-report', label: isAr ? 'حصيلة سنتين' : 'Bilan 2 Ans', icon: Landmark },
  ] : [
    { id: 'dashboard', label: isAr ? 'الرئيسية' : 'Accueil', icon: LayoutDashboard },
    { id: 'payments', label: isAr ? 'المداخيل' : 'Cotisations', icon: HandCoins },
    { id: 'expenses', label: isAr ? 'المصاريف' : 'Dépenses', icon: ReceiptText },
    { id: 'apartments', label: isAr ? 'الشقق' : 'Appts', icon: Building2 },
    { id: 'two-years-report', label: isAr ? 'حصيلة 25-26' : 'Bilan 2 Ans', icon: Landmark },
  ];

  return (
    <div className="fixed bottom-3 inset-x-3 z-40 lg:hidden pointer-events-none no-print">
      <motion.div 
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ type: "spring", damping: 25, stiffness: 300 }}
        className="max-w-md mx-auto bg-slate-950/90 backdrop-blur-2xl border border-white/20 text-white rounded-2xl shadow-2xl p-1.5 flex items-center justify-between gap-1 pointer-events-auto"
      >
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = (activeSection === item.id || 
            (item.id === 'two-years-report' && ['two-years-report', 'bilan-2ans', 'report-2025-2026'].includes(activeSection))) && !isMenuOpen;

          return (
            <button
              key={item.id}
              id={`mobile-nav-${item.id}`}
              type="button"
              onClick={() => setActiveSection(item.id)}
              className="relative flex-1 py-2 px-1 flex flex-col items-center justify-center rounded-xl transition-all cursor-pointer select-none"
            >
              {isActive && (
                <motion.div
                  layoutId="activeMobileNavPill"
                  className="absolute inset-0 bg-gradient-to-br from-emerald-500 to-emerald-700 rounded-xl shadow-lg shadow-emerald-500/30"
                  transition={{ type: "spring", damping: 25, stiffness: 350 }}
                />
              )}
              <div className="relative z-10 flex flex-col items-center gap-0.5">
                <Icon className={`w-[18px] h-[18px] transition-transform ${isActive ? 'scale-110 text-white anim-bob' : 'text-slate-400'}`} />
                <span className={`text-[10px] font-bold truncate max-w-[64px] ${isActive ? 'text-white font-black' : 'text-slate-400'}`}>
                  {item.label}
                </span>
              </div>
            </button>
          );
        })}
      </motion.div>
    </div>
  );
};
