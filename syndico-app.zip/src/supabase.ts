import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Read from Vite environment variables (e.g. Netlify, Vercel, local .env)
export const normalizeSupabaseUrl = (urlStr: string): string => {
  if (!urlStr) return '';
  let cleaned = urlStr.trim();
  // Strip REST v1 endpoint suffix if user provided full REST endpoint
  cleaned = cleaned.replace(/\/rest\/v1\/?$/i, '');
  // Strip trailing slashes
  cleaned = cleaned.replace(/\/+$/, '');
  return cleaned;
};

export const ENV_SUPABASE_URL = normalizeSupabaseUrl(
  (typeof import.meta !== 'undefined' && import.meta.env && (
    import.meta.env.VITE_SUPABASE_URL ||
    import.meta.env.VITE_PUBLIC_SUPABASE_URL
  )) || ''
);

export const ENV_SUPABASE_KEY = (
  (typeof import.meta !== 'undefined' && import.meta.env && (
    import.meta.env.VITE_SUPABASE_KEY ||
    import.meta.env.VITE_SUPABASE_ANON_KEY ||
    import.meta.env.VITE_PUBLIC_SUPABASE_ANON_KEY
  )) || ''
).trim();

export let DEFAULT_SUPABASE_URL = ENV_SUPABASE_URL || '';
export let DEFAULT_SUPABASE_KEY = ENV_SUPABASE_KEY || '';

export const extractProjectRef = (urlStr: string): string => {
  try {
    const clean = normalizeSupabaseUrl(urlStr);
    const match = clean.match(/https:\/\/([a-z0-9-]+)\.supabase\.co/i);
    if (match && match[1]) return match[1];
    const u = new URL(clean);
    return u.hostname.split('.')[0] || 'custom';
  } catch {
    return 'custom';
  }
};

export const getSupabaseConfig = () => {
  let url = DEFAULT_SUPABASE_URL;
  let key = DEFAULT_SUPABASE_KEY;

  if (typeof window !== 'undefined') {
    const savedUrl = localStorage.getItem('custom_supabase_url');
    const savedKey = localStorage.getItem('custom_supabase_key');
    if (savedUrl && savedUrl.trim().startsWith('http')) {
      url = normalizeSupabaseUrl(savedUrl);
      key = savedKey ? savedKey.trim() : key;
    }
  }

  return { url: normalizeSupabaseUrl(url), key };
};

export const saveSupabaseConfig = (url: string, key: string) => {
  const cleanUrl = normalizeSupabaseUrl(url);
  const cleanKey = key.trim();
  if (typeof window !== 'undefined') {
    localStorage.setItem('custom_supabase_url', cleanUrl);
    localStorage.setItem('custom_supabase_key', cleanKey);
    DEFAULT_SUPABASE_URL = cleanUrl;
    DEFAULT_SUPABASE_KEY = cleanKey;
  }
};

export const clearCustomSupabaseConfig = () => {
  if (typeof window !== 'undefined') {
    localStorage.removeItem('custom_supabase_url');
    localStorage.removeItem('custom_supabase_key');
    DEFAULT_SUPABASE_URL = ENV_SUPABASE_URL || '';
    DEFAULT_SUPABASE_KEY = ENV_SUPABASE_KEY || '';
  }
};

export const createDynamicSupabaseClient = (customUrl?: string, customKey?: string): SupabaseClient | null => {
  const { url, key } = getSupabaseConfig();
  const targetUrl = customUrl ? customUrl.trim() : url;
  const targetKey = customKey ? customKey.trim() : key;

  if (!targetUrl || !targetUrl.startsWith('http') || !targetKey) {
    return null;
  }
  try {
    return createClient(targetUrl, targetKey);
  } catch (err) {
    console.warn('Failed to init Supabase client:', err);
    return null;
  }
};

export interface SupabaseTestResult {
  success: boolean;
  message: string;
  code?: string;
  projectRef?: string;
  latencyMs?: number;
  tableReady?: boolean;
  timestamp?: string;
}

/**
 * Test function to verify connection to Supabase project.
 * Checks server proxy (if available) or direct client endpoints (Netlify/Vercel/Browser).
 */
export const testSupabaseConnection = async (testUrl?: string, testKey?: string): Promise<SupabaseTestResult> => {
  const startTime = Date.now();
  const { url, key } = getSupabaseConfig();
  const targetUrl = normalizeSupabaseUrl(testUrl || url);
  const targetKey = (testKey || key).trim();
  const currentRef = extractProjectRef(targetUrl);

  // 1. Try server-side proxy first ONLY if on Express backend (not static Netlify)
  if (!testUrl && !testKey) {
    try {
      const srvRes = await fetch('/api/supabase/test', {
        headers: {
          ...(url ? { 'x-supabase-url': url } : {}),
          ...(key ? { 'x-supabase-key': key } : {})
        }
      });
      const ct = srvRes.headers.get('content-type') || '';
      // Only process if it is a JSON API response from an active backend (not Netlify SPA html fallback)
      if (srvRes.ok && ct.includes('application/json')) {
        const data = await srvRes.json();
        if (data && data.success) {
          return {
            success: true,
            message: data.message || `تم الاتصال بنجاح بمشروع Supabase (${currentRef})`,
            projectRef: data.projectRef || currentRef,
            latencyMs: data.latencyMs || (Date.now() - startTime),
            tableReady: data.tableReady ?? true,
            timestamp: data.timestamp || new Date().toISOString()
          };
        }
      }
    } catch {
      // Fallback to direct client fetch (Netlify static hosting)
    }
  }

  if (!targetUrl || !targetUrl.startsWith('http')) {
    return { success: false, message: 'رابط Supabase غير صالح (يجب أن يبدأ بـ https://)' };
  }
  if (!targetKey) {
    return { success: false, message: 'مفتاح API الخاص بـ Supabase مفقود' };
  }

  try {
    // 2. Direct client fetch to Supabase Auth & REST Health endpoint
    const response = await fetch(`${targetUrl}/auth/v1/health`, {
      method: 'GET',
      headers: {
        'apikey': targetKey,
      }
    });

    const latencyMs = Date.now() - startTime;
    const projectRef = response.headers.get('sb-project-ref') || currentRef;

    if (response.ok || response.status === 200) {
      return { 
        success: true, 
        message: `تم الاتصال بنجاح بمشروع Supabase (${projectRef}) !`,
        projectRef,
        latencyMs,
        tableReady: true,
        timestamp: new Date().toISOString()
      };
    }

    if (response.status === 401) {
      return { success: false, message: 'مفتاح API غير صالح (خطأ 401: تأكد من مفتاح anon/publishable)', code: '401', projectRef };
    }

    if (response.status === 404) {
      return { success: false, message: 'مشروع Supabase غير موجود أو متوقف مؤقتاً (خطأ 404)', code: '404', projectRef };
    }

    return { success: false, message: `خطأ في خادم Supabase (كود HTTP ${response.status})`, code: String(response.status), projectRef };
  } catch (err: any) {
    return { 
      success: false, 
      message: `تعذر الاتصال بخادم Supabase (${currentRef}) - تأكد من صحة الرابط وحالة المشروع في لوحة تحكم Supabase`,
      code: 'NETWORK_ERROR',
      projectRef: currentRef
    };
  }
};

/**
 * Dedicated test function to verify link to current Supabase project
 */
export const checkSupabaseProjectStatus = async (projectId?: string): Promise<SupabaseTestResult> => {
  return await testSupabaseConnection();
};

export const supabase = createDynamicSupabaseClient();

