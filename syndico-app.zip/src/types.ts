export type Language = 'ar' | 'fr';

export type UserRole = 'admin' | 'syndic' | 'agent' | 'resident' | 'super_admin' | 'syndic_admin' | 'guard' | 'supervisor' | 'accountant';

export interface User {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  password?: string;
  phone?: string;
  email?: string;
  cin?: string; // National ID Card (CIN)
  building?: string;
  apartment?: string;
  lastLogin?: string;
}

export interface LoginResult {
  success: boolean;
  status: 'ALLOWED' | 'RESTRICTED' | 'INVALID_CREDENTIALS' | 'ERROR';
  message?: string;
  token?: string;
  userData?: User;
  arrearsCount?: number;
  totalDue?: number;
  contactPhone?: string;
  apartment?: Apartment | null;
  debtStatus?: any;
}

export interface Building {
  id: string;
  code: string; // e.g. ""
  name: string; // e.g. "عمارة 34" or "Immeuble"
  floors: number;
  apartmentsCount: number;
  managerName: string;
  managerPhone: string;
  notes?: string;
}

export type ApartmentStatus = 'occupied' | 'vacant' | 'for_rent' | 'for_sale';
export type PaymentStatus = 'paid' | 'unpaid' | 'partial';

export interface Apartment {
  id: string;
  number: string; // e.g. "12"
  buildingCode: string; // e.g. ""
  floor: number; // 0 = RDC (السفلي), 1 = 1er (الأول), 2 = 2ème (الثاني), 3 = 3ème (الثالث)
  area?: number; // m² (optional)
  ownerName: string;
  ownerPhone: string;
  ownerEmail?: string;
  ownerCin?: string; // National ID Card (CIN)
  residentName: string;
  residentPhone: string;
  residentEmail?: string;
  isRented: boolean;
  status: ApartmentStatus;
  monthlyFee: number; // in MAD / DH
  balanceDue: number; // in MAD / DH
  unpaidMonthsCount?: number; // عدد أشهر المديونية المحددة من السانديك
  debtStartPeriod?: string; // e.g. "2026-06"
  isSyndicOffice?: boolean; // True for the dedicated Syndic Office unit
  notes?: string;
}

export interface Resident {
  id: string;
  fullName: string;
  type: 'owner' | 'tenant'; // مالك أو مكتري
  buildingCode: string;
  apartmentNumber: string;
  phone: string;
  email: string;
  cin?: string; // National ID
  vehiclePlate?: string;
  familyMembersCount?: number;
  entryDate: string;
}

export type EmployeeRole = 'security' | 'supervisor' | 'cleaning' | 'gardener' | 'technician' | 'admin' | 'syndic' | 'deputy_syndic' | 'collector' | 'sweeper';

export interface Employee {
  id: string;
  name: string;
  role: EmployeeRole;
  phone: string;
  shift: string; // e.g. "08:00 - 16:00"
  salary: number; // in MAD
  assignedBuilding?: string;
  status: 'active' | 'leave';
  cin?: string;
  startDate?: string; // YYYY-MM-DD تاريخ بدء العمل
  createdAt?: string; // تاريخ التسجيل في النظام
}

// Pointage & Attendance Types
export type PointageStatus = 'present' | 'rest' | 'absent' | 'leave_paid' | 'half_day';

export interface EmployeeDailyPointage {
  id: string; // `${employeeId}_${date}`
  employeeId: string;
  date: string; // YYYY-MM-DD
  status: PointageStatus;
  notes?: string;
}

export interface EmployeeSalaryCalculation {
  employeeId: string;
  monthKey: string; // YYYY-MM
  baseSalary: number; // e.g. 2200 DH
  standardWorkDays: number; // 26
  standardRestDays: number; // 4
  dailyRate: number; // baseSalary / 26
  presentDays: number;
  restDays: number;
  absentDays: number;
  paidLeaveDays: number;
  halfDays: number;
  totalAbsenceDeduction: number; // absentDays * dailyRate
  advanceDeduction: number; // تسبيقات
  bonusAmount: number; // مكافآت
  netSalary: number; // صافي الأجرة المستحقة للصرف
  isPaid: boolean;
  expenseId?: string;
  startDate?: string; // YYYY-MM-DD تاريخ بدء العمل
}

export type MaintenancePriority = 'low' | 'medium' | 'high' | 'urgent';
export type MaintenanceStatus = 'open' | 'in_progress' | 'resolved';
export type MaintenanceCategory = 'lighting' | 'plumbing' | 'cleaning' | 'security' | 'general';

export interface MaintenanceTicket {
  id: string;
  title: string;
  description: string;
  buildingCode: string;
  apartmentOrArea: string;
  category: MaintenanceCategory;
  priority: MaintenancePriority;
  status: MaintenanceStatus;
  reportedBy: string;
  ownerPhone?: string;
  assignedTo?: string; // Technicien / Prestataire
  technicianPhone?: string;
  estimatedCost?: number;
  actualCost?: number;
  createdAt: string;
  resolvedAt?: string;
  
  // صور العطل الملتقطة عبر الكاميرا (Camera Captured Photos)
  photos?: string[];
  photoUrl?: string;

  // رد وإجابة السانديك على الشكاية (Syndic Response)
  syndicResponse?: string;
  syndicResponseDate?: string;
  syndicResponderName?: string;
  
  // التدخلات التي يجب عملها لإصلاح الأعطال (Technical Intervention & Actions)
  interventionDetails?: string; // طبيعة التدخلات والإصلاحات المطلوبة
  interventionScheduledDate?: string; // تاريخ وساعة التدخل المبرمج
  interventionStatus?: 'pending' | 'in_progress' | 'completed';
  interventionReport?: string; // تقرير التدخل وخلاصة الإصلاح
}

export type PaymentMethod = 'cash' | 'bank_transfer' | 'check' | 'online';

export interface Payment {
  id: string;
  receiptNumber: string; // e.g. "REC-2026-001"
  residentName: string;
  buildingCode: string;
  apartmentNumber: string;
  periodMonth: string; // e.g. "2026-08" or "أغسطس 2026"
  monthsCount?: number; // عدد الأشهر المؤداة (Nombre de mois payés)
  amount: number; // in MAD
  paymentDate: string;
  paymentMethod: PaymentMethod;
  notes?: string;
  receivedBy: string;
  createdAt?: string; // تاريخ وساعة الإنجاز الفعلية بالتوقيت الدقيق
  executedAtTime?: string; // ساعة الإنجاز التلقائية (HH:mm:ss)
  updatedAt?: string;
}

export type ExpenseCategory = 
  | 'worker_salaries'      // أجور العمال
  | 'syndic_fees'          // أجرة وكيل و نائبه
  | 'cleaning_supplies'    // مواد النظافة
  | 'electrical_supplies'  // مواد الكهربائية
  | 'hardware_droguerie'   // العقاقير بمختلفها
  | 'building_materials'   // مواد البناء
  | 'irrigation_tools'     // أدوات السقي
  | 'office_stationery'    // مكتبيات
  | 'lawyer_fees'          // أتعاب المحامي
  | 'bailiff_fees'         // أتعاب مفوض قضائي
  | 'electricity' 
  | 'water' 
  | 'cleaning_company' 
  | 'security_company' 
  | 'emergency_repairs' 
  | 'supplies' 
  | 'other';

export interface Expense {
  id: string;
  category: ExpenseCategory;
  title: string;
  amount: number; // in MAD
  buildingCode?: string; // or "ALL" for whole residence
  date: string;
  supplier: string;
  invoiceRef?: string;
  paidBy: string;
  paymentMethod: PaymentMethod;
  notes?: string;
  createdAt?: string; // تاريخ وساعة الإنجاز الفعلية بالتوقيت الدقيق
  executedAtTime?: string; // ساعة الإنجاز التلقائية (HH:mm:ss)
  updatedAt?: string;
}

export interface Visitor {
  id: string;
  visitorName: string;
  buildingCode: string;
  apartmentNumber: string;
  residentName: string;
  vehiclePlate?: string;
  cin?: string;
  entryTime: string;
  exitTime?: string;
  purpose: string;
  registeredBy: string;
  status: 'inside' | 'left';
}

export type NoticePriority = 'normal' | 'important' | 'high' | 'urgent';

export interface Notice {
  id: string;
  title: string;
  content: string;
  targetBuilding: string; // "ALL" or specific e.g. ""
  targetAudience?: 'all' | 'owners' | 'tenants' | 'specific_building';
  buildingCode?: string;
  date: string;
  publishDate: string;
  priority: NoticePriority;
  author: string;
}

export interface ArchiveBatch {
  id: string;
  archiveDate: string;
  cutoffDate: string;
  cutoffMonths: number;
  paymentsCount: number;
  expensesCount: number;
  paymentsTotalAmount: number;
  expensesTotalAmount: number;
  archivedBy: string;
  notes?: string;
}

export interface ArchiveSummary {
  archivedPaymentsCount: number;
  archivedExpensesCount: number;
  archivedPaymentsTotal: number;
  archivedExpensesTotal: number;
  lastArchiveDate?: string;
  totalBatchesCount: number;
}

export type PeriodicFrequency = 'weekly' | 'monthly' | 'quarterly' | 'biannual' | 'annual' | 'custom';
export type MaintenanceAlertType = 'overdue' | 'today' | 'imminent';

export interface PeriodicMaintenanceHistory {
  id: string;
  completedDate: string;
  completedBy: string;
  actualCost: number;
  notes?: string;
  ticketId?: string;
}

export interface PeriodicMaintenance {
  id: string;
  title: string;
  category: MaintenanceCategory;
  buildingCode: string; // "ALL" or specific e.g. ""
  apartmentOrArea: string;
  frequency: PeriodicFrequency;
  customIntervalDays?: number;
  nextDueDate: string; // YYYY-MM-DD
  lastCompletedDate?: string;
  remindDaysBefore: number; // e.g. 7, 3, 15, 30
  providerOrTechnician: string;
  providerPhone?: string;
  estimatedCost: number;
  notes?: string;
  isActive: boolean;
  createdAt: string;
  history?: PeriodicMaintenanceHistory[];
}

export interface MaintenanceAlert {
  scheduleId: string;
  schedule: PeriodicMaintenance;
  type: MaintenanceAlertType;
  daysRemaining: number;
  message: string;
}

export interface MaintenanceChecklistItem {
  id: string;
  title: string;
  category: MaintenanceCategory;
  area: string; // e.g. "مدخل العمارة", "مضخات الماء", "الموقف", "السطح"
  buildingCode: string; // "ALL" or specific building
  isCompleted: boolean;
  completedAt?: string;
  completedBy?: string;
  notes?: string;
  hasIssue?: boolean;
  issueNotes?: string;
}

export interface DailyMaintenanceLog {
  id: string;
  date: string; // YYYY-MM-DD
  buildingCode: string; // "ALL" or specific
  inspectorName: string;
  items: MaintenanceChecklistItem[];
  generalNotes?: string;
  weatherOrCondition?: string;
  createdAt: string;
  completionRate: number; // percentage 0-100
}

export interface ResidenceLocationInfo {
  name: string;
  nameFr: string;
  city: string;
  country: string;
  fullAddressAr: string;
  fullAddressFr: string;
  latitude: number;
  longitude: number;
  googleMapsUrl: string;
  googleMapsShortUrl?: string;
  wazeUrl: string;
  appleMapsUrl: string;
  syndicOfficeLocationAr: string;
  syndicOfficeLocationFr: string;
  mainEntranceAr: string;
  mainEntranceFr: string;
  landmarksAr: string;
  landmarksFr: string;
  contactPhone: string;
  securityPhone: string;
  email: string;
  notesAr?: string;
  notesFr?: string;
}

export type ActivityAction = 'CREATE' | 'UPDATE' | 'DELETE' | 'RESTORE' | 'LOGOUT' | 'LOGIN' | 'SYSTEM';

export interface ActivityLogEntry {
  id: string;
  userId: string;
  userName: string;
  action: ActivityAction;
  entityType: string;
  entityId: string;
  detailsAr: string;
  detailsFr: string;
  timestamp: string;
}

export interface DeletedRecord {
  id: string;
  originalId: string;
  entityType: string;
  data: any;
  deletedAt: string;
  deletedBy: string;
}

export interface ProjectedExpenseItem {
  id: string;
  category: ExpenseCategory | 'reserve_fund' | 'renovation' | 'elevator' | 'pest_control';
  nameAr: string;
  nameFr: string;
  monthlyAmount: number;
  annualAmount: number;
  isCustom?: boolean;
  notes?: string;
  enabled: boolean;
}

export interface BudgetSimulationPlan {
  id: string;
  targetYear: number;
  createdAt: string;
  updatedAt: string;
  title: string;
  items: ProjectedExpenseItem[];
  reserveFundPercentage: number; // e.g. 10%
  expectedCollectionRate: number; // e.g. 95%
  totalApartmentsCount: number;
  currentMonthlyFeePerApt: number;
  distributionMethod: 'equal' | 'by_area';
}

// السجل المالي اليدوي للأشهر السابقة واللاحقة ابتداء من 04/2025
export interface ManualMonthlyRecord {
  id: string;
  monthKey: string; // YYYY-MM e.g. "2025-04", "2025-05", etc.
  totalIncome: number; // مجموع المداخيل الشهرية (DH)
  totalExpenses: number; // مجموع المصاريف الشهرية (DH)
  openingBalance?: number; // الرصيد المرحل من الشهر السابق (DH)
  closingBalance?: number; // الرصيد الختامي بعد العمليات (DH)
  notes?: string; // ملاحظات وتفاصيل السنديك
  breakdownIncome?: {
    regularFees?: number; // واجبات السنديك العادية
    exceptionalContributions?: number; // مساهمات استثنائية
    priorArrears?: number; // متأخرات مستخلصة
    otherIncome?: number; // مداخيل أخرى
  };
  breakdownExpenses?: {
    salaries?: number; // أجور الحراسة والنظافة
    workerSalaries?: number; // أجرة العمال
    syndicAndDeputyFees?: number; // أجرة الوكيل و نائبه
    lawyerFees?: number; // أتعاب المحامي
    bailiffFees?: number; // أتعاب المفوض القضائي
    hardwareDroguerie?: number; // العقاقير بمختلفها
    utilities?: number; // ماء وكهرباء المرافق المشتركة
    maintenance?: number; // صيانة وإصلاحات
    supplies?: number; // مواد تنظيف ومكتبيات
    otherExpenses?: number; // مصاريف أخرى / استعمال يومي
    buildingMaterials?: number; // مواد البناء
    electricalMaterials?: number; // مواد كهربائية
    irrigationTools?: number; // أدوات السقي
    stairsElectricity?: number; // فاتورة كهرباء الدرج
    wellElectricity?: number; // فاتورة كهرباء البئر
  };
  isClosed?: boolean; // الشهر مغلق: رصيده الختامي مرحّل تلقائياً للشهر الموالي
  closedAt?: string; // تاريخ الإغلاق
  closedBy?: string; // من أغلق الشهر
  recordedBy?: string; // اسم المدون
  updatedAt: string;
  isUserModified?: boolean; // تم تعديلها وحفظها يدوياً بواسطة المستخدم
}

// قرارات وتصويت الجمع العام (Assemblée Générale)
export type ResolutionStatus = 'draft' | 'active' | 'closed';
export type VoteChoice = 'for' | 'against' | 'abstain';
export type AssemblyType = 'ordinary' | 'extraordinary'; // جمع عام عادي أو استثنائي
export type ResolutionCategory = 'financial' | 'management' | 'works' | 'security' | 'statute';
export type MajorityRequired = 'simple' | 'absolute' | 'unanimous'; // الأغلبية النسبية، المطلقة، الإجماع

export interface ResolutionVote {
  id: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  apartmentNumber: string;
  buildingCode: string;
  choice: VoteChoice; // مع / ضد / ممتنع
  timestamp: string;
  comment?: string; // ملاحظة أو تحفظ رسمي
}

export interface AssemblyResolution {
  id: string;
  assemblyYear: number;
  assemblyType: AssemblyType;
  titleAr: string;
  titleFr: string;
  descriptionAr: string;
  descriptionFr: string;
  category: ResolutionCategory;
  status: ResolutionStatus;
  majorityRequired: MajorityRequired;
  createdAt: string;
  closedAt?: string;
  votes: ResolutionVote[];
}


