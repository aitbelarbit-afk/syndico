import { RES } from '../config/residence';
import React, { createContext, useContext, useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { 
  Language, User, Building, Apartment, Resident, Employee, 
  MaintenanceTicket, Payment, Expense, Visitor, Notice, ArchiveBatch,
  PeriodicMaintenance, MaintenanceAlert, PeriodicFrequency,
  MaintenanceChecklistItem, DailyMaintenanceLog, LoginResult,
  ApartmentStatus, PointageStatus, ActivityLogEntry, DeletedRecord, ActivityAction,
  ManualMonthlyRecord, AssemblyResolution, ResolutionVote, VoteChoice, ResolutionStatus
} from '../types';
import { initialAssemblyResolutions } from '../data/initialResolutions';
import { translations } from '../i18n/translations';
import { 
  initialBuildings, initialApartments, initialResidents, 
  initialEmployees, initialMaintenanceTickets, initialPayments, 
  initialExpenses, initialVisitors, initialNotices, initialUsers,
  initialPeriodicMaintenances, initialDailyChecklistItems,
  initialDailyMaintenanceLogs, initialManualMonthlyRecords
} from '../data/initialData';
import { 
  generateMonthlySurplusExpenses, 
  generateMonthlySurplusPayments, 
  ensurePositiveSurplusForAllMonths, 
  MONTHS_FROM_MAY_2026 
} from '../data/monthlyFinancialData';
import { getMoroccanApartmentData, isGenericPlaceholderName, isOldMockResidentName } from '../data/moroccanResidentsData';
import { getApartmentDebtStatus, calculateMonthsLateFromPeriod, SUSPENSION_MONTHS_THRESHOLD } from '../utils/debtUtils';
import { generateDefaultMonthPointage, getEmployeeEffectiveStartDate, isEmployeeActiveInMonth } from '../utils/pointageUtils';
import { harmonizeManualMonthlyRecordsChain, getNextMonthKey } from '../utils/monthlyFinanceUtils';

import { 
  pullResidenceFromSupabase, 
  pushResidenceToSupabase, 
  clearSupabaseAllData,
  subscribeToSupabaseSync,
  ResidenceSyncPayload 
} from '../services/supabaseSync';

interface AppContextType {
  lang: Language;
  t: typeof translations['ar'];
  setLanguage: (lang: Language) => void;
  toggleLanguage: () => void;
  currentUser: User | null;
  login: (user: string, pass: string) => boolean;
  loginResident: (buildingCode: string, apartmentNumber: string, residentName?: string, bypassDebtCheck?: boolean, cin?: string) => { success: boolean; isBlocked?: boolean; debtStatus?: any; message?: string };
  handleUserLogin: (emailOrIdentifier: string, password?: string) => Promise<LoginResult>;
  checkOwnerDebtAccess: (buildingCode: string, apartmentNumber: string) => { isBlocked: boolean; allowed: boolean; unpaidMonths: number; totalDue: number; message: string; debtStatus: any };
  debtWarningAlert: string | null;
  setDebtWarningAlert: (msg: string | null) => void;
  logout: () => void;
  activeSection: string;
  setActiveSection: (sec: string) => void;
  
  // Data State
  buildings: Building[];
  apartments: Apartment[];
  residents: Resident[];
  employees: Employee[];
  maintenanceTickets: MaintenanceTicket[];
  payments: Payment[];
  expenses: Expense[];
  visitors: Visitor[];
  notices: Notice[];
  users: User[];
  archivedPayments: Payment[];
  archivedExpenses: Expense[];
  archiveBatches: ArchiveBatch[];
  periodicMaintenances: PeriodicMaintenance[];

  // Activity & Trash
  activities: ActivityLogEntry[];
  trash: DeletedRecord[];
  isActivityDrawerOpen: boolean;
  setIsActivityDrawerOpen: (open: boolean) => void;
  openActivityLog: () => void;
  closeActivityLog: () => void;
  logActivity: (action: ActivityAction, entityType: string, entityId: string, detailsAr: string, detailsFr: string) => void;
  moveToTrash: (entityType: string, originalId: string, data: any) => void;
  restoreFromTrash: (id: string) => void;

  // Mutations
  addBuilding: (b: Omit<Building, 'id'>) => void;
  updateBuilding: (id: string, b: Partial<Building>) => void;
  deleteBuilding: (id: string) => void;

  addApartment: (apt: Omit<Apartment, 'id'>) => void;
  updateApartment: (id: string, apt: Partial<Apartment>) => void;
  deleteApartment: (id: string) => void;
  updateAllMonthlyFees: (amount: number, buildingCode?: string) => void;
  resetAllApartmentDebts: (targetBuildingCode?: string) => void;
  setApartmentDebt: (apartmentId: string, unpaidMonths: number, customAmount?: number) => void;
  importOwnersFromExcelData: (
    rows: Array<{
      buildingCode: string;
      apartmentNumber: string;
      ownerName: string;
      ownerPhone?: string;
      ownerCin?: string;
      ownerEmail?: string;
      addressOrNotes?: string;
      floor?: number;
      monthlyFee?: number;
      status?: ApartmentStatus;
      residentName?: string;
      residentPhone?: string;
      unpaidMonthsCount?: number;
      balanceDue?: number;
    }>,
    options?: {
      updateApartments?: boolean;
      syncResidents?: boolean;
      createMissingApartments?: boolean;
      overwriteExistingPhones?: boolean;
      updateDebts?: boolean;
    }
  ) => {
    apartmentsUpdated: number;
    residentsUpdated: number;
    apartmentsCreated: number;
  };

  importResidentsFromExcelData: (
    rows: Array<{
      fullName: string;
      type: 'owner' | 'tenant';
      buildingCode: string;
      apartmentNumber: string;
      phone: string;
      email?: string;
      cin?: string;
      vehiclePlate?: string;
      familyMembersCount?: number;
      entryDate?: string;
    }>,
    options?: {
      mode?: 'merge' | 'replace';
      syncApartments?: boolean;
      overwriteExistingDetails?: boolean;
    }
  ) => {
    residentsAdded: number;
    residentsUpdated: number;
    apartmentsSynced: number;
  };

  addResident: (res: Omit<Resident, 'id'>) => void;
  updateResident: (id: string, res: Partial<Resident>) => void;
  deleteResident: (id: string) => void;

  addEmployee: (emp: Omit<Employee, 'id'>) => Employee;
  updateEmployee: (id: string, emp: Partial<Employee>) => void;
  deleteEmployee: (id: string) => void;

  // Pointage & Attendance System (تنقيط العمال وحساب الأجور)
  pointageRecords: Record<string, PointageStatus>;
  pointageAdvances: Record<string, number>;
  pointageBonuses: Record<string, number>;
  setPointageStatus: (employeeId: string, date: string, status: PointageStatus) => void;
  batchSetPointageStatus: (entries: Array<{ employeeId: string; date: string; status: PointageStatus }>) => void;
  applyMonthDefaultPointage: (monthKey: string, employeeId?: string) => void;
  clearMonthPointage: (monthKey: string, employeeId?: string) => void;
  setPointageAdvance: (employeeId: string, monthKey: string, amount: number) => void;
  setPointageBonus: (employeeId: string, monthKey: string, amount: number) => void;
  savePointageData: () => void;

  addMaintenanceTicket: (t: Omit<MaintenanceTicket, 'id' | 'createdAt'>) => void;
  updateMaintenanceTicket: (id: string, t: Partial<MaintenanceTicket>) => void;
  deleteMaintenanceTicket: (id: string) => void;

  // Periodic Maintenance & Smart Alert System
  addPeriodicMaintenance: (pm: Omit<PeriodicMaintenance, 'id' | 'createdAt'>) => void;
  updatePeriodicMaintenance: (id: string, pm: Partial<PeriodicMaintenance>) => void;
  deletePeriodicMaintenance: (id: string) => void;
  startPeriodicMaintenanceOperation: (id: string) => MaintenanceTicket | null;
  completePeriodicMaintenance: (id: string, actualCost?: number, notes?: string) => void;
  maintenanceAlerts: MaintenanceAlert[];
  overdueAlertsCount: number;
  imminentAlertsCount: number;
  totalActiveAlertsCount: number;
  dismissedAlertIds: string[];
  dismissAlert: (id: string) => void;
  resetDismissedAlerts: () => void;

  // Daily Maintenance Checklist & Logging
  dailyChecklistItems: MaintenanceChecklistItem[];
  dailyMaintenanceLogs: DailyMaintenanceLog[];
  toggleChecklistItem: (id: string) => void;
  updateChecklistItem: (id: string, item: Partial<MaintenanceChecklistItem>) => void;
  addChecklistItem: (item: Omit<MaintenanceChecklistItem, 'id'>) => void;
  deleteChecklistItem: (id: string) => void;
  setAllChecklistStatus: (completed: boolean) => void;
  saveDailyLog: (inspectorName: string, notes?: string, weatherOrCondition?: string) => DailyMaintenanceLog;
  resetTodayChecklist: () => void;

  addPayment: (p: Omit<Payment, 'id' | 'receiptNumber'>) => Payment;
  updatePayment: (id: string, p: Partial<Payment>) => void;
  deletePayment: (id: string) => void;
  clearAllPayments: () => void;
  syncAllPaymentsWithResidents: () => number;

  addExpense: (e: Omit<Expense, 'id'>) => Expense;
  updateExpense: (id: string, e: Partial<Expense>) => void;
  deleteExpense: (id: string) => void;

  addVisitor: (v: Omit<Visitor, 'id' | 'entryTime' | 'status'>) => void;
  markVisitorExit: (id: string) => void;
  deleteVisitor: (id: string) => void;

  addNotice: (n: Omit<Notice, 'id' | 'date'>) => Notice;
  deleteNotice: (id: string) => void;

  addUser: (u: Omit<User, 'id'>) => void;
  updateUser: (id: string, u: Partial<User>) => void;
  deleteUser: (id: string) => void;
  updateUserPassword: (usernameOrEmail: string, newPass: string) => boolean;
  verifyUserCredentials: (usernameOrEmail: string, oldPass: string) => boolean;

  // Archive Mutations
  archiveOldRecords: (options: { cutoffDate: string; cutoffMonths?: number; includePayments?: boolean; includeExpenses?: boolean; notes?: string }) => { paymentsMoved: number; expensesMoved: number; paymentsAmount: number; expensesAmount: number };
  restorePaymentFromArchive: (id: string) => void;
  restoreExpenseFromArchive: (id: string) => void;
  restoreBatchFromArchive: (batchId: string) => void;
  restoreAllArchivedRecords: () => void;
  deleteArchivedPayment: (id: string) => void;
  deleteArchivedExpense: (id: string) => void;
  clearAllArchive: () => void;
  exportArchiveJSON: () => void;
  importArchiveFromJSON: (jsonStr: string) => boolean;
  getEligibleArchiveCount: (cutoffDate: string) => { paymentsCount: number; expensesCount: number; paymentsAmount: number; expensesAmount: number };

  // Selected receipt for printing
  selectedReceipt: Payment | null;
  setSelectedReceipt: (p: Payment | null) => void;

  // Selected notice for printing
  selectedNotice: Notice | null;
  setSelectedNotice: (n: Notice | null) => void;

  // السجل المالي اليدوي للأشهر السابقة واللاحقة (ابتداء من 04/2025)
  manualMonthlyRecords: ManualMonthlyRecord[];
  upsertManualMonthlyRecord: (rec: Omit<ManualMonthlyRecord, 'id' | 'updatedAt'> & { id?: string }) => void;
  deleteManualMonthlyRecord: (id: string) => void;
  closeManualMonth: (monthKey: string) => { success: boolean; closingBalance?: number; nextMonthKey?: string; message?: string };
  reopenManualMonth: (monthKey: string) => { success: boolean; message?: string };
  batchSaveManualMonthlyRecords: (records: ManualMonthlyRecord[]) => void;
  clearManualMonthlyRecords: () => void;

  // قرارات وتصويت الجمع العام (Assemblée Générale)
  assemblyResolutions: AssemblyResolution[];
  castResolutionVote: (resolutionId: string, choice: VoteChoice, comment?: string) => { success: boolean; message: string };
  addAssemblyResolution: (res: Omit<AssemblyResolution, 'id' | 'createdAt' | 'votes'>) => void;
  updateAssemblyResolution: (id: string, updates: Partial<AssemblyResolution>) => void;
  deleteAssemblyResolution: (id: string) => void;
  setAssemblyResolutionStatus: (id: string, status: ResolutionStatus) => void;
  resetAssemblyResolutionVotes: (id: string) => void;

  // Calculations
  totalIncome: number;
  totalExpenses: number;
  totalBalance: number;
  totalBalanceDue: number;
  openTicketsCount: number;
  activeVisitorsCount: number;
  archivedPaymentsTotal: number;
  archivedExpensesTotal: number;
  totalArchivedCount: number;

  // Cloud Sync (Supabase)
  isCloudSyncing: boolean;
  isTableMissing: boolean;
  lastCloudSync: string | null;
  syncWithSupabase: () => Promise<{success: boolean, error?: string}>;
  pushToSupabaseNow: () => Promise<{success: boolean, error?: string}>;
  clearCloudAndLocalData: () => Promise<{success: boolean, error?: string}>;

  // Real-time & 1-Minute Periodic Auto-Save Engine (حفظ تلقائي دوري كل دقيقة وفوري في وقت الإنجاز)
  lastAutoSavedTime: string | null;
  isAutoSaving: boolean;
  autoSaveIntervalSeconds: number;
  autoSaveSecondsRemaining: number;
  isAutoSaveEnabled: boolean;
  setIsAutoSaveEnabled: (enabled: boolean) => void;
  setAutoSaveIntervalSeconds: (seconds: number) => void;
  triggerInstantAutoSave: () => Promise<boolean>;

  // Residents Renewal & Purge
  purgeOldResidentData: () => { success: boolean; countPurged: number };

  // Backup & Export
  exportAllDataJSON: () => void;
  restoreDataFromJSON: (jsonStr: string) => boolean;
  resetToDefaults: () => void;
  exportDataAsJSON: () => void;
  importDataFromJSON: (jsonStr: string) => boolean;
  resetToFactoryData: () => void;
  saveAllDataExplicitly: () => boolean;
  ensurePositiveSurplusForAllPreviousMonths: () => { success: boolean; message: string };
  showToast: (msg: string, options?: { type?: 'success' | 'error' | 'warning' | 'info' }) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_PREFIX = 'ma_residence_v9_clean_';

const convertSnakeToCamelObj = (obj: any): any => {
  if (Array.isArray(obj)) return obj.map(convertSnakeToCamelObj);
  if (obj !== null && typeof obj === 'object' && !(obj instanceof Date)) {
    const n: any = {};
    for (const key of Object.keys(obj)) {
      const camelKey = key.replace(/_([a-z])/g, (g) => g[1].toUpperCase());
      n[camelKey] = convertSnakeToCamelObj(obj[key]);
    }
    return n;
  }
  return obj;
};

function loadFromStorage<T>(key: string, defaultValue: T): T {
  try {
    const data = localStorage.getItem(STORAGE_PREFIX + key);
    return data ? convertSnakeToCamelObj(JSON.parse(data)) : defaultValue;
  } catch (err) {
    console.error(`Failed to load ${key} from storage:`, err);
    return defaultValue;
  }
}

function saveToStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(value));
  } catch (err) {
    console.error(`Failed to save ${key} to storage:`, err);
  }
}

export function getTombstones(): Set<string> {
  try {
    if (typeof window === 'undefined') return new Set();
    const raw = localStorage.getItem(STORAGE_PREFIX + 'tombstone_ids');
    return new Set(raw ? JSON.parse(raw) : []);
  } catch {
    return new Set();
  }
}

export function addTombstone(id: string): void {
  try {
    if (typeof window === 'undefined' || !id) return;
    const set = getTombstones();
    set.add(id);
    const arr = Array.from(set).slice(-500);
    localStorage.setItem(STORAGE_PREFIX + 'tombstone_ids', JSON.stringify(arr));
  } catch {}
}

export function isTombstoned(id: string): boolean {
  if (!id) return false;
  return getTombstones().has(id);
}

function computeNextDate(baseDateStr: string, freq: PeriodicFrequency, customDays?: number): string {
  const base = new Date(baseDateStr);
  const validBase = isNaN(base.getTime()) ? new Date() : base;
  
  const next = new Date(validBase);
  switch (freq) {
    case 'weekly':
      next.setDate(next.getDate() + 7);
      break;
    case 'monthly':
      next.setMonth(next.getMonth() + 1);
      break;
    case 'quarterly':
      next.setMonth(next.getMonth() + 3);
      break;
    case 'biannual':
      next.setMonth(next.getMonth() + 6);
      break;
    case 'annual':
      next.setFullYear(next.getFullYear() + 1);
      break;
    case 'custom':
      next.setDate(next.getDate() + (customDays && customDays > 0 ? customDays : 30));
      break;
  }
  return next.toISOString().slice(0, 10);
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [lang, setLang] = useState<Language>(() => {
    const saved = localStorage.getItem(STORAGE_PREFIX + 'lang');
    return saved === 'fr' ? 'fr' : 'ar';
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    return loadFromStorage<User | null>('currentUser', null);
  });

  const [activeSection, setActiveSection] = useState<string>('dashboard');

  const [toastMessage, setToastMessage] = useState<{ message: string; type: 'success' | 'error' | 'warning' | 'info' } | null>(null);

  const showToast = (msg: string, options?: { type?: 'success' | 'error' | 'warning' | 'info' }) => {
    setToastMessage({ message: msg, type: options?.type || 'success' });
    setTimeout(() => {
      setToastMessage(prev => prev?.message === msg ? null : prev);
    }, 4000);
  };

  const normalize20Buildings = (incoming?: Building[] | null): Building[] => {
    const map = new Map<string, Building>();
    if (Array.isArray(incoming)) {
      incoming.forEach(b => {
        if (b && b.code) {
          const cleanCode = b.code.replace(/\s+/g, ' ').trim().toUpperCase();
          map.set(cleanCode, b);
        }
      });
    }
    if (initialBuildings.length === 0) return Array.from(map.values());
    return initialBuildings.map(base => {
      const cleanCode = base.code.replace(/\s+/g, ' ').trim().toUpperCase();
      const existing = map.get(cleanCode);
      if (!existing) return base;
      return {
        ...base,
        ...existing,
        id: base.id,
        code: base.code,
        name: base.name,
        floors: base.floors,
        apartmentsCount: base.apartmentsCount,
      };
    });
  };

  const normalizeApartmentsWithOwnerNames = (incoming?: Apartment[] | null): Apartment[] => {
    const loadedMap = new Map<string, Apartment>();
    if (Array.isArray(incoming)) {
      incoming.forEach(apt => {
        if (apt && apt.buildingCode && apt.number) {
          const key = `${apt.buildingCode.trim().toLowerCase().replace(/\s+/g, '')}-${apt.number.trim().padStart(2, '0')}`;
          if (!loadedMap.has(key)) {
            loadedMap.set(key, apt);
          }
        }
      });
    }

    // Aucune donnée de départ : on garde exactement les appartements saisis par le syndic
    if (initialApartments.length === 0) return Array.from(loadedMap.values());
    return initialApartments.map(baseApt => {
      const cleanB = baseApt.buildingCode.replace(/\s+/g, ' ').trim().toUpperCase();
      const cleanA = String(baseApt.number).trim().padStart(2, '0');
      const key = `${baseApt.buildingCode.trim().toLowerCase().replace(/\s+/g, '')}-${cleanA}`;
      const saved = loadedMap.get(key) || baseApt;

      const isOffice = (false) || baseApt.isSyndicOffice;
      if (isOffice) {
        return {
          ...baseApt,
          ...saved,
          id: baseApt.id,
          number: baseApt.number,
          buildingCode: baseApt.buildingCode,
          floor: baseApt.floor,
          isSyndicOffice: true,
          ownerName: 'مكتب إدارة وسانديك الإقامة',
          residentName: '',
          ownerPhone: '',
          residentPhone: '',
          ownerCin: 'EE450123',
          monthlyFee: 0,
          balanceDue: 0,
          status: 'occupied',
          notes: 'مكتب إدارة وسانديك الإقامة'
        };
      }

      if (false) {
        return {
          ...baseApt,
          ...saved,
          id: baseApt.id,
          number: baseApt.number,
          buildingCode: baseApt.buildingCode,
          floor: baseApt.floor,
          ownerName: 'السيد محمد أيت بلعربي',
          residentName: 'السيد محمد أيت بلعربي',
          ownerPhone: saved.ownerPhone || '',
          residentPhone: saved.residentPhone || '',
          ownerCin: saved.ownerCin || 'EE789303',
          isSyndicOffice: false,
          monthlyFee: 150,
          balanceDue: Number(saved.balanceDue) || 0
        };
      }
      
      const defaultFee = (saved.monthlyFee === 0 || saved.monthlyFee === 200 || saved.monthlyFee === undefined) ? 150 : saved.monthlyFee;
      const currentBalance = Number(saved.balanceDue) || 0;

      // Filter out generic placeholders like "مالك شقة 01", and if empty or purged restore baseApt.ownerName!
      let resolvedOwnerName = (saved.ownerName || '').trim();
      if (isGenericPlaceholderName(resolvedOwnerName) || isOldMockResidentName(resolvedOwnerName) || !resolvedOwnerName) {
        resolvedOwnerName = baseApt.ownerName || '';
      }

      let resolvedResidentName = (saved.residentName || '').trim();
      if (isGenericPlaceholderName(resolvedResidentName) || isOldMockResidentName(resolvedResidentName) || !resolvedResidentName) {
        resolvedResidentName = baseApt.residentName || resolvedOwnerName || '';
      }

      return {
        ...baseApt,
        ...saved,
        id: baseApt.id,
        number: baseApt.number,
        buildingCode: baseApt.buildingCode,
        floor: baseApt.floor,
        ownerName: resolvedOwnerName,
        residentName: resolvedResidentName,
        ownerPhone: (saved.ownerPhone && saved.ownerPhone.trim()) ? saved.ownerPhone : baseApt.ownerPhone,
        residentPhone: (saved.residentPhone && saved.residentPhone.trim()) ? saved.residentPhone : baseApt.residentPhone,
        ownerCin: (saved.ownerCin && saved.ownerCin.trim()) ? saved.ownerCin : baseApt.ownerCin,
        isSyndicOffice: false,
        monthlyFee: defaultFee,
        balanceDue: currentBalance
      };
    });
  };

  const normalizeResidents = (incoming?: Resident[] | null): Resident[] => {
    if (!Array.isArray(incoming) || incoming.length === 0) {
      return initialResidents;
    }
    // Filter out dummy test items
    const cleaned = incoming.filter(r => r && r.fullName && !isOldMockResidentName(r.fullName) && !isGenericPlaceholderName(r.fullName));
    
    // Ensure all 320 standard units have their official registered resident/owner
    const normB = (s: string) => (s || '').replace(/[\s\-_]/g, '').toUpperCase();
    const normA = (s: string) => String(s || '').trim().replace(/^0+/, '') || '0';
    const existingKeys = new Set(cleaned.map(r => `${normB(r.buildingCode)}-${normA(r.apartmentNumber)}`));
    
    initialResidents.forEach(initR => {
      const key = `${normB(initR.buildingCode)}-${normA(initR.apartmentNumber)}`;
      if (!existingKeys.has(key)) {
        cleaned.push(initR);
        existingKeys.add(key);
      }
    });

    return cleaned;
  };

  const [buildings, setBuildings] = useState<Building[]>(() => {
    const loaded = loadFromStorage<Building[]>('buildings', initialBuildings);
    return normalize20Buildings(loaded);
  });

  const [apartments, setApartments] = useState<Apartment[]>(() => {
    const loaded = loadFromStorage<Apartment[]>('apartments', initialApartments);
    return normalizeApartmentsWithOwnerNames(loaded);
  });

  const [residents, setResidents] = useState<Resident[]>(() => {
    const loaded = loadFromStorage<Resident[]>('residents', initialResidents);
    return normalizeResidents(loaded);
  });
  const [employees, setEmployees] = useState<Employee[]>(() => {
    const loaded = loadFromStorage<Employee[]>('employees', initialEmployees);
    let list: Employee[] = (!Array.isArray(loaded) || loaded.length === 0) ? [...initialEmployees] : [...loaded];

    // Ensure all standard initial workers exist so they are never lost
    const existingIds = new Set(list.map(e => e.id));
    initialEmployees.forEach(initEmp => {
      if (!existingIds.has(initEmp.id)) {
        list.push(initEmp);
      }
    });

    return list.map(emp => {
      let updated = { ...emp };
      // Enforce syndic monthly salary to 4,000 DH as mandated
      if (emp.role === 'syndic' || emp.id === 'emp-syn-1') {
        updated.salary = 4000;
      }
      const isInitial = initialEmployees.some(ie => ie.id === updated.id);
      if (isInitial && (!updated.startDate || updated.startDate > '2026-08-01')) {
        return { ...updated, startDate: '2026-01-01' };
      }
      if (!updated.startDate) {
        return { ...updated, startDate: getEmployeeEffectiveStartDate(updated) };
      }
      return updated;
    });
  });
  const [maintenanceTickets, setMaintenanceTickets] = useState<MaintenanceTicket[]>(() => loadFromStorage('maintenance', initialMaintenanceTickets));
  const [payments, setPayments] = useState<Payment[]>(() => {
    const loadedPay = loadFromStorage<Payment[]>('payments', []);
    if (!Array.isArray(loadedPay)) return [];
    // Strictly filter out any synthetic/auto-generated payments (IDs starting with 'pay-')
    // so that the payment ledger ONLY contains payments manually recorded by the syndic.
    const cleanPay = loadedPay.filter(p => !p.id.startsWith('pay-'));
    if (cleanPay.length !== loadedPay.length) {
      saveToStorage('payments', cleanPay);
    }
    return cleanPay;
  });

  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const loadedExp = loadFromStorage<Expense[]>('expenses', []);
    let baseExp: Expense[];
    if (!Array.isArray(loadedExp) || loadedExp.length === 0) {
      baseExp = generateMonthlySurplusExpenses();
    } else {
      baseExp = loadedExp;
    }
    // Automatically update syndic monthly remuneration expenses to 4,000 DH
    return baseExp.map(exp => {
      if (
        (exp.id === 'exp-2a' || exp.id.startsWith('exp-syn-') || (exp.category === 'syndic_fees' && exp.title?.includes('السانديك') && !exp.title?.includes('نائب')))
        && (exp.amount === 2000 || exp.amount === 3500)
      ) {
        return { ...exp, amount: 4000 };
      }
      return exp;
    });
  });
  const [visitors, setVisitors] = useState<Visitor[]>(() => loadFromStorage('visitors', initialVisitors));
  const [notices, setNotices] = useState<Notice[]>(() => loadFromStorage('notices', initialNotices));
  const [users, setUsers] = useState<User[]>(() => {
    let loaded = loadFromStorage<User[]>('users', initialUsers);
    
    if (!Array.isArray(loaded) || loaded.length === 0) {
      loaded = initialUsers;
    } else if (!loaded.some(u => u.role === 'syndic')) {
      loaded = [...loaded, initialUsers[0]];
    }

    return loaded;
  });

  // Periodic Maintenance & Scheduled Contracts
  const [periodicMaintenances, setPeriodicMaintenances] = useState<PeriodicMaintenance[]>(() => {
    const loaded = loadFromStorage<PeriodicMaintenance[]>('periodic_maintenance', initialPeriodicMaintenances);
    if (!Array.isArray(loaded) || loaded.length === 0) {
      return initialPeriodicMaintenances;
    }
    return loaded;
  });

  const [activities, setActivities] = useState<ActivityLogEntry[]>(() => loadFromStorage('activities', []));
  const [trash, setTrash] = useState<DeletedRecord[]>(() => loadFromStorage('trash', []));
  const [isActivityDrawerOpen, setIsActivityDrawerOpen] = useState<boolean>(false);
  const openActivityLog = () => setIsActivityDrawerOpen(true);
  const closeActivityLog = () => setIsActivityDrawerOpen(false);

  const [dismissedAlertIds, setDismissedAlertIds] = useState<string[]>(() => loadFromStorage('dismissed_alerts', []));

  // Daily Maintenance Checklist & History
  const [dailyChecklistItems, setDailyChecklistItems] = useState<MaintenanceChecklistItem[]>(() => {
    const loaded = loadFromStorage<MaintenanceChecklistItem[]>('daily_checklist_items', initialDailyChecklistItems);
    if (!Array.isArray(loaded) || loaded.length === 0) {
      return initialDailyChecklistItems;
    }
    return loaded;
  });

  const [dailyMaintenanceLogs, setDailyMaintenanceLogs] = useState<DailyMaintenanceLog[]>(() => {
    const loaded = loadFromStorage<DailyMaintenanceLog[]>('daily_maintenance_logs', initialDailyMaintenanceLogs);
    if (!Array.isArray(loaded)) {
      return initialDailyMaintenanceLogs;
    }
    return loaded;
  });

  // Archive Database Storage (Isolated from daily active collections for maximum speed)
  const [archivedPayments, setArchivedPayments] = useState<Payment[]>(() => loadFromStorage('archived_payments', []));
  const [archivedExpenses, setArchivedExpenses] = useState<Expense[]>(() => loadFromStorage('archived_expenses', []));
  const [archiveBatches, setArchiveBatches] = useState<ArchiveBatch[]>(() => loadFromStorage('archive_batches', []));

  // Pointage & Attendance Storage (سجل تنقيط العمال واحتساب الأجور الشهرية)
  const [pointageRecords, setPointageRecords] = useState<Record<string, PointageStatus>>(() => {
    const loaded = loadFromStorage<Record<string, PointageStatus>>('pointage_records', {});
    let result = { ...loaded };

    const activeInitialWorkers = initialEmployees.filter(e => e.role !== 'syndic' && e.role !== 'deputy_syndic');

    // 1. Ensure 2026-05 (ماي) has full default records (26 work + 4 rest)
    const has2026_05 = Object.keys(result).some(k => k.includes('2026-05'));
    if (!has2026_05) {
      const mayPointage = generateDefaultMonthPointage('2026-05', activeInitialWorkers, result);
      const secEmp = activeInitialWorkers.find(e => e.id === 'emp-sec-1');
      if (secEmp) {
        mayPointage[`${secEmp.id}_2026-05-12`] = 'absent';
      }
      result = { ...result, ...mayPointage };
    }

    return result;
  });

  const [pointageAdvances, setPointageAdvances] = useState<Record<string, number>>(() => 
    loadFromStorage<Record<string, number>>('pointage_advances', {})
  );

  const [pointageBonuses, setPointageBonuses] = useState<Record<string, number>>(() => 
    loadFromStorage<Record<string, number>>('pointage_bonuses', {})
  );

  // السجل المالي اليدوي للأشهر السابقة واللاحقة (ابتداء من 04/2025)
  const [manualMonthlyRecords, setManualMonthlyRecords] = useState<ManualMonthlyRecord[]>(() => {
    const loaded = loadFromStorage<ManualMonthlyRecord[]>('manual_monthly_records', []);
    let baseList = Array.isArray(loaded) && loaded.length > 0 ? [...loaded] : [...initialManualMonthlyRecords];

    // Ensure all standard initial months exist
    const existingKeys = new Set(baseList.map(r => r.monthKey));
    initialManualMonthlyRecords.forEach(baseRec => {
      if (!existingKeys.has(baseRec.monthKey)) {
        baseList.push(baseRec);
      }
    });

    // Harmonize the chain forward so every month's opening balance and closing balance strictly align
    const harmonized = harmonizeManualMonthlyRecordsChain(baseList);
    saveToStorage('manual_monthly_records', harmonized);
    return harmonized;
  });

  // قرارات وتصويت الجمع العام (Assemblée Générale)
  const [assemblyResolutions, setAssemblyResolutions] = useState<AssemblyResolution[]>(() => 
    loadFromStorage<AssemblyResolution[]>('assembly_resolutions', initialAssemblyResolutions)
  );

  const [selectedReceipt, setSelectedReceipt] = useState<Payment | null>(null);
  const [selectedNotice, setSelectedNotice] = useState<Notice | null>(null);
  const [debtWarningAlert, setDebtWarningAlert] = useState<string | null>(null);

  // Supabase Cloud Sync State
  const [isCloudSyncing, setIsCloudSyncing] = useState<boolean>(false);
  const [isTableMissing, setIsTableMissing] = useState<boolean>(false);
  const [lastCloudSync, setLastCloudSync] = useState<string | null>(() => loadFromStorage('last_supabase_sync', null));

  // Real-time & 1-Minute Periodic Auto-Save Engine State (تفعيل الحفظ التلقائي على توقيت دقيقة)
  const [lastAutoSavedTime, setLastAutoSavedTime] = useState<string | null>(() => loadFromStorage('last_auto_saved_time', null));
  const [isAutoSaving, setIsAutoSaving] = useState<boolean>(false);
  const [autoSaveIntervalSeconds, setAutoSaveIntervalSeconds] = useState<number>(60); // 1 minute = 60s
  const [autoSaveSecondsRemaining, setAutoSaveSecondsRemaining] = useState<number>(60);
  const [isAutoSaveEnabled, setIsAutoSaveEnabled] = useState<boolean>(true);
  const isInitialAutoSaveMount = useRef(true);
  const autoSaveDebounceTimer = useRef<NodeJS.Timeout | null>(null);

  // Ref to hold latest state for sync without triggering re-render cascades
  const residenceSyncDataRef = useRef({
    buildings,
    apartments,
    residents,
    payments,
    expenses,
    employees,
    maintenanceTickets,
    notices,
    visitors,
    currentUser,
    periodicMaintenances,
    dismissedAlertIds,
    dailyChecklistItems,
    dailyMaintenanceLogs,
    users,
    archivedPayments,
    archivedExpenses,
    archiveBatches,
    pointageRecords,
    pointageAdvances,
    pointageBonuses,
    activities,
    trash,
    manualMonthlyRecords,
    assemblyResolutions
  });

  useEffect(() => {
    residenceSyncDataRef.current = {
      buildings,
      apartments,
      residents,
      payments,
      expenses,
      employees,
      maintenanceTickets,
      notices,
      visitors,
      currentUser,
      periodicMaintenances,
      dismissedAlertIds,
      dailyChecklistItems,
      dailyMaintenanceLogs,
      users,
      archivedPayments,
      archivedExpenses,
      archiveBatches,
      pointageRecords,
      pointageAdvances,
      pointageBonuses,
      activities,
      trash,
      manualMonthlyRecords,
      assemblyResolutions
    };
  });

  const skipPushUntilRef = useRef<number>(0);
  const lastPushedSignatureRef = useRef<string>('');
  const localClientId = useRef<string>(
    typeof window !== 'undefined'
      ? (sessionStorage.getItem(STORAGE_PREFIX + 'client_id') || (() => {
          const id = 'client-' + Math.random().toString(36).substring(2, 9) + '-' + Date.now();
          sessionStorage.setItem(STORAGE_PREFIX + 'client_id', id);
          return id;
        })())
      : 'client-' + Date.now()
  ).current;

  const pushToSupabaseNow = useCallback(async (overridePayload?: Partial<ResidenceSyncPayload>): Promise<{success: boolean, error?: string}> => {
    try {
      setIsCloudSyncing(true);
      const data = residenceSyncDataRef.current;
      const tombstones = Array.from(getTombstones());
      const payload: ResidenceSyncPayload = {
        buildings: overridePayload?.buildings ?? data.buildings,
        apartments: overridePayload?.apartments ?? data.apartments,
        residents: overridePayload?.residents ?? data.residents,
        payments: overridePayload?.payments ?? data.payments,
        expenses: overridePayload?.expenses ?? data.expenses,
        employees: overridePayload?.employees ?? data.employees,
        maintenanceTickets: overridePayload?.maintenanceTickets ?? data.maintenanceTickets,
        notices: overridePayload?.notices ?? data.notices,
        visitors: overridePayload?.visitors ?? data.visitors,
        manualMonthlyRecords: overridePayload?.manualMonthlyRecords ?? data.manualMonthlyRecords,
        archivedPayments: overridePayload?.archivedPayments ?? data.archivedPayments,
        archivedExpenses: overridePayload?.archivedExpenses ?? data.archivedExpenses,
        archiveBatches: overridePayload?.archiveBatches ?? data.archiveBatches,
        pointageRecords: overridePayload?.pointageRecords ?? data.pointageRecords,
        pointageAdvances: overridePayload?.pointageAdvances ?? data.pointageAdvances,
        pointageBonuses: overridePayload?.pointageBonuses ?? data.pointageBonuses,
        assemblyResolutions: overridePayload?.assemblyResolutions ?? data.assemblyResolutions,
        lastSyncedAt: new Date().toISOString(),
        clientSourceId: localClientId,
        deletedIds: tombstones
      };
      // تقليل استهلاك Supabase (egress): لا نرسل شيئاً إذا لم تتغير البيانات منذ آخر إرسال ناجح
      const pushSignature = JSON.stringify({ ...payload, lastSyncedAt: undefined, clientSourceId: undefined });
      if (pushSignature === lastPushedSignatureRef.current) {
        return { success: true };
      }
      const res = await pushResidenceToSupabase(payload);
      if (res.success) {
        lastPushedSignatureRef.current = pushSignature;
        setIsTableMissing(false);
        setLastCloudSync(payload.lastSyncedAt);
        saveToStorage('last_supabase_sync', payload.lastSyncedAt);
        return { success: true };
      }
      if (res.error === 'TABLE_MISSING') {
        setIsTableMissing(true);
      }
      return { success: false, error: res.error };
    } catch (e: any) {
      console.warn('Supabase push offline or unreachable:', e?.message || e);
      return { success: false, error: e.message };
    } finally {
      setIsCloudSyncing(false);
    }
  }, [localClientId]);

  // Unified resilient remote merger that avoids resurrecting deleted records or overriding local updates
  const applyRemoteSyncPayload = useCallback((d: ResidenceSyncPayload) => {
    // 1. Echo filter: if this broadcast was generated by this client instance, ignore it completely
    if (d.clientSourceId && d.clientSourceId === localClientId) {
      return;
    }

    const tombstones = getTombstones();
    // Also include any IDs from remote deletedIds into our local tombstones
    if (Array.isArray(d.deletedIds) && d.deletedIds.length > 0) {
      d.deletedIds.forEach(id => addTombstone(id));
    }
    const currentTombstones = getTombstones();
    const currentTrash = residenceSyncDataRef.current?.trash || trash;
    const trashIds = new Set(currentTrash.map(t => t.originalId));
    const shouldIgnoreId = (id: string) => currentTombstones.has(id) || trashIds.has(id);

    // Cloud version newer than the last one this device has seen => cloud wins on identical ids
    // (fixes: edits made on one device never reaching the other, stale device overwriting fresh data)
    const lastSeenCloud = loadFromStorage<string | null>('last_supabase_sync', null);
    const remoteIsNewer = !!d.lastSyncedAt && (!lastSeenCloud || d.lastSyncedAt > lastSeenCloud);
    // Do not echo the data we just received straight back to the cloud (avoids ping-pong between devices)
    skipPushUntilRef.current = Date.now() + 2500;

    // Merge buildings
    if (Array.isArray(d.buildings) && d.buildings.length > 0) {
      setBuildings(normalize20Buildings(d.buildings));
    }

    // Merge apartments
    if (Array.isArray(d.apartments) && d.apartments.length > 0) {
      const filteredRemote = d.apartments.filter(a => !shouldIgnoreId(a.id));
      setApartments(prev => {
        const incoming = normalizeApartmentsWithOwnerNames(filteredRemote);
        const updated = prev.map(localApt => {
          const remote = incoming.find(a => a.id === localApt.id || (a.buildingCode === localApt.buildingCode && a.number === localApt.number));
          if (!remote) return localApt;
          if (remoteIsNewer) return remote;
          // Preserve local edits so cloud pull never reverts user changes
          return {
            ...remote,
            ownerName: (localApt.ownerName !== undefined && localApt.ownerName !== '') ? localApt.ownerName : remote.ownerName,
            ownerPhone: (localApt.ownerPhone !== undefined && localApt.ownerPhone !== '') ? localApt.ownerPhone : remote.ownerPhone,
            ownerCin: (localApt.ownerCin !== undefined && localApt.ownerCin !== '') ? localApt.ownerCin : remote.ownerCin,
            residentName: (localApt.residentName !== undefined && localApt.residentName !== '') ? localApt.residentName : remote.residentName,
            residentPhone: (localApt.residentPhone !== undefined && localApt.residentPhone !== '') ? localApt.residentPhone : remote.residentPhone,
            monthlyFee: localApt.monthlyFee ?? remote.monthlyFee,
            balanceDue: localApt.balanceDue ?? remote.balanceDue,
            unpaidMonthsCount: localApt.unpaidMonthsCount ?? remote.unpaidMonthsCount,
            debtStartPeriod: localApt.debtStartPeriod ?? remote.debtStartPeriod,
            notes: localApt.notes ?? remote.notes,
          };
        });
        saveToStorage('apartments', updated);
        residenceSyncDataRef.current.apartments = updated;
        return updated;
      });
    }

    // Merge residents - NEVER resurrect deleted residents!
    if (Array.isArray(d.residents) && d.residents.length > 0) {
      const filteredRemote = d.residents.filter(r => !shouldIgnoreId(r.id));
      setResidents(prev => {
        const map = new Map<string, Resident>();
        filteredRemote.forEach(r => map.set(r.id, r));
        prev.forEach(r => {
          if (!shouldIgnoreId(r.id) && !(remoteIsNewer && map.has(r.id))) {
            map.set(r.id, r);
          }
        });
        const merged = normalizeResidents(Array.from(map.values()));
        saveToStorage('residents', merged);
        residenceSyncDataRef.current.residents = merged;
        return merged;
      });
    }

    // Merge payments - NEVER resurrect deleted receipts!
    if (Array.isArray(d.payments)) {
      const filteredRemote = d.payments.filter(p => !shouldIgnoreId(p.id));
      setPayments(prev => {
        const map = new Map<string, Payment>();
        filteredRemote.forEach(p => map.set(p.id, p));
        prev.forEach(p => {
          if (!shouldIgnoreId(p.id) && !(remoteIsNewer && map.has(p.id))) {
            map.set(p.id, p);
          }
        });
        const merged = Array.from(map.values()).sort((a, b) => (b.paymentDate || '').localeCompare(a.paymentDate || ''));
        saveToStorage('payments', merged);
        residenceSyncDataRef.current.payments = merged;
        return merged;
      });
    }

    // Merge expenses
    if (Array.isArray(d.expenses)) {
      const filteredRemote = d.expenses.filter(e => !shouldIgnoreId(e.id));
      setExpenses(prev => {
        const map = new Map<string, Expense>();
        filteredRemote.forEach(e => map.set(e.id, e));
        prev.forEach(e => {
          if (!shouldIgnoreId(e.id) && !(remoteIsNewer && map.has(e.id))) {
            map.set(e.id, e);
          }
        });
        const merged = Array.from(map.values());
        saveToStorage('expenses', merged);
        residenceSyncDataRef.current.expenses = merged;
        return merged;
      });
    }

    // Merge employees
    if (Array.isArray(d.employees)) {
      const filteredRemote = d.employees.filter(e => !shouldIgnoreId(e.id));
      setEmployees(prev => {
        const map = new Map<string, Employee>();
        filteredRemote.forEach(e => map.set(e.id, e));
        prev.forEach(e => {
          if (!shouldIgnoreId(e.id) && !(remoteIsNewer && map.has(e.id))) {
            map.set(e.id, e);
          }
        });
        const merged = Array.from(map.values());
        saveToStorage('employees', merged);
        residenceSyncDataRef.current.employees = merged;
        return merged;
      });
    }

    // Merge maintenance tickets
    if (Array.isArray(d.maintenanceTickets)) {
      const filteredRemote = d.maintenanceTickets.filter(t => !shouldIgnoreId(t.id));
      setMaintenanceTickets(prev => {
        const map = new Map<string, MaintenanceTicket>();
        filteredRemote.forEach(t => map.set(t.id, t));
        prev.forEach(t => {
          if (!shouldIgnoreId(t.id) && !(remoteIsNewer && map.has(t.id))) {
            map.set(t.id, t);
          }
        });
        const merged = Array.from(map.values());
        saveToStorage('maintenance', merged);
        residenceSyncDataRef.current.maintenanceTickets = merged;
        return merged;
      });
    }

    // Merge notices
    if (Array.isArray(d.notices)) {
      const filteredRemote = d.notices.filter(n => !shouldIgnoreId(n.id));
      setNotices(prev => {
        const map = new Map<string, Notice>();
        filteredRemote.forEach(n => map.set(n.id, n));
        prev.forEach(n => {
          if (!shouldIgnoreId(n.id) && !(remoteIsNewer && map.has(n.id))) {
            map.set(n.id, n);
          }
        });
        const merged = Array.from(map.values());
        saveToStorage('notices', merged);
        residenceSyncDataRef.current.notices = merged;
        return merged;
      });
    }

    // Merge visitors
    if (Array.isArray(d.visitors)) {
      const filteredRemote = d.visitors.filter(v => !shouldIgnoreId(v.id));
      setVisitors(prev => {
        const map = new Map<string, Visitor>();
        filteredRemote.forEach(v => map.set(v.id, v));
        prev.forEach(v => {
          if (!shouldIgnoreId(v.id) && !(remoteIsNewer && map.has(v.id))) {
            map.set(v.id, v);
          }
        });
        const merged = Array.from(map.values());
        saveToStorage('visitors', merged);
        residenceSyncDataRef.current.visitors = merged;
        return merged;
      });
    }

    // Merge manual monthly records (السجل والتقرير المالي للأشهر السابقة واللاحقة)
    if (Array.isArray(d.manualMonthlyRecords) && d.manualMonthlyRecords.length > 0) {
      const filteredRemote = d.manualMonthlyRecords.filter(r => !shouldIgnoreId(r.id));
      setManualMonthlyRecords(prev => {
        const map = new Map<string, ManualMonthlyRecord>();
        // 1. Baseline records
        initialManualMonthlyRecords.forEach(r => map.set(r.monthKey, r));
        // 2. Remote records from Cloud
        filteredRemote.forEach(r => map.set(r.monthKey, r));
        // 3. Local records (preserve local user updates)
        prev.forEach(r => {
          if (!shouldIgnoreId(r.id) && !(remoteIsNewer && filteredRemote.some(x => x.monthKey === r.monthKey))) {
            map.set(r.monthKey, r);
          }
        });
        const merged = Array.from(map.values()).sort((a, b) => a.monthKey.localeCompare(b.monthKey));
        saveToStorage('manual_monthly_records', merged);
        residenceSyncDataRef.current.manualMonthlyRecords = merged;
        return merged;
      });
    }

    // Merge archived payments & expenses & batches (الأرشيف التاريخي)
    if (Array.isArray(d.archivedPayments)) {
      const filteredRemote = d.archivedPayments.filter(p => !shouldIgnoreId(p.id));
      setArchivedPayments(prev => {
        const map = new Map<string, Payment>();
        filteredRemote.forEach(p => map.set(p.id, p));
        prev.forEach(p => { if (!shouldIgnoreId(p.id) && !(remoteIsNewer && map.has(p.id))) map.set(p.id, p); });
        const merged = Array.from(map.values());
        saveToStorage('archived_payments', merged);
        residenceSyncDataRef.current.archivedPayments = merged;
        return merged;
      });
    }

    if (Array.isArray(d.archivedExpenses)) {
      const filteredRemote = d.archivedExpenses.filter(e => !shouldIgnoreId(e.id));
      setArchivedExpenses(prev => {
        const map = new Map<string, Expense>();
        filteredRemote.forEach(e => map.set(e.id, e));
        prev.forEach(e => { if (!shouldIgnoreId(e.id) && !(remoteIsNewer && map.has(e.id))) map.set(e.id, e); });
        const merged = Array.from(map.values());
        saveToStorage('archived_expenses', merged);
        residenceSyncDataRef.current.archivedExpenses = merged;
        return merged;
      });
    }

    if (Array.isArray(d.archiveBatches)) {
      const filteredRemote = d.archiveBatches.filter(b => !shouldIgnoreId(b.id));
      setArchiveBatches(prev => {
        const map = new Map<string, ArchiveBatch>();
        filteredRemote.forEach(b => map.set(b.id, b));
        prev.forEach(b => { if (!shouldIgnoreId(b.id) && !(remoteIsNewer && map.has(b.id))) map.set(b.id, b); });
        const merged = Array.from(map.values());
        saveToStorage('archive_batches', merged);
        residenceSyncDataRef.current.archiveBatches = merged;
        return merged;
      });
    }

    // Merge pointage records
    if (d.pointageRecords && typeof d.pointageRecords === 'object') {
      setPointageRecords(prev => {
        const merged = remoteIsNewer ? { ...prev, ...d.pointageRecords } : { ...d.pointageRecords, ...prev };
        saveToStorage('pointage_records', merged);
        residenceSyncDataRef.current.pointageRecords = merged;
        return merged;
      });
    }

    // Merge assembly resolutions
    if (Array.isArray(d.assemblyResolutions) && d.assemblyResolutions.length > 0) {
      setAssemblyResolutions(prev => {
        const map = new Map<string, AssemblyResolution>();
        d.assemblyResolutions!.forEach(r => map.set(r.id, r));
        prev.forEach(r => { if (!(remoteIsNewer && map.has(r.id))) map.set(r.id, r); });
        const merged = Array.from(map.values());
        saveToStorage('assembly_resolutions', merged);
        residenceSyncDataRef.current.assemblyResolutions = merged;
        return merged;
      });
    }

    const time = d.lastSyncedAt || new Date().toISOString();
    setLastCloudSync(time);
    saveToStorage('last_supabase_sync', time);
  }, [localClientId, trash]);

  const syncWithSupabase = async (): Promise<{success: boolean, error?: string}> => {
    try {
      setIsCloudSyncing(true);
      const res = await pullResidenceFromSupabase();
      if (res.success && res.data) {
        setIsTableMissing(false);
        applyRemoteSyncPayload(res.data);
        return { success: true };
      }
      if (res.error === 'TABLE_MISSING') {
        setIsTableMissing(true);
      }
      return { success: res.success, error: res.error };
    } catch (e: any) {
      console.warn('Supabase sync offline or unreachable:', e?.message || e);
      return { success: false, error: e.message };
    } finally {
      setIsCloudSyncing(false);
    }
  };

  const clearCloudAndLocalData = async (): Promise<{success: boolean, error?: string}> => {
    try {
      setIsCloudSyncing(true);
      
      // 1. Reset local state
      resetToDefaults();
      setLastCloudSync(null);
      if (typeof window !== 'undefined') {
        localStorage.removeItem(STORAGE_PREFIX + 'last_supabase_sync');
        localStorage.removeItem(STORAGE_PREFIX + 'tombstone_ids');
      }

      // 2. Clear cloud data in Supabase
      const cloudRes = await clearSupabaseAllData();
      return cloudRes;
    } catch (e: any) {
      console.warn('Failed to clear cloud data:', e?.message || e);
      return { success: false, error: e.message };
    } finally {
      setIsCloudSyncing(false);
    }
  };

  useEffect(() => {
    let isMounted = true;
    
    // Initial pull with safe local-state preservation
    pullResidenceFromSupabase().then(res => {
      if (isMounted) {
        if (res.success && res.data) {
          setIsTableMissing(false);
          applyRemoteSyncPayload(res.data);
        } else if (res.error === 'TABLE_MISSING') {
          setIsTableMissing(true);
        }
      }
    }).catch(err => {
      console.warn('Initial Supabase pull skipped:', err?.message || err);
    });

    // Realtime subscription
    const unsubscribe = subscribeToSupabaseSync((payload) => {
      if (isMounted && payload) {
        applyRemoteSyncPayload(payload);
      }
    });

    return () => {
      isMounted = false;
      unsubscribe();
    };
  }, [applyRemoteSyncPayload]);

  // --- Backend Sync Effect (Local / Container) ---
  // Deleted because we now rely entirely on pullResidenceFromSupabase and subscribeToSupabaseChanges
  // which properly handle the unified JSON payload in camelCase format.

  // Sync with document direction & storage
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    localStorage.setItem(STORAGE_PREFIX + 'lang', lang);
  }, [lang]);

  useEffect(() => { saveToStorage('currentUser', currentUser); }, [currentUser]);
  useEffect(() => { saveToStorage('buildings', buildings); }, [buildings]);
  useEffect(() => { saveToStorage('apartments', apartments); }, [apartments]);
  useEffect(() => { saveToStorage('residents', residents); }, [residents]);
  useEffect(() => { saveToStorage('employees', employees); }, [employees]);
  useEffect(() => { saveToStorage('maintenance', maintenanceTickets); }, [maintenanceTickets]);
  useEffect(() => { saveToStorage('periodic_maintenance', periodicMaintenances); }, [periodicMaintenances]);
  useEffect(() => { saveToStorage('dismissed_alerts', dismissedAlertIds); }, [dismissedAlertIds]);
  useEffect(() => { saveToStorage('daily_checklist_items', dailyChecklistItems); }, [dailyChecklistItems]);
  useEffect(() => { saveToStorage('daily_maintenance_logs', dailyMaintenanceLogs); }, [dailyMaintenanceLogs]);
  useEffect(() => { saveToStorage('payments', payments); }, [payments]);
  useEffect(() => { saveToStorage('expenses', expenses); }, [expenses]);
  useEffect(() => { saveToStorage('visitors', visitors); }, [visitors]);
  useEffect(() => { saveToStorage('notices', notices); }, [notices]);
  useEffect(() => { saveToStorage('users', users); }, [users]);
  useEffect(() => { saveToStorage('archived_payments', archivedPayments); }, [archivedPayments]);
  useEffect(() => { saveToStorage('archived_expenses', archivedExpenses); }, [archivedExpenses]);
  useEffect(() => { saveToStorage('archive_batches', archiveBatches); }, [archiveBatches]);
  useEffect(() => { saveToStorage('pointage_records', pointageRecords); }, [pointageRecords]);
  useEffect(() => { saveToStorage('pointage_advances', pointageAdvances); }, [pointageAdvances]);
  useEffect(() => { saveToStorage('pointage_bonuses', pointageBonuses); }, [pointageBonuses]);
  useEffect(() => { saveToStorage('activities', activities); }, [activities]);
  useEffect(() => { saveToStorage('trash', trash); }, [trash]);
  useEffect(() => { saveToStorage('manual_monthly_records', manualMonthlyRecords); }, [manualMonthlyRecords]);
  useEffect(() => { saveToStorage('assembly_resolutions', assemblyResolutions); }, [assemblyResolutions]);

  // Explicitly saves all data tables to local storage & triggers Supabase background sync
  const saveAllDataExplicitly = useCallback((): boolean => {
    try {
      const data = residenceSyncDataRef.current;
      saveToStorage('currentUser', data.currentUser);
      saveToStorage('buildings', data.buildings);
      saveToStorage('apartments', data.apartments);
      saveToStorage('residents', data.residents);
      saveToStorage('employees', data.employees);
      saveToStorage('maintenance', data.maintenanceTickets);
      saveToStorage('periodic_maintenance', data.periodicMaintenances);
      saveToStorage('dismissed_alerts', data.dismissedAlertIds);
      saveToStorage('daily_checklist_items', data.dailyChecklistItems);
      saveToStorage('daily_maintenance_logs', data.dailyMaintenanceLogs);
      saveToStorage('payments', data.payments);
      saveToStorage('expenses', data.expenses);
      saveToStorage('visitors', data.visitors);
      saveToStorage('notices', data.notices);
      saveToStorage('users', data.users);
      saveToStorage('archived_payments', data.archivedPayments);
      saveToStorage('archived_expenses', data.archivedExpenses);
      saveToStorage('archive_batches', data.archiveBatches);
      saveToStorage('pointage_records', data.pointageRecords);
      saveToStorage('pointage_advances', data.pointageAdvances);
      saveToStorage('pointage_bonuses', data.pointageBonuses);
      saveToStorage('activities', data.activities);
      saveToStorage('trash', data.trash);
      saveToStorage('manual_monthly_records', data.manualMonthlyRecords);
      saveToStorage('assembly_resolutions', data.assemblyResolutions);
      
      try {
        pushToSupabaseNow().catch(() => {});
      } catch {
        // ignore
      }
      return true;
    } catch (e) {
      console.error('Error saving all data explicitly:', e);
      return false;
    }
  }, [pushToSupabaseNow]);

  // Background cloud sync to Supabase whenever core residence data changes
  useEffect(() => {
    if (isInitialAutoSaveMount.current) {
      isInitialAutoSaveMount.current = false;
      return;
    }

    if (autoSaveDebounceTimer.current) {
      clearTimeout(autoSaveDebounceTimer.current);
    }

    autoSaveDebounceTimer.current = setTimeout(() => {
      if (Date.now() < skipPushUntilRef.current) return;
      pushToSupabaseNow().catch(err => {
        console.warn('Background Supabase sync skipped:', err?.message || err);
      });
    }, 400);

    return () => {
      if (autoSaveDebounceTimer.current) {
        clearTimeout(autoSaveDebounceTimer.current);
      }
    };
  }, [
    buildings,
    apartments,
    residents,
    employees,
    maintenanceTickets,
    payments,
    expenses,
    visitors,
    notices,
    pushToSupabaseNow
  ]);

  // Periodic Auto-Save Routine (saves all data and updates timestamp)
  const executeAutoSaveRoutine = useCallback(async (): Promise<boolean> => {
    try {
      saveAllDataExplicitly();
      const now = new Date();
      const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
      saveToStorage('last_auto_saved_time', timeStr);

      try {
        await pushToSupabaseNow();
      } catch (err) {
        console.warn('Periodic auto-save Supabase sync skipped:', err);
      }

      return true;
    } catch (err) {
      console.error('Error during auto-save routine:', err);
      return false;
    }
  }, [saveAllDataExplicitly, pushToSupabaseNow]);

  // Instant Manual Trigger for Auto-Save: resets 1-minute countdown and saves immediately
  const triggerInstantAutoSave = useCallback(async (): Promise<boolean> => {
    setAutoSaveSecondsRemaining(autoSaveIntervalSeconds);
    return await executeAutoSaveRoutine();
  }, [autoSaveIntervalSeconds, executeAutoSaveRoutine]);

  // 1-Minute Periodic Auto-Save Engine (تفعيل الحفظ التلقائي على توقيت دقيقة = 60 ثانية)
  useEffect(() => {
    if (!isAutoSaveEnabled) return;

    const interval = setInterval(() => {
      setAutoSaveSecondsRemaining(prev => {
        if (prev <= 1) {
          executeAutoSaveRoutine();
          return autoSaveIntervalSeconds;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isAutoSaveEnabled, autoSaveIntervalSeconds, executeAutoSaveRoutine]);

  // Auto-sync payments with real resident names from residents page (صفحة السكان الحقيقية)
  useEffect(() => {
    if (residents.length > 0 && payments.length > 0) {
      let changed = false;
      const next = payments.map(p => {
        const cleanB = (p.buildingCode || '').replace(/\s+/g, ' ').trim().toUpperCase();
        const cleanA = String(p.apartmentNumber || '01').trim().padStart(2, '0');
        const res = residents.find(r => 
          r.buildingCode.replace(/\s+/g, ' ').trim().toUpperCase() === cleanB && 
          String(r.apartmentNumber).trim().padStart(2, '0') === cleanA
        );
        if (res?.fullName && !isGenericPlaceholderName(res.fullName) && !isOldMockResidentName(res.fullName) && p.residentName !== res.fullName.trim()) {
          changed = true;
          return { ...p, residentName: res.fullName.trim() };
        }
        if (isOldMockResidentName(p.residentName)) {
          changed = true;
          return { ...p, residentName: (false) ? 'مكتب إدارة وسانديك الإقامة' : (false) ? 'السيد محمد أيت بلعربي' : `شقة ${cleanA}` };
        }
        return p;
      });
      if (changed) {
        setPayments(next);
      }
    }
  }, [residents]);

  // Owner Debt Verification Function: Inspects payments & debt status for owner
  // إذا كانت هناك ديون لأكثر من 4 أشهر، يتم تقييد دخوله للتطبيق وعرض رسالة تنبيه
  const checkOwnerDebtAccess = (buildingCode: string, apartmentNumber: string) => {
    const cleanBuilding = buildingCode.trim();
    const cleanApt = apartmentNumber.trim();
    const apt = apartments.find(
      a => a.buildingCode.toLowerCase() === cleanBuilding.toLowerCase() && a.number === cleanApt
    );
    const debtStatus = getApartmentDebtStatus(apt, payments);
    const isBlocked = debtStatus.isBlocked; // true when unpaidMonths > 4
    const message = lang === 'ar'
      ? 'يجب أداء ما بذمتكم مستحقات السنديك لتتمكنوا من الدخول الى التطبيق'
      : 'Vous devez régler vos arriérés de cotisations de syndic pour pouvoir accéder à l\'application.';
    return {
      isBlocked,
      allowed: !isBlocked,
      unpaidMonths: debtStatus.unpaidMonths,
      totalDue: debtStatus.totalBalanceDue,
      message,
      debtStatus
    };
  };

  // Real-time security guard: automatically logout resident if apartment is blocked (> 4 months overdue syndic fees in payments)
  useEffect(() => {
    if (currentUser && currentUser.role === 'resident' && currentUser.building && currentUser.apartment) {
      const currentApt = apartments.find(
        a => a.buildingCode.toLowerCase() === currentUser.building?.toLowerCase() && a.number === currentUser.apartment
      );
      if (currentApt) {
        const debt = getApartmentDebtStatus(currentApt, payments);
        if (debt.isBlocked) {
          const warningMsg = lang === 'ar'
            ? 'يجب أداء ما بذمتكم مستحقات السنديك لتتمكنوا من الدخول الى التطبيق'
            : 'Vous devez régler vos arriérés de cotisations de syndic pour pouvoir accéder à l\'application.';
          setDebtWarningAlert(warningMsg);
          setCurrentUser(null);
        }
      }
    }
  }, [currentUser, apartments, payments, lang]);

  const toggleLanguage = () => {
    setLang(prev => (prev === 'ar' ? 'fr' : 'ar'));
  };

  const handleUserLogin = async (
    emailOrIdentifier: string, 
    password?: string
  ): Promise<LoginResult> => {
    try {
      const cleanId = emailOrIdentifier.trim().toLowerCase();
      
      // 1. Fetch user from registered accounts (Admin, Syndic, Agents, etc.)
      const foundUser = users.find(u => 
        u.username.toLowerCase() === cleanId || 
        (u.email && u.email.toLowerCase() === cleanId)
      );

      // 2. If user exists in account database
      if (foundUser) {
        // Verify password if specified
        if (foundUser.password && password !== undefined && foundUser.password !== password) {
          return {
            success: false,
            status: 'INVALID_CREDENTIALS',
            message: lang === 'ar' ? 'البريد الإلكتروني أو كلمة المرور غير صحيحة.' : 'Identifiant ou mot de passe incorrect.'
          };
        }

        // Check arrears rule in payments (Allows up to 4 months delay, blocks > 4 months)
        if (foundUser.role === 'resident' && foundUser.building && foundUser.apartment) {
          const apt = apartments.find(a => 
            a.buildingCode.toLowerCase() === foundUser.building!.toLowerCase() && 
            a.number === foundUser.apartment
          );
          if (apt) {
            const debtStatus = getApartmentDebtStatus(apt, payments);
            if (debtStatus.isBlocked) {
              const warningMsg = lang === 'ar' 
                ? 'يجب أداء ما بذمتكم مستحقات السنديك لتتمكنوا من الدخول الى التطبيق' 
                : 'Vous devez régler vos arriérés de cotisations de syndic pour pouvoir accéder à l\'application.';
              setDebtWarningAlert(warningMsg);
              return {
                success: false,
                status: 'RESTRICTED',
                message: warningMsg,
                arrearsCount: debtStatus.unpaidMonths,
                totalDue: debtStatus.totalBalanceDue,
                contactPhone: '0661234567',
                apartment: apt,
                debtStatus
              };
            }
          }
        }

        // Generate session token
        const token = 'token_' + btoa(foundUser.id + '_' + Date.now());
        setDebtWarningAlert(null);
        setCurrentUser(foundUser);
        return {
          success: true,
          status: 'ALLOWED',
          token,
          userData: foundUser
        };
      }

      // 3. Check in resident database (matching email or phone)
      const foundResident = residents.find(r => 
        (r.email && r.email.toLowerCase() === cleanId) || 
        (r.phone && r.phone.replace(/\s+/g, '') === cleanId.replace(/\s+/g, ''))
      );

      if (foundResident) {
        const apt = apartments.find(a => 
          a.buildingCode.toLowerCase() === foundResident.buildingCode.toLowerCase() && 
          a.number === foundResident.apartmentNumber
        );
        const debtStatus = getApartmentDebtStatus(apt, payments);

        if (debtStatus.isBlocked) {
          const warningMsg = lang === 'ar' 
            ? 'يجب أداء ما بذمتكم مستحقات السنديك لتتمكنوا من الدخول الى التطبيق' 
            : 'Vous devez régler vos arriérés de cotisations de syndic pour pouvoir accéder à l\'application.';
          setDebtWarningAlert(warningMsg);
          return {
            success: false,
            status: 'RESTRICTED',
            message: warningMsg,
            arrearsCount: debtStatus.unpaidMonths,
            totalDue: debtStatus.totalBalanceDue,
            contactPhone: '0661234567',
            apartment: apt,
            debtStatus
          };
        }

        const resUser: User = {
          id: `res-${foundResident.id}`,
          username: foundResident.email || `res_${foundResident.apartmentNumber}`,
          name: foundResident.fullName,
          role: 'resident',
          building: foundResident.buildingCode,
          apartment: foundResident.apartmentNumber,
          phone: foundResident.phone,
          email: foundResident.email
        };

        const token = 'token_' + btoa(resUser.id + '_' + Date.now());
        setDebtWarningAlert(null);
        setCurrentUser(resUser);
        return {
          success: true,
          status: 'ALLOWED',
          token,
          userData: resUser
        };
      }

      return {
        success: false,
        status: 'INVALID_CREDENTIALS',
        message: lang === 'ar' ? 'المستخدم غير موجود أو بيانات الدخول غير صحيحة.' : 'Utilisateur introuvable ou identifiants incorrects.'
      };
    } catch (error) {
      console.error('Login error:', error);
      return {
        success: false,
        status: 'ERROR',
        message: lang === 'ar' ? 'حدث خطأ أثناء تسجيل الدخول.' : 'Une erreur est survenue lors de la connexion.'
      };
    }
  };

  const login = (u: string, p: string): boolean => {
    const cleanUser = u.trim().toLowerCase();
    const found = users.find(x => x.username.toLowerCase() === cleanUser && x.password === p);
    if (found) {
      // Check if user is resident and blocked due to > 4 months debt in payments
      if (found.role === 'resident' && found.building && found.apartment) {
        const apt = apartments.find(a => 
          a.buildingCode.toLowerCase() === found.building!.toLowerCase() && 
          a.number === found.apartment
        );
        if (apt) {
          const debtStatus = getApartmentDebtStatus(apt, payments);
          if (debtStatus.isBlocked) {
            setDebtWarningAlert(
              lang === 'ar'
                ? 'يجب أداء ما بذمتكم مستحقات السنديك لتتمكنوا من الدخول الى التطبيق'
                : 'Vous devez régler vos arriérés de cotisations de syndic pour pouvoir accéder à l\'application.'
            );
            return false;
          }
        }
      }
      setDebtWarningAlert(null);
      setCurrentUser(found);
      return true;
    }
    return false;
  };

  const loginResident = (
    bCode: string, 
    aptNum: string, 
    customName?: string,
    _bypassDebtCheck?: boolean,
    cin?: string
  ): { success: boolean; isBlocked?: boolean; debtStatus?: any; message?: string } => {
    const cleanBuilding = bCode.trim();
    const cleanApt = aptNum.trim();
    const apt = apartments.find(a => a.buildingCode.toLowerCase() === cleanBuilding.toLowerCase() && a.number === cleanApt);
    const res = residents.find(r => r.buildingCode.toLowerCase() === cleanBuilding.toLowerCase() && r.apartmentNumber === cleanApt);

    // Strict 4-Month Debt Access Rule in payments:
    // يسمح فقط للملاك المتأخرين بأربعة أشهر أو أقل عن أداء واجبات السانديك بالدخول الى التطبيق
    // إذا كانت هناك ديون لأكثر من 4 أشهر، قم بتقييد دخوله للتطبيق وعرض رسالة تنبيه
    if (apt && !_bypassDebtCheck) {
      const debt = getApartmentDebtStatus(apt, payments);
      if (debt.isBlocked) {
        const warningMsg = lang === 'ar'
          ? 'يجب أداء ما بذمتكم مستحقات السنديك لتتمكنوا من الدخول الى التطبيق'
          : 'Vous devez régler vos arriérés de cotisations de syndic pour pouvoir accéder à l\'application.';
        setDebtWarningAlert(warningMsg);
        return {
          success: false,
          isBlocked: true,
          debtStatus: debt,
          message: warningMsg
        };
      }
    }

    const cleanCin = cin?.trim().toUpperCase() || res?.cin || apt?.ownerCin || '';
    const mData = getMoroccanApartmentData(cleanBuilding, cleanApt);
    const candidateName = customName?.trim() || res?.fullName || apt?.ownerName || apt?.residentName;
    const displayName = (candidateName && !candidateName.includes('مالك شقة') && !isOldMockResidentName(candidateName))
      ? candidateName 
      : (false)
        ? 'مكتب إدارة وسانديك الإقامة'
        : (false)
          ? 'السيد محمد أيت بلعربي'
          : `مالك شقة ${cleanApt}`;
    const displayPhone = res?.phone || apt?.ownerPhone || apt?.residentPhone || mData.phone;
    const displayEmail = res?.email || mData.email;

    const residentUser: User = {
      id: `owner-${cleanBuilding}-${cleanApt}`.toLowerCase().replace(/\s+/g, '-'),
      username: `owner_${cleanBuilding}_${cleanApt}`.toLowerCase().replace(/\s+/g, '_'),
      name: displayName,
      role: 'resident',
      password: '',
      building: cleanBuilding,
      apartment: cleanApt,
      phone: displayPhone,
      email: displayEmail,
      cin: cleanCin
    };

    // If CIN was entered and apartment doesn't have it, save it
    if (cleanCin && apt && !apt.ownerCin) {
      setApartments(prev => prev.map(a => a.id === apt.id ? { ...a, ownerCin: cleanCin } : a));
    }

    setDebtWarningAlert(null);
    setCurrentUser(residentUser);
    return { success: true };
  };

  const logout = () => {
    setDebtWarningAlert(null);
    setCurrentUser(null);
  };

  // Activity & Trash Methods
  const logActivity = (action: ActivityAction, entityType: string, entityId: string, detailsAr: string, detailsFr: string) => {
    setActivities(prev => [{
      id: 'act-' + Date.now() + Math.random().toString(36).substr(2, 5),
      userId: currentUser?.id || 'system',
      userName: currentUser?.name || 'System',
      action,
      entityType,
      entityId,
      detailsAr,
      detailsFr,
      timestamp: new Date().toISOString()
    }, ...prev].slice(0, 500)); // Keep last 500
  };

  const moveToTrash = (entityType: string, originalId: string, data: any) => {
    setTrash(prev => [{
      id: 'trash-' + Date.now() + Math.random().toString(36).substr(2, 5),
      originalId,
      entityType,
      data,
      deletedAt: new Date().toISOString(),
      deletedBy: currentUser?.name || 'System'
    }, ...prev].slice(0, 100)); // Keep last 100
  };

  const restoreFromTrash = (id: string) => {
    setTrash(prev => {
      const item = prev.find(t => t.id === id);
      if (!item) return prev;
      
      const { entityType, data } = item;
      
      switch(entityType) {
        case 'building': setBuildings(b => [...b, data]); break;
        case 'apartment': setApartments(a => [...a, data]); break;
        case 'resident': setResidents(r => [...r, data]); break;
        case 'employee': setEmployees(e => [...e, data]); break;
        case 'maintenance': setMaintenanceTickets(m => [...m, data]); break;
        case 'payment': setPayments(p => [...p, data]); break;
        case 'expense': setExpenses(e => [...e, data]); break;
        case 'notice': setNotices(n => [...n, data]); break;
      }
      
      logActivity('RESTORE', entityType, item.originalId, 'تم استرجاع العنصر من المهملات', 'Élément restauré de la corbeille');
      showToast(lang === 'ar' ? 'تم الاسترجاع بنجاح' : 'Restauré avec succès');
      return prev.filter(t => t.id !== id);
    });
  };

  // Buildings
  const addBuilding = (b: Omit<Building, 'id'>) => {
    const newB: Building = { ...b, id: 'b-' + Date.now() };
    setBuildings(prev => [newB, ...prev]);
    fetch('/api/buildings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newB)
    }).catch(console.error);
  };
  const updateBuilding = (id: string, b: Partial<Building>) => {
    const curr = residenceSyncDataRef.current.buildings || buildings;
    const next = curr.map(item => item.id === id ? { ...item, ...b } : item);
    residenceSyncDataRef.current.buildings = next;
    saveToStorage('buildings', next);
    setBuildings(next);
    pushToSupabaseNow({ buildings: next }).catch(() => {});
  };
  const deleteBuilding = (id: string) => {
    addTombstone(id);
    const curr = residenceSyncDataRef.current.buildings || buildings;
    const item = curr.find(i => i.id === id);
    if (item) {
      moveToTrash('building', id, item);
      logActivity('DELETE', 'building', id, `حذف العمارة ${item.code}`, `Suppression Immeuble ${item.code}`);
    }
    const next = curr.filter(i => i.id !== id);
    residenceSyncDataRef.current.buildings = next;
    saveToStorage('buildings', next);
    setBuildings(next);
    pushToSupabaseNow({ buildings: next }).catch(() => {});
  };

  // Apartments
  const addApartment = (apt: Omit<Apartment, 'id'>) => {
    setApartments(prev => {
      const exists = prev.some(a => a.buildingCode === apt.buildingCode && a.number === apt.number);
      let next: Apartment[];
      if (exists) {
        next = prev.map(a => (a.buildingCode === apt.buildingCode && a.number === apt.number) ? { ...a, ...apt } : a);
      } else {
        const newApt = { ...apt, id: 'apt-' + Date.now() } as Apartment;
        fetch('/api/apartments', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(newApt)
        }).catch(console.error);
        next = [newApt, ...prev];
      }
      saveToStorage('apartments', next);
      residenceSyncDataRef.current.apartments = next;
      pushToSupabaseNow({ apartments: next }).catch(() => {});
      return next;
    });
  };
  const updateApartment = (id: string, apt: Partial<Apartment>) => {
    const currApts = residenceSyncDataRef.current.apartments || apartments;
    const target = currApts.find(item => item.id === id);
    const updated = currApts.map(item => item.id === id ? { ...item, ...apt } : item);
    residenceSyncDataRef.current.apartments = updated;
    saveToStorage('apartments', updated);
    setApartments(updated);
    
    // Also sync resident record if owner details are provided
    if (target && apt.ownerName && apt.ownerName.trim()) {
      const buildingCode = apt.buildingCode || target.buildingCode;
      const aptNumber = apt.number || target.number;
      const ownerName = apt.ownerName.trim();
      const ownerPhone = apt.ownerPhone || target.ownerPhone || '';
      const ownerCin = apt.ownerCin || target.ownerCin || '';

      const currRes = residenceSyncDataRef.current.residents || residents;
      const normB = (s: string) => (s || '').replace(/[\s\-_]/g, '').toUpperCase();
      const normA = (s: string) => String(s || '').trim().replace(/^0+/, '') || '0';
      const resIndex = currRes.findIndex(
        r => normB(r.buildingCode) === normB(buildingCode) &&
             (normA(r.apartmentNumber) === normA(aptNumber) || r.apartmentNumber.trim() === aptNumber.trim())
      );
      let nextRes: Resident[];
      if (resIndex >= 0) {
        nextRes = currRes.map((r, idx) => idx === resIndex ? {
          ...r,
          fullName: ownerName,
          phone: ownerPhone || r.phone,
          cin: ownerCin ? ownerCin.toUpperCase() : r.cin
        } : r);
      } else {
        nextRes = [
          {
            id: 'res-' + Date.now(),
            fullName: ownerName,
            type: 'owner' as const,
            buildingCode: buildingCode,
            apartmentNumber: aptNumber,
            phone: ownerPhone,
            email: '',
            cin: ownerCin ? ownerCin.toUpperCase() : '',
            familyMembersCount: 1,
            entryDate: new Date().toISOString().slice(0, 10)
          },
          ...currRes
        ];
      }
      residenceSyncDataRef.current.residents = nextRes;
      saveToStorage('residents', nextRes);
      setResidents(nextRes);
      pushToSupabaseNow({ apartments: updated, residents: nextRes }).catch(() => {});
    } else {
      pushToSupabaseNow({ apartments: updated }).catch(() => {});
    }

    fetch(`/api/apartments/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(apt)
    }).catch(console.error);
  };
  const deleteApartment = (id: string) => {
    addTombstone(id);
    const curr = residenceSyncDataRef.current.apartments || apartments;
    const item = curr.find(i => i.id === id);
    if (item) {
      moveToTrash('apartment', id, item);
      logActivity('DELETE', 'apartment', id, `حذف الشقة ${item.number}`, `Suppression Appartement ${item.number}`);
    }
    const next = curr.filter(i => i.id !== id);
    residenceSyncDataRef.current.apartments = next;
    saveToStorage('apartments', next);
    setApartments(next);

    fetch(`/api/apartments/${id}`, { method: 'DELETE' }).catch(console.error);
    pushToSupabaseNow({ apartments: next }).catch(() => {});
  };

  const updateAllMonthlyFees = (amount: number, targetBuildingCode?: string) => {
    const curr = residenceSyncDataRef.current.apartments || apartments;
    const next = curr.map(apt => {
      if (apt.isSyndicOffice) return apt;
      if (!targetBuildingCode || targetBuildingCode === 'ALL' || apt.buildingCode === targetBuildingCode) {
        return { ...apt, monthlyFee: Number(amount) };
      }
      return apt;
    });
    saveToStorage('apartments', next);
    residenceSyncDataRef.current.apartments = next;
    setApartments(next);
    pushToSupabaseNow({ apartments: next }).catch(() => {});
  };

  const resetAllApartmentDebts = (targetBuildingCode?: string) => {
    const curr = residenceSyncDataRef.current.apartments || apartments;
    const next = curr.map(apt => {
      if (!targetBuildingCode || targetBuildingCode === 'ALL' || apt.buildingCode === targetBuildingCode) {
        return {
          ...apt,
          balanceDue: 0,
          unpaidMonthsCount: 0,
          debtStartPeriod: undefined
        };
      }
      return apt;
    });
    saveToStorage('apartments', next);
    residenceSyncDataRef.current.apartments = next;
    setApartments(next);
    pushToSupabaseNow({ apartments: next }).catch(() => {});
  };

  const setApartmentDebt = (apartmentId: string, unpaidMonths: number, customAmount?: number) => {
    const curr = residenceSyncDataRef.current.apartments || apartments;
    const next = curr.map(apt => {
      if (apt.id === apartmentId) {
        const fee = apt.monthlyFee > 0 ? apt.monthlyFee : 150;
        const balance = customAmount !== undefined && customAmount >= 0 ? customAmount : (unpaidMonths * fee);
        return {
          ...apt,
          unpaidMonthsCount: Math.max(0, unpaidMonths),
          balanceDue: Math.max(0, balance)
        };
      }
      return apt;
    });
    saveToStorage('apartments', next);
    residenceSyncDataRef.current.apartments = next;
    setApartments(next);
    pushToSupabaseNow({ apartments: next }).catch(() => {});
  };

  const importOwnersFromExcelData = (
    rows: Array<{
      buildingCode: string;
      apartmentNumber: string;
      ownerName: string;
      ownerPhone?: string;
      ownerCin?: string;
      ownerEmail?: string;
      addressOrNotes?: string;
      floor?: number;
      monthlyFee?: number;
      status?: ApartmentStatus;
      residentName?: string;
      residentPhone?: string;
      unpaidMonthsCount?: number;
      balanceDue?: number;
    }>,
    options: {
      updateApartments?: boolean;
      syncResidents?: boolean;
      createMissingApartments?: boolean;
      overwriteExistingPhones?: boolean;
      updateDebts?: boolean;
    } = {}
  ) => {
    const {
      updateApartments = true,
      syncResidents = true,
      createMissingApartments = true,
      overwriteExistingPhones = true,
      updateDebts = true
    } = options;

    let apartmentsUpdated = 0;
    let residentsUpdated = 0;
    let apartmentsCreated = 0;

    // 1. Update or create Apartments
    setApartments(prevApts => {
      const updatedList = [...prevApts];
      const newlyCreated: Apartment[] = [];

      rows.forEach(row => {
        if (!row.buildingCode || !row.apartmentNumber || !row.ownerName) return;

        const cleanBldg = row.buildingCode.trim().toLowerCase();
        const cleanAptNum = row.apartmentNumber.trim();
        const cleanAptDigits = cleanAptNum.replace(/[^\d]/g, '');

        const index = updatedList.findIndex(a => 
          a.buildingCode.trim().toLowerCase() === cleanBldg &&
          (a.number.trim() === cleanAptNum || (cleanAptDigits && a.number.replace(/[^\d]/g, '') === cleanAptDigits))
        );

        if (index >= 0) {
          if (updateApartments) {
            const existing = updatedList[index];
            const updatedApt: Apartment = {
              ...existing,
              ownerName: row.ownerName.trim(),
              ...(row.ownerPhone ? { ownerPhone: row.ownerPhone.trim() } : (overwriteExistingPhones && row.ownerPhone !== undefined ? { ownerPhone: row.ownerPhone } : {})),
              ...(row.ownerCin ? { ownerCin: row.ownerCin.trim().toUpperCase() } : {}),
              ...(row.ownerEmail ? { ownerEmail: row.ownerEmail.trim() } : {}),
              ...(row.addressOrNotes ? { notes: row.addressOrNotes.trim() } : {}),
              ...(row.floor !== undefined ? { floor: row.floor } : {}),
              ...(row.monthlyFee !== undefined && row.monthlyFee > 0 ? { monthlyFee: row.monthlyFee } : {}),
              ...(row.status ? { status: row.status } : {}),
              ...(updateDebts && row.unpaidMonthsCount !== undefined ? { unpaidMonthsCount: row.unpaidMonthsCount } : {}),
              ...(updateDebts && row.balanceDue !== undefined ? { balanceDue: row.balanceDue } : {}),
              residentName: row.residentName?.trim() || (row.status === 'occupied' ? row.ownerName.trim() : existing.residentName),
              residentPhone: row.residentPhone?.trim() || (row.status === 'occupied' && row.ownerPhone ? row.ownerPhone.trim() : existing.residentPhone)
            };

            updatedList[index] = updatedApt;
            apartmentsUpdated++;
          }
        } else if (createMissingApartments) {
          const fee = row.monthlyFee || 150;
          const unpaid = row.unpaidMonthsCount !== undefined ? row.unpaidMonthsCount : 0;
          const balance = row.balanceDue !== undefined ? row.balanceDue : (unpaid * fee);

          const newApt: Apartment = {
            id: 'apt-' + Date.now() + '-' + Math.random().toString(36).substr(2, 7),
            number: cleanAptNum,
            buildingCode: row.buildingCode.trim(),
            floor: row.floor ?? 0,
            ownerName: row.ownerName.trim(),
            ownerPhone: row.ownerPhone?.trim() || '',
            ownerCin: row.ownerCin?.trim().toUpperCase() || '',
            ownerEmail: row.ownerEmail?.trim() || '',
            residentName: row.residentName?.trim() || row.ownerName.trim(),
            residentPhone: row.residentPhone?.trim() || row.ownerPhone?.trim() || '',
            isRented: false,
            status: row.status || 'occupied',
            monthlyFee: fee,
            balanceDue: balance,
            unpaidMonthsCount: unpaid,
            notes: row.addressOrNotes?.trim() || ''
          };
          newlyCreated.push(newApt);
          apartmentsCreated++;
        }
      });

      return [...updatedList, ...newlyCreated];
    });

    // 2. Synchronize Residents Directory
    if (syncResidents) {
      setResidents(prevRes => {
        const resList = [...prevRes];

        rows.forEach(row => {
          if (!row.buildingCode || !row.apartmentNumber || !row.ownerName) return;

          const cleanBldg = row.buildingCode.trim().toLowerCase();
          const cleanAptNum = row.apartmentNumber.trim();
          const cleanAptDigits = cleanAptNum.replace(/[^\d]/g, '');

          const resIndex = resList.findIndex(r => 
            r.buildingCode.trim().toLowerCase() === cleanBldg &&
            (r.apartmentNumber.trim() === cleanAptNum || (cleanAptDigits && r.apartmentNumber.replace(/[^\d]/g, '') === cleanAptDigits))
          );

          if (resIndex >= 0) {
            const current = resList[resIndex];
            resList[resIndex] = {
              ...current,
              fullName: row.ownerName.trim(),
              phone: row.ownerPhone?.trim() || current.phone,
              cin: row.ownerCin?.trim().toUpperCase() || current.cin,
              email: row.ownerEmail?.trim() || current.email,
              type: 'owner'
            };
            residentsUpdated++;
          } else {
            const newRes: Resident = {
              id: 'res-' + Date.now() + '-' + Math.random().toString(36).substr(2, 7),
              fullName: row.ownerName.trim(),
              type: 'owner',
              buildingCode: row.buildingCode.trim(),
              apartmentNumber: cleanAptNum,
              phone: row.ownerPhone?.trim() || '',
              cin: row.ownerCin?.trim().toUpperCase() || '',
              email: row.ownerEmail?.trim() || '',
              familyMembersCount: 1,
              entryDate: new Date().toISOString().slice(0, 10)
            };
            resList.push(newRes);
            residentsUpdated++;
          }
        });

        return resList;
      });
    }

    return {
      apartmentsUpdated,
      residentsUpdated,
      apartmentsCreated
    };
  };

  const importResidentsFromExcelData = (
    rows: Array<{
      fullName: string;
      type: 'owner' | 'tenant';
      buildingCode: string;
      apartmentNumber: string;
      phone: string;
      email?: string;
      cin?: string;
      vehiclePlate?: string;
      familyMembersCount?: number;
      entryDate?: string;
    }>,
    options: {
      mode?: 'merge' | 'replace';
      syncApartments?: boolean;
      overwriteExistingDetails?: boolean;
    } = {}
  ) => {
    const {
      mode = 'merge',
      syncApartments = true,
      overwriteExistingDetails = true
    } = options;

    let residentsAdded = 0;
    let residentsUpdated = 0;
    let apartmentsSynced = 0;

    // 1. Process residents list
    setResidents(prevResidents => {
      const baseList = mode === 'replace' ? [] : [...prevResidents];
      const newlyCreated: Resident[] = [];

      rows.forEach(row => {
        if (!row.fullName || !row.buildingCode || !row.apartmentNumber) return;

        const cleanBldg = row.buildingCode.trim().replace(/[\s\-_]/g, '').toUpperCase();
        const cleanApt = row.apartmentNumber.trim().replace(/[^\d]/g, '');

        const existingIndex = baseList.findIndex(r => 
          r.buildingCode.trim().replace(/[\s\-_]/g, '').toUpperCase() === cleanBldg &&
          (r.apartmentNumber.trim().replace(/[^\d]/g, '') === cleanApt || r.apartmentNumber.trim() === row.apartmentNumber.trim())
        );

        if (existingIndex >= 0 && mode !== 'replace') {
          const existing = baseList[existingIndex];
          const updated: Resident = {
            ...existing,
            fullName: row.fullName.trim(),
            type: row.type || existing.type,
            phone: (overwriteExistingDetails && row.phone) ? row.phone.trim() : (existing.phone || row.phone?.trim() || ''),
            cin: (overwriteExistingDetails && row.cin) ? row.cin.trim().toUpperCase() : (existing.cin || row.cin?.trim().toUpperCase() || ''),
            email: (overwriteExistingDetails && row.email) ? row.email.trim() : (existing.email || row.email?.trim() || ''),
            vehiclePlate: (overwriteExistingDetails && row.vehiclePlate) ? row.vehiclePlate.trim() : (existing.vehiclePlate || row.vehiclePlate?.trim() || ''),
            familyMembersCount: row.familyMembersCount !== undefined ? row.familyMembersCount : (existing.familyMembersCount ?? 3),
            entryDate: row.entryDate || existing.entryDate || new Date().toISOString().slice(0, 10)
          };
          baseList[existingIndex] = updated;
          residentsUpdated++;
        } else {
          const newRes: Resident = {
            id: 'res-' + Date.now() + '-' + Math.random().toString(36).substr(2, 7),
            fullName: row.fullName.trim(),
            type: row.type || 'owner',
            buildingCode: row.buildingCode.trim(),
            apartmentNumber: row.apartmentNumber.trim(),
            phone: row.phone?.trim() || '',
            cin: row.cin?.trim().toUpperCase() || '',
            email: row.email?.trim() || '',
            vehiclePlate: row.vehiclePlate?.trim() || '',
            familyMembersCount: row.familyMembersCount ?? 3,
            entryDate: row.entryDate || new Date().toISOString().slice(0, 10)
          };
          newlyCreated.push(newRes);
          residentsAdded++;
        }
      });

      const finalList = [...baseList, ...newlyCreated];
      saveToStorage('residents', finalList);
      return finalList;
    });

    // 2. Synchronize with Apartments if enabled
    if (syncApartments) {
      setApartments(prevApts => {
        const updatedApts = [...prevApts];

        rows.forEach(row => {
          if (!row.fullName || !row.buildingCode || !row.apartmentNumber) return;

          const cleanBldg = row.buildingCode.trim().replace(/[\s\-_]/g, '').toUpperCase();
          const cleanApt = row.apartmentNumber.trim().replace(/[^\d]/g, '');

          const aptIndex = updatedApts.findIndex(a => 
            a.buildingCode.trim().replace(/[\s\-_]/g, '').toUpperCase() === cleanBldg &&
            (a.number.trim().replace(/[^\d]/g, '') === cleanApt || a.number.trim() === row.apartmentNumber.trim())
          );

          if (aptIndex >= 0) {
            const currentApt = updatedApts[aptIndex];
            const isTenant = row.type === 'tenant';

            updatedApts[aptIndex] = {
              ...currentApt,
              residentName: row.fullName.trim(),
              residentPhone: row.phone?.trim() || currentApt.residentPhone,
              residentEmail: row.email?.trim() || currentApt.residentEmail,
              isRented: isTenant,
              status: 'occupied',
              // If resident is owner, also update apartment owner credentials
              ...(!isTenant ? {
                ownerName: row.fullName.trim(),
                ownerPhone: row.phone?.trim() || currentApt.ownerPhone,
                ownerCin: row.cin?.trim().toUpperCase() || currentApt.ownerCin,
                ownerEmail: row.email?.trim() || currentApt.ownerEmail
              } : {})
            };
            apartmentsSynced++;
          }
        });

        saveToStorage('apartments', updatedApts);
        return updatedApts;
      });
    }

    logActivity(
      'UPDATE',
      'resident',
      'excel-import-residents',
      `استيراد وتحديث قائمة السكان من Excel: إضافة ${residentsAdded} ساكن، تحديث ${residentsUpdated}، ومزامنة ${apartmentsSynced} شقة`,
      `Importation liste résidents Excel: ${residentsAdded} ajoutés, ${residentsUpdated} mis à jour, ${apartmentsSynced} appartements synchronisés`
    );

    return {
      residentsAdded,
      residentsUpdated,
      apartmentsSynced
    };
  };

  // Residents
  const addResident = (res: Omit<Resident, 'id'>) => {
    const newRes: Resident = { ...res, id: 'res-' + Date.now(), cin: res.cin ? res.cin.trim().toUpperCase() : '' };
    const currRes = residenceSyncDataRef.current.residents || residents;
    const nextResidents = [newRes, ...currRes.filter(r => r.id !== newRes.id)];
    residenceSyncDataRef.current.residents = nextResidents;
    saveToStorage('residents', nextResidents);
    setResidents(nextResidents);

    // Also auto-link to apartment if match found and update owner/resident information
    const currApts = residenceSyncDataRef.current.apartments || apartments;
    const normB = (s: string) => (s || '').replace(/[\s\-_]/g, '').toUpperCase();
    const normA = (s: string) => String(s || '').trim().replace(/^0+/, '') || '0';
    const nextApts = currApts.map(apt => {
      if (normB(apt.buildingCode) === normB(res.buildingCode) &&
          (normA(apt.number) === normA(res.apartmentNumber) || apt.number.trim() === res.apartmentNumber.trim())) {
        return {
          ...apt,
          ownerName: res.type === 'owner' ? res.fullName : apt.ownerName,
          ownerPhone: res.type === 'owner' ? res.phone : apt.ownerPhone,
          ownerCin: res.cin ? res.cin.trim().toUpperCase() : apt.ownerCin,
          residentName: res.fullName,
          residentPhone: res.phone,
          isRented: res.type === 'tenant',
          status: 'occupied' as const
        };
      }
      return apt;
    });
    saveToStorage('apartments', nextApts);
    residenceSyncDataRef.current.apartments = nextApts;
    setApartments(nextApts);
    
    fetch('/api/residents', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newRes)
    }).catch(console.error);

    pushToSupabaseNow({ residents: nextResidents, apartments: nextApts }).catch(() => {});
  };
  const updateResident = (id: string, res: Partial<Resident>) => {
    const updatedCin = res.cin !== undefined ? res.cin.trim().toUpperCase() : undefined;
    const currRes = residenceSyncDataRef.current.residents || residents;
    const nextResidents = currRes.map(item => item.id === id ? { ...item, ...res, ...(updatedCin !== undefined ? { cin: updatedCin } : {}) } : item);
    residenceSyncDataRef.current.residents = nextResidents;
    saveToStorage('residents', nextResidents);
    setResidents(nextResidents);
    
    // Also update linked apartment if applicable
    const existing = currRes.find(r => r.id === id);
    let nextApts = residenceSyncDataRef.current.apartments || apartments;
    if (existing) {
      const targetBuilding = res.buildingCode || existing.buildingCode;
      const targetApt = res.apartmentNumber || existing.apartmentNumber;
      const targetType = res.type || existing.type;
      const targetFullName = res.fullName || existing.fullName;
      const targetPhone = res.phone || existing.phone;
      const targetCin = updatedCin !== undefined ? updatedCin : (res.cin || existing.cin);

      const normB = (s: string) => (s || '').replace(/[\s\-_]/g, '').toUpperCase();
      const normA = (s: string) => String(s || '').trim().replace(/^0+/, '') || '0';

      nextApts = nextApts.map(apt => {
        if (normB(apt.buildingCode) === normB(targetBuilding) &&
            (normA(apt.number) === normA(targetApt) || apt.number.trim() === targetApt.trim())) {
          return {
            ...apt,
            ...(targetType === 'owner' ? { ownerName: targetFullName, ownerPhone: targetPhone } : {}),
            ...(targetCin ? { ownerCin: targetCin.toUpperCase() } : {}),
            residentName: targetFullName,
            residentPhone: targetPhone
          };
        }
        return apt;
      });
      saveToStorage('apartments', nextApts);
      residenceSyncDataRef.current.apartments = nextApts;
      setApartments(nextApts);
    }

    fetch(`/api/residents/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(res)
    }).catch(console.error);

    pushToSupabaseNow({ residents: nextResidents, apartments: nextApts }).catch(() => {});
  };
  const deleteResident = (id: string) => {
    addTombstone(id);
    const currRes = residenceSyncDataRef.current.residents || residents;
    const item = currRes.find(i => i.id === id);
    if (item) {
      moveToTrash('resident', id, item);
      logActivity('DELETE', 'resident', id, `حذف الساكن ${item.fullName}`, `Suppression Résident ${item.fullName}`);
    }
    const next = currRes.filter(i => i.id !== id);
    residenceSyncDataRef.current.residents = next;
    saveToStorage('residents', next);
    setResidents(next);

    fetch(`/api/residents/${id}`, { method: 'DELETE' }).catch(console.error);
    pushToSupabaseNow({ residents: next }).catch(() => {});
  };

  // Employees
  const addEmployee = (emp: Omit<Employee, 'id'>): Employee => {
    const today = new Date().toISOString().split('T')[0];
    const startDate = emp.startDate?.trim() || today;
    const newEmp: Employee = { 
      ...emp, 
      id: 'emp-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      startDate,
      createdAt: today
    };
    
    const curr = residenceSyncDataRef.current.employees || employees;
    const next = [newEmp, ...curr.filter(e => e.id !== newEmp.id)];
    residenceSyncDataRef.current.employees = next;
    saveToStorage('employees', next);
    setEmployees(next);

    // Automatically generate pointage for the new worker starting from their registration date for the month
    if (newEmp.role !== 'syndic' && newEmp.role !== 'deputy_syndic') {
      const startMonth = startDate.slice(0, 7);
      setPointageRecords(prev => generateDefaultMonthPointage(startMonth, [newEmp], prev));
    }

    fetch('/api/employees', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newEmp)
    }).catch(console.error);

    pushToSupabaseNow({ employees: next }).catch(() => {});
    return newEmp;
  };
  const updateEmployee = (id: string, emp: Partial<Employee>) => {
    const curr = residenceSyncDataRef.current.employees || employees;
    const next = curr.map(item => item.id === id ? { ...item, ...emp } : item);
    residenceSyncDataRef.current.employees = next;
    saveToStorage('employees', next);
    setEmployees(next);

    fetch(`/api/employees/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(emp)
    }).catch(console.error);
    pushToSupabaseNow({ employees: next }).catch(() => {});
  };
  const deleteEmployee = (id: string) => {
    addTombstone(id);
    const curr = residenceSyncDataRef.current.employees || employees;
    const item = curr.find(i => i.id === id);
    if (item) {
      moveToTrash('employee', id, item);
      logActivity('DELETE', 'employee', id, `حذف الموظف ${item.name}`, `Suppression Employé ${item.name}`);
    }
    const next = curr.filter(i => i.id !== id);
    residenceSyncDataRef.current.employees = next;
    saveToStorage('employees', next);
    setEmployees(next);

    fetch(`/api/employees/${id}`, {
      method: 'DELETE'
    }).catch(console.error);
    pushToSupabaseNow({ employees: next }).catch(() => {});
  };

  // Pointage & Attendance System Methods
  const setPointageStatus = (employeeId: string, date: string, status: PointageStatus) => {
    const key = `${employeeId}_${date}`;
    const curr = residenceSyncDataRef.current.pointageRecords || pointageRecords;
    const next = { ...curr, [key]: status };
    residenceSyncDataRef.current.pointageRecords = next;
    saveToStorage('pointage_records', next);
    setPointageRecords(next);
    pushToSupabaseNow({ pointageRecords: next }).catch(() => {});
  };

  const batchSetPointageStatus = (entries: Array<{ employeeId: string; date: string; status: PointageStatus }>) => {
    const curr = residenceSyncDataRef.current.pointageRecords || pointageRecords;
    const next = { ...curr };
    entries.forEach(e => {
      next[`${e.employeeId}_${e.date}`] = e.status;
    });
    residenceSyncDataRef.current.pointageRecords = next;
    saveToStorage('pointage_records', next);
    setPointageRecords(next);
    pushToSupabaseNow({ pointageRecords: next }).catch(() => {});
  };

  const applyMonthDefaultPointage = (monthKey: string, targetEmpId?: string) => {
    const targetEmps = (targetEmpId 
      ? employees.filter(e => e.id === targetEmpId)
      : employees.filter(e => e.status === 'active' && e.role !== 'syndic' && e.role !== 'deputy_syndic')
    ).filter(e => isEmployeeActiveInMonth(e, monthKey));
    
    const curr = residenceSyncDataRef.current.pointageRecords || pointageRecords;
    const next = generateDefaultMonthPointage(monthKey, targetEmps, curr);
    residenceSyncDataRef.current.pointageRecords = next;
    saveToStorage('pointage_records', next);
    setPointageRecords(next);
    pushToSupabaseNow({ pointageRecords: next }).catch(() => {});
  };

  const clearMonthPointage = (monthKey: string, targetEmpId?: string) => {
    const curr = residenceSyncDataRef.current.pointageRecords || pointageRecords;
    const next = { ...curr };
    Object.keys(next).forEach(k => {
      const [empId, date] = k.split('_');
      if (date && date.startsWith(monthKey)) {
        if (!targetEmpId || empId === targetEmpId) {
          delete next[k];
        }
      }
    });
    residenceSyncDataRef.current.pointageRecords = next;
    saveToStorage('pointage_records', next);
    setPointageRecords(next);
    pushToSupabaseNow({ pointageRecords: next }).catch(() => {});
  };

  const setPointageAdvance = (employeeId: string, monthKey: string, amount: number) => {
    const key = `${employeeId}_${monthKey}`;
    const curr = residenceSyncDataRef.current.pointageAdvances || pointageAdvances;
    const next = { ...curr, [key]: amount };
    residenceSyncDataRef.current.pointageAdvances = next;
    saveToStorage('pointage_advances', next);
    setPointageAdvances(next);
    pushToSupabaseNow({ pointageAdvances: next }).catch(() => {});
  };

  const setPointageBonus = (employeeId: string, monthKey: string, amount: number) => {
    const key = `${employeeId}_${monthKey}`;
    const curr = residenceSyncDataRef.current.pointageBonuses || pointageBonuses;
    const next = { ...curr, [key]: amount };
    residenceSyncDataRef.current.pointageBonuses = next;
    saveToStorage('pointage_bonuses', next);
    setPointageBonuses(next);
    pushToSupabaseNow({ pointageBonuses: next }).catch(() => {});
  };

  const savePointageData = () => {
    const recs = residenceSyncDataRef.current.pointageRecords || pointageRecords;
    const advs = residenceSyncDataRef.current.pointageAdvances || pointageAdvances;
    const bons = residenceSyncDataRef.current.pointageBonuses || pointageBonuses;
    saveToStorage('pointage_records', recs);
    saveToStorage('pointage_advances', advs);
    saveToStorage('pointage_bonuses', bons);
    pushToSupabaseNow({
      pointageRecords: recs,
      pointageAdvances: advs,
      pointageBonuses: bons
    }).catch(() => {});
  };

  // Maintenance Tickets
  const addMaintenanceTicket = (t: Omit<MaintenanceTicket, 'id' | 'createdAt'>) => {
    const now = new Date();
    const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const newTicket: MaintenanceTicket = { ...t, id: 'm-' + Date.now(), createdAt: dateStr };
    const curr = residenceSyncDataRef.current.maintenanceTickets || maintenanceTickets;
    const next = [newTicket, ...curr.filter(item => item.id !== newTicket.id)];
    residenceSyncDataRef.current.maintenanceTickets = next;
    saveToStorage('maintenance', next);
    setMaintenanceTickets(next);

    fetch('/api/maintenance_tickets', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newTicket)
    }).catch(console.error);
    pushToSupabaseNow({ maintenanceTickets: next }).catch(() => {});
  };
  const updateMaintenanceTicket = (id: string, t: Partial<MaintenanceTicket>) => {
    const curr = residenceSyncDataRef.current.maintenanceTickets || maintenanceTickets;
    const next = curr.map(item => item.id === id ? { ...item, ...t } : item);
    residenceSyncDataRef.current.maintenanceTickets = next;
    saveToStorage('maintenance', next);
    setMaintenanceTickets(next);

    fetch(`/api/maintenance_tickets/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(t)
    }).catch(console.error);
    pushToSupabaseNow({ maintenanceTickets: next }).catch(() => {});
  };
  const deleteMaintenanceTicket = (id: string) => {
    addTombstone(id);
    const curr = residenceSyncDataRef.current.maintenanceTickets || maintenanceTickets;
    const item = curr.find(i => i.id === id);
    if (item) {
      moveToTrash('maintenance', id, item);
      logActivity('DELETE', 'maintenance', id, `حذف شكاية ${item.title}`, `Suppression Ticket ${item.title}`);
    }
    const next = curr.filter(i => i.id !== id);
    residenceSyncDataRef.current.maintenanceTickets = next;
    saveToStorage('maintenance', next);
    setMaintenanceTickets(next);

    fetch(`/api/maintenance_tickets/${id}`, { method: 'DELETE' }).catch(console.error);
    pushToSupabaseNow({ maintenanceTickets: next }).catch(() => {});
  };

  // Periodic Maintenance & Scheduled Operations
  const addPeriodicMaintenance = (pm: Omit<PeriodicMaintenance, 'id' | 'createdAt'>) => {
    const now = new Date();
    const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const newPm: PeriodicMaintenance = {
      ...pm,
      id: 'pm-' + Date.now(),
      createdAt: dateStr,
      history: pm.history || []
    };
    setPeriodicMaintenances(prev => {
      const next = [newPm, ...prev];
      saveToStorage('periodic_maintenance', next);
      residenceSyncDataRef.current.periodicMaintenances = next;
      return next;
    });
  };

  const updatePeriodicMaintenance = (id: string, pm: Partial<PeriodicMaintenance>) => {
    setPeriodicMaintenances(prev => {
      const next = prev.map(item => item.id === id ? { ...item, ...pm } : item);
      saveToStorage('periodic_maintenance', next);
      residenceSyncDataRef.current.periodicMaintenances = next;
      return next;
    });
  };

  const deletePeriodicMaintenance = (id: string) => {
    addTombstone(id);
    setPeriodicMaintenances(prev => {
      const next = prev.filter(item => item.id !== id);
      saveToStorage('periodic_maintenance', next);
      residenceSyncDataRef.current.periodicMaintenances = next;
      return next;
    });
  };

  const startPeriodicMaintenanceOperation = (id: string): MaintenanceTicket | null => {
    const pm = periodicMaintenances.find(p => p.id === id);
    if (!pm) return null;

    const now = new Date();
    const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    // Check if an existing open ticket is already in progress for this periodic maintenance
    const existingTicket = maintenanceTickets.find(t => 
      t.title.includes(pm.title) && t.status !== 'resolved'
    );

    if (existingTicket) {
      return existingTicket;
    }

    const bCode = pm.buildingCode === 'ALL' ? (buildings[0]?.code || '') : pm.buildingCode;
    const newTicket: MaintenanceTicket = {
      id: 'm-' + Date.now(),
      title: `[صيانة دورية] ${pm.title}`,
      description: `بدء عملية الصيانة الدورية الوقائية المجدولة (${pm.frequency}).\nالمكلف / الشركة: ${pm.providerOrTechnician}\nالهاتف: ${pm.providerPhone || 'غير متوفر'}\nالملاحظات الفنية: ${pm.notes || 'فحص وصيانة وقائية دورية'}\nتاريخ الاستحقاق المسجل: ${pm.nextDueDate}`,
      buildingCode: bCode,
      apartmentOrArea: pm.apartmentOrArea || 'المرافق المشتركة',
      category: pm.category,
      priority: 'high',
      status: 'in_progress',
      reportedBy: 'نظام التنبيهات والصيانة الدورية',
      assignedTo: pm.providerOrTechnician,
      estimatedCost: pm.estimatedCost || 0,
      actualCost: 0,
      createdAt: dateStr,
    };

    setMaintenanceTickets(prev => [newTicket, ...prev]);
    return newTicket;
  };

  const completePeriodicMaintenance = (id: string, actualCost?: number, notes?: string) => {
    const todayStr = new Date().toISOString().slice(0, 10);

    setPeriodicMaintenances(prev => prev.map(pm => {
      if (pm.id !== id) return pm;

      const nextDue = computeNextDate(todayStr, pm.frequency, pm.customIntervalDays);
      const histItem = {
        id: 'pmh-' + Date.now(),
        completedDate: todayStr,
        completedBy: currentUser?.name || 'وكيل السانديك',
        actualCost: actualCost !== undefined ? Number(actualCost) : pm.estimatedCost,
        notes: notes || 'تم إنجاز الفحص والصيانة الدورية بنجاح'
      };

      return {
        ...pm,
        lastCompletedDate: todayStr,
        nextDueDate: nextDue,
        history: [histItem, ...(pm.history || [])]
      };
    }));
  };

  const dismissAlert = (id: string) => {
    setDismissedAlertIds(prev => prev.includes(id) ? prev : [...prev, id]);
  };

  const resetDismissedAlerts = () => {
    setDismissedAlertIds([]);
  };

  // Daily Maintenance Checklist Operations
  const toggleChecklistItem = (id: string) => {
    const now = new Date();
    const timeStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
    const todayStr = now.toISOString().slice(0, 10);
    
    setDailyChecklistItems(prev => {
      const updated = prev.map(item => {
        if (item.id === id) {
          const nextCompleted = !item.isCompleted;
          return {
            ...item,
            isCompleted: nextCompleted,
            completedAt: nextCompleted ? timeStr : undefined,
            completedBy: nextCompleted ? (currentUser?.name || 'المشرف') : undefined
          };
        }
        return item;
      });

      // Automatically maintain and auto-save today's daily log without requiring manual click
      const total = updated.length;
      const completed = updated.filter(i => i.isCompleted).length;
      const rate = total > 0 ? Math.round((completed / total) * 100) : 0;
      
      setDailyMaintenanceLogs(logs => {
        const existingIdx = logs.findIndex(l => l.date === todayStr);
        if (existingIdx >= 0) {
          const newLogs = [...logs];
          newLogs[existingIdx] = {
            ...newLogs[existingIdx],
            items: [...updated],
            completionRate: rate,
            createdAt: timeStr
          };
          return newLogs;
        } else if (completed > 0) {
          const newLog: DailyMaintenanceLog = {
            id: 'log-' + Date.now(),
            date: todayStr,
            buildingCode: 'ALL',
            inspectorName: currentUser?.name || 'وكيل السانديك',
            items: [...updated],
            generalNotes: 'تم تسجيل ومتابعة جولة الفحص آلياً في الوقت الفعلي.',
            weatherOrCondition: 'normal',
            createdAt: timeStr,
            completionRate: rate
          };
          return [newLog, ...logs];
        }
        return logs;
      });

      return updated;
    });
  };

  const updateChecklistItem = (id: string, updates: Partial<MaintenanceChecklistItem>) => {
    setDailyChecklistItems(prev => {
      const next = prev.map(item => item.id === id ? { ...item, ...updates } : item);
      saveToStorage('daily_checklist_items', next);
      residenceSyncDataRef.current.dailyChecklistItems = next;
      return next;
    });
  };

  const addChecklistItem = (item: Omit<MaintenanceChecklistItem, 'id'>) => {
    const newItem: MaintenanceChecklistItem = {
      ...item,
      id: 'chk-' + Date.now()
    };
    setDailyChecklistItems(prev => {
      const next = [...prev, newItem];
      saveToStorage('daily_checklist_items', next);
      residenceSyncDataRef.current.dailyChecklistItems = next;
      return next;
    });
  };

  const deleteChecklistItem = (id: string) => {
    addTombstone(id);
    setDailyChecklistItems(prev => {
      const next = prev.filter(item => item.id !== id);
      saveToStorage('daily_checklist_items', next);
      residenceSyncDataRef.current.dailyChecklistItems = next;
      return next;
    });
  };

  const setAllChecklistStatus = (completed: boolean) => {
    const now = new Date();
    const timeStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
    const todayStr = now.toISOString().slice(0, 10);

    setDailyChecklistItems(prev => {
      const updated = prev.map(item => ({
        ...item,
        isCompleted: completed,
        completedAt: completed ? timeStr : undefined,
        completedBy: completed ? (currentUser?.name || 'المشرف') : undefined
      }));

      // Auto-update today's log in background
      const total = updated.length;
      const doneCount = completed ? total : 0;
      const rate = completed ? 100 : 0;

      setDailyMaintenanceLogs(logs => {
        const existingIdx = logs.findIndex(l => l.date === todayStr);
        if (existingIdx >= 0) {
          const newLogs = [...logs];
          newLogs[existingIdx] = {
            ...newLogs[existingIdx],
            items: [...updated],
            completionRate: rate,
            createdAt: timeStr
          };
          return newLogs;
        } else if (doneCount > 0) {
          const newLog: DailyMaintenanceLog = {
            id: 'log-' + Date.now(),
            date: todayStr,
            buildingCode: 'ALL',
            inspectorName: currentUser?.name || 'وكيل السانديك',
            items: [...updated],
            generalNotes: 'تم تسجيل ومتابعة جولة الفحص آلياً في الوقت الفعلي.',
            weatherOrCondition: 'normal',
            createdAt: timeStr,
            completionRate: rate
          };
          return [newLog, ...logs];
        }
        return logs;
      });

      return updated;
    });
  };

  const resetTodayChecklist = () => {
    setDailyChecklistItems(prev => prev.map(item => ({
      ...item,
      isCompleted: false,
      completedAt: undefined,
      completedBy: undefined,
      hasIssue: false,
      issueNotes: undefined,
      notes: ''
    })));
  };

  const saveDailyLog = (inspectorName: string, generalNotes?: string, weatherOrCondition?: string): DailyMaintenanceLog => {
    const todayStr = new Date().toISOString().slice(0, 10);
    const now = new Date();
    const timeStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    const total = dailyChecklistItems.length;
    const completed = dailyChecklistItems.filter(i => i.isCompleted).length;
    const rate = total > 0 ? Math.round((completed / total) * 100) : 0;

    const newLog: DailyMaintenanceLog = {
      id: 'log-' + Date.now(),
      date: todayStr,
      buildingCode: 'ALL',
      inspectorName: inspectorName || currentUser?.name || 'وكيل السانديك',
      items: [...dailyChecklistItems],
      generalNotes: generalNotes || 'تمت جولة الفحص والمراقبة اليومية.',
      weatherOrCondition: weatherOrCondition || 'normal',
      createdAt: timeStr,
      completionRate: rate
    };

    setDailyMaintenanceLogs(prev => [newLog, ...prev]);
    return newLog;
  };

  // Payments
  const addPayment = (p: Omit<Payment, 'id' | 'receiptNumber'>): Payment => {
    const currentYear = new Date().getFullYear();
    const currPayments = residenceSyncDataRef.current.payments || payments;
    const existingNums = currPayments
      .map(pay => {
        const m = pay.receiptNumber?.match(/REC-\d+-(\d+)/);
        return m ? parseInt(m[1], 10) : 0;
      })
      .filter(n => !isNaN(n) && n > 0);
    const nextSeq = (existingNums.length > 0 ? Math.max(...existingNums) : currPayments.length) + 1;
    const receiptNumber = `REC-${currentYear}-${String(nextSeq).padStart(4, '0')}`;
    const now = new Date();
    const nowIso = now.toISOString();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
    
    const newPayment: Payment = { 
      ...p, 
      id: 'p-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6), 
      receiptNumber,
      paymentDate: p.paymentDate || nowIso.slice(0, 10),
      createdAt: nowIso,
      executedAtTime: timeStr,
    };
    
    // 1. Immediately update and persist payments synchronously
    const nextPayments = [newPayment, ...currPayments.filter(pay => pay.id !== newPayment.id)];
    residenceSyncDataRef.current.payments = nextPayments;
    saveToStorage('payments', nextPayments);
    setPayments(nextPayments);

    // 2. Immediately update and persist apartment balance synchronously
    const currApartments = residenceSyncDataRef.current.apartments || apartments;
    const cleanB = (b: string) => (b || '').replace(/\s+/g, ' ').trim().toUpperCase();
    const cleanA = (a: string) => String(a || '').trim().replace(/^0+/, '') || '0';
    const targetB = cleanB(p.buildingCode);
    const targetA = cleanA(p.apartmentNumber);

    const nextApartments = currApartments.map(apt => {
      if (cleanB(apt.buildingCode) === targetB && cleanA(apt.number) === targetA) {
        const periodLate = calculateMonthsLateFromPeriod(p.periodMonth);
        const monthlyFee = apt.monthlyFee > 0 ? apt.monthlyFee : 150;
        const currentBalance = Number(apt.balanceDue) || 0;
        const paidAmount = Number(p.amount) || 0;

        let newBalance = 0;
        let newUnpaidMonths = 0;

        if (periodLate.monthsLate === 0 || (currentBalance > 0 && paidAmount >= currentBalance)) {
          newBalance = 0;
          newUnpaidMonths = 0;
        } else if (currentBalance > 0) {
          newBalance = Math.max(0, currentBalance - paidAmount);
          newUnpaidMonths = Math.max(0, Math.round(newBalance / monthlyFee));
        } else {
          newBalance = periodLate.monthsLate * monthlyFee;
          newUnpaidMonths = periodLate.monthsLate;
        }

        return { 
          ...apt, 
          balanceDue: newBalance,
          unpaidMonthsCount: newUnpaidMonths
        };
      }
      return apt;
    });

    residenceSyncDataRef.current.apartments = nextApartments;
    saveToStorage('apartments', nextApartments);
    setApartments(nextApartments);

    fetch('/api/payments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newPayment)
    }).catch(console.error);

    try {
      pushToSupabaseNow({ 
        payments: nextPayments,
        apartments: nextApartments
      }).catch(() => {});
    } catch {
      // ignore
    }

    return newPayment;
  };
  const updatePayment = (id: string, updatedFields: Partial<Payment>) => {
    const nowIso = new Date().toISOString();
    const curr = residenceSyncDataRef.current.payments || payments;
    const next = curr.map(item => item.id === id ? { ...item, ...updatedFields, updatedAt: nowIso } : item);
    residenceSyncDataRef.current.payments = next;
    saveToStorage('payments', next);
    setPayments(next);

    fetch(`/api/payments/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...updatedFields, updatedAt: nowIso })
    }).catch(console.error);

    pushToSupabaseNow({ payments: next }).catch(() => {});
  };
  const deletePayment = (id: string) => {
    addTombstone(id);
    const curr = residenceSyncDataRef.current.payments || payments;
    const item = curr.find(i => i.id === id);
    if (item) {
      moveToTrash('payment', id, item);
      logActivity('DELETE', 'payment', id, `حذف أداء بقيمة ${item.amount} درهم`, `Suppression Paiement ${item.amount} DH`);
    }
    const next = curr.filter(i => i.id !== id);
    residenceSyncDataRef.current.payments = next;
    saveToStorage('payments', next);
    setPayments(next);

    fetch(`/api/payments/${id}`, {
      method: 'DELETE'
    }).catch(console.error);

    pushToSupabaseNow({ payments: next }).catch(() => {});
  };

  const clearAllPayments = () => {
    setPayments([]);
    saveToStorage('payments', []);
    residenceSyncDataRef.current.payments = [];
    fetch('/api/payments', { method: 'DELETE' }).catch(() => {});
    pushToSupabaseNow({ payments: [] }).catch(() => {});
  };

  const syncAllPaymentsWithResidents = (): number => {
    let updatedCount = 0;
    const currentResidents = residenceSyncDataRef.current?.residents || residents;
    const currentApartments = residenceSyncDataRef.current?.apartments || apartments;

    setPayments(prev => {
      const next = prev.map(p => {
        const normB = (s: string) => (s || '').replace(/[\s\-_]/g, '').toUpperCase();
        const normA = (s: string) => String(s || '').trim().replace(/^0+/, '') || '0';
        const matchesLot = (b1: string, a1: string, b2: string, a2: string) => 
          normB(b1) === normB(b2) && (normA(a1) === normA(a2) || String(a1).trim() === String(a2).trim());

        if (false) {
          const syndicName = 'مكتب إدارة وسانديك الإقامة';
          if (p.residentName !== syndicName) updatedCount++;
          return { ...p, residentName: syndicName };
        }
        if (false) {
          const ownerName = 'السيد محمد أيت بلعربي';
          if (p.residentName !== ownerName) updatedCount++;
          return { ...p, residentName: ownerName };
        }

        const apt = currentApartments.find(a => matchesLot(a.buildingCode, a.number, p.buildingCode, p.apartmentNumber));
        const res = currentResidents.find(r => matchesLot(r.buildingCode, r.apartmentNumber, p.buildingCode, p.apartmentNumber));

        const aptOwner = (apt?.ownerName && !isGenericPlaceholderName(apt.ownerName)) ? apt.ownerName.trim() : '';
        const resOwner = (res?.fullName && !isGenericPlaceholderName(res.fullName)) ? res.fullName.trim() : '';
        const aptResident = (apt?.residentName && !isGenericPlaceholderName(apt.residentName)) ? apt.residentName.trim() : '';

        const realOwner = aptOwner || resOwner || aptResident || (p.residentName && !isGenericPlaceholderName(p.residentName) ? p.residentName : '');

        if (realOwner && p.residentName !== realOwner) {
          updatedCount++;
          return { ...p, residentName: realOwner };
        }
        return p;
      });
      saveToStorage('payments', next);
      residenceSyncDataRef.current.payments = next;
      return next;
    });
    return updatedCount;
  };

  // Expenses
  const addExpense = (e: Omit<Expense, 'id'>): Expense => {
    const now = new Date();
    const nowIso = now.toISOString();
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;

    const newExp: Expense = { 
      ...e, 
      id: 'exp-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      date: e.date || nowIso.slice(0, 10),
      createdAt: nowIso,
      executedAtTime: timeStr,
    };
    const curr = residenceSyncDataRef.current.expenses || expenses;
    const next = [newExp, ...curr.filter(item => item.id !== newExp.id)];
    residenceSyncDataRef.current.expenses = next;
    saveToStorage('expenses', next);
    setExpenses(next);

    fetch('/api/expenses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newExp)
    }).catch(console.error);

    pushToSupabaseNow({ expenses: next }).catch(() => {});
    return newExp;
  };
  const updateExpense = (id: string, updatedFields: Partial<Expense>) => {
    const nowIso = new Date().toISOString();
    const curr = residenceSyncDataRef.current.expenses || expenses;
    const next = curr.map(item => item.id === id ? { ...item, ...updatedFields, updatedAt: nowIso } : item);
    residenceSyncDataRef.current.expenses = next;
    saveToStorage('expenses', next);
    setExpenses(next);

    fetch(`/api/expenses/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...updatedFields, updatedAt: nowIso })
    }).catch(console.error);
    pushToSupabaseNow({ expenses: next }).catch(() => {});
  };
  const deleteExpense = (id: string) => {
    addTombstone(id);
    const curr = residenceSyncDataRef.current.expenses || expenses;
    const item = curr.find(i => i.id === id);
    if (item) {
      moveToTrash('expense', id, item);
      logActivity('DELETE', 'expense', id, `حذف مصروف بقيمة ${item.amount} درهم`, `Suppression Dépense ${item.amount} DH`);
    }
    const next = curr.filter(i => i.id !== id);
    residenceSyncDataRef.current.expenses = next;
    saveToStorage('expenses', next);
    setExpenses(next);

    fetch(`/api/expenses/${id}`, {
      method: 'DELETE'
    }).catch(console.error);
    pushToSupabaseNow({ expenses: next }).catch(() => {});
  };

  // Visitors
  const addVisitor = (v: Omit<Visitor, 'id' | 'entryTime' | 'status'>) => {
    const now = new Date();
    const timeStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const newVis: Visitor = { ...v, id: 'v-' + Date.now(), entryTime: timeStr, status: 'inside' };
    const curr = residenceSyncDataRef.current.visitors || visitors;
    const next = [newVis, ...curr.filter(item => item.id !== newVis.id)];
    residenceSyncDataRef.current.visitors = next;
    saveToStorage('visitors', next);
    setVisitors(next);

    fetch('/api/visitors', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newVis)
    }).catch(console.error);
    pushToSupabaseNow({ visitors: next }).catch(() => {});
  };
  const markVisitorExit = (id: string) => {
    const now = new Date();
    const timeStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const curr = residenceSyncDataRef.current.visitors || visitors;
    const next: Visitor[] = curr.map(item => item.id === id ? { ...item, exitTime: timeStr, status: 'left' as const } : item);
    residenceSyncDataRef.current.visitors = next;
    saveToStorage('visitors', next);
    setVisitors(next);

    fetch(`/api/visitors/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ exitTime: timeStr, status: 'left' })
    }).catch(console.error);
    pushToSupabaseNow({ visitors: next }).catch(() => {});
  };
  const deleteVisitor = (id: string) => {
    addTombstone(id);
    const curr = residenceSyncDataRef.current.visitors || visitors;
    const next = curr.filter(item => item.id !== id);
    residenceSyncDataRef.current.visitors = next;
    saveToStorage('visitors', next);
    setVisitors(next);
    pushToSupabaseNow({ visitors: next }).catch(() => {});
  };

  // Notices
  const addNotice = (n: Omit<Notice, 'id' | 'date'>): Notice => {
    const now = new Date();
    const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    const newNotice: Notice = {
      targetBuilding: 'ALL',
      publishDate: dateStr,
      ...n,
      id: 'not-' + Date.now(),
      date: dateStr
    };
    const curr = residenceSyncDataRef.current.notices || notices;
    const next = [newNotice, ...curr.filter(item => item.id !== newNotice.id)];
    residenceSyncDataRef.current.notices = next;
    saveToStorage('notices', next);
    setNotices(next);

    fetch('/api/notices', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newNotice)
    }).catch(console.error);
    pushToSupabaseNow({ notices: next }).catch(() => {});
    return newNotice;
  };
  const deleteNotice = (id: string) => {
    addTombstone(id);
    const curr = residenceSyncDataRef.current.notices || notices;
    const item = curr.find(i => i.id === id);
    if (item) {
      moveToTrash('notice', id, item);
      logActivity('DELETE', 'notice', id, `حذف إعلان ${item.title}`, `Suppression Annonce ${item.title}`);
    }
    const next = curr.filter(i => i.id !== id);
    residenceSyncDataRef.current.notices = next;
    saveToStorage('notices', next);
    setNotices(next);

    fetch(`/api/notices/${id}`, { method: 'DELETE' }).catch(console.error);
    pushToSupabaseNow({ notices: next }).catch(() => {});
  };

  // Users
  const addUser = (u: Omit<User, 'id'>) => {
    // L'inscription exige un e-mail valide
    if (!u.email || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(u.email.trim())) return;
    const newUser: User = { ...u, id: 'u-' + Date.now() };
    setUsers(prev => {
      const next = [...prev, newUser];
      saveToStorage('users', next);
      residenceSyncDataRef.current.users = next;
      return next;
    });
  };
  const updateUser = (id: string, u: Partial<User>) => {
    setUsers(prev => {
      const next = prev.map(item => item.id === id ? { ...item, ...u } : item);
      saveToStorage('users', next);
      residenceSyncDataRef.current.users = next;
      return next;
    });
    if (currentUser && currentUser.id === id) {
      setCurrentUser(prev => prev ? { ...prev, ...u } : null);
    }
  };
  const deleteUser = (id: string) => {
    addTombstone(id);
    setUsers(prev => {
      const next = prev.filter(item => item.id !== id);
      saveToStorage('users', next);
      residenceSyncDataRef.current.users = next;
      return next;
    });
  };
  const updateUserPassword = (usernameOrEmail: string, newPass: string): boolean => {
    const clean = usernameOrEmail.trim().toLowerCase();
    let found = false;
    setUsers(prev => prev.map(u => {
      if (u.username.toLowerCase() === clean || (u.email && u.email.toLowerCase() === clean)) {
        found = true;
        return { ...u, password: newPass };
      }
      return u;
    }));
    return found;
  };
  const verifyUserCredentials = (usernameOrEmail: string, oldPass: string): boolean => {
    const clean = usernameOrEmail.trim().toLowerCase();
    const u = users.find(x => x.username.toLowerCase() === clean || (x.email && x.email.toLowerCase() === clean));
    if (!u) return false;
    return (u.password || '') === oldPass;
  };

  // Financial calculations
  const totalIncome = payments.reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);
  const totalExpenses = expenses.reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);
  const totalBalance = totalIncome - totalExpenses;
  const totalBalanceDue = apartments.reduce((acc, curr) => acc + (Number(curr.balanceDue) || 0), 0);
  const openTicketsCount = maintenanceTickets.filter(t => t.status !== 'resolved').length;
  const activeVisitorsCount = visitors.filter(v => v.status === 'inside').length;

  // Archive calculations
  const archivedPaymentsTotal = archivedPayments.reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);
  const archivedExpensesTotal = archivedExpenses.reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0);
  const totalArchivedCount = archivedPayments.length + archivedExpenses.length;

  // Periodic maintenance alert system calculations
  const maintenanceAlerts: MaintenanceAlert[] = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const alerts: MaintenanceAlert[] = [];

    periodicMaintenances.forEach(pm => {
      if (!pm.isActive) return;
      if (!pm.nextDueDate) return;

      const dueDate = new Date(pm.nextDueDate);
      dueDate.setHours(0, 0, 0, 0);

      const diffTime = dueDate.getTime() - today.getTime();
      const daysRemaining = Math.round(diffTime / (1000 * 60 * 60 * 24));

      if (daysRemaining < 0) {
        // Overdue
        const daysOver = Math.abs(daysRemaining);
        alerts.push({
          scheduleId: pm.id,
          schedule: pm,
          type: 'overdue',
          daysRemaining,
          message: lang === 'ar' 
            ? `تأخر موعد فحص ${pm.title} بـ ${daysOver} يوم (${pm.buildingCode})`
            : `Échéance dépassée de ${daysOver} jour(s) pour ${pm.title} (${pm.buildingCode})`
        });
      } else if (daysRemaining === 0) {
        // Today
        alerts.push({
          scheduleId: pm.id,
          schedule: pm,
          type: 'today',
          daysRemaining: 0,
          message: lang === 'ar'
            ? `موعد الفحص والصيانة لـ ${pm.title} مستحق اليوم! (${pm.buildingCode})`
            : `L'échéance de maintenance pour ${pm.title} est aujourd'hui ! (${pm.buildingCode})`
        });
      } else if (daysRemaining <= (pm.remindDaysBefore || 7)) {
        // Imminent
        alerts.push({
          scheduleId: pm.id,
          schedule: pm,
          type: 'imminent',
          daysRemaining,
          message: lang === 'ar'
            ? `اقترب موعد ${pm.title}: متبقي ${daysRemaining} أيام (${pm.buildingCode})`
            : `Échéance imminente pour ${pm.title} : dans ${daysRemaining} jours (${pm.buildingCode})`
        });
      }
    });

    // Sort: overdue first, then today, then imminent
    return alerts.sort((a, b) => a.daysRemaining - b.daysRemaining);
  }, [periodicMaintenances, lang]);

  const overdueAlertsCount = maintenanceAlerts.filter(a => a.type === 'overdue').length;
  const imminentAlertsCount = maintenanceAlerts.filter(a => a.type === 'imminent' || a.type === 'today').length;
  const totalActiveAlertsCount = maintenanceAlerts.length;

  const getEligibleArchiveCount = (cutoffDate: string) => {
    const cutoffTime = new Date(cutoffDate).getTime();
    if (isNaN(cutoffTime)) return { paymentsCount: 0, expensesCount: 0, paymentsAmount: 0, expensesAmount: 0 };
    
    const eligiblePayments = payments.filter(p => {
      const pDate = new Date(p.paymentDate).getTime();
      return !isNaN(pDate) && pDate <= cutoffTime;
    });
    const eligibleExpenses = expenses.filter(e => {
      const eDate = new Date(e.date).getTime();
      return !isNaN(eDate) && eDate <= cutoffTime;
    });

    return {
      paymentsCount: eligiblePayments.length,
      expensesCount: eligibleExpenses.length,
      paymentsAmount: eligiblePayments.reduce((acc, c) => acc + (Number(c.amount) || 0), 0),
      expensesAmount: eligibleExpenses.reduce((acc, c) => acc + (Number(c.amount) || 0), 0)
    };
  };

  const archiveOldRecords = (options: {
    cutoffDate: string;
    cutoffMonths?: number;
    includePayments?: boolean;
    includeExpenses?: boolean;
    notes?: string;
  }) => {
    const { cutoffDate, cutoffMonths = 12, includePayments = true, includeExpenses = true, notes } = options;
    const cutoffTime = new Date(cutoffDate).getTime();

    let movedPayments: Payment[] = [];
    let remainingPayments: Payment[] = payments;
    if (includePayments) {
      movedPayments = payments.filter(p => {
        const pDate = new Date(p.paymentDate).getTime();
        return !isNaN(pDate) && pDate <= cutoffTime;
      });
      remainingPayments = payments.filter(p => {
        const pDate = new Date(p.paymentDate).getTime();
        return isNaN(pDate) || pDate > cutoffTime;
      });
    }

    let movedExpenses: Expense[] = [];
    let remainingExpenses: Expense[] = expenses;
    if (includeExpenses) {
      movedExpenses = expenses.filter(e => {
        const eDate = new Date(e.date).getTime();
        return !isNaN(eDate) && eDate <= cutoffTime;
      });
      remainingExpenses = expenses.filter(e => {
        const eDate = new Date(e.date).getTime();
        return isNaN(eDate) || eDate > cutoffTime;
      });
    }

    if (movedPayments.length === 0 && movedExpenses.length === 0) {
      return { paymentsMoved: 0, expensesMoved: 0, paymentsAmount: 0, expensesAmount: 0 };
    }

    const paymentsAmount = movedPayments.reduce((acc, c) => acc + (Number(c.amount) || 0), 0);
    const expensesAmount = movedExpenses.reduce((acc, c) => acc + (Number(c.amount) || 0), 0);

    const newBatch: ArchiveBatch = {
      id: 'batch-' + Date.now(),
      archiveDate: new Date().toISOString().slice(0, 19).replace('T', ' '),
      cutoffDate,
      cutoffMonths,
      paymentsCount: movedPayments.length,
      expensesCount: movedExpenses.length,
      paymentsTotalAmount: paymentsAmount,
      expensesTotalAmount: expensesAmount,
      archivedBy: currentUser?.name || 'وكيل السانديك',
      notes: notes || `أرشفة السجلات الأقدم من ${cutoffDate}`
    };

    setPayments(remainingPayments);
    setExpenses(remainingExpenses);
    const updatedArchPayments = [...movedPayments, ...archivedPayments];
    const updatedArchExpenses = [...movedExpenses, ...archivedExpenses];
    const updatedArchBatches = [newBatch, ...archiveBatches];

    setArchivedPayments(updatedArchPayments);
    setArchivedExpenses(updatedArchExpenses);
    setArchiveBatches(updatedArchBatches);

    saveToStorage('payments', remainingPayments);
    saveToStorage('expenses', remainingExpenses);
    saveToStorage('archived_payments', updatedArchPayments);
    saveToStorage('archived_expenses', updatedArchExpenses);
    saveToStorage('archive_batches', updatedArchBatches);

    residenceSyncDataRef.current.payments = remainingPayments;
    residenceSyncDataRef.current.expenses = remainingExpenses;
    residenceSyncDataRef.current.archivedPayments = updatedArchPayments;
    residenceSyncDataRef.current.archivedExpenses = updatedArchExpenses;
    residenceSyncDataRef.current.archiveBatches = updatedArchBatches;

    pushToSupabaseNow({
      payments: remainingPayments,
      expenses: remainingExpenses,
      archivedPayments: updatedArchPayments,
      archivedExpenses: updatedArchExpenses,
      archiveBatches: updatedArchBatches
    }).catch(() => {});

    return {
      paymentsMoved: movedPayments.length,
      expensesMoved: movedExpenses.length,
      paymentsAmount,
      expensesAmount
    };
  };

  const restorePaymentFromArchive = (id: string) => {
    const item = archivedPayments.find(p => p.id === id);
    if (!item) return;
    const nextArchived = archivedPayments.filter(p => p.id !== id);
    const nextPayments = [item, ...payments];
    setArchivedPayments(nextArchived);
    setPayments(nextPayments);

    saveToStorage('archived_payments', nextArchived);
    saveToStorage('payments', nextPayments);
    residenceSyncDataRef.current.archivedPayments = nextArchived;
    residenceSyncDataRef.current.payments = nextPayments;

    pushToSupabaseNow({
      payments: nextPayments,
      archivedPayments: nextArchived
    }).catch(() => {});
  };

  const restoreExpenseFromArchive = (id: string) => {
    const item = archivedExpenses.find(e => e.id === id);
    if (!item) return;
    const nextArchived = archivedExpenses.filter(e => e.id !== id);
    const nextExpenses = [item, ...expenses];
    setArchivedExpenses(nextArchived);
    setExpenses(nextExpenses);

    saveToStorage('archived_expenses', nextArchived);
    saveToStorage('expenses', nextExpenses);
    residenceSyncDataRef.current.archivedExpenses = nextArchived;
    residenceSyncDataRef.current.expenses = nextExpenses;

    pushToSupabaseNow({
      expenses: nextExpenses,
      archivedExpenses: nextArchived
    }).catch(() => {});
  };

  const restoreBatchFromArchive = (batchId: string) => {
    const batch = archiveBatches.find(b => b.id === batchId);
    if (!batch) return;
    const cutoffTime = new Date(batch.cutoffDate).getTime();

    const toRestorePayments = archivedPayments.filter(p => {
      const pDate = new Date(p.paymentDate).getTime();
      return !isNaN(pDate) && pDate <= cutoffTime;
    });
    const remainingArchivedPayments = archivedPayments.filter(p => {
      const pDate = new Date(p.paymentDate).getTime();
      return isNaN(pDate) || pDate > cutoffTime;
    });

    const toRestoreExpenses = archivedExpenses.filter(e => {
      const eDate = new Date(e.date).getTime();
      return !isNaN(eDate) && eDate <= cutoffTime;
    });
    const remainingArchivedExpenses = archivedExpenses.filter(e => {
      const eDate = new Date(e.date).getTime();
      return isNaN(eDate) || eDate > cutoffTime;
    });

    const nextPayments = [...toRestorePayments, ...payments];
    const nextExpenses = [...toRestoreExpenses, ...expenses];
    const nextBatches = archiveBatches.filter(b => b.id !== batchId);

    setPayments(nextPayments);
    setExpenses(nextExpenses);
    setArchivedPayments(remainingArchivedPayments);
    setArchivedExpenses(remainingArchivedExpenses);
    setArchiveBatches(nextBatches);

    saveToStorage('payments', nextPayments);
    saveToStorage('expenses', nextExpenses);
    saveToStorage('archived_payments', remainingArchivedPayments);
    saveToStorage('archived_expenses', remainingArchivedExpenses);
    saveToStorage('archive_batches', nextBatches);

    residenceSyncDataRef.current.payments = nextPayments;
    residenceSyncDataRef.current.expenses = nextExpenses;
    residenceSyncDataRef.current.archivedPayments = remainingArchivedPayments;
    residenceSyncDataRef.current.archivedExpenses = remainingArchivedExpenses;
    residenceSyncDataRef.current.archiveBatches = nextBatches;

    pushToSupabaseNow({
      payments: nextPayments,
      expenses: nextExpenses,
      archivedPayments: remainingArchivedPayments,
      archivedExpenses: remainingArchivedExpenses,
      archiveBatches: nextBatches
    }).catch(() => {});
  };

  const restoreAllArchivedRecords = () => {
    const nextPayments = [...archivedPayments, ...payments];
    const nextExpenses = [...archivedExpenses, ...expenses];
    setPayments(nextPayments);
    setExpenses(nextExpenses);
    setArchivedPayments([]);
    setArchivedExpenses([]);
    setArchiveBatches([]);

    saveToStorage('payments', nextPayments);
    saveToStorage('expenses', nextExpenses);
    saveToStorage('archived_payments', []);
    saveToStorage('archived_expenses', []);
    saveToStorage('archive_batches', []);

    residenceSyncDataRef.current.payments = nextPayments;
    residenceSyncDataRef.current.expenses = nextExpenses;
    residenceSyncDataRef.current.archivedPayments = [];
    residenceSyncDataRef.current.archivedExpenses = [];
    residenceSyncDataRef.current.archiveBatches = [];

    pushToSupabaseNow({
      payments: nextPayments,
      expenses: nextExpenses,
      archivedPayments: [],
      archivedExpenses: [],
      archiveBatches: []
    }).catch(() => {});
  };

  const deleteArchivedPayment = (id: string) => {
    setArchivedPayments(prev => {
      const next = prev.filter(p => p.id !== id);
      saveToStorage('archived_payments', next);
      residenceSyncDataRef.current.archivedPayments = next;
      pushToSupabaseNow({ archivedPayments: next }).catch(() => {});
      return next;
    });
  };

  const deleteArchivedExpense = (id: string) => {
    setArchivedExpenses(prev => {
      const next = prev.filter(e => e.id !== id);
      saveToStorage('archived_expenses', next);
      residenceSyncDataRef.current.archivedExpenses = next;
      pushToSupabaseNow({ archivedExpenses: next }).catch(() => {});
      return next;
    });
  };

  const clearAllArchive = () => {
    setArchivedPayments([]);
    setArchivedExpenses([]);
    setArchiveBatches([]);
    saveToStorage('archived_payments', []);
    saveToStorage('archived_expenses', []);
    saveToStorage('archive_batches', []);
    residenceSyncDataRef.current.archivedPayments = [];
    residenceSyncDataRef.current.archivedExpenses = [];
    residenceSyncDataRef.current.archiveBatches = [];
    pushToSupabaseNow({
      archivedPayments: [],
      archivedExpenses: [],
      archiveBatches: []
    }).catch(() => {});
  };

  const exportArchiveJSON = () => {
    const archiveData = {
      archiveVersion: '1.0',
      residence: RES.nameFr,
      exportedAt: new Date().toISOString(),
      archivedPayments,
      archivedExpenses,
      archiveBatches,
      summary: {
        paymentsCount: archivedPayments.length,
        expensesCount: archivedExpenses.length,
        paymentsTotal: archivedPaymentsTotal,
        expensesTotal: archivedExpensesTotal,
      }
    };
    const blob = new Blob([JSON.stringify(archiveData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SYNDICO_Archive_Database_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const importArchiveFromJSON = (jsonStr: string): boolean => {
    try {
      const parsed = JSON.parse(jsonStr);
      if (Array.isArray(parsed.archivedPayments)) {
        setArchivedPayments(prev => {
          const existingIds = new Set(prev.map(x => x.id));
          const newItems = parsed.archivedPayments.filter((x: Payment) => !existingIds.has(x.id));
          return [...prev, ...newItems];
        });
      }
      if (Array.isArray(parsed.archivedExpenses)) {
        setArchivedExpenses(prev => {
          const existingIds = new Set(prev.map(x => x.id));
          const newItems = parsed.archivedExpenses.filter((x: Expense) => !existingIds.has(x.id));
          return [...prev, ...newItems];
        });
      }
      if (Array.isArray(parsed.archiveBatches)) {
        setArchiveBatches(prev => {
          const existingIds = new Set(prev.map(x => x.id));
          const newItems = parsed.archiveBatches.filter((x: ArchiveBatch) => !existingIds.has(x.id));
          return [...prev, ...newItems];
        });
      }
      return true;
    } catch (e) {
      console.error('Failed to parse archive JSON', e);
      return false;
    }
  };

  // عمليات السجل المالي اليدوي للأشهر السابقة واللاحقة (ابتداء من 04/2025)
  const upsertManualMonthlyRecord = (rec: Omit<ManualMonthlyRecord, 'id' | 'updatedAt'> & { id?: string }) => {
    const id = rec.id || `rec-${rec.monthKey}-${Date.now()}`;
    const currList = residenceSyncDataRef.current.manualMonthlyRecords || manualMonthlyRecords;
    const existingIndex = currList.findIndex(r => r.id === id || r.monthKey === rec.monthKey);
    const updatedItem: ManualMonthlyRecord = {
      ...rec,
      id,
      updatedAt: new Date().toISOString(),
      isUserModified: true,
      isClosed: rec.isClosed ?? currList[existingIndex]?.isClosed,
      closedAt: rec.closedAt ?? currList[existingIndex]?.closedAt,
      closedBy: rec.closedBy ?? currList[existingIndex]?.closedBy,
      recordedBy: rec.recordedBy || currentUser?.name || 'وكيل السانديك'
    };

    let newArr: ManualMonthlyRecord[];
    if (existingIndex >= 0) {
      newArr = [...currList];
      newArr[existingIndex] = updatedItem;
    } else {
      newArr = [...currList, updatedItem];
    }
    // Harmonize the chain forward so opening/closing balances flow seamlessly
    const harmonized = harmonizeManualMonthlyRecordsChain(newArr);
    saveToStorage('manual_monthly_records', harmonized);
    residenceSyncDataRef.current.manualMonthlyRecords = harmonized;
    setManualMonthlyRecords(harmonized);

    // Sync to Supabase Cloud & Local Server API immediately
    pushToSupabaseNow({ manualMonthlyRecords: harmonized }).catch(() => {});
    fetch('/api/manual_monthly_records', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updatedItem)
    }).catch(() => {});

    logActivity(
      'UPDATE',
      'MANUAL_MONTHLY_RECORD',
      rec.monthKey,
      `تحديث/إدخال السجل المالي الشهري لشهر ${rec.monthKey} (مداخيل: ${rec.totalIncome} د.م | مصاريف: ${rec.totalExpenses} د.م)`,
      `Mise à jour du registre financier mensuel ${rec.monthKey} (Recettes: ${rec.totalIncome} DH | Dépenses: ${rec.totalExpenses} DH)`
    );
  };

  // حفظ سلسلة السجل المالي (محلياً + السحابة)
  const persistManualRecords = (list: ManualMonthlyRecord[]) => {
    const harmonized = harmonizeManualMonthlyRecordsChain(list);
    saveToStorage('manual_monthly_records', harmonized);
    residenceSyncDataRef.current.manualMonthlyRecords = harmonized;
    setManualMonthlyRecords(harmonized);
    pushToSupabaseNow({ manualMonthlyRecords: harmonized }).catch(() => {});
    return harmonized;
  };

  // إغلاق الشهر: الرصيد المرحل = الرصيد السابق + المداخيل - المصاريف، ويُسجَّل تلقائياً كرصيد افتتاحي للشهر الموالي
  const closeManualMonth = (monthKey: string) => {
    const currList = residenceSyncDataRef.current.manualMonthlyRecords || manualMonthlyRecords;
    const rec = currList.find(r => r.monthKey === monthKey);
    if (!rec) return { success: false, message: 'NO_RECORD' };
    const nextKey = getNextMonthKey(monthKey);
    const now = new Date().toISOString();
    const who = currentUser?.name || 'وكيل السانديك';
    const list: ManualMonthlyRecord[] = currList.map(r =>
      r.monthKey === monthKey ? { ...r, isClosed: true, closedAt: now, closedBy: who, updatedAt: now } : r
    );
    if (nextKey && !list.some(r => r.monthKey === nextKey)) {
      list.push({
        id: `rec-${nextKey}-${Date.now()}`,
        monthKey: nextKey,
        totalIncome: 0,
        totalExpenses: 0,
        updatedAt: now,
        recordedBy: who
      });
    }
    const harmonized = persistManualRecords(list);
    const closed = harmonized.find(r => r.monthKey === monthKey);
    const closing = closed?.closingBalance ?? 0;
    logActivity(
      'UPDATE',
      'MANUAL_MONTHLY_RECORD',
      monthKey,
      `إغلاق شهر ${monthKey} وترحيل الرصيد ${closing} د.م إلى شهر ${nextKey}`,
      `Clôture du mois ${monthKey} et report du solde ${closing} DH vers ${nextKey}`
    );
    return { success: true, closingBalance: closing, nextMonthKey: nextKey };
  };

  const reopenManualMonth = (monthKey: string) => {
    const currList = residenceSyncDataRef.current.manualMonthlyRecords || manualMonthlyRecords;
    const rec = currList.find(r => r.monthKey === monthKey);
    if (!rec) return { success: false, message: 'NO_RECORD' };
    const nextKey = getNextMonthKey(monthKey);
    if (currList.some(r => r.monthKey === nextKey && r.isClosed)) {
      return { success: false, message: 'NEXT_CLOSED' };
    }
    const now = new Date().toISOString();
    persistManualRecords(currList.map(r =>
      r.monthKey === monthKey ? { ...r, isClosed: false, closedAt: undefined, closedBy: undefined, updatedAt: now } : r
    ));
    logActivity(
      'UPDATE',
      'MANUAL_MONTHLY_RECORD',
      monthKey,
      `إعادة فتح شهر ${monthKey}`,
      `Réouverture du mois ${monthKey}`
    );
    return { success: true };
  };

  const deleteManualMonthlyRecord = (id: string) => {
    addTombstone(id);
    const currList = residenceSyncDataRef.current.manualMonthlyRecords || manualMonthlyRecords;
    const target = currList.find(r => r.id === id);
    if (target) {
      logActivity(
        'DELETE',
        'MANUAL_MONTHLY_RECORD',
        target.monthKey,
        `حذف السجل المالي لشهر ${target.monthKey}`,
        `Suppression du registre financier ${target.monthKey}`
      );
    }
    const filtered = currList.filter(r => r.id !== id);
    const harmonized = harmonizeManualMonthlyRecordsChain(filtered);
    saveToStorage('manual_monthly_records', harmonized);
    residenceSyncDataRef.current.manualMonthlyRecords = harmonized;
    setManualMonthlyRecords(harmonized);

    pushToSupabaseNow({ manualMonthlyRecords: harmonized }).catch(() => {});
    fetch(`/api/manual_monthly_records/${id}`, { method: 'DELETE' }).catch(() => {});
  };

  const batchSaveManualMonthlyRecords = (records: ManualMonthlyRecord[]) => {
    const stamped = records.map(r => ({ ...r, isUserModified: true }));
    const harmonized = harmonizeManualMonthlyRecordsChain(stamped);
    setManualMonthlyRecords(harmonized);
    saveToStorage('manual_monthly_records', harmonized);
    residenceSyncDataRef.current.manualMonthlyRecords = harmonized;
    pushToSupabaseNow({ manualMonthlyRecords: harmonized }).catch(() => {});
    fetch('/api/manual_monthly_records/batch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(harmonized)
    }).catch(() => {});
  };

  const clearManualMonthlyRecords = () => {
    setManualMonthlyRecords([]);
    saveToStorage('manual_monthly_records', []);
    residenceSyncDataRef.current.manualMonthlyRecords = [];
    pushToSupabaseNow({ manualMonthlyRecords: [] }).catch(() => {});
    fetch('/api/manual_monthly_records', { method: 'DELETE' }).catch(() => {});
  };

  // قرارات وتصويت الجمع العام (Assemblée Générale)
  const castResolutionVote = (resolutionId: string, choice: VoteChoice, comment?: string): { success: boolean; message: string } => {
    if (!currentUser) {
      return { 
        success: false, 
        message: lang === 'ar' ? 'يرجى تسجيل الدخول أولاً للمشاركة في التصويت' : 'Veuillez vous connecter pour participer au vote' 
      };
    }

    const aptNumber = currentUser.apartment || (currentUser.role === 'resident' ? currentUser.username.replace(/[^\d]/g, '') : '');
    const bldgCode = currentUser.building || '';

    let success = false;
    let message = '';

    setAssemblyResolutions(prev => {
      const target = prev.find(r => r.id === resolutionId);
      if (!target) {
        message = lang === 'ar' ? 'القرار المقترح غير موجود' : 'Résolution introuvable';
        return prev;
      }

      if (target.status !== 'active') {
        message = lang === 'ar' ? 'التصويت على هذا القرار مغلق حالياً' : 'Le vote sur cette résolution est clôturé';
        return prev;
      }

      const voteIndex = target.votes.findIndex(v => 
        v.userId === currentUser.id || 
        (aptNumber && v.apartmentNumber === aptNumber && v.buildingCode.replace(/\s+/g, '') === bldgCode.replace(/\s+/g, ''))
      );

      const newVote: ResolutionVote = {
        id: 'vote-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
        userId: currentUser.id,
        userName: currentUser.name || (currentUser.role === 'resident' ? `شقة ${aptNumber}` : currentUser.username),
        userRole: currentUser.role,
        apartmentNumber: aptNumber || '-',
        buildingCode: bldgCode || '-',
        choice,
        timestamp: new Date().toISOString(),
        comment: comment?.trim() || undefined
      };

      const updatedVotes = [...target.votes];
      if (voteIndex >= 0) {
        updatedVotes[voteIndex] = newVote;
      } else {
        updatedVotes.unshift(newVote);
      }

      success = true;
      message = voteIndex >= 0
        ? (lang === 'ar' ? 'تم تحديث خيار تصويتك بنجاح ✅' : 'Votre vote a été mis à jour avec succès ✅')
        : (lang === 'ar' ? 'تم تسجيل تصويتك في الجمع العام بنجاح 🗳️' : 'Votre vote a été enregistré avec succès 🗳️');

      const updated = prev.map(r => r.id === resolutionId ? { ...r, votes: updatedVotes } : r);
      saveToStorage('assembly_resolutions', updated);
      return updated;
    });

    if (success) {
      logActivity(
        'CREATE',
        'resident',
        resolutionId,
        `تصويت في الجمع العام: ${choice === 'for' ? 'موافق' : choice === 'against' ? 'معارض' : 'ممتنع'} من طرف ${currentUser.name || currentUser.username}`,
        `Vote AG: ${choice} par ${currentUser.name || currentUser.username}`
      );
      showToast(message, { type: 'success' });
    } else {
      showToast(message, { type: 'error' });
    }

    return { success, message };
  };

  const addAssemblyResolution = (res: Omit<AssemblyResolution, 'id' | 'createdAt' | 'votes'>) => {
    const newResolution: AssemblyResolution = {
      ...res,
      id: 'res-' + Date.now(),
      createdAt: new Date().toISOString(),
      votes: []
    };
    setAssemblyResolutions(prev => {
      const updated = [newResolution, ...prev];
      saveToStorage('assembly_resolutions', updated);
      return updated;
    });
    logActivity(
      'CREATE',
      'notice',
      newResolution.id,
      `إضافة مقترح قرار جديد للجمع العام: ${newResolution.titleAr}`,
      `Ajout nouvelle résolution AG: ${newResolution.titleFr}`
    );
    showToast(
      lang === 'ar' ? 'تمت إضافة القرار المقترح للتصويت بالجمع العام بنجاح 📜' : 'Résolution ajoutée avec succès 📜',
      { type: 'success' }
    );
  };

  const updateAssemblyResolution = (id: string, updates: Partial<AssemblyResolution>) => {
    setAssemblyResolutions(prev => {
      const updated = prev.map(r => r.id === id ? { ...r, ...updates } : r);
      saveToStorage('assembly_resolutions', updated);
      residenceSyncDataRef.current.assemblyResolutions = updated;
      return updated;
    });
    showToast(
      lang === 'ar' ? 'تم تحديث القرار المقترح بنجاح' : 'Résolution mise à jour',
      { type: 'success' }
    );
  };

  const deleteAssemblyResolution = (id: string) => {
    addTombstone(id);
    setAssemblyResolutions(prev => {
      const target = prev.find(r => r.id === id);
      if (target) {
        logActivity(
          'DELETE',
          'notice',
          id,
          `حذف قرار من الجمع العام: ${target.titleAr}`,
          `Suppression résolution AG: ${target.titleFr}`
        );
      }
      const updated = prev.filter(r => r.id !== id);
      saveToStorage('assembly_resolutions', updated);
      residenceSyncDataRef.current.assemblyResolutions = updated;
      return updated;
    });
    showToast(
      lang === 'ar' ? 'تم حذف القرار المقترح بنجاح' : 'Résolution supprimée',
      { type: 'success' }
    );
  };

  const setAssemblyResolutionStatus = (id: string, status: ResolutionStatus) => {
    setAssemblyResolutions(prev => {
      const updated = prev.map(r => r.id === id ? {
        ...r,
        status,
        closedAt: status === 'closed' ? new Date().toISOString() : undefined
      } : r);
      saveToStorage('assembly_resolutions', updated);
      return updated;
    });
    showToast(
      status === 'active'
        ? (lang === 'ar' ? 'تم فتح باب التصويت على القرار 🟢' : 'Vote ouvert')
        : (lang === 'ar' ? 'تم إغلاق التصويت على القرار 🔒' : 'Vote clôturé'),
      { type: 'info' }
    );
  };

  const resetAssemblyResolutionVotes = (id: string) => {
    setAssemblyResolutions(prev => {
      const updated = prev.map(r => r.id === id ? { ...r, votes: [] } : r);
      saveToStorage('assembly_resolutions', updated);
      return updated;
    });
    showToast(
      lang === 'ar' ? 'تمت إعادة تعيين أصوات هذا القرار بنجاح' : 'Votes réinitialisés',
      { type: 'info' }
    );
  };

  // Export & Backup
  const exportAllDataJSON = () => {
    const allData = {
      version: '2.0',
      exportDate: new Date().toISOString(),
      buildings,
      apartments,
      residents,
      employees,
      maintenanceTickets,
      payments,
      expenses,
      visitors,
      notices,
      periodicMaintenances,
      archivedPayments,
      archivedExpenses,
      archiveBatches,
      manualMonthlyRecords,
      assemblyResolutions,
      users: users.map(u => ({ ...u, password: '***' }))
    };
    const blob = new Blob([JSON.stringify(allData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SYNDICO_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const restoreDataFromJSON = (jsonStr: string): boolean => {
    try {
      const parsed = JSON.parse(jsonStr);
      const root = parsed.data || parsed.databaseTables || parsed;

      if (root.buildings && Array.isArray(root.buildings) && root.buildings.length > 0) {
        const normB = normalize20Buildings(root.buildings);
        setBuildings(normB);
        saveToStorage('buildings', normB);
      }
      if (root.apartments && Array.isArray(root.apartments)) {
        const normA = normalizeApartmentsWithOwnerNames(root.apartments);
        setApartments(normA);
        saveToStorage('apartments', normA);
      }
      if (root.residents && Array.isArray(root.residents)) {
        const normR = normalizeResidents(root.residents);
        setResidents(normR);
        saveToStorage('residents', normR);
      }
      if (root.employees && Array.isArray(root.employees)) {
        setEmployees(root.employees);
        saveToStorage('employees', root.employees);
      }
      if (root.maintenanceTickets && Array.isArray(root.maintenanceTickets)) {
        setMaintenanceTickets(root.maintenanceTickets);
        saveToStorage('maintenance', root.maintenanceTickets);
      }
      if (root.periodicMaintenances && Array.isArray(root.periodicMaintenances)) {
        setPeriodicMaintenances(root.periodicMaintenances);
        saveToStorage('periodic_maintenance', root.periodicMaintenances);
      }
      if (root.payments && Array.isArray(root.payments)) {
        setPayments(root.payments);
        saveToStorage('payments', root.payments);
      }
      if (root.expenses && Array.isArray(root.expenses)) {
        setExpenses(root.expenses);
        saveToStorage('expenses', root.expenses);
      }
      if (root.visitors && Array.isArray(root.visitors)) {
        setVisitors(root.visitors);
        saveToStorage('visitors', root.visitors);
      }
      if (root.notices && Array.isArray(root.notices)) {
        setNotices(root.notices);
        saveToStorage('notices', root.notices);
      }
      if (root.archivedPayments && Array.isArray(root.archivedPayments)) {
        setArchivedPayments(root.archivedPayments);
        saveToStorage('archived_payments', root.archivedPayments);
      }
      if (root.archivedExpenses && Array.isArray(root.archivedExpenses)) {
        setArchivedExpenses(root.archivedExpenses);
        saveToStorage('archived_expenses', root.archivedExpenses);
      }
      if (root.archiveBatches && Array.isArray(root.archiveBatches)) {
        setArchiveBatches(root.archiveBatches);
        saveToStorage('archive_batches', root.archiveBatches);
      }
      if (root.manualMonthlyRecords && Array.isArray(root.manualMonthlyRecords)) {
        setManualMonthlyRecords(root.manualMonthlyRecords);
        saveToStorage('manual_monthly_records', root.manualMonthlyRecords);
      }
      if (root.assemblyResolutions && Array.isArray(root.assemblyResolutions)) {
        setAssemblyResolutions(root.assemblyResolutions);
        saveToStorage('assembly_resolutions', root.assemblyResolutions);
      }
      return true;
    } catch (e) {
      console.error('Failed to parse backup JSON', e);
      return false;
    }
  };

  const purgeOldResidentData = () => {
    // 1. Initial clean residents list (only official designated units)
    const cleanResidentsList: Resident[] = [
      {
        id: 'res-gh-34-a-01',
        fullName: 'مكتب إدارة وسانديك الإقامة',
        type: 'owner',
        buildingCode: '',
        apartmentNumber: '01',
        phone: '',
        email: 'contact@example.com',
        cin: 'EE450123',
        familyMembersCount: 1,
        entryDate: '2026-01-01'
      },
      {
        id: 'res-gh-38-b-03',
        fullName: 'السيد محمد أيت بلعربي',
        type: 'owner',
        buildingCode: '',
        apartmentNumber: '03',
        phone: '',
        email: 'contact@example.com',
        cin: 'EE789303',
        familyMembersCount: 4,
        entryDate: '2026-01-01'
      }
    ];

    setResidents(cleanResidentsList);
    saveToStorage('residents', cleanResidentsList);

    // 2. Clean apartments: purge old mock names and leave them clean for new owners
    let purgedCount = 0;
    setApartments(prevApts => {
      const updated = prevApts.map(apt => {
        const cleanB = apt.buildingCode.replace(/\s+/g, ' ').trim().toUpperCase();
        const cleanA = String(apt.number).trim().padStart(2, '0');

        if (false) {
          return {
            ...apt,
            ownerName: 'مكتب إدارة وسانديك الإقامة',
            residentName: '',
            ownerPhone: '',
            residentPhone: '',
            ownerCin: 'EE450123',
            isSyndicOffice: true,
            monthlyFee: 0,
            notes: 'مكتب إدارة وسانديك الإقامة'
          };
        }

        if (false) {
          return {
            ...apt,
            ownerName: 'السيد محمد أيت بلعربي',
            residentName: 'السيد محمد أيت بلعربي',
            ownerPhone: '',
            residentPhone: '',
            ownerCin: 'EE789303',
            isSyndicOffice: false,
            monthlyFee: 150
          };
        }

        if (apt.ownerName || apt.residentName) {
          purgedCount++;
        }

        return {
          ...apt,
          ownerName: '',
          ownerPhone: '',
          ownerCin: '',
          ownerEmail: '',
          residentName: '',
          residentPhone: '',
          residentEmail: '',
          isRented: false,
          isSyndicOffice: false,
          monthlyFee: apt.monthlyFee === 0 ? 150 : (apt.monthlyFee || 150),
          notes: undefined
        };
      });
      saveToStorage('apartments', updated);
      return updated;
    });

    // 3. Clean payments: purge old mock resident names from payments history
    setPayments(prevPayments => {
      const updated = prevPayments.map(p => {
        const cleanB = (p.buildingCode || '').replace(/\s+/g, ' ').trim().toUpperCase();
        const cleanA = String(p.apartmentNumber || '01').trim().padStart(2, '0');
        if (false) {
          return { ...p, residentName: 'مكتب إدارة وسانديك الإقامة' };
        }
        if (false) {
          return { ...p, residentName: 'السيد محمد أيت بلعربي' };
        }
        if (isOldMockResidentName(p.residentName) || isGenericPlaceholderName(p.residentName)) {
          return { ...p, residentName: `شقة ${cleanA}` };
        }
        return p;
      });
      saveToStorage('payments', updated);
      return updated;
    });

    localStorage.setItem(STORAGE_PREFIX + 'old_residents_purged_v5', 'true');
    return { success: true, countPurged: purgedCount };
  };

  // One-time automatic purge of old mock data (Nabil Mansouri, Nadia Benhida/Ben Jida, etc.)
  useEffect(() => {
    const isPurged = localStorage.getItem(STORAGE_PREFIX + 'old_residents_purged_v5');
    const hasOldMockInResidents = residents.some(r => isOldMockResidentName(r.fullName));
    const hasOldMockInApartments = apartments.some(a => 
      (a.ownerName && isOldMockResidentName(a.ownerName)) ||
      (a.residentName && isOldMockResidentName(a.residentName))
    );

    if (!isPurged || hasOldMockInResidents || hasOldMockInApartments) {
      purgeOldResidentData();
    }
  }, []);

  // Automatic purge of any auto-generated / synthetic payments
  // Ensures July, August, September and all months strictly reflect manual entries only.
  useEffect(() => {
    const isCleaned = localStorage.getItem(STORAGE_PREFIX + 'synthetic_payments_purged_v3');
    const hasSynthetic = payments.some(p => p.id.startsWith('pay-'));
    if (!isCleaned || hasSynthetic) {
      setPayments(prevPayments => {
        const cleaned = prevPayments.filter(p => !p.id.startsWith('pay-'));
        saveToStorage('payments', cleaned);
        return cleaned;
      });
      localStorage.setItem(STORAGE_PREFIX + 'synthetic_payments_purged_v3', 'true');
    }
  }, [payments]);

  const resetToDefaults = () => {
    setBuildings(initialBuildings);
    setApartments(initialApartments);
    setResidents(initialResidents);
    setEmployees(initialEmployees);
    setMaintenanceTickets(initialMaintenanceTickets);
    setPeriodicMaintenances(initialPeriodicMaintenances);
    setDismissedAlertIds([]);
    // Do NOT generate synthetic payments for owners
    setPayments([]);
    saveToStorage('payments', []);
    const defaultExp = generateMonthlySurplusExpenses();
    setExpenses(defaultExp);
    saveToStorage('expenses', defaultExp);
    setVisitors(initialVisitors);
    setNotices(initialNotices);
    setUsers(initialUsers);
    setArchivedPayments([]);
    setArchivedExpenses([]);
    setArchiveBatches([]);
  };

  const ensurePositiveSurplusForAllPreviousMonths = () => {
    // Purge any synthetic payments so that the payments ledger strictly contains manual records
    setPayments(prev => {
      const cleaned = prev.filter(p => !p.id.startsWith('pay-'));
      saveToStorage('payments', cleaned);
      return cleaned;
    });
    showToast(
      lang === 'ar'
        ? 'تم تنظيف سجل الأداء والتأكد من اقتصاره فقط على الملاك المؤدين فعلياً والمسجلين يدوياً 🟢'
        : 'Registre des paiements nettoyé avec succès 🟢',
      { type: 'success' }
    );
    return {
      success: true,
      message: lang === 'ar' ? 'سجل الأداء مقتصر على العمليات اليدوية' : 'Succès'
    };
  };

  const t = translations[lang];

  return (
    <AppContext.Provider value={{
      lang,
      t,
      setLanguage: setLang,
      toggleLanguage,
      currentUser,
      login,
      loginResident,
      handleUserLogin,
      logout,
      activeSection,
      setActiveSection,
      showToast,
      buildings,
      apartments,
      residents,
      employees,
      maintenanceTickets,
      periodicMaintenances,
      payments,
      expenses,
      visitors,
      notices,
      users,
      archivedPayments,
      archivedExpenses,
      archiveBatches,
      activities,
      trash,
      isActivityDrawerOpen,
      setIsActivityDrawerOpen,
      openActivityLog,
      closeActivityLog,
      logActivity,
      moveToTrash,
      restoreFromTrash,
      addBuilding,
      updateBuilding,
      deleteBuilding,
      addApartment,
      updateApartment,
      deleteApartment,
      updateAllMonthlyFees,
      resetAllApartmentDebts,
      setApartmentDebt,
      importOwnersFromExcelData,
      importResidentsFromExcelData,
      addResident,
      updateResident,
      deleteResident,
      addEmployee,
      updateEmployee,
      deleteEmployee,
      pointageRecords,
      pointageAdvances,
      pointageBonuses,
      setPointageStatus,
      batchSetPointageStatus,
      applyMonthDefaultPointage,
      clearMonthPointage,
      setPointageAdvance,
      setPointageBonus,
      savePointageData,
      addMaintenanceTicket,
      updateMaintenanceTicket,
      deleteMaintenanceTicket,
      addPeriodicMaintenance,
      updatePeriodicMaintenance,
      deletePeriodicMaintenance,
      startPeriodicMaintenanceOperation,
      completePeriodicMaintenance,
      maintenanceAlerts,
      overdueAlertsCount,
      imminentAlertsCount,
      totalActiveAlertsCount,
      dismissedAlertIds,
      dismissAlert,
      resetDismissedAlerts,
      dailyChecklistItems,
      dailyMaintenanceLogs,
      toggleChecklistItem,
      updateChecklistItem,
      addChecklistItem,
      deleteChecklistItem,
      setAllChecklistStatus,
      saveDailyLog,
      resetTodayChecklist,
      addPayment,
      updatePayment,
      deletePayment,
      clearAllPayments,
      syncAllPaymentsWithResidents,
      addExpense,
      updateExpense,
      deleteExpense,
      addVisitor,
      markVisitorExit,
      deleteVisitor,
      addNotice,
      deleteNotice,
      addUser,
      updateUser,
      deleteUser,
      updateUserPassword,
      verifyUserCredentials,
      archiveOldRecords,
      restorePaymentFromArchive,
      restoreExpenseFromArchive,
      restoreBatchFromArchive,
      restoreAllArchivedRecords,
      deleteArchivedPayment,
      deleteArchivedExpense,
      clearAllArchive,
      exportArchiveJSON,
      importArchiveFromJSON,
      getEligibleArchiveCount,
      selectedReceipt,
      setSelectedReceipt,
      selectedNotice,
      setSelectedNotice,
      totalIncome,
      totalExpenses,
      totalBalance,
      totalBalanceDue,
      openTicketsCount,
      activeVisitorsCount,
      archivedPaymentsTotal,
      archivedExpensesTotal,
      totalArchivedCount,
      isCloudSyncing,
      isTableMissing,
      lastCloudSync,
      syncWithSupabase,
      pushToSupabaseNow,
      clearCloudAndLocalData,
      lastAutoSavedTime,
      isAutoSaving,
      autoSaveIntervalSeconds,
      autoSaveSecondsRemaining,
      isAutoSaveEnabled,
      setIsAutoSaveEnabled,
      setAutoSaveIntervalSeconds,
      triggerInstantAutoSave,
      checkOwnerDebtAccess,
      debtWarningAlert,
      setDebtWarningAlert,
      purgeOldResidentData,
      exportAllDataJSON,
      restoreDataFromJSON,
      resetToDefaults,
      exportDataAsJSON: exportAllDataJSON,
      importDataFromJSON: restoreDataFromJSON,
      resetToFactoryData: resetToDefaults,
      saveAllDataExplicitly,
      ensurePositiveSurplusForAllPreviousMonths,
      manualMonthlyRecords,
      upsertManualMonthlyRecord,
      deleteManualMonthlyRecord,
      closeManualMonth,
      reopenManualMonth,
      batchSaveManualMonthlyRecords,
      clearManualMonthlyRecords,
      assemblyResolutions,
      castResolutionVote,
      addAssemblyResolution,
      updateAssemblyResolution,
      deleteAssemblyResolution,
      setAssemblyResolutionStatus,
      resetAssemblyResolutionVotes,
    }}>
      {children}
      {/* Global Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[9999] animate-in fade-in slide-in-from-bottom-5">
          <div className={`px-4 py-2.5 rounded-xl shadow-xl border flex items-center gap-2 ${
            toastMessage.type === 'success' ? 'bg-emerald-900 border-emerald-700 text-emerald-100' :
            toastMessage.type === 'error' ? 'bg-rose-900 border-rose-700 text-rose-100' :
            toastMessage.type === 'warning' ? 'bg-amber-900 border-amber-700 text-amber-100' :
            'bg-slate-900 border-slate-700 text-slate-100'
          }`}>
            <span className="text-sm font-semibold">{toastMessage.message}</span>
          </div>
        </div>
      )}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
