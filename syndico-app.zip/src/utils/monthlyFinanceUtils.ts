import { Payment, Expense, Building, Apartment, ManualMonthlyRecord } from '../types';

export interface MonthOption {
  year: string;
  month: string; // '01', '02', ..., '12'
  key: string;   // '2026-08'
  labelAr: string;
  labelFr: string;
}

export const ARABIC_MONTH_NAMES: Record<string, string> = {
  '01': 'يناير',
  '02': 'فبراير',
  '03': 'مارس',
  '04': 'أبريل',
  '05': 'مايو',
  '06': 'يونيو',
  '07': 'يوليوز',
  '08': 'غشت (أغسطس)',
  '09': 'شتنبر (سبتمبر)',
  '10': 'أكتوبر',
  '11': 'نونبر (نوفمبر)',
  '12': 'دجنبر (ديسمبر)',
};

export const FRENCH_MONTH_NAMES: Record<string, string> = {
  '01': 'Janvier',
  '02': 'Février',
  '03': 'Mars',
  '04': 'Avril',
  '05': 'Mai',
  '06': 'Juin',
  '07': 'Juillet',
  '08': 'Août',
  '09': 'Septembre',
  '10': 'Octobre',
  '11': 'Novembre',
  '12': 'Décembre',
};

/**
 * Extract available month keys from payments, expenses, and manual records.
 */
export function getAvailableMonthsList(
  payments: Payment[], 
  expenses: Expense[], 
  manualRecords?: ManualMonthlyRecord[]
): MonthOption[] {
  const monthKeysSet = new Set<string>();

  // Add default reference months
  ['2025-01', '2025-02', '2025-03', '2025-04', '2025-05', '2025-06', '2025-07', '2025-08', '2025-09', '2025-10', '2025-11', '2025-12',
   '2026-01', '2026-02', '2026-03', '2026-04', '2026-05', '2026-06', '2026-07', '2026-08', '2026-09', '2026-10', '2026-11', '2026-12'
  ].forEach(m => monthKeysSet.add(m));

  // Collect from payments
  payments.forEach(p => {
    if (p.periodMonth && /^\d{4}-\d{2}$/.test(p.periodMonth)) {
      monthKeysSet.add(p.periodMonth);
    }
    if (p.paymentDate && p.paymentDate.length >= 7) {
      const ym = p.paymentDate.slice(0, 7);
      if (/^\d{4}-\d{2}$/.test(ym)) monthKeysSet.add(ym);
    }
  });

  // Collect from expenses
  expenses.forEach(e => {
    if (e.date && e.date.length >= 7) {
      const ym = e.date.slice(0, 7);
      if (/^\d{4}-\d{2}$/.test(ym)) monthKeysSet.add(ym);
    }
  });

  // Collect from manual records
  manualRecords?.forEach(r => {
    if (r.monthKey && /^\d{4}-\d{2}$/.test(r.monthKey)) {
      monthKeysSet.add(r.monthKey);
    }
  });

  const sortedKeys = Array.from(monthKeysSet).sort((a, b) => b.localeCompare(a));

  return sortedKeys.map(key => {
    const [year, month] = key.split('-');
    const labelAr = `${ARABIC_MONTH_NAMES[month] || month} ${year}`;
    const labelFr = `${FRENCH_MONTH_NAMES[month] || month} ${year}`;
    return {
      year,
      month,
      key,
      labelAr,
      labelFr
    };
  });
}

/**
 * Filter payments that belong to a specific month for income accounting.
 * In accordance with financial accounting rules, the income of a month is determined
 * strictly by the ACTUAL PAYMENT DATE (تاريخ الأداء الفعلي).
 * If a payment is made today for overdue months (e.g. late by multiple months),
 * the entire collected amount is accounted for in the month of the payment date.
 */
export function filterPaymentsByMonth(payments: Payment[], monthKey: string): Payment[] {
  if (!monthKey || monthKey === 'ALL') return payments;
  return payments.filter(p => {
    // 1. Payment date is the definitive date for cash income
    if (p.paymentDate && p.paymentDate.length >= 7) {
      return p.paymentDate.slice(0, 7) === monthKey;
    }
    // 2. Fallback only if paymentDate is not recorded
    const pPeriod = p.periodMonth || '';
    return pPeriod === monthKey || pPeriod.startsWith(monthKey);
  });
}

/**
 * Filter expenses that belong to a specific month (YYYY-MM).
 */
export function filterExpensesByMonth(expenses: Expense[], monthKey: string): Expense[] {
  if (!monthKey || monthKey === 'ALL') return expenses;
  return expenses.filter(e => {
    const eDate = e.date || '';
    return eDate.startsWith(monthKey);
  });
}

/**
 * Get preceding month in YYYY-MM format
 */
export function getPreviousMonthKey(monthKey: string): string {
  if (!monthKey || monthKey === 'ALL' || !/^\d{4}-\d{2}$/.test(monthKey)) return '';
  const [yStr, mStr] = monthKey.split('-');
  let y = parseInt(yStr, 10);
  let m = parseInt(mStr, 10);
  m -= 1;
  if (m < 1) {
    m = 12;
    y -= 1;
  }
  return `${y}-${String(m).padStart(2, '0')}`;
}

/**
 * Get next month in YYYY-MM format
 */
export function getNextMonthKey(monthKey: string): string {
  if (!monthKey || monthKey === 'ALL' || !/^\d{4}-\d{2}$/.test(monthKey)) return '';
  const [yStr, mStr] = monthKey.split('-');
  let y = parseInt(yStr, 10);
  let m = parseInt(mStr, 10);
  m += 1;
  if (m > 12) {
    m = 1;
    y += 1;
  }
  return `${y}-${String(m).padStart(2, '0')}`;
}

/**
 * Calculate the cumulative balance (surplus or deficit) carried forward
 * from all operations strictly prior to the specified month.
 */
export function getCarriedForwardBalance(
  payments: Payment[],
  expenses: Expense[],
  monthKey: string,
  buildingCode: string = 'ALL',
  manualRecords?: ManualMonthlyRecord[]
) {
  if (!monthKey || monthKey === 'ALL' || !/^\d{4}-\d{2}$/.test(monthKey)) {
    return {
      carriedIncome: 0,
      carriedExpenses: 0,
      carriedBalance: 0,
      prevMonthKey: '',
      prevMonthNameAr: '',
      prevMonthNameFr: '',
      isSurplus: true
    };
  }

  const prevMonthKey = getPreviousMonthKey(monthKey);
  const prevMonthNum = prevMonthKey ? prevMonthKey.split('-')[1] : '';
  const prevYearNum = prevMonthKey ? prevMonthKey.split('-')[0] : '';
  const prevMonthNameAr = prevMonthKey ? `${ARABIC_MONTH_NAMES[prevMonthNum] || prevMonthNum} ${prevYearNum}` : '';
  const prevMonthNameFr = prevMonthKey ? `${FRENCH_MONTH_NAMES[prevMonthNum] || prevMonthNum} ${prevYearNum}` : '';

  // 1. Check if the current month has an explicitly entered openingBalance
  const currentMonthManual = manualRecords?.find(r => r.monthKey === monthKey);
  if (currentMonthManual && typeof currentMonthManual.openingBalance === 'number') {
    const carriedBalance = currentMonthManual.openingBalance;
    return {
      carriedIncome: carriedBalance > 0 ? carriedBalance : 0,
      carriedExpenses: carriedBalance < 0 ? Math.abs(carriedBalance) : 0,
      carriedBalance,
      prevMonthKey,
      prevMonthNameAr,
      prevMonthNameFr,
      isSurplus: carriedBalance >= 0
    };
  }

  // 2. Check if the previous month has a recorded closing balance in manualRecords
  const prevMonthManual = manualRecords?.find(r => r.monthKey === prevMonthKey);
  if (prevMonthManual) {
    const prevClosing = prevMonthManual.closingBalance !== undefined
      ? prevMonthManual.closingBalance
      : ((prevMonthManual.openingBalance || 0) + prevMonthManual.totalIncome - prevMonthManual.totalExpenses);
    return {
      carriedIncome: prevClosing > 0 ? prevClosing : 0,
      carriedExpenses: prevClosing < 0 ? Math.abs(prevClosing) : 0,
      carriedBalance: prevClosing,
      prevMonthKey,
      prevMonthNameAr,
      prevMonthNameFr,
      isSurplus: prevClosing >= 0
    };
  }

  // 3. Fallback: calculate strictly prior payments and expenses
  const prevPayments = payments.filter(p => {
    if (buildingCode !== 'ALL') {
      const bClean = (p.buildingCode || '').replace(/\s+/g, '').toUpperCase();
      const targetB = buildingCode.replace(/\s+/g, '').toUpperCase();
      if (bClean !== targetB) return false;
    }
    const pMonth = (p.paymentDate && p.paymentDate.length >= 7)
      ? p.paymentDate.slice(0, 7)
      : (p.periodMonth && /^\d{4}-\d{2}/.test(p.periodMonth) ? p.periodMonth.slice(0, 7) : '');
    return pMonth && pMonth < monthKey;
  });

  const prevExpenses = expenses.filter(e => {
    if (buildingCode !== 'ALL') {
      const eClean = (e.buildingCode || 'ALL').replace(/\s+/g, '').toUpperCase();
      const targetB = buildingCode.replace(/\s+/g, '').toUpperCase();
      if (eClean !== 'ALL' && eClean !== targetB) return false;
    }
    const eMonth = (e.date && e.date.length >= 7) ? e.date.slice(0, 7) : '';
    return eMonth && eMonth < monthKey;
  });

  const carriedIncome = prevPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
  const carriedExpenses = prevExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  const carriedBalance = carriedIncome - carriedExpenses;

  return {
    carriedIncome,
    carriedExpenses,
    carriedBalance,
    prevMonthKey,
    prevMonthNameAr,
    prevMonthNameFr,
    isSurplus: carriedBalance >= 0
  };
}

export interface MonthlyCarryoverItem {
  monthKey: string;
  year: string;
  month: string;
  labelAr: string;
  labelFr: string;
  openingBalance: number; // الرصيد المنقول في بداية الشهر
  income: number;         // مقبوضات الشهر
  expenses: number;       // مصاريف الشهر
  monthNet: number;       // فائض أو عجز الشهر الخالص (مقبوضات - مصاريف)
  closingBalance: number; // الرصيد النهائي في نهاية الشهر المرحل للشهر الموالي
  isClosingSurplus: boolean;
  isMonthSurplus: boolean;
  paymentsCount: number;
  expensesCount: number;
}

/**
 * Generate a complete chronological chain of months with carryover:
 * At the end of each month, the surplus or deficit is added to the next month's opening balance.
 */
export function getMonthlyCarryoverChain(
  payments: Payment[],
  expenses: Expense[],
  buildingCode: string = 'ALL',
  filterYear?: string,
  manualRecords?: ManualMonthlyRecord[]
): MonthlyCarryoverItem[] {
  // Collect all months to consider
  const available = getAvailableMonthsList(payments, expenses, manualRecords);
  // Sort in ascending order (chronological from earliest to latest)
  let chronologicalKeys = available.map(m => m.key).sort();

  if (filterYear) {
    // Ensure all 12 months of the year are present
    const fullYearKeys = Array.from({ length: 12 }, (_, i) => `${filterYear}-${String(i + 1).padStart(2, '0')}`);
    const set = new Set([...chronologicalKeys, ...fullYearKeys]);
    chronologicalKeys = Array.from(set).filter(k => k.startsWith(filterYear)).sort();
  }

  if (chronologicalKeys.length === 0) return [];

  // Determine opening balance before the first month in the chain
  const firstMonthKey = chronologicalKeys[0];
  const initialCarry = getCarriedForwardBalance(payments, expenses, firstMonthKey, buildingCode, manualRecords);
  let currentRunningBalance = initialCarry.carriedBalance;

  const result: MonthlyCarryoverItem[] = [];

  for (const mKey of chronologicalKeys) {
    const [year, month] = mKey.split('-');
    
    // Check manual override for this month
    const manual = manualRecords?.find(r => r.monthKey === mKey);

    let openingBalance = manual && typeof manual.openingBalance === 'number'
      ? manual.openingBalance
      : currentRunningBalance;

    const mPayments = filterPaymentsByMonth(payments, mKey).filter(p => {
      if (buildingCode === 'ALL') return true;
      return (p.buildingCode || '').replace(/\s+/g, '').toUpperCase() === buildingCode.replace(/\s+/g, '').toUpperCase();
    });

    const mExpenses = filterExpensesByMonth(expenses, mKey).filter(e => {
      if (buildingCode === 'ALL') return true;
      const eClean = (e.buildingCode || 'ALL').replace(/\s+/g, '').toUpperCase();
      return eClean === 'ALL' || eClean === buildingCode.replace(/\s+/g, '').toUpperCase();
    });

    const income = manual && typeof manual.totalIncome === 'number'
      ? manual.totalIncome
      : mPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);

    const mExpense = manual && typeof manual.totalExpenses === 'number'
      ? manual.totalExpenses
      : mExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);

    const monthNet = income - mExpense;
    const closingBalance = manual && typeof manual.closingBalance === 'number'
      ? manual.closingBalance
      : (openingBalance + monthNet);

    // Next month starts with this month's closing balance (فائض أو ناقص)
    currentRunningBalance = closingBalance;

    result.push({
      monthKey: mKey,
      year,
      month,
      labelAr: `${ARABIC_MONTH_NAMES[month] || month} ${year}`,
      labelFr: `${FRENCH_MONTH_NAMES[month] || month} ${year}`,
      openingBalance,
      income,
      expenses: mExpense,
      monthNet,
      closingBalance,
      isClosingSurplus: closingBalance >= 0,
      isMonthSurplus: monthNet >= 0,
      paymentsCount: mPayments.length,
      expensesCount: mExpenses.length
    });
  }

  return result;
}

/**
 * Harmonizes the manual monthly records chain so that:
 * 1. For every month, closingBalance = openingBalance + totalIncome - totalExpenses.
 * 2. Consecutive months carry over previous month's closingBalance into the next month's openingBalance.
 * 3. User entered data (income, expenses, breakdowns) is ALWAYS strictly preserved and NEVER overwritten.
 */
export function harmonizeManualMonthlyRecordsChain(records: ManualMonthlyRecord[]): ManualMonthlyRecord[] {
  if (!Array.isArray(records) || records.length === 0) return [];
  const sorted = [...records].sort((a, b) => a.monthKey.localeCompare(b.monthKey));
  
  let previousClosing: number | null = null;
  let previousMonthKey: string | null = null;
  let previousClosed = false;

  return sorted.map((rec) => {
    let opening: number;
    const hasExplicitOpening = typeof rec.openingBalance === 'number' && !isNaN(rec.openingBalance);
    const isConsecutive = previousClosing !== null && previousMonthKey !== null && getPreviousMonthKey(rec.monthKey) === previousMonthKey;

    if (isConsecutive && previousClosed) {
      // الشهر السابق مغلق => رصيده الختامي هو الرصيد المرحل تلقائياً
      opening = previousClosing!;
    } else if (rec.isUserModified && hasExplicitOpening) {
      opening = rec.openingBalance!;
    } else if (isConsecutive) {
      opening = previousClosing!;
    } else if (hasExplicitOpening) {
      opening = rec.openingBalance!;
    } else {
      opening = previousClosing !== null ? previousClosing : 0;
    }

    const income = Number(rec.totalIncome) || 0;
    const expenses = Number(rec.totalExpenses) || 0;
    const closing = opening + income - expenses;

    previousClosing = closing;
    previousMonthKey = rec.monthKey;
    previousClosed = !!rec.isClosed;

    return {
      ...rec,
      openingBalance: opening,
      totalIncome: income,
      totalExpenses: expenses,
      closingBalance: closing
    };
  });
}

/**
 * Compute detailed monthly financial breakdown including carryover surplus/deficit
 */
export function computeMonthlyFinanceSummary(
  payments: Payment[],
  expenses: Expense[],
  apartments: Apartment[],
  monthKey: string,
  buildingCode: string = 'ALL',
  manualRecords?: ManualMonthlyRecord[]
) {
  const isAll = monthKey === 'ALL';
  const filteredPayments = isAll ? payments : filterPaymentsByMonth(payments, monthKey);
  const filteredExpenses = isAll ? expenses : filterExpensesByMonth(expenses, monthKey);

  const rawIncome = filteredPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
  const rawExpenses = filteredExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);

  // Check if manual monthly record exists for this specific month
  const manual = !isAll ? manualRecords?.find(r => r.monthKey === monthKey) : null;
  const isFromManualRegistry = Boolean(manual);

  let totalIncome = rawIncome;
  let totalExpenses = rawExpenses;

  if (isAll) {
    if (manualRecords && manualRecords.length > 0) {
      const recordedMonths = new Set(manualRecords.map(r => r.monthKey));
      const manualIncome = manualRecords.reduce((sum, r) => sum + (Number(r.totalIncome) || 0), 0);
      const manualExp = manualRecords.reduce((sum, r) => sum + (Number(r.totalExpenses) || 0), 0);

      const extraPayments = payments.filter(p => {
        const m = (p.paymentDate && p.paymentDate.length >= 7) ? p.paymentDate.slice(0, 7) : (p.periodMonth || '').slice(0, 7);
        return m && !recordedMonths.has(m);
      });
      const extraExpenses = expenses.filter(e => {
        const m = (e.date && e.date.length >= 7) ? e.date.slice(0, 7) : '';
        return m && !recordedMonths.has(m);
      });

      const extraIncome = extraPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
      const extraExpVal = extraExpenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);

      totalIncome = manualIncome + extraIncome;
      totalExpenses = manualExp + extraExpVal;
    }
  } else if (manual) {
    if (typeof manual.totalIncome === 'number') {
      totalIncome = manual.totalIncome;
    }
    if (typeof manual.totalExpenses === 'number') {
      totalExpenses = manual.totalExpenses;
    }
  }

  const netBalance = totalIncome - totalExpenses;

  // Expected monthly revenue from apartments (excluding Syndic office)
  const expectedMonthlyRevenue = apartments
    .filter(a => !a.isSyndicOffice && !(false))
    .reduce((sum, a) => sum + (Number(a.monthlyFee) || 150), 0);

  const collectionRate = expectedMonthlyRevenue > 0
    ? Math.min(100, Math.round((totalIncome / expectedMonthlyRevenue) * 100))
    : (totalIncome > 0 ? 100 : 0);

  // Carried forward balance from preceding months
  const carryover = isAll
    ? { carriedIncome: 0, carriedExpenses: 0, carriedBalance: 0, prevMonthKey: '', prevMonthNameAr: '', prevMonthNameFr: '', isSurplus: true }
    : getCarriedForwardBalance(payments, expenses, monthKey, buildingCode, manualRecords);

  const previousCarriedBalance = (manual && typeof manual.openingBalance === 'number')
    ? manual.openingBalance
    : carryover.carriedBalance;

  // Fundamental Accounting Law:
  // الرصيد النهائي المرحل (التحفة) = الرصيد المنقول السابق (الخانة 1) + مقبوضات الشهر (الخانة 2) - مصاريف الشهر (الخانة 3)
  const finalCumulativeBalance = previousCarriedBalance + netBalance;

  const nextMonthKey = isAll ? '' : getNextMonthKey(monthKey);
  const nextMonthNum = nextMonthKey ? nextMonthKey.split('-')[1] : '';
  const nextYearNum = nextMonthKey ? nextMonthKey.split('-')[0] : '';
  const nextMonthNameAr = nextMonthKey ? `${ARABIC_MONTH_NAMES[nextMonthNum] || nextMonthNum} ${nextYearNum}` : '';
  const nextMonthNameFr = nextMonthKey ? `${FRENCH_MONTH_NAMES[nextMonthNum] || nextMonthNum} ${nextYearNum}` : '';

  return {
    monthKey,
    filteredPayments,
    filteredExpenses,
    totalIncome,
    totalExpenses,
    netBalance, // صافي الشهر الحالي فقط
    monthNetBalance: netBalance,
    previousCarriedBalance, // الفائض أو الناقص المنقول من الأشهر السابقة (الخانة 1)
    finalCumulativeBalance, // الرصيد النهائي في نهاية الشهر المرحّل للشهر الموالي (التحفة)
    previousMonthKey: carryover.prevMonthKey,
    previousMonthNameAr: carryover.prevMonthNameAr,
    previousMonthNameFr: carryover.prevMonthNameFr,
    nextMonthKey,
    nextMonthNameAr,
    nextMonthNameFr,
    isSurplus: finalCumulativeBalance >= 0,
    isMonthSurplus: netBalance >= 0,
    isPreviousSurplus: previousCarriedBalance >= 0,
    expectedMonthlyRevenue,
    collectionRate,
    paymentsCount: filteredPayments.length > 0 ? filteredPayments.length : (manual ? 0 : 0),
    expensesCount: filteredExpenses.length > 0 ? filteredExpenses.length : (manual?.breakdownExpenses ? Object.keys(manual.breakdownExpenses).length : 0),
    isFromManualRegistry,
    manualRecord: manual || null
  };
}

// ============================================================
// تصحيح تكرار البنود في السجل المالي
// بعض الشاشات القديمة كانت تحفظ نفس المبلغ مرتين:
//   salaries = workerSalaries ، supplies = hardwareDroguerie ، utilities = otherExpenses
// وكان ذلك يضاعف المصاريف في التقارير. هذه الدالة تُسقط النسخ المكررة.
// ============================================================
export function getUniqueExpenseBreakdown(b?: Record<string, number | undefined> | null): Record<string, number> {
  const out: Record<string, number> = {};
  if (!b) return out;
  Object.keys(b).forEach(k => {
    const v = Number((b as any)[k]);
    if (isFinite(v) && v > 0) out[k] = v;
  });
  const same = (a?: number, c?: number) => !!a && !!c && Math.abs(a - c) < 0.01;
  if (same(out.salaries, out.workerSalaries)) delete out.salaries;
  if (same(out.supplies, out.hardwareDroguerie)) delete out.supplies;
  if (same(out.utilities, out.otherExpenses)) delete out.utilities;
  return out;
}

// توزيع مصاريف شهر على الأعمدة الخمسة للتقرير، مع ضمان أن المجموع = مصاريف الشهر المسجّلة (دون أي مبالغ افتراضية)
export function splitExpensePillars(rec: { totalExpenses?: number; breakdownExpenses?: any }) {
  const u = getUniqueExpenseBreakdown(rec.breakdownExpenses);
  const total = Number(rec.totalExpenses) || 0;
  let workers = (u.workerSalaries || 0) + (u.salaries || 0);
  let syndic = u.syndicAndDeputyFees || 0;
  let lawyer = u.lawyerFees || 0;
  let bailiff = u.bailiffFees || 0;
  const specific = workers + syndic + lawyer + bailiff;
  if (total > 0 && specific > total + 0.009) {
    const f = total / specific;
    workers *= f; syndic *= f; lawyer *= f; bailiff *= f;
  }
  const diverse = Math.max(0, total - (workers + syndic + lawyer + bailiff));
  return { workers, syndic, lawyer, bailiff, diverse };
}
