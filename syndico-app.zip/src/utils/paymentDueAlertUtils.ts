import { RES } from '../config/residence';
import { Apartment, Payment, Resident } from '../types';
import { getApartmentDebtStatus, CURRENT_REFERENCE_YEAR, CURRENT_REFERENCE_MONTH, MONTH_NAMES_AR, MONTH_NAMES_FR } from './debtUtils';
import { PaymentDueAlertConfig, UpcomingDueResidentItem } from '../types/paymentDueAlertTypes';

export const STORAGE_KEY_DUE_ALERT_CONFIG = 'ma_residence_payment_due_alert_config_v1';

// Default Templates - Arabic
export const DEFAULT_DUE_WHATSAPP_TEMPLATE_AR = 
`*تذكير ودي بحلول موعد أداء واجبات السانديك الشهري - ${RES.nameAr}* 🏢✨

السلام عليكم ورحمة الله،
السيد(ة) المحترم(ة): *{RESIDENT_NAME}*
📍 الشقة: *{BUILDING_CODE} - شقة رقم {APARTMENT_NUM}*

نحيطكم علماً بأن موعد استحقاق واجبات الاشتراك الشهري للسانديك عن *شهر {PERIOD_LABEL}* يحل بتاريخ:
📅 *الأجل المحدد:* {DUE_DATE} ({DAYS_LEFT_LABEL})
💰 *المبلغ المستحق:* {AMOUNT_MAD} درهم مغربي

📌 *طرق الأداء المعتمدة:*
• نقداً أو بشيك لدى مكتب السانديك ( شقة 01).
• أو عبر تحويل بنكي إلى الحساب الرسمي لاتحاد الملاك:
  - البنك: *{BANK_NAME}*
  - الحساب: *{ACCOUNT_NAME}*
  - رقم الحساب (RIB): *{BANK_RIB}*

مساهمتكم في الوقت المحدد هي الضامن لاستمرار خدمات النظافة، الحراسة، صيانة المرافق، والإنارة المشتركة لإقامتنا.
في حال قمتم بالسداد مؤخراً، نرجو تجاهل هذه الرسالة أو موافاتنا بوصل التحويل لتسجيله.

مع خالص التحية والتقدير،
✍️ *إدارة اتحاد الملاك - ${RES.nameAr}*
📞 للتواصل: {CONTACT_PHONE}`;

export const DEFAULT_DUE_EMAIL_SUBJECT_TEMPLATE_AR = 
`تذكير بحلول موعد سداد واجبات السانديك ({PERIOD_LABEL}) - {BUILDING_CODE} شقة {APARTMENT_NUM}`;

export const DEFAULT_DUE_EMAIL_BODY_TEMPLATE_AR = 
`إلى السيد(ة) الفاضل(ة): {RESIDENT_NAME}
مالك / ساكن الشقة رقم {APARTMENT_NUM} ({BUILDING_CODE})
${RES.nameAr} - 

الموضوع: تذكير بموعد سداد واجبات الملكية المشتركة (السانديك) عن شهر {PERIOD_LABEL}

تحية طيبة وبعد،

يسر مكتب اتحاد الملاك (السانديك) ل${RES.nameAr} تذكيركم بحلول الأجل الشهري المعتاد لسداد واجبات الاشتراك المتعلقة بصيانة وتسيير مرافق الإقامة:

• الفترة المستحقة: شهر {PERIOD_LABEL}
• أجل السداد المحدد: {DUE_DATE} ({DAYS_LEFT_LABEL})
• المبلغ المطلوب أداؤه: {AMOUNT_MAD} درهم مغربي

بيانات الحساب البنكي الرسمي لاتحاد الملاك:
- اسم الحساب: {ACCOUNT_NAME}
- البنك: {BANK_NAME}
- رقم الحساب البنكي (RIB): {BANK_RIB}

إن التزامكم بالسداد في الآجال المحددة يمكن مكتب السانديك من الوفاء بالتزاماته المالية تجاه شركات الحراسة، النظافة، وصيانة المرافق المشتركة والكهرباء.

إذا كنتم قد أديتم واجباتكم مؤخراً، يرجى الرد على هذا البريد بنسخة من وصل التحويل البنكي لتحيين سجلكم المحاسبي وتسليمكم وصل الأداء الرسمي.

شاكرين لكم حسن تعاونكم الدائم،
وتقبلوا فائق التقدير والاحترام.

إدارة اتحاد الملاك - ${RES.nameAr}
الهاتف: {CONTACT_PHONE} | البريد: {CONTACT_EMAIL}`;

export const DEFAULT_DUE_SMS_TEMPLATE_AR = 
`سانديك ${RES.nameAr}: تذكير بموعد سداد واجب السانديك لشهر {PERIOD_LABEL} بمبلغ {AMOUNT_MAD} درهم قبل تاريخ {DUE_DATE}. شكراً لتعاونكم. RIB: {BANK_RIB}`;

// Default Templates - French
export const DEFAULT_DUE_WHATSAPP_TEMPLATE_FR = 
`*Rappel amical - Échéance de cotisation Syndic (${RES.nameFr})* 🏢✨

Bonjour M/Mme *{RESIDENT_NAME}*,
Appartement: *{BUILDING_CODE} - Appt {APARTMENT_NUM}*

Nous vous informons que la cotisation mensuelle de syndic pour le mois de *{PERIOD_LABEL}* arrive à échéance le :
📅 *Date limite :* {DUE_DATE} ({DAYS_LEFT_LABEL})
💰 *Montant à régler :* {AMOUNT_MAD} DH

📌 *Coordonnées bancaires pour virement :*
• Banque : *{BANK_NAME}*
• Compte : *{ACCOUNT_NAME}*
• RIB : *{BANK_RIB}*

Votre contribution ponctuelle garantit la continuité des services de nettoyage, gardiennage et maintenance des parties communes.

Cordialement,
✍️ *Le Syndic de Copropriété - ${RES.nameFr}*
📞 Contact : {CONTACT_PHONE}`;

export const DEFAULT_DUE_EMAIL_SUBJECT_TEMPLATE_FR = 
`Échéance de cotisation Syndic ({PERIOD_LABEL}) - {BUILDING_CODE} Appt {APARTMENT_NUM}`;

export const DEFAULT_DUE_EMAIL_BODY_TEMPLATE_FR = 
`À l'attention de M/Mme : {RESIDENT_NAME}
Copropriétaire / Résident de l'appartement {APARTMENT_NUM} ({BUILDING_CODE})
${RES.nameFr}

Objet : Échéance de la cotisation mensuelle de syndic - {PERIOD_LABEL}

Madame, Monsieur,

Le bureau du Syndic de la ${RES.nameFr} vous rappelle l'échéance de la cotisation pour les charges de copropriété :

• Période : {PERIOD_LABEL}
• Date limite de paiement : {DUE_DATE} ({DAYS_LEFT_LABEL})
• Montant dû : {AMOUNT_MAD} DH

Coordonnées bancaires pour règlement par virement :
- Titulaire : {ACCOUNT_NAME}
- Banque : {BANK_NAME}
- RIB : {BANK_RIB}

Votre ponctualité assure le bon fonctionnement de notre résidence (sécurité, propreté, entretien).

Si votre règlement a déjà été effectué, merci de nous envoyer le justificatif pour mise à jour de votre compte.

Bien cordialement,
Le Syndic - ${RES.nameFr}
Tél : {CONTACT_PHONE} | Email : {CONTACT_EMAIL}`;

export const DEFAULT_DUE_SMS_TEMPLATE_FR = 
`Syndic : Rappel cotisation {PERIOD_LABEL} d'un montant de {AMOUNT_MAD} DH avant le {DUE_DATE}. Merci. RIB: {BANK_RIB}`;

export const INITIAL_DUE_ALERT_CONFIG: PaymentDueAlertConfig = {
  isEnabled: true,
  dueDayOfMonth: 10, // Default: 10th of every month
  remindDaysBefore: [7, 3, 0],
  preferredChannel: 'both',
  bankName: RES.bankName,
  bankAccountName: 'اتحاد ملاك ' + RES.nameAr,
  bankRib: RES.bankRib,
  contactPhone: RES.phone,
  contactEmail: RES.email,
  whatsappTemplateAr: DEFAULT_DUE_WHATSAPP_TEMPLATE_AR,
  emailSubjectTemplateAr: DEFAULT_DUE_EMAIL_SUBJECT_TEMPLATE_AR,
  emailBodyTemplateAr: DEFAULT_DUE_EMAIL_BODY_TEMPLATE_AR,
  smsTemplateAr: DEFAULT_DUE_SMS_TEMPLATE_AR,
  whatsappTemplateFr: DEFAULT_DUE_WHATSAPP_TEMPLATE_FR,
  emailSubjectTemplateFr: DEFAULT_DUE_EMAIL_SUBJECT_TEMPLATE_FR,
  emailBodyTemplateFr: DEFAULT_DUE_EMAIL_BODY_TEMPLATE_FR,
  smsTemplateFr: DEFAULT_DUE_SMS_TEMPLATE_FR,
  logs: []
};

/**
 * Calculates current active due cycle based on configuration.
 * For August 2026, due date is 2026-08-10.
 */
export function getActiveDueCycleInfo(config: PaymentDueAlertConfig) {
  const year = CURRENT_REFERENCE_YEAR;
  const month = CURRENT_REFERENCE_MONTH;
  const dueDay = Math.min(28, Math.max(1, config.dueDayOfMonth || 10));

  // Current cycle due date
  const dueDateStr = `${year}-${String(month).padStart(2, '0')}-${String(dueDay).padStart(2, '0')}`;
  const periodKey = `${year}-${String(month).padStart(2, '0')}`;
  const monthIndex = month - 1;
  const periodLabelAr = `${MONTH_NAMES_AR[monthIndex]} ${year}`;
  const periodLabelFr = `${MONTH_NAMES_FR[monthIndex]} ${year}`;

  // Let's assume current reference date is end of month or target day
  // For interactive calculations, we can compute days difference with reference or current day
  // Let's format date nicely
  const dueDateFormattedAr = `${dueDay} ${MONTH_NAMES_AR[monthIndex]} ${year}`;
  const dueDateFormattedFr = `${dueDay} ${MONTH_NAMES_FR[monthIndex]} ${year}`;

  return {
    year,
    month,
    dueDay,
    dueDateStr,
    periodKey,
    periodLabelAr,
    periodLabelFr,
    dueDateFormattedAr,
    dueDateFormattedFr
  };
}

/**
 * Computes the list of residents who have not yet paid for the current due cycle.
 */
export function getUpcomingDueResidents(
  apartments: Apartment[],
  payments: Payment[],
  residents: Resident[],
  config: PaymentDueAlertConfig,
  lang: string = 'ar'
): UpcomingDueResidentItem[] {
  const cycle = getActiveDueCycleInfo(config);
  const items: UpcomingDueResidentItem[] = [];

  apartments.forEach(apt => {
    // Skip Syndic Office
    if (apt.isSyndicOffice || (false)) return;

    const debt = getApartmentDebtStatus(apt, payments);
    
    // Check if paid for current cycle
    const isPaidCurrent = debt.isPaid;

    if (!isPaidCurrent) {
      const res = residents.find(
        r => r.buildingCode.trim().toLowerCase() === apt.buildingCode.trim().toLowerCase() &&
             r.apartmentNumber.trim() === apt.number.trim()
      );

      const residentName = apt.ownerName || res?.fullName || (lang === 'ar' ? `مالك شقة ${apt.number} (${apt.buildingCode})` : `Propriétaire Appt ${apt.number}`);
      const phone = apt.ownerPhone || apt.residentPhone || res?.phone || '';
      const email = apt.ownerEmail || apt.residentEmail || res?.email || '';

      // Compute simulated days remaining (e.g. 3 days remaining if due on 10th and simulated today is 7th, or customized)
      // For reference year 2026, let's provide clear countdown metrics
      const monthlyFee = Number(apt.monthlyFee) || 150;
      const totalDue = debt.totalBalanceDue > 0 ? debt.totalBalanceDue : monthlyFee;
      
      // Calculate days remaining relative to due date:
      // If today is within the month:
      const simulatedTodayDay = 7; // E.g. 3 days before 10th
      const daysRemaining = cycle.dueDay - simulatedTodayDay;

      let urgency: UpcomingDueResidentItem['urgency'] = 'upcoming';
      if (daysRemaining < 0) urgency = 'passed';
      else if (daysRemaining === 0) urgency = 'today';
      else if (daysRemaining <= 3) urgency = 'imminent';
      else urgency = 'upcoming';

      items.push({
        apartment: apt,
        residentName,
        phone,
        email,
        periodKey: cycle.periodKey,
        periodLabelAr: cycle.periodLabelAr,
        periodLabelFr: cycle.periodLabelFr,
        monthlyFee,
        totalDue,
        dueDate: cycle.dueDateStr,
        dueDateFormatted: lang === 'ar' ? cycle.dueDateFormattedAr : cycle.dueDateFormattedFr,
        daysRemaining,
        urgency,
        isPaid: false
      });
    }
  });

  // Sort by building and apartment
  return items.sort((a, b) => {
    if (a.apartment.buildingCode !== b.apartment.buildingCode) {
      return a.apartment.buildingCode.localeCompare(b.apartment.buildingCode, undefined, { numeric: true });
    }
    return Number(a.apartment.number) - Number(b.apartment.number);
  });
}

/**
 * Replaces all placeholders in templates.
 */
export function populateDueTemplate(
  template: string,
  item: UpcomingDueResidentItem,
  config: PaymentDueAlertConfig,
  lang: string = 'ar'
): string {
  if (!template) return '';

  let daysLeftLabel = '';
  if (lang === 'ar') {
    if (item.daysRemaining < 0) daysLeftLabel = 'تجاوز الأجل المحدد';
    else if (item.daysRemaining === 0) daysLeftLabel = 'الأجل يحل اليوم!';
    else if (item.daysRemaining === 1) daysLeftLabel = 'متبقي يوم واحد فقط';
    else if (item.daysRemaining === 2) daysLeftLabel = 'متبقي يومان';
    else daysLeftLabel = `متبقي ${item.daysRemaining} أيام`;
  } else {
    if (item.daysRemaining < 0) daysLeftLabel = 'Échéance dépassée';
    else if (item.daysRemaining === 0) daysLeftLabel = "Aujourd'hui !";
    else if (item.daysRemaining === 1) daysLeftLabel = 'Reste 1 jour';
    else daysLeftLabel = `Reste ${item.daysRemaining} jours`;
  }

  const periodLabel = lang === 'ar' ? item.periodLabelAr : item.periodLabelFr;

  return template
    .replace(/{RESIDENT_NAME}/g, item.residentName)
    .replace(/{BUILDING_CODE}/g, item.apartment.buildingCode)
    .replace(/{APARTMENT_NUM}/g, item.apartment.number)
    .replace(/{PERIOD_LABEL}/g, periodLabel)
    .replace(/{DUE_DATE}/g, item.dueDateFormatted)
    .replace(/{AMOUNT_MAD}/g, item.totalDue.toLocaleString())
    .replace(/{DAYS_LEFT_LABEL}/g, daysLeftLabel)
    .replace(/{BANK_NAME}/g, config.bankName)
    .replace(/{ACCOUNT_NAME}/g, config.bankAccountName)
    .replace(/{BANK_RIB}/g, config.bankRib)
    .replace(/{CONTACT_PHONE}/g, config.contactPhone)
    .replace(/{CONTACT_EMAIL}/g, config.contactEmail);
}

/**
 * Generates WhatsApp click-to-chat URL
 */
export function buildDueWhatsAppUrl(
  item: UpcomingDueResidentItem,
  config: PaymentDueAlertConfig,
  lang: string = 'ar'
): string {
  const rawPhone = item.phone.replace(/\D/g, '');
  const cleanPhone = rawPhone 
    ? (rawPhone.startsWith('0') ? '212' + rawPhone.slice(1) : rawPhone.startsWith('212') ? rawPhone : '212' + rawPhone) 
    : '';

  const template = lang === 'ar' ? (config.whatsappTemplateAr || DEFAULT_DUE_WHATSAPP_TEMPLATE_AR) : (config.whatsappTemplateFr || DEFAULT_DUE_WHATSAPP_TEMPLATE_FR);
  const message = populateDueTemplate(template, item, config, lang);

  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
}

/**
 * Generates Email mailto URL with subject and body
 */
export function buildDueEmailUrl(
  item: UpcomingDueResidentItem,
  config: PaymentDueAlertConfig,
  lang: string = 'ar'
): string {
  const subjectTemplate = lang === 'ar' ? (config.emailSubjectTemplateAr || DEFAULT_DUE_EMAIL_SUBJECT_TEMPLATE_AR) : (config.emailSubjectTemplateFr || DEFAULT_DUE_EMAIL_SUBJECT_TEMPLATE_FR);
  const bodyTemplate = lang === 'ar' ? (config.emailBodyTemplateAr || DEFAULT_DUE_EMAIL_BODY_TEMPLATE_AR) : (config.emailBodyTemplateFr || DEFAULT_DUE_EMAIL_BODY_TEMPLATE_FR);

  const subject = populateDueTemplate(subjectTemplate, item, config, lang);
  const body = populateDueTemplate(bodyTemplate, item, config, lang);

  return `mailto:${item.email || ''}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

/**
 * Generates SMS link
 */
export function buildDueSmsUrl(
  item: UpcomingDueResidentItem,
  config: PaymentDueAlertConfig,
  lang: string = 'ar'
): string {
  const rawPhone = item.phone.replace(/\D/g, '');
  const template = lang === 'ar' ? (config.smsTemplateAr || DEFAULT_DUE_SMS_TEMPLATE_AR) : (config.smsTemplateFr || DEFAULT_DUE_SMS_TEMPLATE_FR);
  const message = populateDueTemplate(template, item, config, lang);

  return `sms:${rawPhone}?body=${encodeURIComponent(message)}`;
}
