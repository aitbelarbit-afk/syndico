import * as XLSX from 'xlsx';
import { Apartment, Building, Resident, ApartmentStatus } from '../types';

export interface ExcelImportFieldMapping {
  buildingCode: string;
  apartmentNumber: string;
  ownerName: string;
  ownerPhone: string;
  ownerCin: string;
  ownerEmail: string;
  addressOrNotes: string;
  floor: string;
  monthlyFee: string;
  status: string;
  residentName: string;
  residentPhone: string;
  unpaidMonthsCount: string;
  balanceDue: string;
}

export interface ParsedOwnerRow {
  rowNumber: number;
  buildingCode: string;
  apartmentNumber: string;
  ownerName: string;
  ownerPhone: string;
  ownerCin: string;
  ownerEmail: string;
  addressOrNotes: string;
  floor?: number;
  monthlyFee?: number;
  status?: ApartmentStatus;
  residentName?: string;
  residentPhone?: string;
  unpaidMonthsCount?: number;
  balanceDue?: number;
  matchType: 'existing' | 'new' | 'invalid';
  matchedApartmentId?: string;
  validationErrors: string[];
}

export interface ImportSummary {
  totalRows: number;
  validRows: number;
  matchingApartments: number;
  newApartments: number;
  invalidRows: number;
  parsedData: ParsedOwnerRow[];
}

/**
 * Standardize building code to match app formats (e.g., "", "" -> matching building code)
 */
export function normalizeBuildingCode(input: string, buildings: Building[]): string {
  if (!input) return '';
  const cleanInput = input.toString().replace(/[\s\-_]/g, '').toUpperCase();
  
  // Find exact or normalized match among known buildings
  const matched = buildings.find(b => b.code.replace(/[\s\-_]/g, '').toUpperCase() === cleanInput);
  if (matched) return matched.code;

  // Pattern fallback e.g.,  -> 
  const matchPattern = cleanInput.match(/^GH(\d{2})([A-Z])$/i);
  if (matchPattern) {
    const formatted = `GH ${matchPattern[1]} ${matchPattern[2].toUpperCase()}`;
    const found = buildings.find(b => b.code === formatted);
    if (found) return found.code;
    return formatted;
  }

  return input.toString().trim();
}

/**
 * Standardize apartment number (e.g., "1" -> "01", " 02 " -> "02")
 */
export function normalizeApartmentNumber(input: string | number): string {
  if (input === null || input === undefined) return '';
  const numStr = input.toString().replace(/[^\d]/g, '');
  if (numStr) {
    const intVal = parseInt(numStr, 10);
    return intVal < 10 ? String(intVal).padStart(2, '0') : String(intVal);
  }
  return input.toString().trim();
}

/**
 * Clean and format Moroccan phone number
 */
export function normalizePhoneNumber(phone: string | number | undefined): string {
  if (!phone) return '';
  const str = phone.toString().trim();
  // Remove non-numeric except +
  const cleaned = str.replace(/[^\d+]/g, '');
  
  // Format standard Moroccan local 06... / 07... to international or formatted
  if (cleaned.startsWith('06') || cleaned.startsWith('07') || cleaned.startsWith('05')) {
    return `+212 ${cleaned.substring(1, 2)} ${cleaned.substring(2, 4)} ${cleaned.substring(4, 6)} ${cleaned.substring(6, 8)} ${cleaned.substring(8, 10)}`.trim();
  }
  if (cleaned.startsWith('212')) {
    return `+${cleaned.substring(0, 3)} ${cleaned.substring(3, 4)} ${cleaned.substring(4, 6)} ${cleaned.substring(6, 8)} ${cleaned.substring(8, 10)}`.trim();
  }
  if (cleaned.startsWith('+212')) {
    return cleaned;
  }
  return str;
}

/**
 * Clean and uppercase CIN (Carte d'Identité Nationale)
 */
export function normalizeCin(cin: string | undefined): string {
  if (!cin) return '';
  return cin.toString().trim().toUpperCase().replace(/[\s\-_]/g, '');
}

/**
 * Download a styled Excel template pre-filled with the registered apartments
 * or a blank formatted template with explanatory sample rows.
 */
export function generateOwnersExcelTemplate(
  apartments: Apartment[],
  buildings: Building[],
  lang: 'ar' | 'fr' = 'ar',
  prefillCurrentData: boolean = true
) {
  const isAr = lang === 'ar';

  const headers = isAr ? [
    'رمز العمارة *',
    'رقم الشقة *',
    'اسم المالك الكامل *',
    'رقم هاتف المالك',
    'بطاقة التعريف الوطنية (CIN)',
    'البريد الإلكتروني',
    'العنوان الشخصي / الملاحظات',
    'الطابق (0, 1, 2, 3)',
    'الواجب الشهري (درهم)',
    'عدد الشهور غير المؤداة',
    'إجمالي المستحقات والديون (درهم)',
    'حالة الشقة (مأهولة/فارغة/للكراء/للبيع)',
    'اسم الساكن الحالي (إن كان مأجوراً)',
    'هاتف الساكن'
  ] : [
    'Code Bâtiment *',
    'N° Appartement *',
    'Nom Complet du Propriétaire *',
    'Téléphone Propriétaire',
    'N° CIN Propriétaire',
    'Email Propriétaire',
    'Adresse Personnelle / Notes',
    'Étage (0, 1, 2, 3)',
    'Cotisation Mensuelle (DH)',
    'Mois d\'Arriérés',
    'Total Dû / Arriérés (DH)',
    'Statut (occupé/vide/à louer/à vendre)',
    'Nom Résident Actuel',
    'Téléphone Résident'
  ];

  let rowsData: any[][] = [];

  if (prefillCurrentData && apartments.length > 0) {
    rowsData = apartments.map(apt => {
      let statusLabel = apt.status;
      if (isAr) {
        if (apt.status === 'occupied') statusLabel = 'مأهولة' as any;
        else if (apt.status === 'vacant') statusLabel = 'فارغة' as any;
        else if (apt.status === 'for_rent') statusLabel = 'للكراء' as any;
        else if (apt.status === 'for_sale') statusLabel = 'للبيع' as any;
      }
      return [
        apt.buildingCode,
        apt.number,
        apt.ownerName || '',
        apt.ownerPhone || '',
        apt.ownerCin || '',
        apt.ownerEmail || '',
        apt.notes || '',
        apt.floor ?? 0,
        apt.monthlyFee || 150,
        apt.unpaidMonthsCount || 0,
        apt.balanceDue || 0,
        statusLabel,
        apt.residentName || '',
        apt.residentPhone || ''
      ];
    });
  } else {
    // Sample rows for blank template
    rowsData = [
      ['A1', '01', 'مالك تجريبي 1', '0600000001', 'AB000001', 'owner1@example.com', 'المدينة', 0, 150, 0, 0, 'مأهولة', 'مالك تجريبي 1', '0600000001'],
      ['A1', '02', 'مالك تجريبي 2', '0600000002', 'AB000002', 'owner2@example.com', '', 0, 150, 2, 300, 'للكراء', 'مكتري تجريبي', '0600000003']
    ];
  }

  // Create worksheet
  const wsData = [headers, ...rowsData];
  const ws = XLSX.utils.aoa_to_sheet(wsData);

  // Set column widths for comfortable editing in Excel
  ws['!cols'] = [
    { wch: 16 }, // Building
    { wch: 14 }, // Apt Number
    { wch: 28 }, // Owner Name
    { wch: 20 }, // Phone
    { wch: 18 }, // CIN
    { wch: 26 }, // Email
    { wch: 32 }, // Address / Notes
    { wch: 14 }, // Floor
    { wch: 18 }, // Fee
    { wch: 22 }, // Status
    { wch: 26 }, // Resident Name
    { wch: 20 }  // Resident Phone
  ];

  // Create workbook
  const wb = XLSX.utils.book_new();
  const sheetName = isAr ? 'سجل الملاك' : 'Registre Propriétaires';
  XLSX.utils.book_append_sheet(wb, ws, sheetName);

  // Instructions sheet
  const instructionHeaders = isAr ? ['تعليمات هامة للاستيراد السليم', 'التفاصيل'] : ['Guide d\'importation', 'Détails'];
  const instructionsData = isAr ? [
    ['رمز العمارة (إجباري)', 'يجب أن يطابق رمز العمارة الموجود في النظام (مثل )'],
    ['رقم الشقة (إجباري)', 'رقم الشقة من 01 إلى 16'],
    ['اسم المالك (إجباري)', 'الاسم الكامل لمالك الشقة'],
    ['رقم الهاتف', 'يقبل جميع الصيغ: 06XXXXXXXX أو +2126XXXXXXXX'],
    ['بطاقة التعريف (CIN)', 'رقم بطاقة التعريف الوطنية مثل AB123456'],
    ['الواجب الشهري', 'مبلغ السانديك الشهري بالدرهم (الافتراضي 150 درهم)'],
    ['العنوان / الملاحظات', 'عنوان المالك الشخصي أو أي ملاحظات هامة'],
    ['مزامنة السكان', 'عند الاستيراد، يقوم النظام تلقائياً بتحديث سجل الشقق وسجل السكان معاً']
  ] : [
    ['Code Bâtiment (Requis)', 'Doit correspondre aux codes de la résidence (ex: )'],
    ['N° Appartement (Requis)', 'Numéro du lot (ex: 01 à 16)'],
    ['Nom Propriétaire (Requis)', 'Nom et prénom du copropriétaire'],
    ['Téléphone', 'Format marocain standard 06... ou international +212...'],
    ['CIN', 'N° de la Carte Nationale d\'Identité (ex: AB123456)'],
    ['Cotisation Mensuelle', 'Montant de la cotisation syndic en MAD (ex: 150)'],
    ['Adresse / Notes', 'Adresse personnelle du propriétaire ou observations'],
    ['Synchronisation', 'Met à jour automatiquement le registre des appartements et l\'annuaire des résidents']
  ];

  const wsGuide = XLSX.utils.aoa_to_sheet([instructionHeaders, ...instructionsData]);
  wsGuide['!cols'] = [{ wch: 28 }, { wch: 65 }];
  XLSX.utils.book_append_sheet(wb, wsGuide, isAr ? 'دليل الاستخدام' : 'Instructions');

  // Write file
  const dateStr = new Date().toISOString().slice(0, 10);
  const filename = prefillCurrentData 
    ? `SYNDICO_Donnees_Proprietaires_${dateStr}.xlsx`
    : `Modele_Import_Proprietaires_Al_.xlsx`;

  XLSX.writeFile(wb, filename);
}

/**
 * Parse uploaded Excel or CSV file
 */
export async function readExcelFile(file: File): Promise<{
  sheetNames: string[];
  sheetsData: Record<string, { headers: string[]; rows: any[][] }>;
}> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });

        const sheetNames = workbook.SheetNames;
        const sheetsData: Record<string, { headers: string[]; rows: any[][] }> = {};

        sheetNames.forEach(name => {
          const sheet = workbook.Sheets[name];
          const rawAoa: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });
          
          if (rawAoa && rawAoa.length > 0) {
            // Find first non-empty header row
            let headerRowIndex = 0;
            for (let i = 0; i < Math.min(rawAoa.length, 5); i++) {
              if (rawAoa[i] && rawAoa[i].some((cell: any) => cell && String(cell).trim().length > 0)) {
                headerRowIndex = i;
                break;
              }
            }

            const headers = (rawAoa[headerRowIndex] || []).map((h: any) => String(h || '').trim());
            const rows = rawAoa.slice(headerRowIndex + 1).filter(r => r && r.some((c: any) => c !== '' && c !== null && c !== undefined));
            
            sheetsData[name] = { headers, rows };
          } else {
            sheetsData[name] = { headers: [], rows: [] };
          }
        });

        resolve({ sheetNames, sheetsData });
      } catch (err) {
        reject(err);
      }
    };

    reader.onerror = (err) => reject(err);
    reader.readAsArrayBuffer(file);
  });
}

/**
 * Automatically detects column mappings from header names
 */
export function autoDetectFieldMapping(headers: string[]): ExcelImportFieldMapping {
  const mapping: ExcelImportFieldMapping = {
    buildingCode: '',
    apartmentNumber: '',
    ownerName: '',
    ownerPhone: '',
    ownerCin: '',
    ownerEmail: '',
    addressOrNotes: '',
    floor: '',
    monthlyFee: '',
    status: '',
    residentName: '',
    residentPhone: '',
    unpaidMonthsCount: '',
    balanceDue: ''
  };

  const normalizeHeader = (h: string) => h.toLowerCase().replace(/[\s\-_*()]/g, '');

  headers.forEach((header) => {
    const norm = normalizeHeader(header);
    if (!norm) return;

    // Building Code
    if (!mapping.buildingCode && (
      norm.includes('عمارة') || norm.includes('عمار') || norm.includes('مبنى') || 
      norm.includes('batiment') || norm.includes('immeuble') || norm.includes('building') || 
      norm.includes('bloc') || norm.includes('block') || norm.includes('gh')
    )) {
      mapping.buildingCode = header;
    }
    // Apartment Number
    else if (!mapping.apartmentNumber && (
      norm.includes('شقة') || norm.includes('شقه') || norm.includes('رقمشقة') ||
      norm.includes('appartement') || norm.includes('apt') || norm.includes('unit') || 
      norm.includes('logement') || (norm.includes('numero') && !norm.includes('tel') && !norm.includes('cin'))
    )) {
      mapping.apartmentNumber = header;
    }
    // Owner Name
    else if (!mapping.ownerName && (
      norm.includes('مالك') || norm.includes('اسممالك') || norm.includes('اسمالمالك') ||
      norm.includes('proprietar') || norm.includes('proprio') || norm.includes('owner') ||
      norm.includes('coproprietaire') || (norm.includes('nom') && !norm.includes('resident') && !norm.includes('locataire'))
    )) {
      mapping.ownerName = header;
    }
    // Phone
    else if (!mapping.ownerPhone && (
      norm.includes('هاتف') || norm.includes('جوال') || norm.includes('موبايل') || 
      norm.includes('telephone') || norm.includes('tel') || norm.includes('phone') || 
      norm.includes('mobile') || norm.includes('gsm')
    )) {
      mapping.ownerPhone = header;
    }
    // CIN
    else if (!mapping.ownerCin && (
      norm.includes('cin') || norm.includes('cnie') || norm.includes('بطاقة') || 
      norm.includes('هوية') || norm.includes('cartenationale')
    )) {
      mapping.ownerCin = header;
    }
    // Email
    else if (!mapping.ownerEmail && (
      norm.includes('بريد') || norm.includes('إيميل') || norm.includes('ايميل') || 
      norm.includes('email') || norm.includes('mail') || norm.includes('courriel')
    )) {
      mapping.ownerEmail = header;
    }
    // Address or Notes
    else if (!mapping.addressOrNotes && (
      norm.includes('عنوان') || norm.includes('ملاحظات') || norm.includes('ملاحظة') || 
      norm.includes('adresse') || norm.includes('address') || norm.includes('notes') || norm.includes('obs')
    )) {
      mapping.addressOrNotes = header;
    }
    // Floor
    else if (!mapping.floor && (
      norm.includes('طابق') || norm.includes('etage') || norm.includes('floor')
    )) {
      mapping.floor = header;
    }
    // Monthly Fee
    else if (!mapping.monthlyFee && (
      norm.includes('واجب') || norm.includes('مبلغ') || norm.includes('شهري') || 
      norm.includes('سانديك') || norm.includes('cotisation') || norm.includes('mensualite') || 
      norm.includes('fee') || norm.includes('montant')
    )) {
      mapping.monthlyFee = header;
    }
    // Status
    else if (!mapping.status && (
      norm.includes('حالة') || norm.includes('وضعية') || norm.includes('statut') || norm.includes('status')
    )) {
      mapping.status = header;
    }
    // Resident Name
    else if (!mapping.residentName && (
      norm.includes('ساكن') || norm.includes('مكتري') || norm.includes('مقيم') || 
      norm.includes('locataire') || norm.includes('resident')
    )) {
      mapping.residentName = header;
    }
    // Resident Phone
    else if (!mapping.residentPhone && (
      (norm.includes('هاتف') && (norm.includes('ساكن') || norm.includes('مكتري'))) ||
      (norm.includes('tel') && (norm.includes('resident') || norm.includes('locataire')))
    )) {
      mapping.residentPhone = header;
    }
    // Unpaid Months Count
    else if (!mapping.unpaidMonthsCount && (
      norm.includes('أشهر') || norm.includes('شهور') || norm.includes('تأخير') ||
      norm.includes('arriere') || norm.includes('retard') || norm.includes('impaye')
    )) {
      mapping.unpaidMonthsCount = header;
    }
    // Balance Due
    else if (!mapping.balanceDue && (
      norm.includes('مستحق') || norm.includes('دين') || norm.includes('ديون') || 
      norm.includes('solde') || norm.includes('dette') || norm.includes('totaldu')
    )) {
      mapping.balanceDue = header;
    }
  });

  return mapping;
}

/**
 * Process and validate imported rows against system apartments and buildings
 */
export function processImportData(
  headers: string[],
  rows: any[][],
  mapping: ExcelImportFieldMapping,
  existingApartments: Apartment[],
  existingBuildings: Building[]
): ImportSummary {
  const getIndex = (headerName: string) => headers.indexOf(headerName);

  const idxBuilding = getIndex(mapping.buildingCode);
  const idxApt = getIndex(mapping.apartmentNumber);
  const idxOwnerName = getIndex(mapping.ownerName);
  const idxOwnerPhone = getIndex(mapping.ownerPhone);
  const idxOwnerCin = getIndex(mapping.ownerCin);
  const idxOwnerEmail = getIndex(mapping.ownerEmail);
  const idxAddress = getIndex(mapping.addressOrNotes);
  const idxFloor = getIndex(mapping.floor);
  const idxMonthlyFee = getIndex(mapping.monthlyFee);
  const idxStatus = getIndex(mapping.status);
  const idxResidentName = getIndex(mapping.residentName);
  const idxResidentPhone = getIndex(mapping.residentPhone);
  const idxUnpaidMonths = getIndex(mapping.unpaidMonthsCount);
  const idxBalanceDue = getIndex(mapping.balanceDue);

  const parsedData: ParsedOwnerRow[] = [];
  let validRows = 0;
  let matchingApartments = 0;
  let newApartments = 0;
  let invalidRows = 0;

  rows.forEach((row, index) => {
    const rowNumber = index + 2; // considering header is row 1
    const rawBuilding = idxBuilding >= 0 ? String(row[idxBuilding] || '').trim() : '';
    const rawApt = idxApt >= 0 ? row[idxApt] : '';
    const rawOwnerName = idxOwnerName >= 0 ? String(row[idxOwnerName] || '').trim() : '';
    const rawPhone = idxOwnerPhone >= 0 ? row[idxOwnerPhone] : '';
    const rawCin = idxOwnerCin >= 0 ? String(row[idxOwnerCin] || '').trim() : '';
    const rawEmail = idxOwnerEmail >= 0 ? String(row[idxOwnerEmail] || '').trim() : '';
    const rawAddress = idxAddress >= 0 ? String(row[idxAddress] || '').trim() : '';
    const rawFloor = idxFloor >= 0 ? row[idxFloor] : undefined;
    const rawMonthlyFee = idxMonthlyFee >= 0 ? row[idxMonthlyFee] : undefined;
    const rawStatus = idxStatus >= 0 ? String(row[idxStatus] || '').trim() : '';
    const rawResidentName = idxResidentName >= 0 ? String(row[idxResidentName] || '').trim() : '';
    const rawResidentPhone = idxResidentPhone >= 0 ? row[idxResidentPhone] : '';
    const rawUnpaidMonths = idxUnpaidMonths >= 0 ? row[idxUnpaidMonths] : undefined;
    const rawBalanceDue = idxBalanceDue >= 0 ? row[idxBalanceDue] : undefined;

    // Skip empty lines
    if (!rawBuilding && !rawApt && !rawOwnerName && !rawPhone) {
      return;
    }

    const validationErrors: string[] = [];

    const buildingCode = normalizeBuildingCode(rawBuilding, existingBuildings);
    const apartmentNumber = normalizeApartmentNumber(rawApt);
    const ownerName = rawOwnerName;
    const ownerPhone = normalizePhoneNumber(rawPhone);
    const ownerCin = normalizeCin(rawCin);
    const ownerEmail = rawEmail;
    const addressOrNotes = rawAddress;
    
    // Parse floor
    let floor: number | undefined = undefined;
    if (rawFloor !== undefined && rawFloor !== '') {
      const num = parseInt(String(rawFloor).replace(/[^\d-]/g, ''), 10);
      if (!isNaN(num)) floor = num;
    }

    // Parse fee
    let monthlyFee: number | undefined = undefined;
    if (rawMonthlyFee !== undefined && rawMonthlyFee !== '') {
      const num = parseFloat(String(rawMonthlyFee).replace(/[^\d.]/g, ''));
      if (!isNaN(num)) monthlyFee = num;
    }

    // Parse unpaid months count
    let unpaidMonthsCount: number | undefined = undefined;
    if (rawUnpaidMonths !== undefined && rawUnpaidMonths !== '') {
      const num = parseInt(String(rawUnpaidMonths).replace(/[^\d-]/g, ''), 10);
      if (!isNaN(num)) unpaidMonthsCount = Math.max(0, num);
    }

    // Parse balance due
    let balanceDue: number | undefined = undefined;
    if (rawBalanceDue !== undefined && rawBalanceDue !== '') {
      const num = parseFloat(String(rawBalanceDue).replace(/[^\d.]/g, ''));
      if (!isNaN(num)) balanceDue = Math.max(0, num);
    } else if (unpaidMonthsCount !== undefined && monthlyFee !== undefined) {
      balanceDue = unpaidMonthsCount * monthlyFee;
    }

    // Parse status
    let status: ApartmentStatus | undefined = undefined;
    if (rawStatus) {
      const lower = rawStatus.toLowerCase();
      if (lower.includes('مأهول') || lower.includes('occup') || lower.includes('ساكن')) status = 'occupied';
      else if (lower.includes('فارغ') || lower.includes('vide') || lower.includes('vacant')) status = 'vacant';
      else if (lower.includes('كراء') || lower.includes('louer') || lower.includes('rent')) status = 'for_rent';
      else if (lower.includes('بيع') || lower.includes('vente') || lower.includes('sale')) status = 'for_sale';
    }

    // Validation
    if (!buildingCode) {
      validationErrors.push('رمز العمارة غير محدد أو غير صالح');
    }
    if (!apartmentNumber) {
      validationErrors.push('رقم الشقة غير محدد');
    }
    if (!ownerName) {
      validationErrors.push('اسم المالك غير محدد');
    }

    // Check if matches existing apartment
    let matchType: 'existing' | 'new' | 'invalid' = 'invalid';
    let matchedApartmentId: string | undefined = undefined;

    if (validationErrors.length === 0) {
      const cleanTargetBldg = buildingCode.replace(/[\s\-_]/g, '').toUpperCase();
      const cleanTargetApt = apartmentNumber.replace(/[^\d]/g, '');

      const matchedApt = existingApartments.find(a => 
        a.buildingCode.replace(/[\s\-_]/g, '').toUpperCase() === cleanTargetBldg &&
        (a.number.replace(/[^\d]/g, '') === cleanTargetApt || a.number.trim() === apartmentNumber.trim())
      );

      if (matchedApt) {
        matchType = 'existing';
        matchedApartmentId = matchedApt.id;
        matchingApartments++;
      } else {
        matchType = 'new';
        newApartments++;
      }
      validRows++;
    } else {
      matchType = 'invalid';
      invalidRows++;
    }

    parsedData.push({
      rowNumber,
      buildingCode,
      apartmentNumber,
      ownerName,
      ownerPhone,
      ownerCin,
      ownerEmail,
      addressOrNotes,
      floor,
      monthlyFee,
      status,
      residentName: rawResidentName || (status === 'occupied' ? ownerName : undefined),
      residentPhone: normalizePhoneNumber(rawResidentPhone) || (status === 'occupied' ? ownerPhone : undefined),
      unpaidMonthsCount,
      balanceDue,
      matchType,
      matchedApartmentId,
      validationErrors
    });
  });

  return {
    totalRows: parsedData.length,
    validRows,
    matchingApartments,
    newApartments,
    invalidRows,
    parsedData
  };
}

// ==========================================
// RESIDENTS IMPORT TYPES & UTILITIES
// ==========================================

export interface ResidentImportFieldMapping {
  fullName: string;
  type: string;
  buildingCode: string;
  apartmentNumber: string;
  phone: string;
  cin: string;
  email: string;
  vehiclePlate: string;
  familyMembersCount: string;
  entryDate: string;
}

export interface ParsedResidentRow {
  rowNumber: number;
  fullName: string;
  type: 'owner' | 'tenant';
  buildingCode: string;
  apartmentNumber: string;
  phone: string;
  email: string;
  cin?: string;
  vehiclePlate?: string;
  familyMembersCount?: number;
  entryDate?: string;
  matchType: 'existing' | 'new' | 'invalid';
  matchedResidentId?: string;
  matchedApartmentId?: string;
  validationErrors: string[];
}

export interface ResidentImportSummary {
  totalRows: number;
  validRows: number;
  newResidents: number;
  existingResidents: number;
  invalidRows: number;
  parsedData: ParsedResidentRow[];
}

/**
 * Generate and download an Excel template specifically designed for Residents (قائمة السكان)
 * Supports pre-filling all 320 apartments or generating a clean sample template.
 */
export function generateResidentsExcelTemplate(
  apartments: Apartment[],
  buildings: Building[],
  residents: Resident[],
  lang: 'ar' | 'fr' = 'ar',
  prefillCurrentData: boolean = true
) {
  const isAr = lang === 'ar';

  const headers = isAr ? [
    'الاسم الكامل للساكن *',
    'صفة الساكن (مالك / مكتري) *',
    'رمز العمارة *',
    'رقم الشقة *',
    'رقم الهاتف',
    'بطاقة التعريف الوطنية (CIN)',
    'البريد الإلكتروني',
    'رقم لوحة ترقيم السيارة',
    'عدد أفراد الأسرة',
    'تاريخ الدخول / الالتحاق (YYYY-MM-DD)'
  ] : [
    'Nom Complet du Résident *',
    'Qualité (Propriétaire / Locataire) *',
    'Code Bâtiment *',
    'N° Appartement *',
    'Téléphone',
    'N° CIN',
    'Email',
    'Matricule Véhicule',
    'Nombre de personnes dans le foyer',
    'Date d\'entrée (AAAA-MM-JJ)'
  ];

  let rowsData: any[][] = [];

  if (prefillCurrentData && apartments.length > 0) {
    // Fill with apartments and matching residents if any
    rowsData = apartments.map(apt => {
      // Find matching resident
      const cleanBldg = apt.buildingCode.replace(/[\s\-_]/g, '').toUpperCase();
      const cleanApt = apt.number.replace(/[^\d]/g, '');
      const matchedRes = residents.find(r => 
        r.buildingCode.replace(/[\s\-_]/g, '').toUpperCase() === cleanBldg &&
        (r.apartmentNumber.replace(/[^\d]/g, '') === cleanApt || r.apartmentNumber.trim() === apt.number.trim())
      );

      const fullName = matchedRes?.fullName || apt.residentName || apt.ownerName || '';
      const isTenant = matchedRes ? matchedRes.type === 'tenant' : apt.isRented;
      const typeLabel = isAr 
        ? (isTenant ? 'مكتري' : 'مالك')
        : (isTenant ? 'Locataire' : 'Propriétaire');
      const phone = matchedRes?.phone || apt.residentPhone || apt.ownerPhone || '';
      const cin = matchedRes?.cin || apt.ownerCin || '';
      const email = matchedRes?.email || apt.ownerEmail || '';
      const vehicle = matchedRes?.vehiclePlate || '';
      const familyCount = matchedRes?.familyMembersCount ?? 3;
      const entryDate = matchedRes?.entryDate || '2026-01-01';

      return [
        fullName,
        typeLabel,
        apt.buildingCode,
        apt.number,
        phone,
        cin,
        email,
        vehicle,
        familyCount,
        entryDate
      ];
    });
  } else {
    // Explanatory sample rows
    rowsData = isAr ? [
      ['مالك تجريبي 1', 'مالك', 'A1', '01', '0600000001', 'AB000001', 'owner1@example.com', '', 4, '2026-01-15'],
      ['مكتري تجريبي', 'مكتري', 'A1', '02', '0600000002', 'AB000002', 'tenant@example.com', '', 3, '2026-02-01']
    ] : [
      ['Propriétaire Test 1', 'Propriétaire', 'A1', '01', '0600000001', 'AB000001', 'owner1@example.com', '', 4, '2026-01-15'],
      ['Locataire Test', 'Locataire', 'A1', '02', '0600000002', 'AB000002', 'tenant@example.com', '', 3, '2026-02-01']
    ];
  }

  // Create worksheet
  const wsData = [headers, ...rowsData];
  const ws = XLSX.utils.aoa_to_sheet(wsData);

  ws['!cols'] = [
    { wch: 28 }, // Full Name
    { wch: 20 }, // Type
    { wch: 16 }, // Building
    { wch: 14 }, // Apt
    { wch: 20 }, // Phone
    { wch: 18 }, // CIN
    { wch: 26 }, // Email
    { wch: 20 }, // Vehicle
    { wch: 16 }, // Family
    { wch: 22 }  // Entry Date
  ];

  const wb = XLSX.utils.book_new();
  const sheetName = isAr ? 'قائمة السكان' : 'Liste Résidents';
  XLSX.utils.book_append_sheet(wb, ws, sheetName);

  // Guide sheet
  const instructionHeaders = isAr ? ['الحقل', 'الشروط والتعليمات لتسهيل الإدخال الأولي'] : ['Champ', 'Règles et instructions'];
  const instructionsData = isAr ? [
    ['الاسم الكامل *', 'الاسم الشخصي والعائلي لشاغل الشقة الحالي (إجباري)'],
    ['صفة الساكن *', 'اكتب "مالك" أو "مكتري" (أو Propriétaire / Locataire)'],
    ['رمز العمارة *', 'رمز العمارة حسب نظام الإقامة (مثال: )'],
    ['رقم الشقة *', 'رقم الشقة من 01 إلى 16'],
    ['رقم الهاتف', 'يقبل جميع الصيغ المغربية والدولية (06... / 07... / +212...)'],
    ['بطاقة التعريف (CIN)', 'رقم البطاقة الوطنية (مثال: AB123456)'],
    ['البريد الإلكتروني', 'البريد الإلكتروني للساكن للتواصل والإشعارات'],
    ['رقم لوحة السيارة', 'الترقيم الخاص بسيارة الساكن لتسهيل حراسة المرآب'],
    ['عدد أفراد الأسرة', 'عدد الأفراد القاطنين بالشقة'],
    ['تاريخ الدخول', 'تاريخ الاستقرار بالشقة بصيغة YYYY-MM-DD'],
    ['تسهيل الإدخال الأولي', 'عند استيراد هذا الملف، يتم تسجيل السكان وتحديث بطاقات الشقق ومطابقتها فوراً تلقائياً.']
  ] : [
    ['Nom Complet *', 'Nom et prénom du résident / occupant actuel (Obligatoire)'],
    ['Qualité *', 'Préciser "Propriétaire" ou "Locataire" (ou "مالك" / "مكتري")'],
    ['Code Bâtiment *', 'Format standard de la résidence (ex: )'],
    ['N° Appartement *', 'Numéro de porte (ex: 01 à 16)'],
    ['Téléphone', 'Format marocain 06... / 07... ou international +212...'],
    ['CIN', 'Numéro de la Carte Nationale d\'Identité (ex: AB123456)'],
    ['Email', 'Adresse email pour notifications et convocations'],
    ['Matricule Véhicule', 'Plaque d\'immatriculation pour le contrôle d\'accès / parking'],
    ['Membres Famille', 'Nombre de personnes vivant dans le logement'],
    ['Date d\'entrée', 'Date d\'installation au format AAAA-MM-JJ'],
    ['Initialisation', 'Met à jour instantanément le registre des résidents et les fiches appartements.']
  ];

  const wsGuide = XLSX.utils.aoa_to_sheet([instructionHeaders, ...instructionsData]);
  wsGuide['!cols'] = [{ wch: 26 }, { wch: 70 }];
  XLSX.utils.book_append_sheet(wb, wsGuide, isAr ? 'دليل الاستخدام' : 'Instructions');

  const dateStr = new Date().toISOString().slice(0, 10);
  const filename = prefillCurrentData 
    ? `SYNDICO_Liste_Residents_${dateStr}.xlsx`
    : `Modele_Import_Residents_Al_.xlsx`;

  XLSX.writeFile(wb, filename);
}

/**
 * Automatically detect resident field mapping from column headers
 */
export function autoDetectResidentFieldMapping(headers: string[]): ResidentImportFieldMapping {
  const mapping: ResidentImportFieldMapping = {
    fullName: '',
    type: '',
    buildingCode: '',
    apartmentNumber: '',
    phone: '',
    cin: '',
    email: '',
    vehiclePlate: '',
    familyMembersCount: '',
    entryDate: ''
  };

  const normalizeHeader = (h: string) => h.toLowerCase().replace(/[\s\-_*()]/g, '');

  headers.forEach((header) => {
    const norm = normalizeHeader(header);
    if (!norm) return;

    // Full Name
    if (!mapping.fullName && (
      norm.includes('اسمالساكن') || norm.includes('اسمكامل') || norm.includes('الاسمكامل') ||
      norm.includes('الاسموالنسب') || norm.includes('الاسم') || norm.includes('nomresident') ||
      norm.includes('nomcomplet') || norm.includes('occupant') || (norm.includes('resident') && !norm.includes('type')) ||
      (norm.includes('nom') && !norm.includes('batiment') && !norm.includes('immeuble'))
    )) {
      mapping.fullName = header;
    }
    // Resident Type (مالك / مكتري)
    else if (!mapping.type && (
      norm.includes('صفة') || norm.includes('النوع') || norm.includes('وضعية') ||
      norm.includes('صفةالساكن') || norm.includes('qualite') || norm.includes('type') ||
      norm.includes('statut') || norm.includes('nature') || norm.includes('propriooulocataire')
    )) {
      mapping.type = header;
    }
    // Building Code
    else if (!mapping.buildingCode && (
      norm.includes('عمارة') || norm.includes('عمار') || norm.includes('مبنى') || 
      norm.includes('batiment') || norm.includes('immeuble') || norm.includes('building') || 
      norm.includes('bloc') || norm.includes('gh')
    )) {
      mapping.buildingCode = header;
    }
    // Apartment Number
    else if (!mapping.apartmentNumber && (
      norm.includes('شقة') || norm.includes('شقه') || norm.includes('رقمشقة') ||
      norm.includes('appartement') || norm.includes('apt') || norm.includes('unit') || 
      norm.includes('logement') || (norm.includes('numero') && !norm.includes('tel') && !norm.includes('cin'))
    )) {
      mapping.apartmentNumber = header;
    }
    // Phone
    else if (!mapping.phone && (
      norm.includes('هاتف') || norm.includes('جوال') || norm.includes('موبايل') || 
      norm.includes('telephone') || norm.includes('tel') || norm.includes('phone') || 
      norm.includes('mobile') || norm.includes('gsm')
    )) {
      mapping.phone = header;
    }
    // CIN
    else if (!mapping.cin && (
      norm.includes('cin') || norm.includes('cnie') || norm.includes('بطاقة') || 
      norm.includes('هوية') || norm.includes('cartenationale')
    )) {
      mapping.cin = header;
    }
    // Email
    else if (!mapping.email && (
      norm.includes('بريد') || norm.includes('إيميل') || norm.includes('ايميل') || 
      norm.includes('email') || norm.includes('mail') || norm.includes('courriel')
    )) {
      mapping.email = header;
    }
    // Vehicle Plate
    else if (!mapping.vehiclePlate && (
      norm.includes('سيارة') || norm.includes('ترقيم') || norm.includes('لوحة') ||
      norm.includes('matricule') || norm.includes('plaque') || norm.includes('vehicule') ||
      norm.includes('voiture') || norm.includes('immatriculation')
    )) {
      mapping.vehiclePlate = header;
    }
    // Family Members Count
    else if (!mapping.familyMembersCount && (
      norm.includes('أفراد') || norm.includes('افراد') || norm.includes('أسرة') || norm.includes('اسرة') ||
      norm.includes('عائلة') || norm.includes('foyer') || norm.includes('famille') ||
      norm.includes('personnes') || norm.includes('membres')
    )) {
      mapping.familyMembersCount = header;
    }
    // Entry Date
    else if (!mapping.entryDate && (
      norm.includes('دخول') || norm.includes('التحاق') || norm.includes('سكن') ||
      norm.includes('dateentree') || norm.includes('entree') || norm.includes('arrivee') ||
      norm.includes('date')
    )) {
      mapping.entryDate = header;
    }
  });

  return mapping;
}

/**
 * Process and validate uploaded rows for Resident list importation
 */
export function processResidentImportData(
  headers: string[],
  rows: any[][],
  mapping: ResidentImportFieldMapping,
  existingResidents: Resident[],
  existingApartments: Apartment[],
  existingBuildings: Building[]
): ResidentImportSummary {
  const getIndex = (headerName: string) => headers.indexOf(headerName);

  const idxFullName = getIndex(mapping.fullName);
  const idxType = getIndex(mapping.type);
  const idxBuilding = getIndex(mapping.buildingCode);
  const idxApt = getIndex(mapping.apartmentNumber);
  const idxPhone = getIndex(mapping.phone);
  const idxCin = getIndex(mapping.cin);
  const idxEmail = getIndex(mapping.email);
  const idxVehicle = getIndex(mapping.vehiclePlate);
  const idxFamily = getIndex(mapping.familyMembersCount);
  const idxEntryDate = getIndex(mapping.entryDate);

  const parsedData: ParsedResidentRow[] = [];
  let validRows = 0;
  let newResidents = 0;
  let existingResidentsCount = 0;
  let invalidRows = 0;

  rows.forEach((row, index) => {
    const rowNumber = index + 2; // header is row 1
    const rawFullName = idxFullName >= 0 ? String(row[idxFullName] || '').trim() : '';
    const rawType = idxType >= 0 ? String(row[idxType] || '').trim() : '';
    const rawBuilding = idxBuilding >= 0 ? String(row[idxBuilding] || '').trim() : '';
    const rawApt = idxApt >= 0 ? row[idxApt] : '';
    const rawPhone = idxPhone >= 0 ? row[idxPhone] : '';
    const rawCin = idxCin >= 0 ? String(row[idxCin] || '').trim() : '';
    const rawEmail = idxEmail >= 0 ? String(row[idxEmail] || '').trim() : '';
    const rawVehicle = idxVehicle >= 0 ? String(row[idxVehicle] || '').trim() : '';
    const rawFamily = idxFamily >= 0 ? row[idxFamily] : undefined;
    const rawEntryDate = idxEntryDate >= 0 ? String(row[idxEntryDate] || '').trim() : '';

    // Skip empty lines
    if (!rawFullName && !rawBuilding && !rawApt && !rawPhone) {
      return;
    }

    const validationErrors: string[] = [];

    const fullName = rawFullName;
    const buildingCode = normalizeBuildingCode(rawBuilding, existingBuildings);
    const apartmentNumber = normalizeApartmentNumber(rawApt);
    const phone = normalizePhoneNumber(rawPhone);
    const cin = normalizeCin(rawCin);
    const email = rawEmail;
    const vehiclePlate = rawVehicle;

    // Detect type: owner or tenant
    let type: 'owner' | 'tenant' = 'owner';
    if (rawType) {
      const lower = rawType.toLowerCase();
      if (lower.includes('مكتري') || lower.includes('كراء') || lower.includes('locataire') || lower.includes('tenant') || lower.includes('rent')) {
        type = 'tenant';
      } else {
        type = 'owner';
      }
    }

    // Family count
    let familyMembersCount: number = 3;
    if (rawFamily !== undefined && rawFamily !== '') {
      const num = parseInt(String(rawFamily).replace(/[^\d]/g, ''), 10);
      if (!isNaN(num) && num > 0) familyMembersCount = num;
    }

    // Entry date
    let entryDate = rawEntryDate;
    if (!entryDate || !entryDate.match(/^\d{4}-\d{2}-\d{2}$/)) {
      entryDate = new Date().toISOString().slice(0, 10);
    }

    // Validations
    if (!fullName) {
      validationErrors.push('الاسم الكامل للساكن غير محدد');
    }
    if (!buildingCode) {
      validationErrors.push('رمز العمارة غير محدد أو غير صالح');
    }
    if (!apartmentNumber) {
      validationErrors.push('رقم الشقة غير محدد');
    }

    // Matching
    let matchType: 'existing' | 'new' | 'invalid' = 'invalid';
    let matchedResidentId: string | undefined = undefined;
    let matchedApartmentId: string | undefined = undefined;

    if (validationErrors.length === 0) {
      const cleanBldg = buildingCode.replace(/[\s\-_]/g, '').toUpperCase();
      const cleanApt = apartmentNumber.replace(/[^\d]/g, '');

      // Check matching resident
      const foundRes = existingResidents.find(r => 
        r.buildingCode.replace(/[\s\-_]/g, '').toUpperCase() === cleanBldg &&
        (r.apartmentNumber.replace(/[^\d]/g, '') === cleanApt || r.apartmentNumber.trim() === apartmentNumber.trim())
      );

      // Check matching apartment
      const foundApt = existingApartments.find(a =>
        a.buildingCode.replace(/[\s\-_]/g, '').toUpperCase() === cleanBldg &&
        (a.number.replace(/[^\d]/g, '') === cleanApt || a.number.trim() === apartmentNumber.trim())
      );

      if (foundApt) {
        matchedApartmentId = foundApt.id;
      }

      if (foundRes) {
        matchType = 'existing';
        matchedResidentId = foundRes.id;
        existingResidentsCount++;
      } else {
        matchType = 'new';
        newResidents++;
      }
      validRows++;
    } else {
      matchType = 'invalid';
      invalidRows++;
    }

    parsedData.push({
      rowNumber,
      fullName,
      type,
      buildingCode,
      apartmentNumber,
      phone,
      email,
      cin,
      vehiclePlate,
      familyMembersCount,
      entryDate,
      matchType,
      matchedResidentId,
      matchedApartmentId,
      validationErrors
    });
  });

  return {
    totalRows: parsedData.length,
    validRows,
    newResidents,
    existingResidents: existingResidentsCount,
    invalidRows,
    parsedData
  };
}
