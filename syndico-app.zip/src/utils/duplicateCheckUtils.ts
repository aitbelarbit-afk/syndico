import { Payment, Expense } from '../types';

/**
 * Normalizes building code for robust comparison (e.g. "gh 38 b" -> "")
 */
export function normalizeBuilding(code?: string): string {
  return (code || '').trim().toUpperCase().replace(/\s+/g, ' ');
}

/**
 * Normalizes apartment number (e.g. "3" -> "03", " 03 " -> "03")
 */
export function normalizeApartment(num?: string | number): string {
  const str = String(num || '').trim();
  if (!str) return '';
  // If it is numeric, pad with leading zero
  const numeric = parseInt(str, 10);
  if (!isNaN(numeric) && numeric >= 1 && numeric <= 99) {
    return String(numeric).padStart(2, '0');
  }
  return str.padStart(2, '0');
}

/**
 * Normalizes month period string (e.g., "2026-08", "أغسطس 2026", etc.)
 */
export function normalizeMonthPeriod(period?: string): string {
  if (!period) return '';
  const trimmed = period.trim();
  // If format YYYY-MM
  const yyyyMmMatch = trimmed.match(/^(\d{4})-(\d{1,2})$/);
  if (yyyyMmMatch) {
    const y = yyyyMmMatch[1];
    const m = String(parseInt(yyyyMmMatch[2], 10)).padStart(2, '0');
    return `${y}-${m}`;
  }
  return trimmed;
}

export interface DuplicatePaymentCheckResult {
  isDuplicate: boolean;
  existingPayment?: Payment;
  messageAr: string;
  messageFr: string;
}

/**
 * Checks if a payment already exists for the same building, apartment, and month period.
 */
export function checkDuplicatePayment(
  existingPayments: Payment[],
  candidate: {
    buildingCode: string;
    apartmentNumber: string;
    periodMonth: string;
    residentName?: string;
    amount?: number;
    excludeId?: string;
  }
): DuplicatePaymentCheckResult {
  const candBld = normalizeBuilding(candidate.buildingCode);
  const candApt = normalizeApartment(candidate.apartmentNumber);
  const candMonth = normalizeMonthPeriod(candidate.periodMonth);

  if (!candBld || !candApt || !candMonth) {
    return {
      isDuplicate: false,
      messageAr: '',
      messageFr: ''
    };
  }

  const match = existingPayments.find(p => {
    if (candidate.excludeId && p.id === candidate.excludeId) return false;
    const pBld = normalizeBuilding(p.buildingCode);
    const pApt = normalizeApartment(p.apartmentNumber);
    const pMonth = normalizeMonthPeriod(p.periodMonth);

    return pBld === candBld && pApt === candApt && pMonth === candMonth;
  });

  if (match) {
    return {
      isDuplicate: true,
      existingPayment: match,
      messageAr: `تنبيه: تم تسجيل أداء مسبقاً للعمارة ${match.buildingCode}، الشقة ${match.apartmentNumber} عن شهر (${match.periodMonth}) بمبلغ ${match.amount} درهم، وصل رقم (${match.receiptNumber || match.id}) بتاريخ ${match.paymentDate}.`,
      messageFr: `Attention: Un paiement a déjà été enregistré pour ${match.buildingCode} Apt ${match.apartmentNumber} pour le mois (${match.periodMonth}) d'un montant de ${match.amount} DH (Reçu ${match.receiptNumber || match.id}) le ${match.paymentDate}.`
    };
  }

  return {
    isDuplicate: false,
    messageAr: '',
    messageFr: ''
  };
}

export interface DuplicateExpenseCheckResult {
  isDuplicate: boolean;
  existingExpense?: Expense;
  messageAr: string;
  messageFr: string;
}

/**
 * Checks if an expense might be a duplicate based on invoice reference or same category, month, and title/supplier.
 */
export function checkDuplicateExpense(
  existingExpenses: Expense[],
  candidate: {
    title: string;
    category?: string;
    amount: number;
    date: string;
    supplier?: string;
    invoiceRef?: string;
    excludeId?: string;
  }
): DuplicateExpenseCheckResult {
  const candTitle = (candidate.title || '').trim().toLowerCase();
  const candInvoice = (candidate.invoiceRef || '').trim().toLowerCase();
  const candSupplier = (candidate.supplier || '').trim().toLowerCase();
  const candDate = (candidate.date || '').slice(0, 7); // YYYY-MM
  const candAmount = Number(candidate.amount) || 0;

  if (!candTitle && !candInvoice) {
    return { isDuplicate: false, messageAr: '', messageFr: '' };
  }

  // 1. Direct match on invoiceRef if provided and not generic
  if (candInvoice && candInvoice.length >= 3) {
    const invoiceMatch = existingExpenses.find(e => {
      if (candidate.excludeId && e.id === candidate.excludeId) return false;
      const eInvoice = (e.invoiceRef || '').trim().toLowerCase();
      return eInvoice === candInvoice;
    });

    if (invoiceMatch) {
      return {
        isDuplicate: true,
        existingExpense: invoiceMatch,
        messageAr: `تنبيه: يوجد مصروف مسجل مسبقاً بنفس رقم الفاتورة (${invoiceMatch.invoiceRef}) بعنوان "${invoiceMatch.title}" بمبلغ ${invoiceMatch.amount} درهم بتاريخ ${invoiceMatch.date}.`,
        messageFr: `Attention: Une dépense existe déjà avec le même numéro de facture (${invoiceMatch.invoiceRef}) : "${invoiceMatch.title}" (${invoiceMatch.amount} DH le ${invoiceMatch.date}).`
      };
    }
  }

  // 2. Match in the same month with same category, title and similar amount
  const similarMatch = existingExpenses.find(e => {
    if (candidate.excludeId && e.id === candidate.excludeId) return false;
    const eDateMonth = (e.date || '').slice(0, 7);
    if (candDate && eDateMonth && candDate !== eDateMonth) return false;

    const eTitle = (e.title || '').trim().toLowerCase();
    const eSupplier = (e.supplier || '').trim().toLowerCase();
    const eCategory = e.category || '';
    const eAmount = Number(e.amount) || 0;

    // Same category and exact same title
    const sameTitleAndCat = candidate.category && eCategory === candidate.category && eTitle === candTitle;
    
    // Same supplier and exact same amount in the same month
    const sameSupplierAndAmount = candSupplier && eSupplier && eSupplier === candSupplier && Math.abs(eAmount - candAmount) < 0.01;

    // Exact title and exact amount in same month
    const sameTitleAndAmount = eTitle === candTitle && Math.abs(eAmount - candAmount) < 0.01;

    return sameTitleAndCat || sameSupplierAndAmount || sameTitleAndAmount;
  });

  if (similarMatch) {
    return {
      isDuplicate: true,
      existingExpense: similarMatch,
      messageAr: `تنبيه: يوجد مصروف مشابه مسجل مسبقاً في نفس الشهر (${similarMatch.date}) بعنوان "${similarMatch.title}" من المورد (${similarMatch.supplier}) بمبلغ ${similarMatch.amount} درهم.`,
      messageFr: `Attention: Une dépense similaire existe déjà pour le même mois (${similarMatch.date}) : "${similarMatch.title}" fournisseur (${similarMatch.supplier}) pour ${similarMatch.amount} DH.`
    };
  }

  return {
    isDuplicate: false,
    messageAr: '',
    messageFr: ''
  };
}
