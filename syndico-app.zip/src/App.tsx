import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { LoginScreen } from './components/LoginScreen';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { BuildingsView } from './components/BuildingsView';
import { ApartmentsView } from './components/ApartmentsView';
import { ResidentsView } from './components/ResidentsView';
import { EmployeesView } from './components/EmployeesView';
import { MaintenanceView } from './components/MaintenanceView';
import { PaymentsView } from './components/PaymentsView';
import { ExpensesView } from './components/ExpensesView';
import { NoticesView } from './components/NoticesView';
import { UsersView } from './components/UsersView';
import { ArchiveView } from './components/ArchiveView';
import { FinancialControlView } from './components/FinancialControlView';
import { SyndicOfficeView } from './components/SyndicOfficeView';
import { BudgetSimulatorView } from './components/BudgetSimulatorView';
import { ManualFinancialEntryView } from './components/ManualFinancialEntryView';
import { LedgerEntryView } from './components/LedgerEntryView';
import { MonthlyBreakdownSheetView } from './components/MonthlyBreakdownSheetView';
import { TwoYearsFinancialReportView } from './components/TwoYearsFinancialReportView';
import { ServicesOperationsView } from './components/ServicesOperationsView';
import { ReceiptModal } from './components/ReceiptModal';
import { NoticeModal } from './components/NoticeModal';
import { BackupModal } from './components/BackupModal';
import { ResidenceProfileModal } from './components/ResidenceProfileModal';
import { hasResidenceProfile } from './config/residence';
import { ActivityLogDrawer } from './components/ActivityLogDrawer';
import { AutoLogoutGuard } from './components/AutoLogoutGuard';
import { MobileFloatingNav } from './components/MobileFloatingNav';
import { motion, AnimatePresence } from 'motion/react';

const MainLayout: React.FC = () => {
  const { currentUser, activeSection, isActivityDrawerOpen, closeActivityLog } = useApp();
  const [isBackupOpen, setIsBackupOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState<boolean>(() => currentUser?.role === 'syndic' && !hasResidenceProfile());
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  if (!currentUser) {
    return <LoginScreen />;
  }

  const renderActiveSection = () => {
    switch (activeSection) {
      case 'dashboard':
        return <DashboardView />;
      case 'financial-control':
      case 'control':
        return <FinancialControlView />;
      case 'buildings':
        return <BuildingsView />;
      case 'apartments':
        return <ApartmentsView />;
      case 'residents':
        return <ResidentsView />;
      case 'employees':
      case 'pointage':
        return <EmployeesView />;
      case 'maintenance':
        return <MaintenanceView />;
      case 'payments':
        return <PaymentsView />;
      case 'expenses':
        return <ExpensesView />;
      case 'budget-simulator':
      case 'budget':
      case 'simulator':
        return <BudgetSimulatorView />;
      case 'ledger':
      case 'income-expenses':
        return <LedgerEntryView />;
      case 'manual-financial':
      case 'manual-entry':
      case 'financial-report':
        return <ManualFinancialEntryView />;
      case 'monthly-sheet':
      case 'monthly-breakdown':
      case 'financial-sheet':
        return <MonthlyBreakdownSheetView />;
      case 'two-years-report':
      case 'bilan-2ans':
      case 'report-2025-2026':
        return <TwoYearsFinancialReportView />;
      case 'operations':
      case 'services':
        return <ServicesOperationsView />;
      case 'maintenance':
        return <ServicesOperationsView initialTab="maintenance" />;
      case 'notices':
        return <ServicesOperationsView initialTab="notices" />;
      case 'employees':
      case 'pointage':
        return <ServicesOperationsView initialTab="employees" />;
      case 'archive':
        return <ServicesOperationsView initialTab="archive" />;
      case 'users':
        return <UsersView />;
      case 'syndic-office':
      case 'syndic':
      case 'ai-syndic':
        if (currentUser.role === 'resident') {
          return <DashboardView />;
        }
        return <SyndicOfficeView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans relative selection:bg-[#9a3412] selection:text-white">
      {/* Light Clean Subtle Background & Dots */}
      <div className="fixed inset-0 pointer-events-none app-bg -z-20" />
      <div className="fixed inset-0 pointer-events-none overflow-hidden -z-20 no-print" aria-hidden="true">
        <div className="aurora-blob aurora-a w-[34rem] h-[34rem] -top-40 -end-40 bg-emerald-300/30" />
        <div className="aurora-blob aurora-b w-[30rem] h-[30rem] -bottom-40 -start-32 bg-amber-300/25" />
      </div>
      <div className="fixed inset-0 pointer-events-none app-dots opacity-40 -z-10" />

      <Navbar 
        onToggleMobileSidebar={() => setIsMobileSidebarOpen(prev => !prev)} 
        isMobileSidebarOpen={isMobileSidebarOpen}
      />

      <div className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-6 lg:p-8 flex flex-col lg:flex-row gap-6 items-start">
        {/* Responsive Sidebar */}
        <Sidebar 
          isOpenMobile={isMobileSidebarOpen}
          onCloseMobile={() => setIsMobileSidebarOpen(false)}
          onOpenBackup={() => setIsBackupOpen(true)} 
          onOpenProfile={() => setIsProfileOpen(true)}
        />

        {/* Dynamic Content Body with Smooth Spring Page Transitions */}
        <main className="flex-1 w-full min-w-0 transition-all pb-16 lg:pb-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeSection}
              className="stagger-children"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
            >
              {renderActiveSection()}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Floating Bottom Navigation for Mobile (Like the video 00:40) */}
      <MobileFloatingNav 
        onOpenMenu={() => setIsMobileSidebarOpen(prev => !prev)} 
        isMenuOpen={isMobileSidebarOpen} 
      />

      {/* Global Modals & Utilities */}
      <AutoLogoutGuard />
      <ReceiptModal />
      <NoticeModal />
      <ResidenceProfileModal
        isOpen={isProfileOpen}
        firstRun={!hasResidenceProfile()}
        onClose={() => setIsProfileOpen(false)}
      />
      <BackupModal 
        isOpen={isBackupOpen} 
        onClose={() => setIsBackupOpen(false)} 
      />
      <ActivityLogDrawer 
        isOpen={isActivityDrawerOpen} 
        onClose={closeActivityLog} 
      />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
