import { Expense, Payment } from '../types';

// Aucune donnée financière n'est générée automatiquement.
export const MONTHS_FROM_MAY_2026: any[] = [];

export function generateMonthlySurplusExpenses(): Expense[] {
  return [];
}

export function generateMonthlySurplusPayments(): Payment[] {
  return [];
}

export function ensurePositiveSurplusForAllMonths(
  existingPayments: Payment[] = [],
  existingExpenses: Expense[] = []
): { payments: Payment[]; expenses: Expense[]; seeded: boolean } {
  return { payments: existingPayments, expenses: existingExpenses, seeded: false };
}
