import { Apartment, Resident } from '../types';

export const OLD_MOCK_NAMES_SET = new Set<string>();

// Détecte uniquement des jetons de test évidents.
export function isOldMockResidentName(name: string | null | undefined): boolean {
  if (!name) return false;
  const n = name.trim().toLowerCase();
  return n.includes('تجريبي') || n.includes('test_owner') || n.includes('dummy_mock');
}

interface ResidentInfo {
  fullName: string;
  phone: string;
  cin: string;
  email: string;
  isRented: boolean;
  residentName: string;
  residentPhone: string;
}

// Aucune identité n'est inventée : les informations proviennent uniquement de ce que vous saisissez.
export function getMoroccanApartmentData(_buildingCode: string, _aptNum: string): ResidentInfo {
  return { fullName: '', phone: '', cin: '', email: '', isRented: false, residentName: '', residentPhone: '' };
}

export function generateMoroccanApartments(_buildings?: { code: string; id?: string }[]): Apartment[] {
  return [];
}

export function generateMoroccanResidents(_buildings?: { code: string }[]): Resident[] {
  return [];
}

// Détecte les noms génériques ("مالك شقة 03", "Propriétaire Appt 3"...)
export function isGenericPlaceholderName(name: string | null | undefined): boolean {
  if (!name) return true;
  const n = name.trim().toLowerCase();
  if (n.length < 2) return true;
  const exactPlaceholders = [
    'مالك', 'المالك', 'ساكن', 'الساكن', 'مكتري', 'المكتري', 'صاحب الشقة',
    'غير مسجل', 'غير محدد', 'بدون اسم', '-', '--', '---',
    'proprietaire', 'propriétaire', 'resident', 'résident', 'locataire',
    'non renseigne', 'non renseigné', 'inconnu', 'a definir', 'à définir'
  ];
  if (exactPlaceholders.includes(n)) return true;
  if (/^(?:مالك|المالك|ساكن|الساكن|مكتري)\s+(?:شقة|الشقة|رقم|عمارة)?\s*\d+$/i.test(n)) return true;
  if (/^(?:propri[eé]taire|r[eé]sident|locataire)\s+(?:appt|appartement|n°|no)?\s*\d+$/i.test(n)) return true;
  return false;
}
