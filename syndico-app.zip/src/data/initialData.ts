import { Building, Apartment, Resident, Employee, MaintenanceTicket, Payment, Expense, Visitor, Notice, User, PeriodicMaintenance, ManualMonthlyRecord } from '../types';

// Syndico — données de départ VIDES.
// Chaque résidence saisit ses propres bâtiments, appartements, résidents, employés et dépenses.
export const initialBuildings: Building[] = [];
export const initialApartments: Apartment[] = [];
export const initialResidents: Resident[] = [];
export const initialEmployees: Employee[] = [];
export const initialMaintenanceTickets: MaintenanceTicket[] = [];
export const initialPayments: Payment[] = [];
export const initialExpenses: Expense[] = [];
export const initialVisitors: Visitor[] = [];
export const initialNotices: Notice[] = [];

// Compte administrateur initial : à modifier dès la première connexion (menu Utilisateurs).
export const initialUsers: User[] = [
  {
    id: 'u-1',
    username: 'syndic',
    name: 'مدير النظام / Administrateur',
    role: 'syndic',
    password: 'admin@2026',
    phone: '',
    email: ''
  }
];

export const initialPeriodicMaintenances: PeriodicMaintenance[] = [];
export const initialDailyChecklistItems: any[] = [];
export const initialDailyMaintenanceLogs: any[] = [];
export const initialManualMonthlyRecords: ManualMonthlyRecord[] = [];
