import { AssemblyResolution } from '../types';

// Aucune résolution pré-remplie : chaque syndicat crée ses propres résolutions d'assemblée générale.
export const initialAssemblyResolutions: AssemblyResolution[] = [];
