-- ====================================================================
-- 1. جدول مزامنة البيانات الشاملة (للحفظ الشامل ككائن JSON)
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.residence_sync (
  id text PRIMARY KEY,
  data jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- ====================================================================
-- 2. جدول الطلبات / Orders (استُخدم في بعض أجزاء التطبيق)
-- ====================================================================
CREATE TABLE IF NOT EXISTS public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text,
  email text,
  details text,
  created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- ====================================================================
-- 3. إعدادات الأمان وسياسات الوصول (ROW LEVEL SECURITY - RLS)
-- ====================================================================
-- تفعيل RLS على الجداول
ALTER TABLE public.residence_sync ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- حذف السياسات السابقة إن وجدت لتفادي التكرار
DROP POLICY IF EXISTS "Allow public access on residence_sync" ON public.residence_sync;
DROP POLICY IF EXISTS "Allow public access on orders" ON public.orders;

-- إنشاء سياسات الوصول (تتيح الصلاحية الكاملة لتطبيق Netlify/الواجهة الأمامية)
CREATE POLICY "Allow public access on residence_sync" 
ON public.residence_sync FOR ALL TO anon, authenticated 
USING (true) WITH CHECK (true);

CREATE POLICY "Allow public access on orders" 
ON public.orders FOR ALL TO anon, authenticated 
USING (true) WITH CHECK (true);

-- ====================================================================
-- 4. تفعيل المزامنة الفورية (REALTIME REPLICATION)
-- ====================================================================
DO $$
BEGIN
  EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.residence_sync';
EXCEPTION WHEN OTHERS THEN
  NULL;
END $$;

DO $$
BEGIN
  EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.orders';
EXCEPTION WHEN OTHERS THEN
  NULL;
END $$;
