# Syndico — سنديكو

Plateforme de gestion de copropriété / تدبير الإقامات والسانديك (Maroc).
Application React + Vite, bilingue arabe / français, fonctionne hors-ligne (données sur l'appareil) et peut se synchroniser avec une base **Supabase** à vous.

## Démarrage rapide
```bash
npm install
npm run dev        # développement
npm run build      # production (dossier dist/)
```
Déploiement statique : Netlify / Vercel (`netlify.toml` et `vercel.json` fournis).

## Première utilisation
1. Connectez-vous au **Portail Syndic** avec le compte initial : identifiant `syndic` / mot de passe provisoire `admin@2026`.
2. Renseignez le **Profil de la résidence** (nom, ville, adresse, banque, clé de récupération). Il s'affiche automatiquement au premier lancement.
3. **Changez immédiatement le mot de passe** (menu Utilisateurs ou « Changer le mot de passe »).
4. Ajoutez vos **immeubles**, puis vos **appartements et propriétaires** (saisie ou import Excel).

L'application ne contient **aucune donnée** de résidence : tout est vide au départ.

## Base de données cloud (facultatif)
1. Créez un projet gratuit sur https://supabase.com.
2. Exécutez `supabase_schema.sql` dans l'éditeur SQL.
3. Renseignez `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY` (voir `.env.example`) ou saisissez-les dans l'application (Sauvegarde → liaison Supabase).

> ⚠️ Le script SQL fourni autorise l'accès public à la table (`anon`). Pour un usage commercial, **activez l'authentification Supabase et restreignez les politiques RLS** avant de stocker des données réelles de résidents.

## Assistant IA (facultatif)
Définissez `GEMINI_API_KEY` côté serveur (voir `.env.example`).
